<?php
#########################
##    Arabic
#########################

$lang['alumni_list']		= "قائمة الخريجين";
$lang['registration']		= "تسجيل خريج";
$lang['login']		= "تسجيل الدخول";



/* End of file form_validation_lang.php */
/* Location: ./system/language/english/form_validation_lang.php */
