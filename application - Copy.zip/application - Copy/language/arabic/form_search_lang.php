<?php
#########################
##    Arabic
#########################

$lang['graduation_year']		= "سنة التخرج";
$lang['graduation_faculty']		= "الكلية";
$lang['after_year']		= "بعد سنة التخرج";
$lang['at_year']      = "في سنة التخرج" ;
$lang['before_year']  = "قبل سنة التخرج";
$lang['show_results']  = "اظهار النتائج";
$lang['alumni']  = "قائمة ابخريجين";

$lang['error_discussion_request']		= "كلمات الطلب";

$lang['first_letters_from_name']		= "اول حروف من الاسم";

$lang['error_discussion_request']		= "كلمات الطلب";

$lang['error_insert_year']		= "السنة";
$lang['error_insert_title']		= "عنوان البحث";
$lang['error_insert_metakey']		= "الكلمات المفتاحية";
$lang['error_insert_authors']		= "المؤالفين";
#####################
#####################
#####            ####
#####  HOME PAGE ####
#####            ####
#####################
#####################
$lang['name'] = 'الاسم';
$lang['faculty'] = 'الكلبة';
$lang['scientific_degree'] = 'الدرجة العلمية';
$lang['graduation_year'] = 'سنة التخرج';

/* End of file form_validation_lang.php */
/* Location: ./system/language/english/form_validation_lang.php */
