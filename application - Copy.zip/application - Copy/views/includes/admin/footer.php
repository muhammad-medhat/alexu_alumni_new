	<script type="text/javascript" >
		//$('input').click(function(){
		//	$(this).select();	
		//});
	</script>
<hr />
  <div id="copyright">
    <?= $this->lang->line('copyright')?>
  </div>
</body>
</html>



