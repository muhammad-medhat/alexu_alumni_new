<div id='lang' class='lang'>
  <ul>
    <li>
      <a href='<?php echo site_url( "langswitch/switchLanguage/english")?>' >
        <img src='<?php echo base_url() ."images/m/en.gif"?>' />
      </a>
    </li>
    
    <li>
      <a href='<?php echo site_url( "langswitch/switchLanguage/arabic")?>'  >
        <img src='<?php echo base_url() ."images/m/ar.gif"?>' />
      </a>
    </li>
</div>
