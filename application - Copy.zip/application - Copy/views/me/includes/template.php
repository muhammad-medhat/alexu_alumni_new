<?php $this->load->view('me/includes/header'); ?>

<div id="main_content">
<?php $this->load->view($main_content); ?>
</div>


<?php $this->load->view('me/includes/footer'); ?>
