  <div id="copyright">
<p><span>روابط ذات صلة</span></p>
<div class='links'>
<?php
// echo "<ul>";
// 
//   echo '<li>';
//     echo anchor(alexu_url .'/هيئة-التدريس/staffclub',                'نادى أعضاء هيئة التدريس'              ,'target="_blank"');
//   echo '</li>';
//   echo '<li>';
//     echo anchor(alexu_url .'/هيئة-التدريس/2011-11-24-07-04-43',      'مركز تنمية قدرات اعضاء هيئة التدريس'  ,'target="_blank"');
//   echo '</li>';
// echo "</ul>";
// echo "<ul>";
//   echo '<li>';
//     echo anchor(alexu_url .'/هيئة-التدريس/الحاصلين-على-جوائز',       'الحاصلين على جوائز'                   ,'target="_blank"');
//   echo '</li>';
//   echo "<li>";
//     echo anchor(alexu_url .'/هيئة-التدريس/الرعاية-الصحية',           'الرعاية الصحية'                       ,'target="_blank"');
//   echo '</li>';
//   echo "<li>";
//     echo anchor(alexu_url .'/هيئة-التدريس/2011-09-22-07-11-08',      'خدمات هيئة التدريس'                   ,'target="_blank"');
//   echo '</li>';
// echo "</ul>";    
?>
</div>
  </div>
</body>
</html>
