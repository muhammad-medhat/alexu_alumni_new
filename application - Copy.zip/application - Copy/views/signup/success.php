
<div class='success'>
  <h2><?php echo $this->lang->line('registration_success_head')?></h2>
<p><?php echo $this->lang->line('registration_success_message')?></p>
</div>
