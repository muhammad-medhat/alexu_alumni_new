<?php

        $ci =& get_instance();


    $config['full_tag_open']  = "<div class='paging'>";
    $config['full_tag_close'] = "</div>";

    $config['first_link'] = $ci->lang->line('first_link');
    $config['last_link']  = $ci->lang->line('last_link');
    $config['next_link']  = $ci->lang->line('next_link');
    $config['prev_link']  = $ci->lang->line('prev_link');

