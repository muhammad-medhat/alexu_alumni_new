<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-25 00:01:10 --> Config Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:01:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:01:10 --> URI Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Router Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Output Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Security Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Input Class Initialized
DEBUG - 2016-09-25 00:01:10 --> XSS Filtering completed
DEBUG - 2016-09-25 00:01:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:01:10 --> Language Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Loader Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:01:10 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:01:10 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:01:10 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:01:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:01:10 --> Session Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:01:10 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Session routines successfully run
ERROR - 2016-09-25 00:01:10 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:01:10 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:01:10 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:01:10 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:01:10 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Table Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Model Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Model Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:01:10 --> Model Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Controller Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:01:10 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:01:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:01:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:01:13 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:01:13 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:01:13 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:01:13 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:01:13 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:01:13 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:01:13 --> Final output sent to browser
DEBUG - 2016-09-25 00:01:13 --> Total execution time: 2.6201
DEBUG - 2016-09-25 00:01:13 --> Config Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Config Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:01:13 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:01:13 --> URI Class Initialized
DEBUG - 2016-09-25 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:01:13 --> Config Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Config Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Router Class Initialized
DEBUG - 2016-09-25 00:01:13 --> URI Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Config Class Initialized
ERROR - 2016-09-25 00:01:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:01:13 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Router Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Config Class Initialized
DEBUG - 2016-09-25 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:01:13 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:01:13 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:01:13 --> UTF-8 Support Enabled
ERROR - 2016-09-25 00:01:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:01:13 --> URI Class Initialized
DEBUG - 2016-09-25 00:01:13 --> URI Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:01:13 --> URI Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Router Class Initialized
DEBUG - 2016-09-25 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:01:13 --> Router Class Initialized
DEBUG - 2016-09-25 00:01:13 --> URI Class Initialized
ERROR - 2016-09-25 00:01:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:01:13 --> Router Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Router Class Initialized
ERROR - 2016-09-25 00:01:13 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:01:13 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:01:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:01:13 --> Config Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:01:13 --> URI Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Router Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Config Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Hooks Class Initialized
ERROR - 2016-09-25 00:01:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:01:13 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:01:13 --> URI Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Router Class Initialized
ERROR - 2016-09-25 00:01:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:01:13 --> Config Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:01:13 --> URI Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Router Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Config Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Hooks Class Initialized
ERROR - 2016-09-25 00:01:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:01:13 --> Config Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Config Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:01:13 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:01:13 --> URI Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:01:13 --> Router Class Initialized
DEBUG - 2016-09-25 00:01:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:01:13 --> URI Class Initialized
ERROR - 2016-09-25 00:01:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:01:13 --> URI Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Router Class Initialized
DEBUG - 2016-09-25 00:01:13 --> Router Class Initialized
ERROR - 2016-09-25 00:01:13 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:01:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:01:59 --> Config Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:01:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:01:59 --> URI Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Router Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Output Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Security Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Input Class Initialized
DEBUG - 2016-09-25 00:01:59 --> XSS Filtering completed
DEBUG - 2016-09-25 00:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:01:59 --> Language Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Loader Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:01:59 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:01:59 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:01:59 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:01:59 --> Session Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:01:59 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Session routines successfully run
ERROR - 2016-09-25 00:01:59 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:01:59 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:01:59 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:01:59 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:01:59 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Table Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:01:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Controller Class Initialized
DEBUG - 2016-09-25 00:01:59 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:02:00 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:02:00 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:02:00 --> Final output sent to browser
DEBUG - 2016-09-25 00:02:00 --> Total execution time: 0.1070
DEBUG - 2016-09-25 00:04:15 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:15 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:15 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:04:15 --> URI Class Initialized
DEBUG - 2016-09-25 00:04:15 --> Router Class Initialized
DEBUG - 2016-09-25 00:04:15 --> Output Class Initialized
DEBUG - 2016-09-25 00:04:15 --> Security Class Initialized
DEBUG - 2016-09-25 00:04:15 --> Input Class Initialized
DEBUG - 2016-09-25 00:04:15 --> XSS Filtering completed
DEBUG - 2016-09-25 00:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:04:15 --> Language Class Initialized
DEBUG - 2016-09-25 00:04:16 --> Loader Class Initialized
DEBUG - 2016-09-25 00:04:16 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:04:16 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:04:16 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:04:16 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:04:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:04:16 --> Session Class Initialized
DEBUG - 2016-09-25 00:04:16 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:04:16 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:04:16 --> Session routines successfully run
ERROR - 2016-09-25 00:04:16 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:04:16 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:04:16 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:04:16 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:04:16 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:04:16 --> Table Class Initialized
DEBUG - 2016-09-25 00:04:16 --> Model Class Initialized
DEBUG - 2016-09-25 00:04:16 --> Model Class Initialized
DEBUG - 2016-09-25 00:04:16 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:04:16 --> Model Class Initialized
DEBUG - 2016-09-25 00:04:16 --> Controller Class Initialized
DEBUG - 2016-09-25 00:04:16 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:04:16 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:04:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:04:16 --> Final output sent to browser
DEBUG - 2016-09-25 00:04:16 --> Total execution time: 0.0780
DEBUG - 2016-09-25 00:04:26 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:04:26 --> URI Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Router Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Output Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Security Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Input Class Initialized
DEBUG - 2016-09-25 00:04:26 --> XSS Filtering completed
DEBUG - 2016-09-25 00:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:04:26 --> Language Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Loader Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:04:26 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:04:26 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:04:26 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:04:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:04:26 --> Session Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:04:26 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Session routines successfully run
ERROR - 2016-09-25 00:04:26 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:04:26 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:04:26 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:04:26 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:04:26 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Table Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Model Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Model Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:04:26 --> Model Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Controller Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:04:26 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:04:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:04:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:04:28 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:04:28 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:04:28 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:04:28 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:04:28 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:04:28 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:04:28 --> Final output sent to browser
DEBUG - 2016-09-25 00:04:28 --> Total execution time: 2.4551
DEBUG - 2016-09-25 00:04:28 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:04:28 --> URI Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Router Class Initialized
ERROR - 2016-09-25 00:04:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:04:28 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:04:28 --> URI Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Router Class Initialized
ERROR - 2016-09-25 00:04:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:04:28 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:04:28 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:28 --> URI Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:04:28 --> Router Class Initialized
DEBUG - 2016-09-25 00:04:28 --> URI Class Initialized
ERROR - 2016-09-25 00:04:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:04:28 --> Router Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:28 --> UTF-8 Support Enabled
ERROR - 2016-09-25 00:04:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:04:28 --> URI Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Router Class Initialized
ERROR - 2016-09-25 00:04:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:04:28 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:04:28 --> URI Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Router Class Initialized
ERROR - 2016-09-25 00:04:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:04:28 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:04:28 --> URI Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Router Class Initialized
ERROR - 2016-09-25 00:04:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:04:28 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:04:28 --> URI Class Initialized
DEBUG - 2016-09-25 00:04:28 --> Router Class Initialized
ERROR - 2016-09-25 00:04:29 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:04:29 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:29 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:29 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:04:29 --> URI Class Initialized
DEBUG - 2016-09-25 00:04:29 --> Router Class Initialized
ERROR - 2016-09-25 00:04:29 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:04:29 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:29 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:29 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:29 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:29 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:29 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:29 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:29 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:04:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:04:29 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:04:29 --> URI Class Initialized
DEBUG - 2016-09-25 00:04:29 --> URI Class Initialized
DEBUG - 2016-09-25 00:04:29 --> Router Class Initialized
DEBUG - 2016-09-25 00:04:29 --> Router Class Initialized
DEBUG - 2016-09-25 00:04:29 --> URI Class Initialized
DEBUG - 2016-09-25 00:04:29 --> Router Class Initialized
ERROR - 2016-09-25 00:04:29 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:04:29 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:04:29 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:04:42 --> Config Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:04:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:04:42 --> URI Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Router Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Output Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Security Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Input Class Initialized
DEBUG - 2016-09-25 00:04:42 --> XSS Filtering completed
DEBUG - 2016-09-25 00:04:42 --> XSS Filtering completed
DEBUG - 2016-09-25 00:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:04:42 --> Language Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Loader Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:04:42 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:04:42 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:04:42 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:04:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:04:42 --> Session Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:04:42 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Session routines successfully run
ERROR - 2016-09-25 00:04:42 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:04:42 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:04:42 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:04:42 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:04:42 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Table Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Model Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Model Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:04:42 --> Model Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Controller Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:04:42 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:04:42 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:04:42 --> Final output sent to browser
DEBUG - 2016-09-25 00:04:42 --> Total execution time: 0.1490
DEBUG - 2016-09-25 00:05:46 --> Config Class Initialized
DEBUG - 2016-09-25 00:05:46 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:05:46 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:05:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:05:46 --> URI Class Initialized
DEBUG - 2016-09-25 00:05:46 --> Router Class Initialized
DEBUG - 2016-09-25 00:05:46 --> No URI present. Default controller set.
DEBUG - 2016-09-25 00:05:46 --> Output Class Initialized
DEBUG - 2016-09-25 00:05:46 --> Security Class Initialized
DEBUG - 2016-09-25 00:05:46 --> Input Class Initialized
DEBUG - 2016-09-25 00:05:46 --> XSS Filtering completed
DEBUG - 2016-09-25 00:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:05:46 --> Language Class Initialized
DEBUG - 2016-09-25 00:05:46 --> Loader Class Initialized
DEBUG - 2016-09-25 00:05:46 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:05:46 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:05:46 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:05:46 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:05:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:05:46 --> Session Class Initialized
DEBUG - 2016-09-25 00:05:46 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:05:46 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:05:46 --> A session cookie was not found.
DEBUG - 2016-09-25 00:05:46 --> Session routines successfully run
ERROR - 2016-09-25 00:05:46 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:05:46 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:05:46 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:05:46 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:05:46 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:05:46 --> Table Class Initialized
DEBUG - 2016-09-25 00:05:46 --> Model Class Initialized
DEBUG - 2016-09-25 00:05:46 --> Model Class Initialized
DEBUG - 2016-09-25 00:05:46 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:05:46 --> Model Class Initialized
DEBUG - 2016-09-25 00:05:46 --> Controller Class Initialized
DEBUG - 2016-09-25 00:05:47 --> Config Class Initialized
DEBUG - 2016-09-25 00:05:47 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:05:47 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:05:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:05:47 --> URI Class Initialized
DEBUG - 2016-09-25 00:05:47 --> Router Class Initialized
DEBUG - 2016-09-25 00:05:47 --> No URI present. Default controller set.
DEBUG - 2016-09-25 00:05:47 --> Output Class Initialized
DEBUG - 2016-09-25 00:05:47 --> Security Class Initialized
DEBUG - 2016-09-25 00:05:47 --> Input Class Initialized
DEBUG - 2016-09-25 00:05:47 --> XSS Filtering completed
DEBUG - 2016-09-25 00:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:05:47 --> Language Class Initialized
DEBUG - 2016-09-25 00:05:47 --> Loader Class Initialized
DEBUG - 2016-09-25 00:05:47 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:05:47 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:05:47 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:05:47 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:05:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:05:47 --> Session Class Initialized
DEBUG - 2016-09-25 00:05:47 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:05:47 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:05:47 --> A session cookie was not found.
DEBUG - 2016-09-25 00:05:47 --> Session routines successfully run
ERROR - 2016-09-25 00:05:47 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:05:47 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:05:47 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:05:47 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:05:47 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:05:47 --> Table Class Initialized
DEBUG - 2016-09-25 00:05:47 --> Model Class Initialized
DEBUG - 2016-09-25 00:05:47 --> Model Class Initialized
DEBUG - 2016-09-25 00:05:47 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:05:47 --> Model Class Initialized
DEBUG - 2016-09-25 00:05:47 --> Controller Class Initialized
DEBUG - 2016-09-25 00:05:49 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:05:49 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:05:49 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:05:49 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:05:50 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-25 00:05:50 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-25 00:05:53 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:05:53 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-25 00:05:53 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:05:53 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-25 00:05:53 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-25 00:05:53 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-25 00:05:53 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-25 00:05:53 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-25 00:05:53 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-25 00:05:53 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-25 00:05:53 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-25 00:05:53 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-25 00:05:53 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-25 00:05:53 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-25 00:05:53 --> Final output sent to browser
DEBUG - 2016-09-25 00:05:53 --> Total execution time: 6.8934
DEBUG - 2016-09-25 00:05:53 --> Final output sent to browser
DEBUG - 2016-09-25 00:05:53 --> Total execution time: 6.3254
DEBUG - 2016-09-25 00:05:53 --> Config Class Initialized
DEBUG - 2016-09-25 00:05:53 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:05:53 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:05:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:05:53 --> URI Class Initialized
DEBUG - 2016-09-25 00:05:53 --> Router Class Initialized
ERROR - 2016-09-25 00:05:53 --> 404 Page Not Found --> js
DEBUG - 2016-09-25 00:05:58 --> Config Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:05:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:05:58 --> URI Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Router Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Output Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Security Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Input Class Initialized
DEBUG - 2016-09-25 00:05:58 --> XSS Filtering completed
DEBUG - 2016-09-25 00:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:05:58 --> Language Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Loader Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:05:58 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:05:58 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:05:58 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:05:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:05:58 --> Session Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:05:58 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Session routines successfully run
ERROR - 2016-09-25 00:05:58 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:05:58 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:05:58 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:05:58 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:05:58 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Table Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:05:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Controller Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:05:58 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:05:58 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:05:58 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-25 00:05:58 --> File loaded: application/views/login_form.php
DEBUG - 2016-09-25 00:05:58 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-25 00:05:58 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-25 00:05:58 --> Final output sent to browser
DEBUG - 2016-09-25 00:05:58 --> Total execution time: 0.0880
DEBUG - 2016-09-25 00:05:58 --> Config Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:05:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:05:58 --> URI Class Initialized
DEBUG - 2016-09-25 00:05:58 --> Router Class Initialized
ERROR - 2016-09-25 00:05:58 --> 404 Page Not Found --> js
DEBUG - 2016-09-25 00:06:09 --> Config Class Initialized
DEBUG - 2016-09-25 00:06:09 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:06:09 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:06:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:06:09 --> URI Class Initialized
DEBUG - 2016-09-25 00:06:09 --> Router Class Initialized
DEBUG - 2016-09-25 00:06:09 --> Output Class Initialized
DEBUG - 2016-09-25 00:06:09 --> Security Class Initialized
DEBUG - 2016-09-25 00:06:09 --> Input Class Initialized
DEBUG - 2016-09-25 00:06:09 --> XSS Filtering completed
DEBUG - 2016-09-25 00:06:09 --> XSS Filtering completed
DEBUG - 2016-09-25 00:06:10 --> XSS Filtering completed
DEBUG - 2016-09-25 00:06:10 --> XSS Filtering completed
DEBUG - 2016-09-25 00:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:06:10 --> Language Class Initialized
DEBUG - 2016-09-25 00:06:10 --> Loader Class Initialized
DEBUG - 2016-09-25 00:06:10 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:06:10 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:06:10 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:06:10 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:06:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:06:10 --> Session Class Initialized
DEBUG - 2016-09-25 00:06:10 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:06:10 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:06:10 --> Session routines successfully run
ERROR - 2016-09-25 00:06:10 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:06:10 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:06:10 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:06:10 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:06:10 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:06:10 --> Table Class Initialized
DEBUG - 2016-09-25 00:06:10 --> Model Class Initialized
DEBUG - 2016-09-25 00:06:10 --> Model Class Initialized
DEBUG - 2016-09-25 00:06:10 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:06:10 --> Model Class Initialized
DEBUG - 2016-09-25 00:06:10 --> Controller Class Initialized
DEBUG - 2016-09-25 00:06:10 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:06:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:06:10 --> Model Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Config Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:06:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:06:12 --> URI Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Router Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Output Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Security Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Input Class Initialized
DEBUG - 2016-09-25 00:06:12 --> XSS Filtering completed
DEBUG - 2016-09-25 00:06:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:06:12 --> Language Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Loader Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:06:12 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:06:12 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:06:12 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:06:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:06:12 --> Session Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:06:12 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Session routines successfully run
ERROR - 2016-09-25 00:06:12 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:06:12 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:06:12 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:06:12 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:06:12 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Table Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Model Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Model Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:06:12 --> Model Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Controller Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:06:12 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:06:12 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:06:14 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:06:14 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:06:14 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:06:14 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:06:14 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:06:14 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:06:14 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:06:14 --> Final output sent to browser
DEBUG - 2016-09-25 00:06:14 --> Total execution time: 2.3601
DEBUG - 2016-09-25 00:06:14 --> Config Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:06:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:06:14 --> URI Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Router Class Initialized
ERROR - 2016-09-25 00:06:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:06:14 --> Config Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Config Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:06:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:06:14 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:06:14 --> URI Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:06:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:06:14 --> Router Class Initialized
DEBUG - 2016-09-25 00:06:14 --> URI Class Initialized
ERROR - 2016-09-25 00:06:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:06:14 --> Router Class Initialized
ERROR - 2016-09-25 00:06:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:06:14 --> Config Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:06:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:06:14 --> URI Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Router Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Config Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Hooks Class Initialized
ERROR - 2016-09-25 00:06:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:06:14 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:06:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:06:14 --> Config Class Initialized
DEBUG - 2016-09-25 00:06:14 --> URI Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Router Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:06:14 --> UTF-8 Support Enabled
ERROR - 2016-09-25 00:06:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:06:14 --> URI Class Initialized
DEBUG - 2016-09-25 00:06:14 --> Router Class Initialized
ERROR - 2016-09-25 00:06:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:06:20 --> Config Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:06:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:06:20 --> URI Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Router Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Output Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Security Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Input Class Initialized
DEBUG - 2016-09-25 00:06:20 --> XSS Filtering completed
DEBUG - 2016-09-25 00:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:06:20 --> Language Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Loader Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:06:20 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:06:20 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:06:20 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:06:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:06:20 --> Session Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:06:20 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Session routines successfully run
ERROR - 2016-09-25 00:06:20 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:06:20 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:06:20 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:06:20 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:06:20 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Table Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Model Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Model Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:06:20 --> Model Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Controller Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:06:20 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:06:20 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:06:20 --> Final output sent to browser
DEBUG - 2016-09-25 00:06:20 --> Total execution time: 0.1350
DEBUG - 2016-09-25 00:07:27 --> Config Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:07:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:07:27 --> URI Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Router Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Output Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Security Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Input Class Initialized
DEBUG - 2016-09-25 00:07:27 --> XSS Filtering completed
DEBUG - 2016-09-25 00:07:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:07:27 --> Language Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Loader Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:07:27 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:07:27 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:07:27 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:07:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:07:27 --> Session Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:07:27 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Session routines successfully run
ERROR - 2016-09-25 00:07:27 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:07:27 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:07:27 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:07:27 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:07:27 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Table Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Model Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Model Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:07:27 --> Model Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Controller Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:07:27 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:07:27 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:07:27 --> Final output sent to browser
DEBUG - 2016-09-25 00:07:27 --> Total execution time: 0.0710
DEBUG - 2016-09-25 00:07:57 --> Config Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:07:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:07:57 --> URI Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Router Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Output Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Security Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Input Class Initialized
DEBUG - 2016-09-25 00:07:57 --> XSS Filtering completed
DEBUG - 2016-09-25 00:07:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:07:57 --> Language Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Loader Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:07:57 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:07:57 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:07:57 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:07:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:07:57 --> Session Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:07:57 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Session routines successfully run
ERROR - 2016-09-25 00:07:57 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:07:57 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:07:57 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:07:57 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:07:57 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Table Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Model Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Model Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:07:57 --> Model Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Controller Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:07:57 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:07:57 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:07:57 --> Final output sent to browser
DEBUG - 2016-09-25 00:07:57 --> Total execution time: 0.0790
DEBUG - 2016-09-25 00:08:34 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:08:34 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Router Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Output Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Security Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Input Class Initialized
DEBUG - 2016-09-25 00:08:34 --> XSS Filtering completed
DEBUG - 2016-09-25 00:08:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:08:34 --> Language Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Loader Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:08:34 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:08:34 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:08:34 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:08:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:08:34 --> Session Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:08:34 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Session routines successfully run
ERROR - 2016-09-25 00:08:34 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:08:34 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:08:34 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:08:34 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:08:34 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Table Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Model Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Model Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:08:34 --> Model Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Controller Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:08:34 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:08:34 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:08:34 --> Final output sent to browser
DEBUG - 2016-09-25 00:08:34 --> Total execution time: 0.0850
DEBUG - 2016-09-25 00:08:43 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:08:43 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Router Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Output Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Security Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Input Class Initialized
DEBUG - 2016-09-25 00:08:43 --> XSS Filtering completed
DEBUG - 2016-09-25 00:08:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:08:43 --> Language Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Loader Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:08:43 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:08:43 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:08:43 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:08:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:08:43 --> Session Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:08:43 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Session routines successfully run
ERROR - 2016-09-25 00:08:43 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:08:43 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:08:43 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:08:43 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:08:43 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Table Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Model Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Model Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:08:43 --> Model Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Controller Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:08:43 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:08:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:08:45 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:08:45 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:08:45 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:08:45 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:08:45 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:08:45 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:08:45 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:08:45 --> Final output sent to browser
DEBUG - 2016-09-25 00:08:45 --> Total execution time: 2.5341
DEBUG - 2016-09-25 00:08:46 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:08:46 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Router Class Initialized
ERROR - 2016-09-25 00:08:46 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:08:46 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:08:46 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:46 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Router Class Initialized
DEBUG - 2016-09-25 00:08:46 --> UTF-8 Support Enabled
ERROR - 2016-09-25 00:08:46 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:08:46 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Router Class Initialized
ERROR - 2016-09-25 00:08:46 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:08:46 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:08:46 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Router Class Initialized
ERROR - 2016-09-25 00:08:46 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:08:46 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:08:46 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:46 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:08:46 --> Router Class Initialized
DEBUG - 2016-09-25 00:08:46 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:46 --> Router Class Initialized
ERROR - 2016-09-25 00:08:46 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:08:46 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:08:52 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:08:52 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Router Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Output Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Security Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Input Class Initialized
DEBUG - 2016-09-25 00:08:52 --> XSS Filtering completed
DEBUG - 2016-09-25 00:08:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:08:52 --> Language Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Loader Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:08:52 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:08:52 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:08:52 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:08:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:08:52 --> Session Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:08:52 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Session routines successfully run
ERROR - 2016-09-25 00:08:52 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:08:52 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:08:52 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:08:52 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:08:52 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Table Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Model Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Model Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:08:52 --> Model Class Initialized
DEBUG - 2016-09-25 00:08:52 --> Controller Class Initialized
DEBUG - 2016-09-25 00:08:53 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:08:53 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:08:53 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:08:55 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:08:55 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:08:55 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:08:55 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:08:55 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:08:55 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:08:55 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:08:55 --> Final output sent to browser
DEBUG - 2016-09-25 00:08:55 --> Total execution time: 2.4961
DEBUG - 2016-09-25 00:08:55 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:08:55 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Router Class Initialized
ERROR - 2016-09-25 00:08:55 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:08:55 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:08:55 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:08:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:08:55 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:55 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:55 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Router Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Router Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Router Class Initialized
ERROR - 2016-09-25 00:08:55 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:08:55 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:08:55 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:08:55 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:08:55 --> Config Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:08:55 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Router Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:08:55 --> UTF-8 Support Enabled
ERROR - 2016-09-25 00:08:55 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:08:55 --> URI Class Initialized
DEBUG - 2016-09-25 00:08:55 --> Router Class Initialized
ERROR - 2016-09-25 00:08:55 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:09:59 --> Config Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:09:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:09:59 --> URI Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Router Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Output Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Security Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Input Class Initialized
DEBUG - 2016-09-25 00:09:59 --> XSS Filtering completed
DEBUG - 2016-09-25 00:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:09:59 --> Language Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Loader Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:09:59 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:09:59 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:09:59 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:09:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:09:59 --> Session Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:09:59 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Session routines successfully run
ERROR - 2016-09-25 00:09:59 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:09:59 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:09:59 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:09:59 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:09:59 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Table Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:09:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Controller Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:09:59 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:09:59 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:10:02 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:10:02 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:10:02 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:10:02 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:10:02 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:10:02 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:10:02 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:10:02 --> Final output sent to browser
DEBUG - 2016-09-25 00:10:02 --> Total execution time: 2.4861
DEBUG - 2016-09-25 00:10:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:10:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:10:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:10:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:10:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:10:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Config Class Initialized
ERROR - 2016-09-25 00:10:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:10:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Hooks Class Initialized
ERROR - 2016-09-25 00:10:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:10:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:10:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:10:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Router Class Initialized
ERROR - 2016-09-25 00:10:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:10:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:10:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:10:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Router Class Initialized
ERROR - 2016-09-25 00:10:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:10:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:10:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:10:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Router Class Initialized
ERROR - 2016-09-25 00:10:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:10:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:10:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:10:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:10:02 --> Router Class Initialized
ERROR - 2016-09-25 00:10:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:19:43 --> Config Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:19:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:19:43 --> URI Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Router Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Output Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Security Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Input Class Initialized
DEBUG - 2016-09-25 00:19:43 --> XSS Filtering completed
DEBUG - 2016-09-25 00:19:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:19:43 --> Language Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Loader Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:19:43 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:19:43 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:19:43 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:19:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:19:43 --> Session Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:19:43 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Session routines successfully run
ERROR - 2016-09-25 00:19:43 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:19:43 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:19:43 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:19:43 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:19:43 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Table Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Model Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Model Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:19:43 --> Model Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Controller Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:19:43 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:19:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:19:45 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:19:45 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:19:45 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:19:45 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:19:45 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:19:45 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:19:45 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:19:45 --> Final output sent to browser
DEBUG - 2016-09-25 00:19:45 --> Total execution time: 2.4131
DEBUG - 2016-09-25 00:19:45 --> Config Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Config Class Initialized
DEBUG - 2016-09-25 00:19:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:19:45 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:19:45 --> URI Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:19:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:19:45 --> Router Class Initialized
DEBUG - 2016-09-25 00:19:45 --> URI Class Initialized
ERROR - 2016-09-25 00:19:45 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:19:45 --> Router Class Initialized
ERROR - 2016-09-25 00:19:45 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:19:45 --> Config Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:19:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:19:45 --> URI Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Router Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Config Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Config Class Initialized
ERROR - 2016-09-25 00:19:45 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:19:45 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:19:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:19:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:19:45 --> URI Class Initialized
DEBUG - 2016-09-25 00:19:45 --> URI Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Router Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Router Class Initialized
ERROR - 2016-09-25 00:19:45 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:19:45 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:19:45 --> Config Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:19:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:19:45 --> URI Class Initialized
DEBUG - 2016-09-25 00:19:45 --> Router Class Initialized
ERROR - 2016-09-25 00:19:45 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:19:49 --> Config Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:19:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:19:49 --> URI Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Router Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Output Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Security Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Input Class Initialized
DEBUG - 2016-09-25 00:19:49 --> XSS Filtering completed
DEBUG - 2016-09-25 00:19:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:19:49 --> Language Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Loader Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:19:49 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:19:49 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:19:49 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:19:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:19:49 --> Session Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:19:49 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Session routines successfully run
ERROR - 2016-09-25 00:19:49 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:19:49 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:19:49 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:19:49 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:19:49 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Table Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Model Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Model Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:19:49 --> Model Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Controller Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:19:49 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:19:49 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:19:49 --> Final output sent to browser
DEBUG - 2016-09-25 00:19:49 --> Total execution time: 0.1040
DEBUG - 2016-09-25 00:20:58 --> Config Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:20:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:20:58 --> URI Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Router Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Output Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Security Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Input Class Initialized
DEBUG - 2016-09-25 00:20:58 --> XSS Filtering completed
DEBUG - 2016-09-25 00:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:20:58 --> Language Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Loader Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:20:58 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:20:58 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:20:58 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:20:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:20:58 --> Session Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:20:58 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Session routines successfully run
ERROR - 2016-09-25 00:20:58 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:20:58 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:20:58 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:20:58 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:20:58 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Table Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:20:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Controller Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:20:58 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:20:58 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:21:00 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:21:00 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:21:00 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:21:00 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:21:00 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:21:00 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:21:00 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:21:00 --> Final output sent to browser
DEBUG - 2016-09-25 00:21:00 --> Total execution time: 2.2261
DEBUG - 2016-09-25 00:21:00 --> Config Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Config Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:21:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:21:00 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:21:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:21:00 --> URI Class Initialized
DEBUG - 2016-09-25 00:21:00 --> URI Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Router Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Router Class Initialized
ERROR - 2016-09-25 00:21:00 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:21:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:21:00 --> Config Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:21:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:21:00 --> Config Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Config Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:21:00 --> URI Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:21:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:21:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:21:00 --> Router Class Initialized
DEBUG - 2016-09-25 00:21:00 --> URI Class Initialized
DEBUG - 2016-09-25 00:21:00 --> URI Class Initialized
ERROR - 2016-09-25 00:21:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:21:00 --> Router Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Router Class Initialized
ERROR - 2016-09-25 00:21:00 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:21:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:21:00 --> Config Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:21:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:21:00 --> URI Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Router Class Initialized
ERROR - 2016-09-25 00:21:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:21:00 --> Config Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:21:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:21:00 --> URI Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Router Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Output Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Security Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Input Class Initialized
DEBUG - 2016-09-25 00:21:00 --> XSS Filtering completed
DEBUG - 2016-09-25 00:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:21:00 --> Language Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Loader Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:21:00 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:21:00 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:21:00 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:21:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:21:00 --> Session Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:21:00 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Session routines successfully run
ERROR - 2016-09-25 00:21:00 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:21:00 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:21:00 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:21:00 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:21:00 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Table Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Model Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Model Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:21:00 --> Model Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Controller Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:21:00 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:21:00 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:21:00 --> Final output sent to browser
DEBUG - 2016-09-25 00:21:00 --> Total execution time: 0.1500
DEBUG - 2016-09-25 00:21:59 --> Config Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:21:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:21:59 --> URI Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Router Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Output Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Security Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Input Class Initialized
DEBUG - 2016-09-25 00:21:59 --> XSS Filtering completed
DEBUG - 2016-09-25 00:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:21:59 --> Language Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Loader Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:21:59 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:21:59 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:21:59 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:21:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:21:59 --> Session Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:21:59 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Session routines successfully run
ERROR - 2016-09-25 00:21:59 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:21:59 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:21:59 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:21:59 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:21:59 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Table Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:21:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Controller Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:21:59 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:21:59 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:22:01 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:22:01 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:22:01 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:22:01 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:22:01 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:22:01 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:22:01 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:22:01 --> Final output sent to browser
DEBUG - 2016-09-25 00:22:01 --> Total execution time: 2.2111
DEBUG - 2016-09-25 00:22:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:22:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:22:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Router Class Initialized
ERROR - 2016-09-25 00:22:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:22:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:22:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:22:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Utf8 Class Initialized
ERROR - 2016-09-25 00:22:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:22:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:22:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:22:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:22:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:22:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Config Class Initialized
ERROR - 2016-09-25 00:22:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:22:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:22:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:22:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:22:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Router Class Initialized
ERROR - 2016-09-25 00:22:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:22:02 --> UTF-8 Support Enabled
ERROR - 2016-09-25 00:22:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:22:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:22:02 --> Router Class Initialized
ERROR - 2016-09-25 00:22:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:22:04 --> Config Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:22:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:22:04 --> URI Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Router Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Output Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Security Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Input Class Initialized
DEBUG - 2016-09-25 00:22:04 --> XSS Filtering completed
DEBUG - 2016-09-25 00:22:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:22:04 --> Language Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Loader Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:22:04 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:22:04 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:22:04 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:22:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:22:04 --> Session Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:22:04 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Session routines successfully run
ERROR - 2016-09-25 00:22:04 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:22:04 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:22:04 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:22:04 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:22:04 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Table Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Model Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Model Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:22:04 --> Model Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Controller Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:22:04 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:22:04 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:22:04 --> Final output sent to browser
DEBUG - 2016-09-25 00:22:04 --> Total execution time: 0.0980
DEBUG - 2016-09-25 00:22:53 --> Config Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:22:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:22:53 --> URI Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Router Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Output Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Security Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Input Class Initialized
DEBUG - 2016-09-25 00:22:53 --> XSS Filtering completed
DEBUG - 2016-09-25 00:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:22:53 --> Language Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Loader Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:22:53 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:22:53 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:22:53 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:22:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:22:53 --> Session Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:22:53 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Session routines successfully run
ERROR - 2016-09-25 00:22:53 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:22:53 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:22:53 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:22:53 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:22:53 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Table Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Model Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Model Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:22:53 --> Model Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Controller Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:22:53 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:22:53 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:22:53 --> Final output sent to browser
DEBUG - 2016-09-25 00:22:53 --> Total execution time: 0.0600
DEBUG - 2016-09-25 00:24:57 --> Config Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:24:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:24:57 --> URI Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Router Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Output Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Security Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Input Class Initialized
DEBUG - 2016-09-25 00:24:57 --> XSS Filtering completed
DEBUG - 2016-09-25 00:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:24:57 --> Language Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Loader Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:24:57 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:24:57 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:24:57 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:24:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:24:57 --> Session Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:24:57 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Session routines successfully run
ERROR - 2016-09-25 00:24:57 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:24:57 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:24:57 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:24:57 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:24:57 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Table Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Model Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Model Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:24:57 --> Model Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Controller Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:24:57 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:24:57 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:24:59 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:24:59 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:24:59 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:24:59 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:24:59 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:24:59 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:24:59 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:24:59 --> Final output sent to browser
DEBUG - 2016-09-25 00:24:59 --> Total execution time: 2.4371
DEBUG - 2016-09-25 00:24:59 --> Config Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Config Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Config Class Initialized
DEBUG - 2016-09-25 00:24:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:24:59 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:24:59 --> URI Class Initialized
DEBUG - 2016-09-25 00:24:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:24:59 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:24:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:24:59 --> Router Class Initialized
DEBUG - 2016-09-25 00:24:59 --> URI Class Initialized
ERROR - 2016-09-25 00:24:59 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:24:59 --> URI Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Router Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Router Class Initialized
ERROR - 2016-09-25 00:24:59 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:24:59 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:24:59 --> Config Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:24:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:24:59 --> URI Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Config Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Router Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:24:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:24:59 --> Config Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:24:59 --> URI Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:24:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:24:59 --> Router Class Initialized
ERROR - 2016-09-25 00:24:59 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:24:59 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:24:59 --> URI Class Initialized
DEBUG - 2016-09-25 00:24:59 --> Router Class Initialized
ERROR - 2016-09-25 00:24:59 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:25:00 --> Config Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:25:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:25:00 --> URI Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Router Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Output Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Security Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Input Class Initialized
DEBUG - 2016-09-25 00:25:00 --> XSS Filtering completed
DEBUG - 2016-09-25 00:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:25:00 --> Language Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Loader Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:25:00 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:25:00 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:25:00 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:25:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:25:00 --> Session Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:25:00 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Session routines successfully run
ERROR - 2016-09-25 00:25:00 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:25:00 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:25:00 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:25:00 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:25:00 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Table Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Model Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Model Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:25:00 --> Model Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Controller Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:25:00 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:25:00 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:25:00 --> Final output sent to browser
DEBUG - 2016-09-25 00:25:00 --> Total execution time: 0.1140
DEBUG - 2016-09-25 00:27:10 --> Config Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:10 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Router Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Output Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Security Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Input Class Initialized
DEBUG - 2016-09-25 00:27:10 --> XSS Filtering completed
DEBUG - 2016-09-25 00:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:27:10 --> Language Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Loader Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:27:10 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:27:10 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:27:10 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:27:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:27:10 --> Session Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:27:10 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Session routines successfully run
ERROR - 2016-09-25 00:27:10 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:27:10 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:27:10 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:27:10 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:27:10 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Table Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Model Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Model Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:27:10 --> Model Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Controller Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:27:10 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:27:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:27:10 --> Final output sent to browser
DEBUG - 2016-09-25 00:27:10 --> Total execution time: 0.0580
DEBUG - 2016-09-25 00:27:17 --> Config Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:17 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Router Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Output Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Security Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Input Class Initialized
DEBUG - 2016-09-25 00:27:17 --> XSS Filtering completed
DEBUG - 2016-09-25 00:27:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:27:17 --> Language Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Loader Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:27:17 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:27:17 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:27:17 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:27:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:27:17 --> Session Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:27:17 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Session routines successfully run
ERROR - 2016-09-25 00:27:17 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:27:17 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:27:17 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:27:17 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:27:17 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Table Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Model Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Model Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:27:17 --> Model Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Controller Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:27:17 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:27:17 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:27:19 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:27:19 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:27:19 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:27:19 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:27:19 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:27:19 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:27:19 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:27:19 --> Final output sent to browser
DEBUG - 2016-09-25 00:27:19 --> Total execution time: 2.5421
DEBUG - 2016-09-25 00:27:20 --> Config Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:20 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Router Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Config Class Initialized
ERROR - 2016-09-25 00:27:20 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:27:20 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:20 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Router Class Initialized
ERROR - 2016-09-25 00:27:20 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:27:20 --> Config Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:20 --> Config Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:20 --> Config Class Initialized
DEBUG - 2016-09-25 00:27:20 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Router Class Initialized
DEBUG - 2016-09-25 00:27:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:20 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Config Class Initialized
ERROR - 2016-09-25 00:27:20 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:27:20 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Router Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:20 --> Router Class Initialized
ERROR - 2016-09-25 00:27:20 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:27:20 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:27:20 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:20 --> Router Class Initialized
ERROR - 2016-09-25 00:27:20 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:27:23 --> Config Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:23 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Router Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Output Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Security Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Input Class Initialized
DEBUG - 2016-09-25 00:27:23 --> XSS Filtering completed
DEBUG - 2016-09-25 00:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:27:23 --> Language Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Loader Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:27:23 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:27:23 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:27:23 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:27:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:27:23 --> Session Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:27:23 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Session routines successfully run
ERROR - 2016-09-25 00:27:23 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:27:23 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:27:23 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:27:23 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:27:23 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Table Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Model Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Model Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:27:23 --> Model Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Controller Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:27:23 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:27:23 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:27:23 --> Final output sent to browser
DEBUG - 2016-09-25 00:27:23 --> Total execution time: 0.1090
DEBUG - 2016-09-25 00:27:25 --> Config Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:25 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Router Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Output Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Security Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Input Class Initialized
DEBUG - 2016-09-25 00:27:25 --> XSS Filtering completed
DEBUG - 2016-09-25 00:27:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:27:25 --> Language Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Loader Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:27:25 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:27:25 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:27:25 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:27:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:27:25 --> Session Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:27:25 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Session routines successfully run
ERROR - 2016-09-25 00:27:25 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:27:25 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:27:25 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:27:25 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:27:25 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Table Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Model Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Model Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:27:25 --> Model Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Controller Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:27:25 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:27:25 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:27:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:27:28 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:27:28 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:27:28 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:27:28 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:27:28 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:27:28 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:27:28 --> Final output sent to browser
DEBUG - 2016-09-25 00:27:28 --> Total execution time: 2.4521
DEBUG - 2016-09-25 00:27:28 --> Config Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:28 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Router Class Initialized
ERROR - 2016-09-25 00:27:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:27:28 --> Config Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Config Class Initialized
DEBUG - 2016-09-25 00:27:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:28 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:28 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:28 --> Router Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Config Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Hooks Class Initialized
ERROR - 2016-09-25 00:27:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:27:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:28 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:28 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Router Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Router Class Initialized
ERROR - 2016-09-25 00:27:28 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:27:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:27:28 --> Config Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:28 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Router Class Initialized
ERROR - 2016-09-25 00:27:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:27:28 --> Config Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:27:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:27:28 --> URI Class Initialized
DEBUG - 2016-09-25 00:27:28 --> Router Class Initialized
ERROR - 2016-09-25 00:27:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:35:10 --> Config Class Initialized
DEBUG - 2016-09-25 00:35:10 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:35:10 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:35:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:35:10 --> URI Class Initialized
DEBUG - 2016-09-25 00:35:10 --> Router Class Initialized
DEBUG - 2016-09-25 00:35:10 --> Output Class Initialized
DEBUG - 2016-09-25 00:35:10 --> Security Class Initialized
DEBUG - 2016-09-25 00:35:10 --> Input Class Initialized
DEBUG - 2016-09-25 00:35:10 --> XSS Filtering completed
DEBUG - 2016-09-25 00:35:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:35:10 --> Language Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Config Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:35:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:35:59 --> URI Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Router Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Output Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Security Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Input Class Initialized
DEBUG - 2016-09-25 00:35:59 --> XSS Filtering completed
DEBUG - 2016-09-25 00:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:35:59 --> Language Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Loader Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:35:59 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:35:59 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:35:59 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:35:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:35:59 --> Session Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:35:59 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Session routines successfully run
ERROR - 2016-09-25 00:35:59 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:35:59 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:35:59 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:35:59 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:35:59 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Table Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:35:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Controller Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:35:59 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:35:59 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:36:01 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:36:01 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:36:01 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:36:01 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:36:01 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:36:01 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:36:01 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:36:01 --> Final output sent to browser
DEBUG - 2016-09-25 00:36:01 --> Total execution time: 2.7720
DEBUG - 2016-09-25 00:36:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Router Class Initialized
ERROR - 2016-09-25 00:36:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Router Class Initialized
ERROR - 2016-09-25 00:36:02 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:36:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Hooks Class Initialized
ERROR - 2016-09-25 00:36:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Hooks Class Initialized
ERROR - 2016-09-25 00:36:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Router Class Initialized
ERROR - 2016-09-25 00:36:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Router Class Initialized
ERROR - 2016-09-25 00:36:02 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:36:02 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:36:02 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:36:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:02 --> URI Class Initialized
ERROR - 2016-09-25 00:36:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:02 --> Router Class Initialized
ERROR - 2016-09-25 00:36:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:24 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:24 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Output Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Security Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Input Class Initialized
DEBUG - 2016-09-25 00:36:24 --> XSS Filtering completed
DEBUG - 2016-09-25 00:36:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:36:24 --> Language Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Loader Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:36:24 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:36:24 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:36:24 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:36:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:36:24 --> Session Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:36:24 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Session routines successfully run
ERROR - 2016-09-25 00:36:24 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:36:24 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:36:24 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:36:24 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:36:24 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Table Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Model Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Model Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:36:24 --> Model Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Controller Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:36:24 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:36:24 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:36:27 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:36:27 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:36:27 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:36:27 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:36:27 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:36:27 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:36:27 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:36:27 --> Final output sent to browser
DEBUG - 2016-09-25 00:36:27 --> Total execution time: 2.5550
DEBUG - 2016-09-25 00:36:27 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:27 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:27 --> Router Class Initialized
ERROR - 2016-09-25 00:36:27 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:27 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:27 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:27 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:27 --> URI Class Initialized
ERROR - 2016-09-25 00:36:27 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:27 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Utf8 Class Initialized
ERROR - 2016-09-25 00:36:27 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:27 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:27 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:27 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Router Class Initialized
ERROR - 2016-09-25 00:36:27 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:36:27 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:36:27 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:27 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:27 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:27 --> Router Class Initialized
ERROR - 2016-09-25 00:36:27 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:30 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:30 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Output Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Security Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Input Class Initialized
DEBUG - 2016-09-25 00:36:30 --> XSS Filtering completed
DEBUG - 2016-09-25 00:36:30 --> XSS Filtering completed
DEBUG - 2016-09-25 00:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:36:30 --> Language Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Loader Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:36:30 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:36:30 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:36:30 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:36:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:36:30 --> Session Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:36:30 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Session routines successfully run
ERROR - 2016-09-25 00:36:30 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:36:30 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:36:30 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:36:30 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:36:30 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Table Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Model Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Model Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:36:30 --> Model Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Controller Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:36:30 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-25 00:36:30 --> Severity: Warning  --> fopen(http://localhost:811/alumni/application/uploads\request.log): failed to open stream: HTTP wrapper does not support writeable connections C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 234
ERROR - 2016-09-25 00:36:30 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 235
ERROR - 2016-09-25 00:36:30 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 236
DEBUG - 2016-09-25 00:36:30 --> Final output sent to browser
DEBUG - 2016-09-25 00:36:30 --> Total execution time: 0.1090
DEBUG - 2016-09-25 00:36:30 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:30 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Output Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Security Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Input Class Initialized
DEBUG - 2016-09-25 00:36:30 --> XSS Filtering completed
DEBUG - 2016-09-25 00:36:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:36:30 --> Language Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Loader Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:36:30 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:36:30 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:36:30 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:36:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:36:30 --> Session Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:36:30 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Session routines successfully run
ERROR - 2016-09-25 00:36:30 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:36:30 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:36:30 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:36:30 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:36:30 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Table Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Model Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Model Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:36:30 --> Model Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Controller Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:36:30 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:36:30 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:36:33 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:36:33 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:36:33 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:36:33 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:36:33 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:36:33 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:36:33 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:36:33 --> Final output sent to browser
DEBUG - 2016-09-25 00:36:33 --> Total execution time: 2.4261
DEBUG - 2016-09-25 00:36:33 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:33 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Router Class Initialized
ERROR - 2016-09-25 00:36:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:33 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:33 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Router Class Initialized
ERROR - 2016-09-25 00:36:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:33 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:33 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:33 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:33 --> UTF-8 Support Enabled
ERROR - 2016-09-25 00:36:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:33 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:33 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Router Class Initialized
ERROR - 2016-09-25 00:36:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:33 --> UTF-8 Support Enabled
ERROR - 2016-09-25 00:36:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:33 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Router Class Initialized
ERROR - 2016-09-25 00:36:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:33 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:33 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:33 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:33 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:33 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Hooks Class Initialized
ERROR - 2016-09-25 00:36:33 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:36:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:33 --> URI Class Initialized
ERROR - 2016-09-25 00:36:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:33 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:33 --> UTF-8 Support Enabled
ERROR - 2016-09-25 00:36:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:33 --> Config Class Initialized
DEBUG - 2016-09-25 00:36:33 --> URI Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:36:33 --> Router Class Initialized
DEBUG - 2016-09-25 00:36:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:36:33 --> URI Class Initialized
ERROR - 2016-09-25 00:36:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:36:33 --> Router Class Initialized
ERROR - 2016-09-25 00:36:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:38:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:38:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:38:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Output Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Security Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Input Class Initialized
DEBUG - 2016-09-25 00:38:02 --> XSS Filtering completed
DEBUG - 2016-09-25 00:38:02 --> XSS Filtering completed
DEBUG - 2016-09-25 00:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:38:02 --> Language Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Loader Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:38:02 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:38:02 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:38:02 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:38:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:38:02 --> Session Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:38:02 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Session routines successfully run
ERROR - 2016-09-25 00:38:02 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:38:02 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:38:02 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:38:02 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:38:02 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Table Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Model Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Model Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:38:02 --> Model Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Controller Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:38:02 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-25 00:38:02 --> Severity: Warning  --> fopen(http://localhost:811/alumni/application/uploads\request.log): failed to open stream: HTTP wrapper does not support writeable connections C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 234
ERROR - 2016-09-25 00:38:02 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 235
ERROR - 2016-09-25 00:38:02 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 236
DEBUG - 2016-09-25 00:38:02 --> Final output sent to browser
DEBUG - 2016-09-25 00:38:02 --> Total execution time: 0.1300
DEBUG - 2016-09-25 00:38:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:38:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:38:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Output Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Security Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Input Class Initialized
DEBUG - 2016-09-25 00:38:02 --> XSS Filtering completed
DEBUG - 2016-09-25 00:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:38:02 --> Language Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Loader Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:38:02 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:38:02 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:38:02 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:38:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:38:02 --> Session Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:38:02 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Session routines successfully run
ERROR - 2016-09-25 00:38:02 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:38:02 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:38:02 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:38:02 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:38:02 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Table Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Model Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Model Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:38:02 --> Model Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Controller Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:38:02 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:38:02 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:38:04 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:38:04 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:38:04 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:38:04 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:38:04 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:38:04 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:38:04 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:38:04 --> Final output sent to browser
DEBUG - 2016-09-25 00:38:04 --> Total execution time: 2.3520
DEBUG - 2016-09-25 00:38:05 --> Config Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:38:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:38:05 --> URI Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Router Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Config Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:38:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:38:05 --> URI Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Router Class Initialized
ERROR - 2016-09-25 00:38:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:38:05 --> Config Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Config Class Initialized
DEBUG - 2016-09-25 00:38:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:38:05 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:38:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:38:05 --> URI Class Initialized
ERROR - 2016-09-25 00:38:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:38:05 --> Router Class Initialized
ERROR - 2016-09-25 00:38:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:38:05 --> URI Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Router Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Config Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:38:05 --> UTF-8 Support Enabled
ERROR - 2016-09-25 00:38:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:38:05 --> URI Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Router Class Initialized
ERROR - 2016-09-25 00:38:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:38:05 --> Config Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:38:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:38:05 --> URI Class Initialized
DEBUG - 2016-09-25 00:38:05 --> Router Class Initialized
ERROR - 2016-09-25 00:38:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:38:58 --> Config Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:38:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:38:58 --> URI Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Router Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Output Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Security Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Input Class Initialized
DEBUG - 2016-09-25 00:38:58 --> XSS Filtering completed
DEBUG - 2016-09-25 00:38:58 --> XSS Filtering completed
DEBUG - 2016-09-25 00:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:38:58 --> Language Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Loader Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:38:58 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:38:58 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:38:58 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:38:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:38:58 --> Session Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:38:58 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Session routines successfully run
ERROR - 2016-09-25 00:38:58 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:38:58 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:38:58 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:38:58 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:38:58 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Table Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:38:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Controller Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:38:58 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-25 00:38:58 --> Severity: Warning  --> fopen(http://localhost:811/alumni/application/uploads\request.log): failed to open stream: HTTP wrapper does not support writeable connections C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 234
ERROR - 2016-09-25 00:38:58 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 235
ERROR - 2016-09-25 00:38:58 --> Severity: Warning  --> fclose() expects parameter 1 to be resource, boolean given C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 236
DEBUG - 2016-09-25 00:38:58 --> Final output sent to browser
DEBUG - 2016-09-25 00:38:58 --> Total execution time: 0.1230
DEBUG - 2016-09-25 00:38:58 --> Config Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:38:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:38:58 --> URI Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Router Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Output Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Security Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Input Class Initialized
DEBUG - 2016-09-25 00:38:58 --> XSS Filtering completed
DEBUG - 2016-09-25 00:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:38:58 --> Language Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Loader Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:38:58 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:38:58 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:38:58 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:38:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:38:58 --> Session Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:38:58 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Session routines successfully run
ERROR - 2016-09-25 00:38:58 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:38:58 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:38:58 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:38:58 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:38:58 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Table Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:38:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Controller Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:38:58 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:38:58 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:39:01 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:39:01 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:39:01 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:39:01 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:39:01 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:39:01 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:39:01 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:39:01 --> Final output sent to browser
DEBUG - 2016-09-25 00:39:01 --> Total execution time: 2.4800
DEBUG - 2016-09-25 00:39:01 --> Config Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Config Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:39:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:39:01 --> URI Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Router Class Initialized
ERROR - 2016-09-25 00:39:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:39:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:39:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:39:01 --> URI Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Router Class Initialized
ERROR - 2016-09-25 00:39:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:39:01 --> Config Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:39:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:39:01 --> URI Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Router Class Initialized
ERROR - 2016-09-25 00:39:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:39:01 --> Config Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Config Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:39:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:39:01 --> URI Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Router Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:39:01 --> UTF-8 Support Enabled
ERROR - 2016-09-25 00:39:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:39:01 --> Config Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:39:01 --> URI Class Initialized
DEBUG - 2016-09-25 00:39:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:39:01 --> URI Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Router Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Router Class Initialized
ERROR - 2016-09-25 00:39:01 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:39:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:39:01 --> Config Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:39:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:39:01 --> URI Class Initialized
DEBUG - 2016-09-25 00:39:01 --> Router Class Initialized
ERROR - 2016-09-25 00:39:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:41:59 --> Config Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:41:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:41:59 --> URI Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Router Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Output Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Security Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Input Class Initialized
DEBUG - 2016-09-25 00:41:59 --> XSS Filtering completed
DEBUG - 2016-09-25 00:41:59 --> XSS Filtering completed
DEBUG - 2016-09-25 00:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:41:59 --> Language Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Loader Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:41:59 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:41:59 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:41:59 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:41:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:41:59 --> Session Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:41:59 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Session routines successfully run
ERROR - 2016-09-25 00:41:59 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:41:59 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:41:59 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:41:59 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:41:59 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Table Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:41:59 --> Model Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Controller Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:41:59 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:41:59 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-25 00:41:59 --> Severity: Warning  --> fopen(application//test_files/test.txt): failed to open stream: No such file or directory C:\xampp\htdocs\www\alumni\system\helpers\file_helper.php 90
DEBUG - 2016-09-25 00:41:59 --> Final output sent to browser
DEBUG - 2016-09-25 00:41:59 --> Total execution time: 0.1200
DEBUG - 2016-09-25 00:42:00 --> Config Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:42:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:42:00 --> URI Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Router Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Output Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Security Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Input Class Initialized
DEBUG - 2016-09-25 00:42:00 --> XSS Filtering completed
DEBUG - 2016-09-25 00:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:42:00 --> Language Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Loader Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:42:00 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:42:00 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:42:00 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:42:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:42:00 --> Session Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:42:00 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Session routines successfully run
ERROR - 2016-09-25 00:42:00 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:42:00 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:42:00 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:42:00 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:42:00 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Table Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Model Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Model Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:42:00 --> Model Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Controller Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:42:00 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:42:00 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:42:02 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:42:02 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:42:02 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:42:02 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:42:02 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:42:02 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:42:02 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:42:02 --> Final output sent to browser
DEBUG - 2016-09-25 00:42:02 --> Total execution time: 2.5560
DEBUG - 2016-09-25 00:42:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:42:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:42:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Router Class Initialized
ERROR - 2016-09-25 00:42:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:42:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:42:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:42:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Router Class Initialized
ERROR - 2016-09-25 00:42:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:42:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:42:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:42:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:42:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:42:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:42:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:42:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Router Class Initialized
ERROR - 2016-09-25 00:42:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:42:02 --> Utf8 Class Initialized
ERROR - 2016-09-25 00:42:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:42:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:42:02 --> URI Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Config Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Router Class Initialized
DEBUG - 2016-09-25 00:42:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:42:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:42:02 --> URI Class Initialized
ERROR - 2016-09-25 00:42:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:42:02 --> Router Class Initialized
ERROR - 2016-09-25 00:42:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:43:58 --> Config Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:43:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:43:58 --> URI Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Router Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Output Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Security Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Input Class Initialized
DEBUG - 2016-09-25 00:43:58 --> XSS Filtering completed
DEBUG - 2016-09-25 00:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:43:58 --> Language Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Loader Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:43:58 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:43:58 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:43:58 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:43:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:43:58 --> Session Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:43:58 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Session routines successfully run
ERROR - 2016-09-25 00:43:58 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:43:58 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:43:58 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:43:58 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:43:58 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Table Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:43:58 --> Model Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Controller Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:43:58 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:43:58 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:44:01 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:44:01 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:44:01 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:44:01 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:44:01 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:44:01 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:44:01 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:44:01 --> Final output sent to browser
DEBUG - 2016-09-25 00:44:01 --> Total execution time: 2.4570
DEBUG - 2016-09-25 00:44:01 --> Config Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:44:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:44:01 --> URI Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Router Class Initialized
ERROR - 2016-09-25 00:44:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:44:01 --> Config Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:44:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:44:01 --> URI Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Router Class Initialized
ERROR - 2016-09-25 00:44:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:44:01 --> Config Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Config Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Config Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Config Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:44:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:44:01 --> URI Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Router Class Initialized
ERROR - 2016-09-25 00:44:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:44:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:44:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:44:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:44:01 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:44:01 --> URI Class Initialized
DEBUG - 2016-09-25 00:44:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:44:01 --> URI Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Router Class Initialized
DEBUG - 2016-09-25 00:44:01 --> URI Class Initialized
DEBUG - 2016-09-25 00:44:01 --> Router Class Initialized
ERROR - 2016-09-25 00:44:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:44:01 --> Router Class Initialized
ERROR - 2016-09-25 00:44:01 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:44:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:44:04 --> Config Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:44:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:44:04 --> URI Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Router Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Output Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Security Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Input Class Initialized
DEBUG - 2016-09-25 00:44:04 --> XSS Filtering completed
DEBUG - 2016-09-25 00:44:04 --> XSS Filtering completed
DEBUG - 2016-09-25 00:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:44:04 --> Language Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Loader Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:44:04 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:44:04 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:44:04 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:44:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:44:04 --> Session Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:44:04 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Session routines successfully run
ERROR - 2016-09-25 00:44:04 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:44:04 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:44:04 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:44:04 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:44:04 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Table Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Model Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Model Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:44:04 --> Model Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Controller Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:44:04 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:44:04 --> Final output sent to browser
DEBUG - 2016-09-25 00:44:04 --> Total execution time: 0.1350
DEBUG - 2016-09-25 00:44:04 --> Config Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:44:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:44:04 --> URI Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Router Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Output Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Security Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Input Class Initialized
DEBUG - 2016-09-25 00:44:04 --> XSS Filtering completed
DEBUG - 2016-09-25 00:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:44:04 --> Language Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Loader Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:44:04 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:44:04 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:44:04 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:44:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:44:04 --> Session Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:44:04 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Session routines successfully run
ERROR - 2016-09-25 00:44:04 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:44:04 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:44:04 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:44:04 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:44:04 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Table Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Model Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Model Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:44:04 --> Model Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Controller Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:44:04 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:44:04 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:44:06 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:44:06 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:44:06 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:44:06 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:44:06 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:44:06 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:44:06 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:44:06 --> Final output sent to browser
DEBUG - 2016-09-25 00:44:06 --> Total execution time: 2.2401
DEBUG - 2016-09-25 00:44:06 --> Config Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Config Class Initialized
DEBUG - 2016-09-25 00:44:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:44:06 --> Config Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:44:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:44:06 --> URI Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Config Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Router Class Initialized
DEBUG - 2016-09-25 00:44:06 --> URI Class Initialized
ERROR - 2016-09-25 00:44:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:44:06 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:44:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:44:06 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Router Class Initialized
DEBUG - 2016-09-25 00:44:06 --> URI Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Config Class Initialized
DEBUG - 2016-09-25 00:44:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:44:06 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:44:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:44:06 --> URI Class Initialized
ERROR - 2016-09-25 00:44:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:44:06 --> Router Class Initialized
DEBUG - 2016-09-25 00:44:06 --> URI Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Router Class Initialized
ERROR - 2016-09-25 00:44:06 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:44:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:44:06 --> Router Class Initialized
ERROR - 2016-09-25 00:44:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:44:06 --> Config Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:44:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:44:06 --> URI Class Initialized
DEBUG - 2016-09-25 00:44:06 --> Router Class Initialized
ERROR - 2016-09-25 00:44:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:46:01 --> Config Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:46:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:01 --> URI Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Router Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Output Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Security Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Input Class Initialized
DEBUG - 2016-09-25 00:46:01 --> XSS Filtering completed
DEBUG - 2016-09-25 00:46:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:46:01 --> Language Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Loader Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:46:01 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:46:01 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:46:01 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:46:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:46:01 --> Session Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:46:01 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Session routines successfully run
ERROR - 2016-09-25 00:46:01 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:46:01 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:46:01 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:46:01 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:46:01 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Table Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Model Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Model Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:46:01 --> Model Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Controller Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:46:01 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:46:01 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:46:03 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:46:03 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:46:03 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:46:03 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:46:03 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:46:03 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:46:03 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:46:03 --> Final output sent to browser
DEBUG - 2016-09-25 00:46:03 --> Total execution time: 2.3411
DEBUG - 2016-09-25 00:46:03 --> Config Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Config Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:46:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:03 --> URI Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:46:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:03 --> Config Class Initialized
DEBUG - 2016-09-25 00:46:03 --> URI Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Router Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:46:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:03 --> Router Class Initialized
ERROR - 2016-09-25 00:46:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:46:03 --> Config Class Initialized
DEBUG - 2016-09-25 00:46:03 --> URI Class Initialized
ERROR - 2016-09-25 00:46:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:46:03 --> Router Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Utf8 Class Initialized
ERROR - 2016-09-25 00:46:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:46:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:03 --> URI Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Router Class Initialized
ERROR - 2016-09-25 00:46:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:46:03 --> Config Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:46:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:03 --> URI Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Router Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Config Class Initialized
ERROR - 2016-09-25 00:46:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:46:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:03 --> URI Class Initialized
DEBUG - 2016-09-25 00:46:03 --> Router Class Initialized
ERROR - 2016-09-25 00:46:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:46:08 --> Config Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:46:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:08 --> URI Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Router Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Output Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Security Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Input Class Initialized
DEBUG - 2016-09-25 00:46:08 --> XSS Filtering completed
DEBUG - 2016-09-25 00:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:46:08 --> Language Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Loader Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:46:08 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:46:08 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:46:08 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:46:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:46:08 --> Session Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:46:08 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Session routines successfully run
ERROR - 2016-09-25 00:46:08 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:46:08 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:46:08 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:46:08 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:46:08 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Table Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Model Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Model Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:46:08 --> Model Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Controller Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:46:08 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:46:08 --> Final output sent to browser
DEBUG - 2016-09-25 00:46:08 --> Total execution time: 0.1600
DEBUG - 2016-09-25 00:46:08 --> Config Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:46:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:08 --> URI Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Router Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Output Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Security Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Input Class Initialized
DEBUG - 2016-09-25 00:46:08 --> XSS Filtering completed
DEBUG - 2016-09-25 00:46:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:46:08 --> Language Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Loader Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:46:08 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:46:08 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:46:08 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:46:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:46:08 --> Session Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:46:08 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Session routines successfully run
ERROR - 2016-09-25 00:46:08 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:46:08 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:46:08 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:46:08 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:46:08 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Table Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Model Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Model Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:46:08 --> Model Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Controller Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:46:08 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:46:08 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:46:11 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:46:11 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:46:11 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:46:11 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:46:11 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:46:11 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:46:11 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:46:11 --> Final output sent to browser
DEBUG - 2016-09-25 00:46:11 --> Total execution time: 2.5171
DEBUG - 2016-09-25 00:46:11 --> Config Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:46:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:11 --> URI Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Router Class Initialized
ERROR - 2016-09-25 00:46:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:46:11 --> Config Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:46:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:11 --> URI Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Config Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Router Class Initialized
DEBUG - 2016-09-25 00:46:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:11 --> Config Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:11 --> URI Class Initialized
ERROR - 2016-09-25 00:46:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:46:11 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:46:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:11 --> Router Class Initialized
DEBUG - 2016-09-25 00:46:11 --> URI Class Initialized
ERROR - 2016-09-25 00:46:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:46:11 --> Router Class Initialized
ERROR - 2016-09-25 00:46:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:46:11 --> Config Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:46:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:11 --> URI Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Router Class Initialized
ERROR - 2016-09-25 00:46:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:46:11 --> Config Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:46:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:46:11 --> URI Class Initialized
DEBUG - 2016-09-25 00:46:11 --> Router Class Initialized
ERROR - 2016-09-25 00:46:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:47:16 --> Config Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:47:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:47:16 --> URI Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Router Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Output Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Security Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Input Class Initialized
DEBUG - 2016-09-25 00:47:16 --> XSS Filtering completed
DEBUG - 2016-09-25 00:47:16 --> XSS Filtering completed
DEBUG - 2016-09-25 00:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:47:16 --> Language Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Loader Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:47:16 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:47:16 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:47:16 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:47:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:47:16 --> Session Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:47:16 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Session routines successfully run
ERROR - 2016-09-25 00:47:16 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:47:16 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:47:16 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:47:16 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:47:16 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Table Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Model Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Model Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:47:16 --> Model Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Controller Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:47:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:47:16 --> Final output sent to browser
DEBUG - 2016-09-25 00:47:16 --> Total execution time: 0.1170
DEBUG - 2016-09-25 00:47:16 --> Config Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:47:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:47:16 --> URI Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Router Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Output Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Security Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Input Class Initialized
DEBUG - 2016-09-25 00:47:16 --> XSS Filtering completed
DEBUG - 2016-09-25 00:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 00:47:16 --> Language Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Loader Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Helper loaded: url_helper
DEBUG - 2016-09-25 00:47:16 --> Helper loaded: form_helper
DEBUG - 2016-09-25 00:47:16 --> Helper loaded: func_helper
DEBUG - 2016-09-25 00:47:16 --> Database Driver Class Initialized
ERROR - 2016-09-25 00:47:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 00:47:16 --> Session Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Helper loaded: string_helper
DEBUG - 2016-09-25 00:47:16 --> Encrypt Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Session routines successfully run
ERROR - 2016-09-25 00:47:16 --> Could not find the language line "first_link"
ERROR - 2016-09-25 00:47:16 --> Could not find the language line "last_link"
ERROR - 2016-09-25 00:47:16 --> Could not find the language line "next_link"
ERROR - 2016-09-25 00:47:16 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 00:47:16 --> Pagination Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Table Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Model Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Model Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Helper loaded: file_helper
DEBUG - 2016-09-25 00:47:16 --> Model Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Controller Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Form Validation Class Initialized
DEBUG - 2016-09-25 00:47:16 --> Helper loaded: language_helper
DEBUG - 2016-09-25 00:47:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 00:47:18 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 00:47:18 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 00:47:18 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 00:47:18 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 00:47:18 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 00:47:18 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 00:47:18 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 00:47:18 --> Final output sent to browser
DEBUG - 2016-09-25 00:47:18 --> Total execution time: 2.3981
DEBUG - 2016-09-25 00:47:18 --> Config Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:47:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:47:18 --> URI Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Router Class Initialized
ERROR - 2016-09-25 00:47:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:47:18 --> Config Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:47:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:47:18 --> URI Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Config Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Router Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:47:18 --> UTF-8 Support Enabled
ERROR - 2016-09-25 00:47:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:47:18 --> Config Class Initialized
DEBUG - 2016-09-25 00:47:18 --> URI Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Config Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Router Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:47:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:47:18 --> Utf8 Class Initialized
ERROR - 2016-09-25 00:47:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:47:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:47:18 --> URI Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Router Class Initialized
DEBUG - 2016-09-25 00:47:18 --> URI Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Router Class Initialized
ERROR - 2016-09-25 00:47:18 --> 404 Page Not Found --> application
ERROR - 2016-09-25 00:47:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 00:47:18 --> Config Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Hooks Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Utf8 Class Initialized
DEBUG - 2016-09-25 00:47:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 00:47:18 --> URI Class Initialized
DEBUG - 2016-09-25 00:47:18 --> Router Class Initialized
ERROR - 2016-09-25 00:47:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 21:41:32 --> Config Class Initialized
DEBUG - 2016-09-25 21:41:32 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:41:32 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:41:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:41:32 --> URI Class Initialized
DEBUG - 2016-09-25 21:41:32 --> Router Class Initialized
DEBUG - 2016-09-25 21:41:32 --> No URI present. Default controller set.
DEBUG - 2016-09-25 21:41:32 --> Output Class Initialized
DEBUG - 2016-09-25 21:41:32 --> Security Class Initialized
DEBUG - 2016-09-25 21:41:32 --> Input Class Initialized
DEBUG - 2016-09-25 21:41:32 --> XSS Filtering completed
DEBUG - 2016-09-25 21:41:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 21:41:32 --> Language Class Initialized
DEBUG - 2016-09-25 21:41:32 --> Loader Class Initialized
DEBUG - 2016-09-25 21:41:32 --> Helper loaded: url_helper
DEBUG - 2016-09-25 21:41:32 --> Helper loaded: form_helper
DEBUG - 2016-09-25 21:41:32 --> Helper loaded: func_helper
DEBUG - 2016-09-25 21:41:32 --> Database Driver Class Initialized
ERROR - 2016-09-25 21:41:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-25 21:41:32 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 21:41:32 --> Session Class Initialized
DEBUG - 2016-09-25 21:41:32 --> Helper loaded: string_helper
DEBUG - 2016-09-25 21:41:32 --> Encrypt Class Initialized
DEBUG - 2016-09-25 21:41:32 --> A session cookie was not found.
DEBUG - 2016-09-25 21:41:32 --> Session routines successfully run
ERROR - 2016-09-25 21:41:32 --> Could not find the language line "first_link"
ERROR - 2016-09-25 21:41:32 --> Could not find the language line "last_link"
ERROR - 2016-09-25 21:41:32 --> Could not find the language line "next_link"
ERROR - 2016-09-25 21:41:32 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 21:41:32 --> Pagination Class Initialized
DEBUG - 2016-09-25 21:41:32 --> Table Class Initialized
DEBUG - 2016-09-25 21:41:32 --> Model Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Config Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:42:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:42:30 --> URI Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Router Class Initialized
DEBUG - 2016-09-25 21:42:30 --> No URI present. Default controller set.
DEBUG - 2016-09-25 21:42:30 --> Output Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Security Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Input Class Initialized
DEBUG - 2016-09-25 21:42:30 --> XSS Filtering completed
DEBUG - 2016-09-25 21:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 21:42:30 --> Language Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Loader Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Helper loaded: url_helper
DEBUG - 2016-09-25 21:42:30 --> Helper loaded: form_helper
DEBUG - 2016-09-25 21:42:30 --> Helper loaded: func_helper
DEBUG - 2016-09-25 21:42:30 --> Database Driver Class Initialized
ERROR - 2016-09-25 21:42:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 21:42:30 --> Session Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Helper loaded: string_helper
DEBUG - 2016-09-25 21:42:30 --> Encrypt Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Session routines successfully run
ERROR - 2016-09-25 21:42:30 --> Could not find the language line "first_link"
ERROR - 2016-09-25 21:42:30 --> Could not find the language line "last_link"
ERROR - 2016-09-25 21:42:30 --> Could not find the language line "next_link"
ERROR - 2016-09-25 21:42:30 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 21:42:30 --> Pagination Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Table Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Model Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Model Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Helper loaded: file_helper
DEBUG - 2016-09-25 21:42:30 --> Model Class Initialized
DEBUG - 2016-09-25 21:42:30 --> Controller Class Initialized
DEBUG - 2016-09-25 21:42:33 --> Helper loaded: language_helper
DEBUG - 2016-09-25 21:42:33 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 21:42:36 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-25 21:42:39 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 21:42:39 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-25 21:42:39 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-25 21:42:39 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-25 21:42:39 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-25 21:42:39 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-25 21:42:39 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-25 21:42:39 --> Final output sent to browser
DEBUG - 2016-09-25 21:42:39 --> Total execution time: 8.6305
DEBUG - 2016-09-25 21:42:39 --> Config Class Initialized
DEBUG - 2016-09-25 21:42:39 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:42:39 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:42:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:42:39 --> URI Class Initialized
DEBUG - 2016-09-25 21:42:39 --> Router Class Initialized
ERROR - 2016-09-25 21:42:39 --> 404 Page Not Found --> js
DEBUG - 2016-09-25 21:42:39 --> Config Class Initialized
DEBUG - 2016-09-25 21:42:39 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:42:39 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:42:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:42:39 --> URI Class Initialized
DEBUG - 2016-09-25 21:42:39 --> Router Class Initialized
ERROR - 2016-09-25 21:42:39 --> 404 Page Not Found --> js
DEBUG - 2016-09-25 21:44:11 --> Config Class Initialized
DEBUG - 2016-09-25 21:44:11 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:44:11 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:44:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:44:11 --> URI Class Initialized
DEBUG - 2016-09-25 21:44:11 --> Router Class Initialized
DEBUG - 2016-09-25 21:44:11 --> No URI present. Default controller set.
DEBUG - 2016-09-25 21:44:11 --> Output Class Initialized
DEBUG - 2016-09-25 21:44:11 --> Security Class Initialized
DEBUG - 2016-09-25 21:44:11 --> Input Class Initialized
DEBUG - 2016-09-25 21:44:11 --> XSS Filtering completed
DEBUG - 2016-09-25 21:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 21:44:11 --> Language Class Initialized
DEBUG - 2016-09-25 21:44:11 --> Loader Class Initialized
DEBUG - 2016-09-25 21:44:11 --> Helper loaded: url_helper
DEBUG - 2016-09-25 21:44:11 --> Helper loaded: form_helper
DEBUG - 2016-09-25 21:44:11 --> Helper loaded: func_helper
DEBUG - 2016-09-25 21:44:11 --> Database Driver Class Initialized
ERROR - 2016-09-25 21:44:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-25 21:44:11 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 21:44:11 --> Session Class Initialized
DEBUG - 2016-09-25 21:44:11 --> Helper loaded: string_helper
DEBUG - 2016-09-25 21:44:11 --> Encrypt Class Initialized
DEBUG - 2016-09-25 21:44:11 --> Session routines successfully run
ERROR - 2016-09-25 21:44:11 --> Could not find the language line "first_link"
ERROR - 2016-09-25 21:44:11 --> Could not find the language line "last_link"
ERROR - 2016-09-25 21:44:11 --> Could not find the language line "next_link"
ERROR - 2016-09-25 21:44:11 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 21:44:11 --> Pagination Class Initialized
DEBUG - 2016-09-25 21:44:11 --> Table Class Initialized
DEBUG - 2016-09-25 21:44:11 --> Model Class Initialized
DEBUG - 2016-09-25 21:44:11 --> Model Class Initialized
DEBUG - 2016-09-25 21:44:11 --> Helper loaded: file_helper
DEBUG - 2016-09-25 21:44:11 --> Model Class Initialized
DEBUG - 2016-09-25 21:44:11 --> Controller Class Initialized
DEBUG - 2016-09-25 21:44:13 --> Helper loaded: language_helper
DEBUG - 2016-09-25 21:44:13 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 21:44:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-25 21:44:19 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 21:44:19 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-25 21:44:19 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-25 21:44:19 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-25 21:44:19 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-25 21:44:19 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-25 21:44:19 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-25 21:44:19 --> Final output sent to browser
DEBUG - 2016-09-25 21:44:19 --> Total execution time: 8.6165
DEBUG - 2016-09-25 21:44:20 --> Config Class Initialized
DEBUG - 2016-09-25 21:44:20 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:44:20 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:44:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:44:20 --> URI Class Initialized
DEBUG - 2016-09-25 21:44:20 --> Router Class Initialized
ERROR - 2016-09-25 21:44:20 --> 404 Page Not Found --> js
DEBUG - 2016-09-25 21:44:43 --> Config Class Initialized
DEBUG - 2016-09-25 21:44:43 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:44:43 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:44:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:44:43 --> URI Class Initialized
DEBUG - 2016-09-25 21:44:43 --> Router Class Initialized
DEBUG - 2016-09-25 21:44:43 --> Output Class Initialized
DEBUG - 2016-09-25 21:44:43 --> Security Class Initialized
DEBUG - 2016-09-25 21:44:43 --> Input Class Initialized
DEBUG - 2016-09-25 21:44:43 --> XSS Filtering completed
DEBUG - 2016-09-25 21:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 21:44:43 --> Language Class Initialized
DEBUG - 2016-09-25 21:44:43 --> Loader Class Initialized
DEBUG - 2016-09-25 21:44:43 --> Helper loaded: url_helper
DEBUG - 2016-09-25 21:44:43 --> Helper loaded: form_helper
DEBUG - 2016-09-25 21:44:43 --> Helper loaded: func_helper
DEBUG - 2016-09-25 21:44:43 --> Database Driver Class Initialized
ERROR - 2016-09-25 21:44:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-25 21:44:43 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 21:44:43 --> Session Class Initialized
DEBUG - 2016-09-25 21:44:43 --> Helper loaded: string_helper
DEBUG - 2016-09-25 21:44:43 --> Encrypt Class Initialized
DEBUG - 2016-09-25 21:44:43 --> Session routines successfully run
ERROR - 2016-09-25 21:44:43 --> Could not find the language line "first_link"
ERROR - 2016-09-25 21:44:43 --> Could not find the language line "last_link"
ERROR - 2016-09-25 21:44:43 --> Could not find the language line "next_link"
ERROR - 2016-09-25 21:44:43 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 21:44:43 --> Pagination Class Initialized
DEBUG - 2016-09-25 21:44:43 --> Table Class Initialized
DEBUG - 2016-09-25 21:44:43 --> Model Class Initialized
DEBUG - 2016-09-25 21:44:43 --> Model Class Initialized
DEBUG - 2016-09-25 21:44:43 --> Helper loaded: file_helper
DEBUG - 2016-09-25 21:44:44 --> Model Class Initialized
DEBUG - 2016-09-25 21:44:44 --> Controller Class Initialized
DEBUG - 2016-09-25 21:44:46 --> Helper loaded: language_helper
DEBUG - 2016-09-25 21:44:46 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 21:44:46 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 21:44:46 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-25 21:44:46 --> File loaded: application/views/signup/main.php
DEBUG - 2016-09-25 21:44:46 --> File loaded: application/views/signup/login.php
DEBUG - 2016-09-25 21:44:46 --> File loaded: application/views/signup/personal.php
ERROR - 2016-09-25 21:44:46 --> Could not find the language line "register"
DEBUG - 2016-09-25 21:44:46 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-09-25 21:44:46 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-25 21:44:46 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-25 21:44:46 --> Final output sent to browser
DEBUG - 2016-09-25 21:44:46 --> Total execution time: 2.6762
DEBUG - 2016-09-25 21:44:46 --> Config Class Initialized
DEBUG - 2016-09-25 21:44:46 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:44:46 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:44:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:44:46 --> URI Class Initialized
DEBUG - 2016-09-25 21:44:46 --> Router Class Initialized
ERROR - 2016-09-25 21:44:46 --> 404 Page Not Found --> js
DEBUG - 2016-09-25 21:45:17 --> Config Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:45:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:45:17 --> URI Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Router Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Output Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Security Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Input Class Initialized
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 21:45:17 --> Language Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Loader Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Helper loaded: url_helper
DEBUG - 2016-09-25 21:45:17 --> Helper loaded: form_helper
DEBUG - 2016-09-25 21:45:17 --> Helper loaded: func_helper
DEBUG - 2016-09-25 21:45:17 --> Database Driver Class Initialized
ERROR - 2016-09-25 21:45:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 21:45:17 --> Session Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Helper loaded: string_helper
DEBUG - 2016-09-25 21:45:17 --> Encrypt Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Session routines successfully run
ERROR - 2016-09-25 21:45:17 --> Could not find the language line "first_link"
ERROR - 2016-09-25 21:45:17 --> Could not find the language line "last_link"
ERROR - 2016-09-25 21:45:17 --> Could not find the language line "next_link"
ERROR - 2016-09-25 21:45:17 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 21:45:17 --> Pagination Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Table Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Model Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Model Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Helper loaded: file_helper
DEBUG - 2016-09-25 21:45:17 --> Model Class Initialized
DEBUG - 2016-09-25 21:45:17 --> Controller Class Initialized
DEBUG - 2016-09-25 21:45:20 --> Helper loaded: language_helper
DEBUG - 2016-09-25 21:45:20 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 21:45:20 --> Form Validation Class Initialized
ERROR - 2016-09-25 21:45:20 --> Could not find the language line "year"
ERROR - 2016-09-25 21:45:20 --> Could not find the language line "retype"
DEBUG - 2016-09-25 21:45:20 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> Config Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:45:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:45:21 --> URI Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Router Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Output Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Security Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Input Class Initialized
DEBUG - 2016-09-25 21:45:21 --> XSS Filtering completed
DEBUG - 2016-09-25 21:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 21:45:21 --> Language Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Loader Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Helper loaded: url_helper
DEBUG - 2016-09-25 21:45:21 --> Helper loaded: form_helper
DEBUG - 2016-09-25 21:45:21 --> Helper loaded: func_helper
DEBUG - 2016-09-25 21:45:21 --> Database Driver Class Initialized
ERROR - 2016-09-25 21:45:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 21:45:21 --> Session Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Helper loaded: string_helper
DEBUG - 2016-09-25 21:45:21 --> Encrypt Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Session routines successfully run
ERROR - 2016-09-25 21:45:21 --> Could not find the language line "first_link"
ERROR - 2016-09-25 21:45:21 --> Could not find the language line "last_link"
ERROR - 2016-09-25 21:45:21 --> Could not find the language line "next_link"
ERROR - 2016-09-25 21:45:21 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 21:45:21 --> Pagination Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Table Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Model Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Model Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Helper loaded: file_helper
DEBUG - 2016-09-25 21:45:21 --> Model Class Initialized
DEBUG - 2016-09-25 21:45:21 --> Controller Class Initialized
DEBUG - 2016-09-25 21:45:24 --> Helper loaded: language_helper
DEBUG - 2016-09-25 21:45:24 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-25 21:45:24 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-09-25 21:45:24 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 21:45:24 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-25 21:45:24 --> File loaded: application/views/signup/complete.php
DEBUG - 2016-09-25 21:45:24 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-25 21:45:24 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-25 21:45:24 --> Final output sent to browser
DEBUG - 2016-09-25 21:45:24 --> Total execution time: 3.1025
DEBUG - 2016-09-25 21:45:24 --> Config Class Initialized
DEBUG - 2016-09-25 21:45:24 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:45:24 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:45:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:45:24 --> URI Class Initialized
DEBUG - 2016-09-25 21:45:24 --> Router Class Initialized
ERROR - 2016-09-25 21:45:24 --> 404 Page Not Found --> js
DEBUG - 2016-09-25 21:46:42 --> Config Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:46:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:46:42 --> URI Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Router Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Output Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Security Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Input Class Initialized
DEBUG - 2016-09-25 21:46:42 --> XSS Filtering completed
DEBUG - 2016-09-25 21:46:42 --> XSS Filtering completed
DEBUG - 2016-09-25 21:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 21:46:42 --> Language Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Loader Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Helper loaded: url_helper
DEBUG - 2016-09-25 21:46:42 --> Helper loaded: form_helper
DEBUG - 2016-09-25 21:46:42 --> Helper loaded: func_helper
DEBUG - 2016-09-25 21:46:42 --> Database Driver Class Initialized
ERROR - 2016-09-25 21:46:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 21:46:42 --> Session Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Helper loaded: string_helper
DEBUG - 2016-09-25 21:46:42 --> Encrypt Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Session routines successfully run
ERROR - 2016-09-25 21:46:42 --> Could not find the language line "first_link"
ERROR - 2016-09-25 21:46:42 --> Could not find the language line "last_link"
ERROR - 2016-09-25 21:46:42 --> Could not find the language line "next_link"
ERROR - 2016-09-25 21:46:42 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 21:46:42 --> Pagination Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Table Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Model Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Model Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Helper loaded: file_helper
DEBUG - 2016-09-25 21:46:42 --> Model Class Initialized
DEBUG - 2016-09-25 21:46:42 --> Controller Class Initialized
DEBUG - 2016-09-25 21:46:44 --> Helper loaded: language_helper
DEBUG - 2016-09-25 21:46:44 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 21:46:44 --> Upload Class Initialized
DEBUG - 2016-09-25 21:46:44 --> Image Lib Class Initialized
DEBUG - 2016-09-25 21:46:45 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 21:46:45 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-25 21:46:45 --> File loaded: application/views/signup/success.php
DEBUG - 2016-09-25 21:46:45 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-25 21:46:45 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-25 21:46:45 --> Final output sent to browser
DEBUG - 2016-09-25 21:46:45 --> Total execution time: 3.4101
DEBUG - 2016-09-25 21:46:45 --> Config Class Initialized
DEBUG - 2016-09-25 21:46:45 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:46:45 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:46:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:46:45 --> URI Class Initialized
DEBUG - 2016-09-25 21:46:45 --> Router Class Initialized
ERROR - 2016-09-25 21:46:45 --> 404 Page Not Found --> js
DEBUG - 2016-09-25 21:47:50 --> Config Class Initialized
DEBUG - 2016-09-25 21:47:50 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:47:50 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:47:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:47:50 --> URI Class Initialized
DEBUG - 2016-09-25 21:47:50 --> Router Class Initialized
DEBUG - 2016-09-25 21:47:50 --> Output Class Initialized
DEBUG - 2016-09-25 21:47:50 --> Security Class Initialized
DEBUG - 2016-09-25 21:47:50 --> Input Class Initialized
DEBUG - 2016-09-25 21:47:50 --> XSS Filtering completed
DEBUG - 2016-09-25 21:47:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 21:47:50 --> Language Class Initialized
DEBUG - 2016-09-25 21:47:50 --> Loader Class Initialized
DEBUG - 2016-09-25 21:47:50 --> Helper loaded: url_helper
DEBUG - 2016-09-25 21:47:50 --> Helper loaded: form_helper
DEBUG - 2016-09-25 21:47:50 --> Helper loaded: func_helper
DEBUG - 2016-09-25 21:47:51 --> Database Driver Class Initialized
ERROR - 2016-09-25 21:47:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 21:47:51 --> Session Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Helper loaded: string_helper
DEBUG - 2016-09-25 21:47:51 --> Encrypt Class Initialized
DEBUG - 2016-09-25 21:47:51 --> A session cookie was not found.
DEBUG - 2016-09-25 21:47:51 --> Session routines successfully run
ERROR - 2016-09-25 21:47:51 --> Could not find the language line "first_link"
ERROR - 2016-09-25 21:47:51 --> Could not find the language line "last_link"
ERROR - 2016-09-25 21:47:51 --> Could not find the language line "next_link"
ERROR - 2016-09-25 21:47:51 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 21:47:51 --> Pagination Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Table Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Model Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Model Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Helper loaded: file_helper
DEBUG - 2016-09-25 21:47:51 --> Model Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Controller Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Form Validation Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Config Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:47:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:47:51 --> URI Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Router Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Output Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Security Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Input Class Initialized
DEBUG - 2016-09-25 21:47:51 --> XSS Filtering completed
DEBUG - 2016-09-25 21:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 21:47:51 --> Language Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Loader Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Helper loaded: url_helper
DEBUG - 2016-09-25 21:47:51 --> Helper loaded: form_helper
DEBUG - 2016-09-25 21:47:51 --> Helper loaded: func_helper
DEBUG - 2016-09-25 21:47:51 --> Database Driver Class Initialized
ERROR - 2016-09-25 21:47:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 21:47:51 --> Session Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Helper loaded: string_helper
DEBUG - 2016-09-25 21:47:51 --> Encrypt Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Session routines successfully run
ERROR - 2016-09-25 21:47:51 --> Could not find the language line "first_link"
ERROR - 2016-09-25 21:47:51 --> Could not find the language line "last_link"
ERROR - 2016-09-25 21:47:51 --> Could not find the language line "next_link"
ERROR - 2016-09-25 21:47:51 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 21:47:51 --> Pagination Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Table Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Model Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Model Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Helper loaded: file_helper
DEBUG - 2016-09-25 21:47:51 --> Model Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Controller Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Helper loaded: language_helper
DEBUG - 2016-09-25 21:47:51 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 21:47:51 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 21:47:51 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-25 21:47:51 --> File loaded: application/views/login_form.php
DEBUG - 2016-09-25 21:47:51 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-25 21:47:51 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-25 21:47:51 --> Final output sent to browser
DEBUG - 2016-09-25 21:47:51 --> Total execution time: 0.1000
DEBUG - 2016-09-25 21:47:51 --> Config Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:47:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:47:51 --> URI Class Initialized
DEBUG - 2016-09-25 21:47:51 --> Router Class Initialized
ERROR - 2016-09-25 21:47:51 --> 404 Page Not Found --> js
DEBUG - 2016-09-25 21:48:00 --> Config Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:48:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:48:00 --> URI Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Router Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Output Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Security Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Input Class Initialized
DEBUG - 2016-09-25 21:48:00 --> XSS Filtering completed
DEBUG - 2016-09-25 21:48:00 --> XSS Filtering completed
DEBUG - 2016-09-25 21:48:00 --> XSS Filtering completed
DEBUG - 2016-09-25 21:48:00 --> XSS Filtering completed
DEBUG - 2016-09-25 21:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 21:48:00 --> Language Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Loader Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Helper loaded: url_helper
DEBUG - 2016-09-25 21:48:00 --> Helper loaded: form_helper
DEBUG - 2016-09-25 21:48:00 --> Helper loaded: func_helper
DEBUG - 2016-09-25 21:48:00 --> Database Driver Class Initialized
ERROR - 2016-09-25 21:48:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 21:48:00 --> Session Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Helper loaded: string_helper
DEBUG - 2016-09-25 21:48:00 --> Encrypt Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Session routines successfully run
ERROR - 2016-09-25 21:48:00 --> Could not find the language line "first_link"
ERROR - 2016-09-25 21:48:00 --> Could not find the language line "last_link"
ERROR - 2016-09-25 21:48:00 --> Could not find the language line "next_link"
ERROR - 2016-09-25 21:48:00 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 21:48:00 --> Pagination Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Table Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Model Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Model Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Helper loaded: file_helper
DEBUG - 2016-09-25 21:48:00 --> Model Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Controller Class Initialized
DEBUG - 2016-09-25 21:48:00 --> Helper loaded: language_helper
DEBUG - 2016-09-25 21:48:00 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 21:48:00 --> Model Class Initialized
DEBUG - 2016-09-25 21:48:02 --> Config Class Initialized
DEBUG - 2016-09-25 21:48:02 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:48:02 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:48:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:48:02 --> URI Class Initialized
DEBUG - 2016-09-25 21:48:02 --> Router Class Initialized
DEBUG - 2016-09-25 21:48:02 --> Output Class Initialized
DEBUG - 2016-09-25 21:48:02 --> Security Class Initialized
DEBUG - 2016-09-25 21:48:02 --> Input Class Initialized
DEBUG - 2016-09-25 21:48:02 --> XSS Filtering completed
DEBUG - 2016-09-25 21:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 21:48:02 --> Language Class Initialized
DEBUG - 2016-09-25 21:48:02 --> Loader Class Initialized
DEBUG - 2016-09-25 21:48:02 --> Helper loaded: url_helper
DEBUG - 2016-09-25 21:48:02 --> Helper loaded: form_helper
DEBUG - 2016-09-25 21:48:02 --> Helper loaded: func_helper
DEBUG - 2016-09-25 21:48:02 --> Database Driver Class Initialized
ERROR - 2016-09-25 21:48:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 21:48:02 --> Session Class Initialized
DEBUG - 2016-09-25 21:48:02 --> Helper loaded: string_helper
DEBUG - 2016-09-25 21:48:02 --> Encrypt Class Initialized
DEBUG - 2016-09-25 21:48:03 --> Session routines successfully run
ERROR - 2016-09-25 21:48:03 --> Could not find the language line "first_link"
ERROR - 2016-09-25 21:48:03 --> Could not find the language line "last_link"
ERROR - 2016-09-25 21:48:03 --> Could not find the language line "next_link"
ERROR - 2016-09-25 21:48:03 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 21:48:03 --> Pagination Class Initialized
DEBUG - 2016-09-25 21:48:03 --> Table Class Initialized
DEBUG - 2016-09-25 21:48:03 --> Model Class Initialized
DEBUG - 2016-09-25 21:48:03 --> Model Class Initialized
DEBUG - 2016-09-25 21:48:03 --> Helper loaded: file_helper
DEBUG - 2016-09-25 21:48:03 --> Model Class Initialized
DEBUG - 2016-09-25 21:48:03 --> Controller Class Initialized
DEBUG - 2016-09-25 21:48:03 --> Form Validation Class Initialized
DEBUG - 2016-09-25 21:48:03 --> Helper loaded: language_helper
DEBUG - 2016-09-25 21:48:03 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 21:48:06 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 21:48:06 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 21:48:06 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 21:48:06 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 21:48:06 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 21:48:06 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 21:48:06 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 21:48:06 --> Final output sent to browser
DEBUG - 2016-09-25 21:48:06 --> Total execution time: 3.7200
DEBUG - 2016-09-25 21:48:06 --> Config Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:48:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:48:06 --> URI Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Router Class Initialized
ERROR - 2016-09-25 21:48:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 21:48:06 --> Config Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:48:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:48:06 --> URI Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Router Class Initialized
ERROR - 2016-09-25 21:48:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 21:48:06 --> Config Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:48:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:48:06 --> Config Class Initialized
DEBUG - 2016-09-25 21:48:06 --> URI Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Router Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:48:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:48:06 --> URI Class Initialized
ERROR - 2016-09-25 21:48:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 21:48:06 --> Router Class Initialized
ERROR - 2016-09-25 21:48:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 21:48:06 --> Config Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Config Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:48:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:48:06 --> URI Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Router Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:48:06 --> UTF-8 Support Enabled
ERROR - 2016-09-25 21:48:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 21:48:06 --> URI Class Initialized
DEBUG - 2016-09-25 21:48:06 --> Router Class Initialized
ERROR - 2016-09-25 21:48:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 21:48:36 --> Config Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Hooks Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Utf8 Class Initialized
DEBUG - 2016-09-25 21:48:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 21:48:36 --> URI Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Router Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Output Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Security Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Input Class Initialized
DEBUG - 2016-09-25 21:48:36 --> XSS Filtering completed
DEBUG - 2016-09-25 21:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 21:48:36 --> Language Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Loader Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Helper loaded: url_helper
DEBUG - 2016-09-25 21:48:36 --> Helper loaded: form_helper
DEBUG - 2016-09-25 21:48:36 --> Helper loaded: func_helper
DEBUG - 2016-09-25 21:48:36 --> Database Driver Class Initialized
ERROR - 2016-09-25 21:48:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-25 21:48:36 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 21:48:36 --> Session Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Helper loaded: string_helper
DEBUG - 2016-09-25 21:48:36 --> Encrypt Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Session routines successfully run
ERROR - 2016-09-25 21:48:36 --> Could not find the language line "first_link"
ERROR - 2016-09-25 21:48:36 --> Could not find the language line "last_link"
ERROR - 2016-09-25 21:48:36 --> Could not find the language line "next_link"
ERROR - 2016-09-25 21:48:36 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 21:48:36 --> Pagination Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Table Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Model Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Model Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Helper loaded: file_helper
DEBUG - 2016-09-25 21:48:36 --> Model Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Controller Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Form Validation Class Initialized
DEBUG - 2016-09-25 21:48:36 --> Helper loaded: language_helper
DEBUG - 2016-09-25 21:48:36 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 21:48:36 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 21:48:36 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 21:48:36 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 21:48:36 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-09-25 21:48:36 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-09-25 21:48:36 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 21:48:36 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-09-25 21:48:36 --> Final output sent to browser
DEBUG - 2016-09-25 21:48:36 --> Total execution time: 0.2900
DEBUG - 2016-09-25 22:01:30 --> Config Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Utf8 Class Initialized
DEBUG - 2016-09-25 22:01:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 22:01:30 --> URI Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Router Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Output Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Security Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Input Class Initialized
DEBUG - 2016-09-25 22:01:30 --> XSS Filtering completed
DEBUG - 2016-09-25 22:01:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 22:01:30 --> Language Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Loader Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Helper loaded: url_helper
DEBUG - 2016-09-25 22:01:30 --> Helper loaded: form_helper
DEBUG - 2016-09-25 22:01:30 --> Helper loaded: func_helper
DEBUG - 2016-09-25 22:01:30 --> Database Driver Class Initialized
ERROR - 2016-09-25 22:01:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 22:01:30 --> Session Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Helper loaded: string_helper
DEBUG - 2016-09-25 22:01:30 --> Encrypt Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Session routines successfully run
ERROR - 2016-09-25 22:01:30 --> Could not find the language line "first_link"
ERROR - 2016-09-25 22:01:30 --> Could not find the language line "last_link"
ERROR - 2016-09-25 22:01:30 --> Could not find the language line "next_link"
ERROR - 2016-09-25 22:01:30 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 22:01:30 --> Pagination Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Table Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Model Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Model Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Helper loaded: file_helper
DEBUG - 2016-09-25 22:01:30 --> Model Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Controller Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Form Validation Class Initialized
DEBUG - 2016-09-25 22:01:30 --> Helper loaded: language_helper
DEBUG - 2016-09-25 22:01:30 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 22:01:32 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 22:01:32 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 22:01:32 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 22:01:32 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-25 22:01:32 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-25 22:01:32 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 22:01:32 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-25 22:01:32 --> Final output sent to browser
DEBUG - 2016-09-25 22:01:32 --> Total execution time: 2.4621
DEBUG - 2016-09-25 22:01:33 --> Config Class Initialized
DEBUG - 2016-09-25 22:01:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:01:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 22:01:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 22:01:33 --> URI Class Initialized
DEBUG - 2016-09-25 22:01:33 --> Config Class Initialized
DEBUG - 2016-09-25 22:01:33 --> Router Class Initialized
DEBUG - 2016-09-25 22:01:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:01:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 22:01:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 22:01:33 --> URI Class Initialized
DEBUG - 2016-09-25 22:01:33 --> Router Class Initialized
ERROR - 2016-09-25 22:01:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 22:01:33 --> Config Class Initialized
ERROR - 2016-09-25 22:01:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 22:01:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:01:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 22:01:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 22:01:33 --> URI Class Initialized
DEBUG - 2016-09-25 22:01:33 --> Router Class Initialized
ERROR - 2016-09-25 22:01:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 22:01:33 --> Config Class Initialized
DEBUG - 2016-09-25 22:01:33 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:01:33 --> Utf8 Class Initialized
DEBUG - 2016-09-25 22:01:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 22:01:33 --> URI Class Initialized
DEBUG - 2016-09-25 22:01:33 --> Router Class Initialized
ERROR - 2016-09-25 22:01:33 --> 404 Page Not Found --> application
DEBUG - 2016-09-25 22:01:48 --> Config Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Utf8 Class Initialized
DEBUG - 2016-09-25 22:01:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 22:01:48 --> URI Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Router Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Output Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Security Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Input Class Initialized
DEBUG - 2016-09-25 22:01:48 --> XSS Filtering completed
DEBUG - 2016-09-25 22:01:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 22:01:48 --> Language Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Loader Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Helper loaded: url_helper
DEBUG - 2016-09-25 22:01:48 --> Helper loaded: form_helper
DEBUG - 2016-09-25 22:01:48 --> Helper loaded: func_helper
DEBUG - 2016-09-25 22:01:48 --> Database Driver Class Initialized
ERROR - 2016-09-25 22:01:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-25 22:01:48 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 22:01:48 --> Session Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Helper loaded: string_helper
DEBUG - 2016-09-25 22:01:48 --> Encrypt Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Session routines successfully run
ERROR - 2016-09-25 22:01:48 --> Could not find the language line "first_link"
ERROR - 2016-09-25 22:01:48 --> Could not find the language line "last_link"
ERROR - 2016-09-25 22:01:48 --> Could not find the language line "next_link"
ERROR - 2016-09-25 22:01:48 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 22:01:48 --> Pagination Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Table Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Model Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Model Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Helper loaded: file_helper
DEBUG - 2016-09-25 22:01:48 --> Model Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Controller Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Form Validation Class Initialized
DEBUG - 2016-09-25 22:01:48 --> Helper loaded: language_helper
DEBUG - 2016-09-25 22:01:48 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 22:01:48 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 22:01:48 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 22:01:48 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 22:01:48 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-09-25 22:01:48 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-09-25 22:01:48 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 22:01:48 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-09-25 22:01:48 --> Final output sent to browser
DEBUG - 2016-09-25 22:01:48 --> Total execution time: 0.2170
DEBUG - 2016-09-25 22:05:39 --> Config Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Utf8 Class Initialized
DEBUG - 2016-09-25 22:05:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 22:05:39 --> URI Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Router Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Output Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Security Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Input Class Initialized
DEBUG - 2016-09-25 22:05:39 --> XSS Filtering completed
DEBUG - 2016-09-25 22:05:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 22:05:39 --> Language Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Loader Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Helper loaded: url_helper
DEBUG - 2016-09-25 22:05:39 --> Helper loaded: form_helper
DEBUG - 2016-09-25 22:05:39 --> Helper loaded: func_helper
DEBUG - 2016-09-25 22:05:39 --> Database Driver Class Initialized
ERROR - 2016-09-25 22:05:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 22:05:39 --> Session Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Helper loaded: string_helper
DEBUG - 2016-09-25 22:05:39 --> Encrypt Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Session routines successfully run
ERROR - 2016-09-25 22:05:39 --> Could not find the language line "first_link"
ERROR - 2016-09-25 22:05:39 --> Could not find the language line "last_link"
ERROR - 2016-09-25 22:05:39 --> Could not find the language line "next_link"
ERROR - 2016-09-25 22:05:39 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 22:05:39 --> Pagination Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Table Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Model Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Model Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Helper loaded: file_helper
DEBUG - 2016-09-25 22:05:39 --> Model Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Controller Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Form Validation Class Initialized
DEBUG - 2016-09-25 22:05:39 --> Helper loaded: language_helper
DEBUG - 2016-09-25 22:05:39 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 22:05:39 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 22:05:39 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 22:05:39 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 22:05:39 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-09-25 22:05:39 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-09-25 22:05:39 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 22:05:39 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-09-25 22:05:39 --> Final output sent to browser
DEBUG - 2016-09-25 22:05:39 --> Total execution time: 0.1200
DEBUG - 2016-09-25 22:12:28 --> Config Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Utf8 Class Initialized
DEBUG - 2016-09-25 22:12:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 22:12:28 --> URI Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Router Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Output Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Security Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Input Class Initialized
DEBUG - 2016-09-25 22:12:28 --> XSS Filtering completed
DEBUG - 2016-09-25 22:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 22:12:28 --> Language Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Loader Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Helper loaded: url_helper
DEBUG - 2016-09-25 22:12:28 --> Helper loaded: form_helper
DEBUG - 2016-09-25 22:12:28 --> Helper loaded: func_helper
DEBUG - 2016-09-25 22:12:28 --> Database Driver Class Initialized
ERROR - 2016-09-25 22:12:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-25 22:12:28 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 22:12:28 --> Session Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Helper loaded: string_helper
DEBUG - 2016-09-25 22:12:28 --> Encrypt Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Session routines successfully run
ERROR - 2016-09-25 22:12:28 --> Could not find the language line "first_link"
ERROR - 2016-09-25 22:12:28 --> Could not find the language line "last_link"
ERROR - 2016-09-25 22:12:28 --> Could not find the language line "next_link"
ERROR - 2016-09-25 22:12:28 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 22:12:28 --> Pagination Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Table Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Model Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Model Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Helper loaded: file_helper
DEBUG - 2016-09-25 22:12:28 --> Model Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Controller Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Form Validation Class Initialized
DEBUG - 2016-09-25 22:12:28 --> Helper loaded: language_helper
DEBUG - 2016-09-25 22:12:28 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 22:12:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 22:12:28 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 22:12:28 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 22:12:28 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-09-25 22:12:28 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-09-25 22:12:28 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 22:12:28 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-09-25 22:12:28 --> Final output sent to browser
DEBUG - 2016-09-25 22:12:28 --> Total execution time: 0.1240
DEBUG - 2016-09-25 22:15:14 --> Config Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Utf8 Class Initialized
DEBUG - 2016-09-25 22:15:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 22:15:14 --> URI Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Router Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Output Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Security Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Input Class Initialized
DEBUG - 2016-09-25 22:15:14 --> XSS Filtering completed
DEBUG - 2016-09-25 22:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 22:15:14 --> Language Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Loader Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Helper loaded: url_helper
DEBUG - 2016-09-25 22:15:14 --> Helper loaded: form_helper
DEBUG - 2016-09-25 22:15:14 --> Helper loaded: func_helper
DEBUG - 2016-09-25 22:15:14 --> Database Driver Class Initialized
ERROR - 2016-09-25 22:15:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-25 22:15:14 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 22:15:14 --> Session Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Helper loaded: string_helper
DEBUG - 2016-09-25 22:15:14 --> Encrypt Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Session routines successfully run
ERROR - 2016-09-25 22:15:14 --> Could not find the language line "first_link"
ERROR - 2016-09-25 22:15:14 --> Could not find the language line "last_link"
ERROR - 2016-09-25 22:15:14 --> Could not find the language line "next_link"
ERROR - 2016-09-25 22:15:14 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 22:15:14 --> Pagination Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Table Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Model Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Model Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Helper loaded: file_helper
DEBUG - 2016-09-25 22:15:14 --> Model Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Controller Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Form Validation Class Initialized
DEBUG - 2016-09-25 22:15:14 --> Helper loaded: language_helper
DEBUG - 2016-09-25 22:15:14 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 22:15:14 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 22:15:14 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 22:15:14 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 22:15:14 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-09-25 22:15:14 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-09-25 22:15:14 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 22:15:14 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-09-25 22:15:14 --> Final output sent to browser
DEBUG - 2016-09-25 22:15:14 --> Total execution time: 0.1020
DEBUG - 2016-09-25 22:20:46 --> Config Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Utf8 Class Initialized
DEBUG - 2016-09-25 22:20:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 22:20:46 --> URI Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Router Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Output Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Security Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Input Class Initialized
DEBUG - 2016-09-25 22:20:46 --> XSS Filtering completed
DEBUG - 2016-09-25 22:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 22:20:46 --> Language Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Loader Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Helper loaded: url_helper
DEBUG - 2016-09-25 22:20:46 --> Helper loaded: form_helper
DEBUG - 2016-09-25 22:20:46 --> Helper loaded: func_helper
DEBUG - 2016-09-25 22:20:46 --> Database Driver Class Initialized
ERROR - 2016-09-25 22:20:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 22:20:46 --> Session Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Helper loaded: string_helper
DEBUG - 2016-09-25 22:20:46 --> Encrypt Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Session routines successfully run
ERROR - 2016-09-25 22:20:46 --> Could not find the language line "first_link"
ERROR - 2016-09-25 22:20:46 --> Could not find the language line "last_link"
ERROR - 2016-09-25 22:20:46 --> Could not find the language line "next_link"
ERROR - 2016-09-25 22:20:46 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 22:20:46 --> Pagination Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Table Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Model Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Model Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Helper loaded: file_helper
DEBUG - 2016-09-25 22:20:46 --> Model Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Controller Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Form Validation Class Initialized
DEBUG - 2016-09-25 22:20:46 --> Helper loaded: language_helper
DEBUG - 2016-09-25 22:20:46 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 22:20:46 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 22:20:46 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 22:20:46 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 22:20:46 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-09-25 22:20:46 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-09-25 22:20:46 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 22:20:46 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-09-25 22:20:46 --> Final output sent to browser
DEBUG - 2016-09-25 22:20:46 --> Total execution time: 0.1180
DEBUG - 2016-09-25 22:20:47 --> Config Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Utf8 Class Initialized
DEBUG - 2016-09-25 22:20:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 22:20:47 --> URI Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Router Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Output Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Security Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Input Class Initialized
DEBUG - 2016-09-25 22:20:47 --> XSS Filtering completed
DEBUG - 2016-09-25 22:20:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 22:20:47 --> Language Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Loader Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Helper loaded: url_helper
DEBUG - 2016-09-25 22:20:47 --> Helper loaded: form_helper
DEBUG - 2016-09-25 22:20:47 --> Helper loaded: func_helper
DEBUG - 2016-09-25 22:20:47 --> Database Driver Class Initialized
ERROR - 2016-09-25 22:20:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-25 22:20:47 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 22:20:47 --> Session Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Helper loaded: string_helper
DEBUG - 2016-09-25 22:20:47 --> Encrypt Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Session routines successfully run
ERROR - 2016-09-25 22:20:47 --> Could not find the language line "first_link"
ERROR - 2016-09-25 22:20:47 --> Could not find the language line "last_link"
ERROR - 2016-09-25 22:20:47 --> Could not find the language line "next_link"
ERROR - 2016-09-25 22:20:47 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 22:20:47 --> Pagination Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Table Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Model Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Model Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Helper loaded: file_helper
DEBUG - 2016-09-25 22:20:47 --> Model Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Controller Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Form Validation Class Initialized
DEBUG - 2016-09-25 22:20:47 --> Helper loaded: language_helper
DEBUG - 2016-09-25 22:20:47 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 22:20:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 22:20:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 22:20:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 22:20:47 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-09-25 22:20:47 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-09-25 22:20:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 22:20:47 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-09-25 22:20:47 --> Final output sent to browser
DEBUG - 2016-09-25 22:20:47 --> Total execution time: 0.1200
DEBUG - 2016-09-25 22:20:48 --> Config Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Hooks Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Utf8 Class Initialized
DEBUG - 2016-09-25 22:20:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-25 22:20:48 --> URI Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Router Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Output Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Security Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Input Class Initialized
DEBUG - 2016-09-25 22:20:48 --> XSS Filtering completed
DEBUG - 2016-09-25 22:20:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-25 22:20:48 --> Language Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Loader Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Helper loaded: url_helper
DEBUG - 2016-09-25 22:20:48 --> Helper loaded: form_helper
DEBUG - 2016-09-25 22:20:48 --> Helper loaded: func_helper
DEBUG - 2016-09-25 22:20:48 --> Database Driver Class Initialized
ERROR - 2016-09-25 22:20:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-25 22:20:48 --> Session Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Helper loaded: string_helper
DEBUG - 2016-09-25 22:20:48 --> Encrypt Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Session routines successfully run
ERROR - 2016-09-25 22:20:48 --> Could not find the language line "first_link"
ERROR - 2016-09-25 22:20:48 --> Could not find the language line "last_link"
ERROR - 2016-09-25 22:20:48 --> Could not find the language line "next_link"
ERROR - 2016-09-25 22:20:48 --> Could not find the language line "prev_link"
DEBUG - 2016-09-25 22:20:48 --> Pagination Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Table Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Model Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Model Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Helper loaded: file_helper
DEBUG - 2016-09-25 22:20:48 --> Model Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Controller Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Form Validation Class Initialized
DEBUG - 2016-09-25 22:20:48 --> Helper loaded: language_helper
DEBUG - 2016-09-25 22:20:48 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-25 22:20:48 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-25 22:20:48 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-25 22:20:48 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-25 22:20:49 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-09-25 22:20:49 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-09-25 22:20:49 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-25 22:20:49 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-09-25 22:20:49 --> Final output sent to browser
DEBUG - 2016-09-25 22:20:49 --> Total execution time: 0.1000
