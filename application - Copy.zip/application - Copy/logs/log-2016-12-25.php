<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-12-25 01:12:45 --> Config Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Hooks Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Utf8 Class Initialized
DEBUG - 2016-12-25 01:12:45 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 01:12:45 --> URI Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Router Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Output Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Security Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Input Class Initialized
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> XSS Filtering completed
DEBUG - 2016-12-25 01:12:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-25 01:12:45 --> Language Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Loader Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Helper loaded: url_helper
DEBUG - 2016-12-25 01:12:45 --> Helper loaded: form_helper
DEBUG - 2016-12-25 01:12:45 --> Helper loaded: func_helper
DEBUG - 2016-12-25 01:12:45 --> Database Driver Class Initialized
ERROR - 2016-12-25 01:12:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-25 01:12:45 --> Session Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Helper loaded: string_helper
DEBUG - 2016-12-25 01:12:45 --> Encrypt Class Initialized
DEBUG - 2016-12-25 01:12:45 --> A session cookie was not found.
DEBUG - 2016-12-25 01:12:45 --> Session routines successfully run
ERROR - 2016-12-25 01:12:45 --> Could not find the language line "first_link"
ERROR - 2016-12-25 01:12:45 --> Could not find the language line "last_link"
ERROR - 2016-12-25 01:12:45 --> Could not find the language line "next_link"
ERROR - 2016-12-25 01:12:45 --> Could not find the language line "prev_link"
DEBUG - 2016-12-25 01:12:45 --> Pagination Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Table Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Model Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Model Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Helper loaded: file_helper
DEBUG - 2016-12-25 01:12:45 --> Model Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Controller Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Helper loaded: language_helper
DEBUG - 2016-12-25 01:12:45 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-25 01:12:45 --> Model Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Upload Class Initialized
DEBUG - 2016-12-25 01:12:45 --> Language file loaded: language/arabic/upload_lang.php
ERROR - 2016-12-25 01:12:45 --> لم تختر ملف لرفعه.
ERROR - 2016-12-25 01:12:45 --> Severity: Warning  --> file_get_contents(application/uploads/): failed to open stream: No such file or directory C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Shared\OLERead.php 85
ERROR - 2016-12-25 01:12:45 --> Severity: Warning  --> fopen(application/uploads/): failed to open stream: No such file or directory C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Reader\Abstract.php 200
DEBUG - 2016-12-25 01:14:03 --> Config Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Hooks Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Utf8 Class Initialized
DEBUG - 2016-12-25 01:14:03 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 01:14:03 --> URI Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Router Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Output Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Security Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Input Class Initialized
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> XSS Filtering completed
DEBUG - 2016-12-25 01:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-25 01:14:03 --> Language Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Loader Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Helper loaded: url_helper
DEBUG - 2016-12-25 01:14:03 --> Helper loaded: form_helper
DEBUG - 2016-12-25 01:14:03 --> Helper loaded: func_helper
DEBUG - 2016-12-25 01:14:03 --> Database Driver Class Initialized
ERROR - 2016-12-25 01:14:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-25 01:14:03 --> Session Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Helper loaded: string_helper
DEBUG - 2016-12-25 01:14:03 --> Encrypt Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Session routines successfully run
ERROR - 2016-12-25 01:14:03 --> Could not find the language line "first_link"
ERROR - 2016-12-25 01:14:03 --> Could not find the language line "last_link"
ERROR - 2016-12-25 01:14:03 --> Could not find the language line "next_link"
ERROR - 2016-12-25 01:14:03 --> Could not find the language line "prev_link"
DEBUG - 2016-12-25 01:14:03 --> Pagination Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Table Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Model Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Model Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Helper loaded: file_helper
DEBUG - 2016-12-25 01:14:03 --> Model Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Controller Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Helper loaded: language_helper
DEBUG - 2016-12-25 01:14:03 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-25 01:14:03 --> Model Class Initialized
DEBUG - 2016-12-25 01:14:03 --> Upload Class Initialized
DEBUG - 2016-12-25 01:14:59 --> DB Transaction Failure
ERROR - 2016-12-25 01:14:59 --> Query error: Table 'univ_alumni.lk9v6_alumni_main' doesn't exist
DEBUG - 2016-12-25 01:14:59 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-25 01:14:59 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-25 17:47:16 --> Config Class Initialized
DEBUG - 2016-12-25 17:47:17 --> Hooks Class Initialized
DEBUG - 2016-12-25 17:47:17 --> Utf8 Class Initialized
DEBUG - 2016-12-25 17:47:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 17:47:17 --> URI Class Initialized
DEBUG - 2016-12-25 17:47:18 --> Router Class Initialized
DEBUG - 2016-12-25 17:47:18 --> Output Class Initialized
DEBUG - 2016-12-25 17:47:19 --> Security Class Initialized
DEBUG - 2016-12-25 17:47:19 --> Input Class Initialized
DEBUG - 2016-12-25 17:47:19 --> XSS Filtering completed
DEBUG - 2016-12-25 17:47:19 --> XSS Filtering completed
DEBUG - 2016-12-25 17:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-25 17:47:19 --> Language Class Initialized
DEBUG - 2016-12-25 17:47:19 --> Loader Class Initialized
DEBUG - 2016-12-25 17:47:21 --> Helper loaded: url_helper
DEBUG - 2016-12-25 17:47:21 --> Helper loaded: form_helper
DEBUG - 2016-12-25 17:47:21 --> Helper loaded: func_helper
DEBUG - 2016-12-25 17:47:21 --> Database Driver Class Initialized
ERROR - 2016-12-25 17:47:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-25 17:47:21 --> Session Class Initialized
DEBUG - 2016-12-25 17:47:21 --> Helper loaded: string_helper
DEBUG - 2016-12-25 17:47:22 --> Encrypt Class Initialized
ERROR - 2016-12-25 17:47:22 --> Session: The session cookie was not signed.
DEBUG - 2016-12-25 17:47:22 --> Session routines successfully run
ERROR - 2016-12-25 17:47:22 --> Could not find the language line "first_link"
ERROR - 2016-12-25 17:47:22 --> Could not find the language line "last_link"
ERROR - 2016-12-25 17:47:22 --> Could not find the language line "next_link"
ERROR - 2016-12-25 17:47:22 --> Could not find the language line "prev_link"
DEBUG - 2016-12-25 17:47:22 --> Pagination Class Initialized
DEBUG - 2016-12-25 17:47:22 --> Table Class Initialized
DEBUG - 2016-12-25 17:47:22 --> Model Class Initialized
DEBUG - 2016-12-25 17:47:22 --> Model Class Initialized
DEBUG - 2016-12-25 17:47:22 --> Helper loaded: file_helper
DEBUG - 2016-12-25 17:47:22 --> Model Class Initialized
DEBUG - 2016-12-25 17:47:22 --> Controller Class Initialized
DEBUG - 2016-12-25 17:47:22 --> Helper loaded: language_helper
DEBUG - 2016-12-25 17:47:22 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-25 17:47:23 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-25 17:47:23 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-25 17:47:23 --> File loaded: application/views/me/myadmin_upload.php
DEBUG - 2016-12-25 17:47:23 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-25 17:47:23 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-25 17:47:23 --> Final output sent to browser
DEBUG - 2016-12-25 17:47:23 --> Total execution time: 8.4975
DEBUG - 2016-12-25 17:47:26 --> Config Class Initialized
DEBUG - 2016-12-25 17:47:26 --> Hooks Class Initialized
DEBUG - 2016-12-25 17:47:26 --> Utf8 Class Initialized
DEBUG - 2016-12-25 17:47:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 17:47:26 --> URI Class Initialized
DEBUG - 2016-12-25 17:47:27 --> Router Class Initialized
ERROR - 2016-12-25 17:47:27 --> 404 Page Not Found --> js
DEBUG - 2016-12-25 20:24:06 --> Config Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Hooks Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Utf8 Class Initialized
DEBUG - 2016-12-25 20:24:06 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 20:24:06 --> URI Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Router Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Output Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Security Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Input Class Initialized
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-25 20:24:06 --> Language Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Loader Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Helper loaded: url_helper
DEBUG - 2016-12-25 20:24:06 --> Helper loaded: form_helper
DEBUG - 2016-12-25 20:24:06 --> Helper loaded: func_helper
DEBUG - 2016-12-25 20:24:06 --> Database Driver Class Initialized
ERROR - 2016-12-25 20:24:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-25 20:24:06 --> Session Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Helper loaded: string_helper
DEBUG - 2016-12-25 20:24:06 --> Encrypt Class Initialized
DEBUG - 2016-12-25 20:24:06 --> A session cookie was not found.
DEBUG - 2016-12-25 20:24:06 --> Session routines successfully run
ERROR - 2016-12-25 20:24:06 --> Could not find the language line "first_link"
ERROR - 2016-12-25 20:24:06 --> Could not find the language line "last_link"
ERROR - 2016-12-25 20:24:06 --> Could not find the language line "next_link"
ERROR - 2016-12-25 20:24:06 --> Could not find the language line "prev_link"
DEBUG - 2016-12-25 20:24:06 --> Pagination Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Table Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Model Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Model Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Helper loaded: file_helper
DEBUG - 2016-12-25 20:24:06 --> Model Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Controller Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Helper loaded: language_helper
DEBUG - 2016-12-25 20:24:06 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-25 20:24:06 --> Model Class Initialized
DEBUG - 2016-12-25 20:24:06 --> Upload Class Initialized
ERROR - 2016-12-25 20:24:06 --> Severity: Warning  --> copy(C:/xampp/htdocs/www/alumni/application/uploads/ظ‚ط§ط¹ط¯ط©_ط¨ظٹط§ظ†ط§طھ_ظƒظ„ظٹط©_ط§ظ„ط²ط±ط§ط¹ط©_ط§ظ„ط´ط§ط·ط¨ظٹ_ظˆ_ط³ط§ط¨ط§_ط¨ط§ط´ط§_ط¯.ظ…ط­ظ…ط¯_ط³ظ„ط·ط§ظ†_.xlsx): failed to open stream: Invalid argument C:\xampp\htdocs\www\alumni\system\libraries\Upload.php 313
ERROR - 2016-12-25 20:24:06 --> Severity: Warning  --> move_uploaded_file(C:/xampp/htdocs/www/alumni/application/uploads/ظ‚ط§ط¹ط¯ط©_ط¨ظٹط§ظ†ط§طھ_ظƒظ„ظٹط©_ط§ظ„ط²ط±ط§ط¹ط©_ط§ظ„ط´ط§ط·ط¨ظٹ_ظˆ_ط³ط§ط¨ط§_ط¨ط§ط´ط§_ط¯.ظ…ط­ظ…ط¯_ط³ظ„ط·ط§ظ†_.xlsx): failed to open stream: Invalid argument C:\xampp\htdocs\www\alumni\system\libraries\Upload.php 315
ERROR - 2016-12-25 20:24:06 --> Severity: Warning  --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\php9149.tmp' to 'C:/xampp/htdocs/www/alumni/application/uploads/ظ‚ط§ط¹ط¯ط©_ط¨ظٹط§ظ†ط§طھ_ظƒظ„ظٹط©_ط§ظ„ط²ط±ط§ط¹ط©_ط§ظ„ط´ط§ط·ط¨ظٹ_ظˆ_ط³ط§ط¨ط§_ط¨ط§ط´ط§_ط¯.ظ…ط­ظ…ط¯_ط³ظ„ط·ط§ظ†_.xlsx' C:\xampp\htdocs\www\alumni\system\libraries\Upload.php 315
DEBUG - 2016-12-25 20:24:06 --> Language file loaded: language/arabic/upload_lang.php
ERROR - 2016-12-25 20:24:06 --> حدث خطأ أثناء محاولة نقل الملف المرفوع إلى الموضع النهائي.
DEBUG - 2016-12-25 20:24:14 --> Config Class Initialized
DEBUG - 2016-12-25 20:24:14 --> Hooks Class Initialized
DEBUG - 2016-12-25 20:24:14 --> Utf8 Class Initialized
DEBUG - 2016-12-25 20:24:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 20:24:14 --> URI Class Initialized
DEBUG - 2016-12-25 20:24:14 --> Router Class Initialized
ERROR - 2016-12-25 20:24:14 --> 404 Page Not Found --> js
DEBUG - 2016-12-25 20:24:46 --> Config Class Initialized
DEBUG - 2016-12-25 20:24:46 --> Hooks Class Initialized
DEBUG - 2016-12-25 20:24:46 --> Utf8 Class Initialized
DEBUG - 2016-12-25 20:24:46 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 20:24:46 --> URI Class Initialized
DEBUG - 2016-12-25 20:24:46 --> Router Class Initialized
DEBUG - 2016-12-25 20:24:46 --> Output Class Initialized
DEBUG - 2016-12-25 20:24:46 --> Security Class Initialized
DEBUG - 2016-12-25 20:24:46 --> Input Class Initialized
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:46 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:47 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:47 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:47 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:47 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:47 --> XSS Filtering completed
DEBUG - 2016-12-25 20:24:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-25 20:24:47 --> Language Class Initialized
DEBUG - 2016-12-25 20:24:47 --> Loader Class Initialized
DEBUG - 2016-12-25 20:24:47 --> Helper loaded: url_helper
DEBUG - 2016-12-25 20:24:47 --> Helper loaded: form_helper
DEBUG - 2016-12-25 20:24:47 --> Helper loaded: func_helper
DEBUG - 2016-12-25 20:24:47 --> Database Driver Class Initialized
ERROR - 2016-12-25 20:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-25 20:24:47 --> Session Class Initialized
DEBUG - 2016-12-25 20:24:47 --> Helper loaded: string_helper
DEBUG - 2016-12-25 20:24:47 --> Encrypt Class Initialized
DEBUG - 2016-12-25 20:24:47 --> Session routines successfully run
ERROR - 2016-12-25 20:24:47 --> Could not find the language line "first_link"
ERROR - 2016-12-25 20:24:47 --> Could not find the language line "last_link"
ERROR - 2016-12-25 20:24:47 --> Could not find the language line "next_link"
ERROR - 2016-12-25 20:24:47 --> Could not find the language line "prev_link"
DEBUG - 2016-12-25 20:24:47 --> Pagination Class Initialized
DEBUG - 2016-12-25 20:24:47 --> Table Class Initialized
DEBUG - 2016-12-25 20:24:47 --> Model Class Initialized
DEBUG - 2016-12-25 20:24:47 --> Model Class Initialized
DEBUG - 2016-12-25 20:24:47 --> Helper loaded: file_helper
DEBUG - 2016-12-25 20:24:47 --> Model Class Initialized
DEBUG - 2016-12-25 20:24:47 --> Controller Class Initialized
DEBUG - 2016-12-25 20:24:47 --> Helper loaded: language_helper
DEBUG - 2016-12-25 20:24:47 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-25 20:24:47 --> Model Class Initialized
DEBUG - 2016-12-25 20:24:47 --> Upload Class Initialized
ERROR - 2016-12-25 20:24:47 --> Severity: Warning  --> copy(C:/xampp/htdocs/www/alumni/application/uploads/ظ‚ط§ط¹ط¯ط©_ط¨ظٹط§ظ†ط§طھ_ظƒظ„ظٹط©_ط§ظ„ط²ط±ط§ط¹ط©_ط§ظ„ط´ط§ط·ط¨ظٹ_ظˆ_ط³ط§ط¨ط§_ط¨ط§ط´ط§_ط¯.ظ…ط­ظ…ط¯_ط³ظ„ط·ط§ظ†_.xlsx): failed to open stream: Invalid argument C:\xampp\htdocs\www\alumni\system\libraries\Upload.php 313
ERROR - 2016-12-25 20:24:47 --> Severity: Warning  --> move_uploaded_file(C:/xampp/htdocs/www/alumni/application/uploads/ظ‚ط§ط¹ط¯ط©_ط¨ظٹط§ظ†ط§طھ_ظƒظ„ظٹط©_ط§ظ„ط²ط±ط§ط¹ط©_ط§ظ„ط´ط§ط·ط¨ظٹ_ظˆ_ط³ط§ط¨ط§_ط¨ط§ط´ط§_ط¯.ظ…ط­ظ…ط¯_ط³ظ„ط·ط§ظ†_.xlsx): failed to open stream: Invalid argument C:\xampp\htdocs\www\alumni\system\libraries\Upload.php 315
ERROR - 2016-12-25 20:24:47 --> Severity: Warning  --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\php3008.tmp' to 'C:/xampp/htdocs/www/alumni/application/uploads/ظ‚ط§ط¹ط¯ط©_ط¨ظٹط§ظ†ط§طھ_ظƒظ„ظٹط©_ط§ظ„ط²ط±ط§ط¹ط©_ط§ظ„ط´ط§ط·ط¨ظٹ_ظˆ_ط³ط§ط¨ط§_ط¨ط§ط´ط§_ط¯.ظ…ط­ظ…ط¯_ط³ظ„ط·ط§ظ†_.xlsx' C:\xampp\htdocs\www\alumni\system\libraries\Upload.php 315
DEBUG - 2016-12-25 20:24:47 --> Language file loaded: language/arabic/upload_lang.php
ERROR - 2016-12-25 20:24:47 --> حدث خطأ أثناء محاولة نقل الملف المرفوع إلى الموضع النهائي.
DEBUG - 2016-12-25 20:35:34 --> Config Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Hooks Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Utf8 Class Initialized
DEBUG - 2016-12-25 20:35:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 20:35:34 --> URI Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Router Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Output Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Security Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Input Class Initialized
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> XSS Filtering completed
DEBUG - 2016-12-25 20:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-25 20:35:34 --> Language Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Loader Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Helper loaded: url_helper
DEBUG - 2016-12-25 20:35:34 --> Helper loaded: form_helper
DEBUG - 2016-12-25 20:35:34 --> Helper loaded: func_helper
DEBUG - 2016-12-25 20:35:34 --> Database Driver Class Initialized
ERROR - 2016-12-25 20:35:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-25 20:35:34 --> Session Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Helper loaded: string_helper
DEBUG - 2016-12-25 20:35:34 --> Encrypt Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Session routines successfully run
ERROR - 2016-12-25 20:35:34 --> Could not find the language line "first_link"
ERROR - 2016-12-25 20:35:34 --> Could not find the language line "last_link"
ERROR - 2016-12-25 20:35:34 --> Could not find the language line "next_link"
ERROR - 2016-12-25 20:35:34 --> Could not find the language line "prev_link"
DEBUG - 2016-12-25 20:35:34 --> Pagination Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Table Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Model Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Model Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Helper loaded: file_helper
DEBUG - 2016-12-25 20:35:34 --> Model Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Controller Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Helper loaded: language_helper
DEBUG - 2016-12-25 20:35:34 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-25 20:35:34 --> Model Class Initialized
DEBUG - 2016-12-25 20:35:34 --> Upload Class Initialized
ERROR - 2016-12-25 20:35:34 --> Severity: Warning  --> copy(C:/xampp/htdocs/www/alumni/application/uploads/ظ‚ط§ط¹ط¯ط©_ط¨ظٹط§ظ†ط§طھ_ظƒظ„ظٹط©_ط§ظ„ط²ط±ط§ط¹ط©_ط§ظ„ط´ط§ط·ط¨ظٹ_ظˆ_ط³ط§ط¨ط§_ط¨ط§ط´ط§_ط¯.ظ…ط­ظ…ط¯_ط³ظ„ط·ط§ظ†_.xlsx): failed to open stream: Invalid argument C:\xampp\htdocs\www\alumni\system\libraries\Upload.php 313
ERROR - 2016-12-25 20:35:34 --> Severity: Warning  --> move_uploaded_file(C:/xampp/htdocs/www/alumni/application/uploads/ظ‚ط§ط¹ط¯ط©_ط¨ظٹط§ظ†ط§طھ_ظƒظ„ظٹط©_ط§ظ„ط²ط±ط§ط¹ط©_ط§ظ„ط´ط§ط·ط¨ظٹ_ظˆ_ط³ط§ط¨ط§_ط¨ط§ط´ط§_ط¯.ظ…ط­ظ…ط¯_ط³ظ„ط·ط§ظ†_.xlsx): failed to open stream: Invalid argument C:\xampp\htdocs\www\alumni\system\libraries\Upload.php 315
ERROR - 2016-12-25 20:35:34 --> Severity: Warning  --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\php1163.tmp' to 'C:/xampp/htdocs/www/alumni/application/uploads/ظ‚ط§ط¹ط¯ط©_ط¨ظٹط§ظ†ط§طھ_ظƒظ„ظٹط©_ط§ظ„ط²ط±ط§ط¹ط©_ط§ظ„ط´ط§ط·ط¨ظٹ_ظˆ_ط³ط§ط¨ط§_ط¨ط§ط´ط§_ط¯.ظ…ط­ظ…ط¯_ط³ظ„ط·ط§ظ†_.xlsx' C:\xampp\htdocs\www\alumni\system\libraries\Upload.php 315
DEBUG - 2016-12-25 20:35:34 --> Language file loaded: language/arabic/upload_lang.php
ERROR - 2016-12-25 20:35:34 --> حدث خطأ أثناء محاولة نقل الملف المرفوع إلى الموضع النهائي.
DEBUG - 2016-12-25 20:36:02 --> Config Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Hooks Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Utf8 Class Initialized
DEBUG - 2016-12-25 20:36:02 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 20:36:02 --> URI Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Router Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Output Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Security Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Input Class Initialized
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-25 20:36:02 --> Language Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Loader Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Helper loaded: url_helper
DEBUG - 2016-12-25 20:36:02 --> Helper loaded: form_helper
DEBUG - 2016-12-25 20:36:02 --> Helper loaded: func_helper
DEBUG - 2016-12-25 20:36:02 --> Database Driver Class Initialized
ERROR - 2016-12-25 20:36:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-25 20:36:02 --> Session Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Helper loaded: string_helper
DEBUG - 2016-12-25 20:36:02 --> Encrypt Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Session routines successfully run
ERROR - 2016-12-25 20:36:02 --> Could not find the language line "first_link"
ERROR - 2016-12-25 20:36:02 --> Could not find the language line "last_link"
ERROR - 2016-12-25 20:36:02 --> Could not find the language line "next_link"
ERROR - 2016-12-25 20:36:02 --> Could not find the language line "prev_link"
DEBUG - 2016-12-25 20:36:02 --> Pagination Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Table Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Model Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Model Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Helper loaded: file_helper
DEBUG - 2016-12-25 20:36:02 --> Model Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Controller Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Helper loaded: language_helper
DEBUG - 2016-12-25 20:36:02 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-25 20:36:02 --> Model Class Initialized
DEBUG - 2016-12-25 20:36:02 --> Upload Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Config Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Hooks Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Utf8 Class Initialized
DEBUG - 2016-12-25 20:36:09 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 20:36:09 --> URI Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Router Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Output Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Security Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Input Class Initialized
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> XSS Filtering completed
DEBUG - 2016-12-25 20:36:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-25 20:36:09 --> Language Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Loader Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Helper loaded: url_helper
DEBUG - 2016-12-25 20:36:09 --> Helper loaded: form_helper
DEBUG - 2016-12-25 20:36:09 --> Helper loaded: func_helper
DEBUG - 2016-12-25 20:36:09 --> Database Driver Class Initialized
ERROR - 2016-12-25 20:36:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-25 20:36:09 --> Session Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Helper loaded: string_helper
DEBUG - 2016-12-25 20:36:09 --> Encrypt Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Session routines successfully run
ERROR - 2016-12-25 20:36:09 --> Could not find the language line "first_link"
ERROR - 2016-12-25 20:36:09 --> Could not find the language line "last_link"
ERROR - 2016-12-25 20:36:09 --> Could not find the language line "next_link"
ERROR - 2016-12-25 20:36:09 --> Could not find the language line "prev_link"
DEBUG - 2016-12-25 20:36:09 --> Pagination Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Table Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Model Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Model Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Helper loaded: file_helper
DEBUG - 2016-12-25 20:36:09 --> Model Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Controller Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Helper loaded: language_helper
DEBUG - 2016-12-25 20:36:09 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-25 20:36:09 --> Model Class Initialized
DEBUG - 2016-12-25 20:36:09 --> Upload Class Initialized
ERROR - 2016-12-25 20:37:13 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-25 20:37:13 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-25 20:37:14 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-25 20:37:14 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-25 20:37:14 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-25 20:37:14 --> Final output sent to browser
DEBUG - 2016-12-25 20:37:14 --> Total execution time: 71.6291
DEBUG - 2016-12-25 20:37:14 --> Config Class Initialized
DEBUG - 2016-12-25 20:37:14 --> Hooks Class Initialized
DEBUG - 2016-12-25 20:37:14 --> Utf8 Class Initialized
DEBUG - 2016-12-25 20:37:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 20:37:14 --> URI Class Initialized
DEBUG - 2016-12-25 20:37:14 --> Router Class Initialized
ERROR - 2016-12-25 20:37:14 --> 404 Page Not Found --> js
ERROR - 2016-12-25 20:37:22 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-25 20:37:22 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-25 20:37:22 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-25 20:37:22 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-25 20:37:22 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-25 20:37:22 --> Final output sent to browser
DEBUG - 2016-12-25 20:37:22 --> Total execution time: 73.1402
DEBUG - 2016-12-25 20:37:22 --> Config Class Initialized
DEBUG - 2016-12-25 20:37:22 --> Hooks Class Initialized
DEBUG - 2016-12-25 20:37:22 --> Utf8 Class Initialized
DEBUG - 2016-12-25 20:37:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 20:37:22 --> URI Class Initialized
DEBUG - 2016-12-25 20:37:22 --> Router Class Initialized
ERROR - 2016-12-25 20:37:22 --> 404 Page Not Found --> js
DEBUG - 2016-12-25 20:40:57 --> Config Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Hooks Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Utf8 Class Initialized
DEBUG - 2016-12-25 20:40:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 20:40:57 --> URI Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Router Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Output Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Security Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Input Class Initialized
DEBUG - 2016-12-25 20:40:57 --> XSS Filtering completed
DEBUG - 2016-12-25 20:40:57 --> XSS Filtering completed
DEBUG - 2016-12-25 20:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-25 20:40:57 --> Language Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Loader Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Helper loaded: url_helper
DEBUG - 2016-12-25 20:40:57 --> Helper loaded: form_helper
DEBUG - 2016-12-25 20:40:57 --> Helper loaded: func_helper
DEBUG - 2016-12-25 20:40:57 --> Database Driver Class Initialized
ERROR - 2016-12-25 20:40:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-25 20:40:57 --> Session Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Helper loaded: string_helper
DEBUG - 2016-12-25 20:40:57 --> Encrypt Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Session routines successfully run
ERROR - 2016-12-25 20:40:57 --> Could not find the language line "first_link"
ERROR - 2016-12-25 20:40:57 --> Could not find the language line "last_link"
ERROR - 2016-12-25 20:40:57 --> Could not find the language line "next_link"
ERROR - 2016-12-25 20:40:57 --> Could not find the language line "prev_link"
DEBUG - 2016-12-25 20:40:57 --> Pagination Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Table Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Model Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Model Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Helper loaded: file_helper
DEBUG - 2016-12-25 20:40:57 --> Model Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Controller Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Helper loaded: language_helper
DEBUG - 2016-12-25 20:40:57 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-25 20:40:57 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-25 20:40:57 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-25 20:40:57 --> File loaded: application/views/me/myadmin_upload.php
DEBUG - 2016-12-25 20:40:57 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-25 20:40:57 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-25 20:40:57 --> Final output sent to browser
DEBUG - 2016-12-25 20:40:57 --> Total execution time: 0.1040
DEBUG - 2016-12-25 20:40:57 --> Config Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Hooks Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Utf8 Class Initialized
DEBUG - 2016-12-25 20:40:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 20:40:57 --> URI Class Initialized
DEBUG - 2016-12-25 20:40:57 --> Router Class Initialized
ERROR - 2016-12-25 20:40:57 --> 404 Page Not Found --> js
DEBUG - 2016-12-25 20:42:13 --> Config Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Hooks Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Utf8 Class Initialized
DEBUG - 2016-12-25 20:42:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-25 20:42:13 --> URI Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Router Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Output Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Security Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Input Class Initialized
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> XSS Filtering completed
DEBUG - 2016-12-25 20:42:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-25 20:42:13 --> Language Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Loader Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Helper loaded: url_helper
DEBUG - 2016-12-25 20:42:13 --> Helper loaded: form_helper
DEBUG - 2016-12-25 20:42:13 --> Helper loaded: func_helper
DEBUG - 2016-12-25 20:42:13 --> Database Driver Class Initialized
ERROR - 2016-12-25 20:42:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-25 20:42:13 --> Session Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Helper loaded: string_helper
DEBUG - 2016-12-25 20:42:13 --> Encrypt Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Session routines successfully run
ERROR - 2016-12-25 20:42:13 --> Could not find the language line "first_link"
ERROR - 2016-12-25 20:42:13 --> Could not find the language line "last_link"
ERROR - 2016-12-25 20:42:13 --> Could not find the language line "next_link"
ERROR - 2016-12-25 20:42:13 --> Could not find the language line "prev_link"
DEBUG - 2016-12-25 20:42:13 --> Pagination Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Table Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Model Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Model Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Helper loaded: file_helper
DEBUG - 2016-12-25 20:42:13 --> Model Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Controller Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Helper loaded: language_helper
DEBUG - 2016-12-25 20:42:13 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-25 20:42:13 --> Model Class Initialized
DEBUG - 2016-12-25 20:42:13 --> Upload Class Initialized
DEBUG - 2016-12-25 20:43:09 --> DB Transaction Failure
ERROR - 2016-12-25 20:43:09 --> Query error: Table 'univ_alumni.lk9v6_alumni_main' doesn't exist
DEBUG - 2016-12-25 20:43:09 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-25 20:43:09 --> Could not find the language line "db_error_heading"
