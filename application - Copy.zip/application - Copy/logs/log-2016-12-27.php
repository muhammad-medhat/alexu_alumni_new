<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-12-27 00:00:02 --> Config Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Hooks Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Utf8 Class Initialized
DEBUG - 2016-12-27 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 00:00:02 --> URI Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Router Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Output Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Security Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Input Class Initialized
DEBUG - 2016-12-27 00:00:02 --> XSS Filtering completed
DEBUG - 2016-12-27 00:00:02 --> XSS Filtering completed
DEBUG - 2016-12-27 00:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 00:00:02 --> Language Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Loader Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Helper loaded: url_helper
DEBUG - 2016-12-27 00:00:02 --> Helper loaded: form_helper
DEBUG - 2016-12-27 00:00:02 --> Helper loaded: func_helper
DEBUG - 2016-12-27 00:00:02 --> Database Driver Class Initialized
ERROR - 2016-12-27 00:00:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 00:00:02 --> Session Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Helper loaded: string_helper
DEBUG - 2016-12-27 00:00:02 --> Encrypt Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Session routines successfully run
ERROR - 2016-12-27 00:00:02 --> Could not find the language line "first_link"
ERROR - 2016-12-27 00:00:02 --> Could not find the language line "last_link"
ERROR - 2016-12-27 00:00:02 --> Could not find the language line "next_link"
ERROR - 2016-12-27 00:00:02 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 00:00:02 --> Pagination Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Table Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Model Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Model Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Helper loaded: file_helper
DEBUG - 2016-12-27 00:00:02 --> Model Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Controller Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Helper loaded: language_helper
DEBUG - 2016-12-27 00:00:02 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-27 00:00:02 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-27 00:00:02 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-27 00:00:02 --> File loaded: application/views/me/myadmin_upload.php
DEBUG - 2016-12-27 00:00:02 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-27 00:00:02 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-27 00:00:02 --> Final output sent to browser
DEBUG - 2016-12-27 00:00:02 --> Total execution time: 0.1020
DEBUG - 2016-12-27 00:00:02 --> Config Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Hooks Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Utf8 Class Initialized
DEBUG - 2016-12-27 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 00:00:02 --> URI Class Initialized
DEBUG - 2016-12-27 00:00:02 --> Router Class Initialized
ERROR - 2016-12-27 00:00:02 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 00:01:21 --> Config Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Hooks Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Utf8 Class Initialized
DEBUG - 2016-12-27 00:01:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 00:01:21 --> URI Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Router Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Output Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Security Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Input Class Initialized
DEBUG - 2016-12-27 00:01:21 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:21 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 00:01:21 --> Language Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Loader Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Helper loaded: url_helper
DEBUG - 2016-12-27 00:01:21 --> Helper loaded: form_helper
DEBUG - 2016-12-27 00:01:21 --> Helper loaded: func_helper
DEBUG - 2016-12-27 00:01:21 --> Database Driver Class Initialized
ERROR - 2016-12-27 00:01:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 00:01:21 --> Session Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Helper loaded: string_helper
DEBUG - 2016-12-27 00:01:21 --> Encrypt Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Session routines successfully run
ERROR - 2016-12-27 00:01:21 --> Could not find the language line "first_link"
ERROR - 2016-12-27 00:01:21 --> Could not find the language line "last_link"
ERROR - 2016-12-27 00:01:21 --> Could not find the language line "next_link"
ERROR - 2016-12-27 00:01:21 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 00:01:21 --> Pagination Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Table Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Model Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Model Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Helper loaded: file_helper
DEBUG - 2016-12-27 00:01:21 --> Model Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Controller Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Helper loaded: language_helper
DEBUG - 2016-12-27 00:01:21 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-27 00:01:21 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-27 00:01:21 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-27 00:01:21 --> File loaded: application/views/me/myadmin_upload.php
DEBUG - 2016-12-27 00:01:21 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-27 00:01:21 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-27 00:01:21 --> Final output sent to browser
DEBUG - 2016-12-27 00:01:21 --> Total execution time: 0.0870
DEBUG - 2016-12-27 00:01:21 --> Config Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Hooks Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Utf8 Class Initialized
DEBUG - 2016-12-27 00:01:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 00:01:21 --> URI Class Initialized
DEBUG - 2016-12-27 00:01:21 --> Router Class Initialized
ERROR - 2016-12-27 00:01:21 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 00:01:57 --> Config Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Hooks Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Utf8 Class Initialized
DEBUG - 2016-12-27 00:01:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 00:01:57 --> URI Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Router Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Output Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Security Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Input Class Initialized
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> XSS Filtering completed
DEBUG - 2016-12-27 00:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 00:01:57 --> Language Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Loader Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Helper loaded: url_helper
DEBUG - 2016-12-27 00:01:57 --> Helper loaded: form_helper
DEBUG - 2016-12-27 00:01:57 --> Helper loaded: func_helper
DEBUG - 2016-12-27 00:01:57 --> Database Driver Class Initialized
ERROR - 2016-12-27 00:01:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 00:01:57 --> Session Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Helper loaded: string_helper
DEBUG - 2016-12-27 00:01:57 --> Encrypt Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Session routines successfully run
ERROR - 2016-12-27 00:01:57 --> Could not find the language line "first_link"
ERROR - 2016-12-27 00:01:57 --> Could not find the language line "last_link"
ERROR - 2016-12-27 00:01:57 --> Could not find the language line "next_link"
ERROR - 2016-12-27 00:01:57 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 00:01:57 --> Pagination Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Table Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Model Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Model Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Helper loaded: file_helper
DEBUG - 2016-12-27 00:01:57 --> Model Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Controller Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Helper loaded: language_helper
DEBUG - 2016-12-27 00:01:57 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 00:01:57 --> Model Class Initialized
DEBUG - 2016-12-27 00:01:57 --> Upload Class Initialized
ERROR - 2016-12-27 00:01:58 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-27 00:01:58 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-27 00:01:58 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-27 00:01:58 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-27 00:01:58 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-27 00:01:58 --> Final output sent to browser
DEBUG - 2016-12-27 00:01:58 --> Total execution time: 0.5450
DEBUG - 2016-12-27 00:01:58 --> Config Class Initialized
DEBUG - 2016-12-27 00:01:58 --> Hooks Class Initialized
DEBUG - 2016-12-27 00:01:58 --> Utf8 Class Initialized
DEBUG - 2016-12-27 00:01:58 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 00:01:58 --> URI Class Initialized
DEBUG - 2016-12-27 00:01:58 --> Router Class Initialized
ERROR - 2016-12-27 00:01:58 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 00:02:48 --> Config Class Initialized
DEBUG - 2016-12-27 00:02:48 --> Hooks Class Initialized
DEBUG - 2016-12-27 00:02:48 --> Utf8 Class Initialized
DEBUG - 2016-12-27 00:02:48 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 00:02:48 --> URI Class Initialized
DEBUG - 2016-12-27 00:02:48 --> Router Class Initialized
DEBUG - 2016-12-27 00:02:48 --> Output Class Initialized
DEBUG - 2016-12-27 00:02:48 --> Security Class Initialized
DEBUG - 2016-12-27 00:02:48 --> Input Class Initialized
DEBUG - 2016-12-27 00:02:48 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:48 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> XSS Filtering completed
DEBUG - 2016-12-27 00:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 00:02:49 --> Language Class Initialized
DEBUG - 2016-12-27 00:02:49 --> Loader Class Initialized
DEBUG - 2016-12-27 00:02:49 --> Helper loaded: url_helper
DEBUG - 2016-12-27 00:02:49 --> Helper loaded: form_helper
DEBUG - 2016-12-27 00:02:49 --> Helper loaded: func_helper
DEBUG - 2016-12-27 00:02:49 --> Database Driver Class Initialized
ERROR - 2016-12-27 00:02:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 00:02:49 --> Session Class Initialized
DEBUG - 2016-12-27 00:02:49 --> Helper loaded: string_helper
DEBUG - 2016-12-27 00:02:49 --> Encrypt Class Initialized
DEBUG - 2016-12-27 00:02:49 --> Session routines successfully run
ERROR - 2016-12-27 00:02:49 --> Could not find the language line "first_link"
ERROR - 2016-12-27 00:02:49 --> Could not find the language line "last_link"
ERROR - 2016-12-27 00:02:49 --> Could not find the language line "next_link"
ERROR - 2016-12-27 00:02:49 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 00:02:49 --> Pagination Class Initialized
DEBUG - 2016-12-27 00:02:49 --> Table Class Initialized
DEBUG - 2016-12-27 00:02:49 --> Model Class Initialized
DEBUG - 2016-12-27 00:02:49 --> Model Class Initialized
DEBUG - 2016-12-27 00:02:49 --> Helper loaded: file_helper
DEBUG - 2016-12-27 00:02:49 --> Model Class Initialized
DEBUG - 2016-12-27 00:02:49 --> Controller Class Initialized
DEBUG - 2016-12-27 00:02:49 --> Helper loaded: language_helper
DEBUG - 2016-12-27 00:02:49 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 00:02:49 --> Model Class Initialized
DEBUG - 2016-12-27 00:02:49 --> Upload Class Initialized
ERROR - 2016-12-27 00:02:49 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-27 00:02:49 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-27 00:02:49 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-27 00:02:49 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-27 00:02:49 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-27 00:02:49 --> Final output sent to browser
DEBUG - 2016-12-27 00:02:49 --> Total execution time: 0.5240
DEBUG - 2016-12-27 00:02:49 --> Config Class Initialized
DEBUG - 2016-12-27 00:02:49 --> Hooks Class Initialized
DEBUG - 2016-12-27 00:02:49 --> Utf8 Class Initialized
DEBUG - 2016-12-27 00:02:49 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 00:02:49 --> URI Class Initialized
DEBUG - 2016-12-27 00:02:49 --> Router Class Initialized
ERROR - 2016-12-27 00:02:49 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:00:05 --> Config Class Initialized
DEBUG - 2016-12-27 22:00:05 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:00:05 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:00:05 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:00:05 --> URI Class Initialized
DEBUG - 2016-12-27 22:00:05 --> Router Class Initialized
DEBUG - 2016-12-27 22:00:05 --> Output Class Initialized
DEBUG - 2016-12-27 22:00:05 --> Security Class Initialized
DEBUG - 2016-12-27 22:00:05 --> Input Class Initialized
DEBUG - 2016-12-27 22:00:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:00:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:00:05 --> Language Class Initialized
DEBUG - 2016-12-27 22:00:05 --> Loader Class Initialized
DEBUG - 2016-12-27 22:00:05 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:00:05 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:00:05 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:00:05 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:00:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:00:05 --> Session Class Initialized
DEBUG - 2016-12-27 22:00:05 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:00:05 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:00:05 --> A session cookie was not found.
DEBUG - 2016-12-27 22:00:05 --> Session routines successfully run
ERROR - 2016-12-27 22:00:05 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:00:05 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:00:05 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:00:05 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:00:05 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:00:05 --> Table Class Initialized
DEBUG - 2016-12-27 22:00:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:00:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:00:05 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:00:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:00:05 --> Controller Class Initialized
DEBUG - 2016-12-27 22:00:13 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:00:13 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:00:14 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:00:14 --> File loaded: application/views/includes/header.php
ERROR - 2016-12-27 22:00:14 --> Could not find the language line "not_found_message"
DEBUG - 2016-12-27 22:00:14 --> File loaded: application/views/not_found.php
DEBUG - 2016-12-27 22:00:14 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:00:14 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:00:14 --> Final output sent to browser
DEBUG - 2016-12-27 22:00:14 --> Total execution time: 8.8665
DEBUG - 2016-12-27 22:00:14 --> Config Class Initialized
DEBUG - 2016-12-27 22:00:14 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:00:14 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:00:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:00:14 --> URI Class Initialized
DEBUG - 2016-12-27 22:00:14 --> Router Class Initialized
ERROR - 2016-12-27 22:00:14 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:00:44 --> Config Class Initialized
DEBUG - 2016-12-27 22:00:44 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:00:44 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:00:44 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:00:44 --> URI Class Initialized
DEBUG - 2016-12-27 22:00:44 --> Router Class Initialized
DEBUG - 2016-12-27 22:00:44 --> No URI present. Default controller set.
DEBUG - 2016-12-27 22:00:44 --> Output Class Initialized
DEBUG - 2016-12-27 22:00:44 --> Security Class Initialized
DEBUG - 2016-12-27 22:00:44 --> Input Class Initialized
DEBUG - 2016-12-27 22:00:44 --> XSS Filtering completed
DEBUG - 2016-12-27 22:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:00:44 --> Language Class Initialized
DEBUG - 2016-12-27 22:00:44 --> Loader Class Initialized
DEBUG - 2016-12-27 22:00:44 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:00:44 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:00:44 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:00:44 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:00:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:00:44 --> Session Class Initialized
DEBUG - 2016-12-27 22:00:44 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:00:44 --> Encrypt Class Initialized
ERROR - 2016-12-27 22:00:44 --> Session: The session cookie was not signed.
DEBUG - 2016-12-27 22:00:44 --> Session routines successfully run
ERROR - 2016-12-27 22:00:44 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:00:44 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:00:44 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:00:44 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:00:44 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:00:44 --> Table Class Initialized
DEBUG - 2016-12-27 22:00:44 --> Model Class Initialized
DEBUG - 2016-12-27 22:00:44 --> Model Class Initialized
DEBUG - 2016-12-27 22:00:44 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:00:44 --> Model Class Initialized
DEBUG - 2016-12-27 22:00:44 --> Controller Class Initialized
DEBUG - 2016-12-27 22:00:48 --> DB Transaction Failure
ERROR - 2016-12-27 22:00:48 --> Query error: Duplicate entry '0' for key 'PRIMARY'
DEBUG - 2016-12-27 22:00:48 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-27 22:00:48 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-27 22:01:56 --> Config Class Initialized
DEBUG - 2016-12-27 22:01:56 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:01:56 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:01:56 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:01:56 --> URI Class Initialized
DEBUG - 2016-12-27 22:01:56 --> Router Class Initialized
DEBUG - 2016-12-27 22:01:56 --> No URI present. Default controller set.
DEBUG - 2016-12-27 22:01:56 --> Output Class Initialized
DEBUG - 2016-12-27 22:01:56 --> Security Class Initialized
DEBUG - 2016-12-27 22:01:56 --> Input Class Initialized
DEBUG - 2016-12-27 22:01:56 --> XSS Filtering completed
DEBUG - 2016-12-27 22:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:01:56 --> Language Class Initialized
DEBUG - 2016-12-27 22:01:56 --> Loader Class Initialized
DEBUG - 2016-12-27 22:01:56 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:01:56 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:01:56 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:01:56 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:01:56 --> Session Class Initialized
DEBUG - 2016-12-27 22:01:56 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:01:56 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:01:56 --> Session routines successfully run
ERROR - 2016-12-27 22:01:56 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:01:56 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:01:56 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:01:56 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:01:56 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:01:56 --> Table Class Initialized
DEBUG - 2016-12-27 22:01:56 --> Model Class Initialized
DEBUG - 2016-12-27 22:01:56 --> Model Class Initialized
DEBUG - 2016-12-27 22:01:56 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:01:56 --> Model Class Initialized
DEBUG - 2016-12-27 22:01:56 --> Controller Class Initialized
DEBUG - 2016-12-27 22:01:57 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:01:57 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:01:59 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-27 22:02:01 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:02:01 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:02:02 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-27 22:02:02 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-27 22:02:02 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-27 22:02:02 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:02:02 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:02:02 --> Final output sent to browser
DEBUG - 2016-12-27 22:02:02 --> Total execution time: 5.2993
DEBUG - 2016-12-27 22:02:02 --> Config Class Initialized
DEBUG - 2016-12-27 22:02:02 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:02:02 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:02:02 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:02:02 --> URI Class Initialized
DEBUG - 2016-12-27 22:02:02 --> Router Class Initialized
ERROR - 2016-12-27 22:02:02 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:02:02 --> Config Class Initialized
DEBUG - 2016-12-27 22:02:02 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:02:02 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:02:02 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:02:02 --> URI Class Initialized
DEBUG - 2016-12-27 22:02:02 --> Router Class Initialized
ERROR - 2016-12-27 22:02:02 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:02:14 --> Config Class Initialized
DEBUG - 2016-12-27 22:02:14 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:02:14 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:02:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:02:14 --> URI Class Initialized
DEBUG - 2016-12-27 22:02:14 --> Router Class Initialized
DEBUG - 2016-12-27 22:02:14 --> Output Class Initialized
DEBUG - 2016-12-27 22:02:15 --> Security Class Initialized
DEBUG - 2016-12-27 22:02:15 --> Input Class Initialized
DEBUG - 2016-12-27 22:02:15 --> XSS Filtering completed
DEBUG - 2016-12-27 22:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:02:15 --> Language Class Initialized
DEBUG - 2016-12-27 22:02:15 --> Loader Class Initialized
DEBUG - 2016-12-27 22:02:15 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:02:15 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:02:15 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:02:15 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:02:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:02:15 --> Session Class Initialized
DEBUG - 2016-12-27 22:02:15 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:02:15 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:02:15 --> Session routines successfully run
ERROR - 2016-12-27 22:02:15 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:02:15 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:02:15 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:02:15 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:02:15 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:02:15 --> Table Class Initialized
DEBUG - 2016-12-27 22:02:15 --> Model Class Initialized
DEBUG - 2016-12-27 22:02:15 --> Model Class Initialized
DEBUG - 2016-12-27 22:02:15 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:02:15 --> Model Class Initialized
DEBUG - 2016-12-27 22:02:15 --> Controller Class Initialized
DEBUG - 2016-12-27 22:02:16 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:02:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:02:17 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:02:17 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:02:17 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-27 22:02:17 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:02:17 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:02:17 --> Final output sent to browser
DEBUG - 2016-12-27 22:02:17 --> Total execution time: 2.4771
DEBUG - 2016-12-27 22:02:17 --> Config Class Initialized
DEBUG - 2016-12-27 22:02:17 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:02:17 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:02:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:02:17 --> URI Class Initialized
DEBUG - 2016-12-27 22:02:17 --> Router Class Initialized
ERROR - 2016-12-27 22:02:17 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:02:17 --> Config Class Initialized
DEBUG - 2016-12-27 22:02:17 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:02:17 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:02:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:02:17 --> URI Class Initialized
DEBUG - 2016-12-27 22:02:17 --> Router Class Initialized
ERROR - 2016-12-27 22:02:17 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:02:35 --> Config Class Initialized
DEBUG - 2016-12-27 22:02:35 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:02:35 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:02:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:02:35 --> URI Class Initialized
DEBUG - 2016-12-27 22:02:35 --> Router Class Initialized
DEBUG - 2016-12-27 22:02:35 --> No URI present. Default controller set.
DEBUG - 2016-12-27 22:02:35 --> Output Class Initialized
DEBUG - 2016-12-27 22:02:35 --> Security Class Initialized
DEBUG - 2016-12-27 22:02:35 --> Input Class Initialized
DEBUG - 2016-12-27 22:02:35 --> XSS Filtering completed
DEBUG - 2016-12-27 22:02:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:02:35 --> Language Class Initialized
DEBUG - 2016-12-27 22:02:35 --> Loader Class Initialized
DEBUG - 2016-12-27 22:02:35 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:02:35 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:02:35 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:02:35 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:02:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:02:35 --> Session Class Initialized
DEBUG - 2016-12-27 22:02:35 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:02:35 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:02:35 --> Session routines successfully run
ERROR - 2016-12-27 22:02:35 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:02:35 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:02:35 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:02:35 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:02:35 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:02:35 --> Table Class Initialized
DEBUG - 2016-12-27 22:02:35 --> Model Class Initialized
DEBUG - 2016-12-27 22:02:35 --> Model Class Initialized
DEBUG - 2016-12-27 22:02:35 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:02:35 --> Model Class Initialized
DEBUG - 2016-12-27 22:02:35 --> Controller Class Initialized
DEBUG - 2016-12-27 22:02:37 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:02:37 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:02:39 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-27 22:02:41 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:02:41 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:02:41 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-27 22:02:41 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-27 22:02:41 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-27 22:02:41 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:02:41 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:02:41 --> Final output sent to browser
DEBUG - 2016-12-27 22:02:41 --> Total execution time: 6.0293
DEBUG - 2016-12-27 22:02:41 --> Config Class Initialized
DEBUG - 2016-12-27 22:02:41 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:02:41 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:02:41 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:02:41 --> URI Class Initialized
DEBUG - 2016-12-27 22:02:41 --> Router Class Initialized
ERROR - 2016-12-27 22:02:41 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:02:41 --> Config Class Initialized
DEBUG - 2016-12-27 22:02:41 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:02:41 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:02:41 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:02:41 --> URI Class Initialized
DEBUG - 2016-12-27 22:02:41 --> Router Class Initialized
ERROR - 2016-12-27 22:02:41 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:02:50 --> Config Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:02:50 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:02:50 --> URI Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Router Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Output Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Security Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Input Class Initialized
DEBUG - 2016-12-27 22:02:50 --> XSS Filtering completed
DEBUG - 2016-12-27 22:02:50 --> XSS Filtering completed
DEBUG - 2016-12-27 22:02:50 --> XSS Filtering completed
DEBUG - 2016-12-27 22:02:50 --> XSS Filtering completed
DEBUG - 2016-12-27 22:02:50 --> XSS Filtering completed
DEBUG - 2016-12-27 22:02:50 --> XSS Filtering completed
DEBUG - 2016-12-27 22:02:50 --> XSS Filtering completed
DEBUG - 2016-12-27 22:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:02:50 --> Language Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Loader Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:02:50 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:02:50 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:02:50 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:02:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:02:50 --> Session Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:02:50 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Session routines successfully run
ERROR - 2016-12-27 22:02:50 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:02:50 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:02:50 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:02:50 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:02:50 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Table Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Model Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Model Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:02:50 --> Model Class Initialized
DEBUG - 2016-12-27 22:02:50 --> Controller Class Initialized
DEBUG - 2016-12-27 22:02:51 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:02:51 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:02:54 --> Config Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:02:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:02:54 --> URI Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Router Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Output Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Security Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Input Class Initialized
DEBUG - 2016-12-27 22:02:54 --> XSS Filtering completed
DEBUG - 2016-12-27 22:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:02:54 --> Language Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Loader Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:02:54 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:02:54 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:02:54 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:02:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:02:54 --> Session Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:02:54 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Session routines successfully run
ERROR - 2016-12-27 22:02:54 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:02:54 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:02:54 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:02:54 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:02:54 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Table Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Model Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Model Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:02:54 --> Model Class Initialized
DEBUG - 2016-12-27 22:02:54 --> Controller Class Initialized
DEBUG - 2016-12-27 22:02:56 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:02:56 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:02:56 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-12-27 22:02:57 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-27 22:02:57 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:02:57 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:02:57 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-27 22:02:57 --> File loaded: application/views/alumni_view_files/single.php
DEBUG - 2016-12-27 22:02:57 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-27 22:02:57 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:02:57 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:02:57 --> Final output sent to browser
DEBUG - 2016-12-27 22:02:57 --> Total execution time: 3.7012
DEBUG - 2016-12-27 22:02:57 --> Config Class Initialized
DEBUG - 2016-12-27 22:02:57 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:02:57 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:02:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:02:57 --> URI Class Initialized
DEBUG - 2016-12-27 22:02:57 --> Router Class Initialized
ERROR - 2016-12-27 22:02:57 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:02:58 --> Config Class Initialized
DEBUG - 2016-12-27 22:02:58 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:02:58 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:02:58 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:02:58 --> URI Class Initialized
DEBUG - 2016-12-27 22:02:58 --> Router Class Initialized
ERROR - 2016-12-27 22:02:58 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:03:19 --> Config Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:03:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:03:19 --> URI Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Router Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Output Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Security Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Input Class Initialized
DEBUG - 2016-12-27 22:03:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:03:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:03:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:03:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:03:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:03:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:03:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:03:19 --> Language Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Loader Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:03:19 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:03:19 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:03:19 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:03:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:03:19 --> Session Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:03:19 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Session routines successfully run
ERROR - 2016-12-27 22:03:19 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:03:19 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:03:19 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:03:19 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:03:19 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Table Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Model Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Model Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:03:19 --> Model Class Initialized
DEBUG - 2016-12-27 22:03:19 --> Controller Class Initialized
DEBUG - 2016-12-27 22:03:21 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:03:21 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:03:22 --> Config Class Initialized
DEBUG - 2016-12-27 22:03:22 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:03:22 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:03:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:03:22 --> URI Class Initialized
DEBUG - 2016-12-27 22:03:22 --> Router Class Initialized
DEBUG - 2016-12-27 22:03:22 --> Output Class Initialized
DEBUG - 2016-12-27 22:03:22 --> Security Class Initialized
DEBUG - 2016-12-27 22:03:22 --> Input Class Initialized
DEBUG - 2016-12-27 22:03:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:03:23 --> Language Class Initialized
DEBUG - 2016-12-27 22:03:23 --> Loader Class Initialized
DEBUG - 2016-12-27 22:03:23 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:03:23 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:03:23 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:03:23 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:03:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:03:23 --> Session Class Initialized
DEBUG - 2016-12-27 22:03:23 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:03:23 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:03:23 --> Session routines successfully run
ERROR - 2016-12-27 22:03:23 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:03:23 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:03:23 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:03:23 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:03:23 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:03:23 --> Table Class Initialized
DEBUG - 2016-12-27 22:03:23 --> Model Class Initialized
DEBUG - 2016-12-27 22:03:23 --> Model Class Initialized
DEBUG - 2016-12-27 22:03:23 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:03:23 --> Model Class Initialized
DEBUG - 2016-12-27 22:03:23 --> Controller Class Initialized
DEBUG - 2016-12-27 22:03:25 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:03:25 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:03:25 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-12-27 22:03:26 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-27 22:03:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:03:26 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:03:26 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-27 22:03:26 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-27 22:03:26 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-27 22:03:26 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:03:26 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:03:26 --> Final output sent to browser
DEBUG - 2016-12-27 22:03:26 --> Total execution time: 3.9452
DEBUG - 2016-12-27 22:03:26 --> Config Class Initialized
DEBUG - 2016-12-27 22:03:26 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:03:26 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:03:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:03:26 --> URI Class Initialized
DEBUG - 2016-12-27 22:03:26 --> Router Class Initialized
ERROR - 2016-12-27 22:03:26 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:03:27 --> Config Class Initialized
DEBUG - 2016-12-27 22:03:27 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:03:27 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:03:27 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:03:27 --> URI Class Initialized
DEBUG - 2016-12-27 22:03:27 --> Router Class Initialized
ERROR - 2016-12-27 22:03:27 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:03:33 --> Config Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:03:33 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:03:33 --> URI Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Router Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Output Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Security Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Input Class Initialized
DEBUG - 2016-12-27 22:03:33 --> XSS Filtering completed
DEBUG - 2016-12-27 22:03:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:03:33 --> Language Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Loader Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:03:33 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:03:33 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:03:33 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:03:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:03:33 --> Session Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:03:33 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Session routines successfully run
ERROR - 2016-12-27 22:03:33 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:03:33 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:03:33 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:03:33 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:03:33 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Table Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Model Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Model Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:03:33 --> Model Class Initialized
DEBUG - 2016-12-27 22:03:33 --> Controller Class Initialized
DEBUG - 2016-12-27 22:03:35 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:03:35 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:03:35 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-12-27 22:03:37 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-27 22:03:37 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:03:37 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:03:37 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-27 22:03:37 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-27 22:03:37 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-27 22:03:37 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:03:37 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:03:37 --> Final output sent to browser
DEBUG - 2016-12-27 22:03:37 --> Total execution time: 4.0012
DEBUG - 2016-12-27 22:03:37 --> Config Class Initialized
DEBUG - 2016-12-27 22:03:37 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:03:37 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:03:37 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:03:37 --> URI Class Initialized
DEBUG - 2016-12-27 22:03:37 --> Router Class Initialized
ERROR - 2016-12-27 22:03:37 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:03:37 --> Config Class Initialized
DEBUG - 2016-12-27 22:03:37 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:03:37 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:03:37 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:03:37 --> URI Class Initialized
DEBUG - 2016-12-27 22:03:37 --> Router Class Initialized
ERROR - 2016-12-27 22:03:37 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:03:45 --> Config Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:03:45 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:03:45 --> URI Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Router Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Output Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Security Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Input Class Initialized
DEBUG - 2016-12-27 22:03:45 --> XSS Filtering completed
DEBUG - 2016-12-27 22:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:03:45 --> Language Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Loader Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:03:45 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:03:45 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:03:45 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:03:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:03:45 --> Session Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:03:45 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Session routines successfully run
ERROR - 2016-12-27 22:03:45 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:03:45 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:03:45 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:03:45 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:03:45 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Table Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Model Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Model Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:03:45 --> Model Class Initialized
DEBUG - 2016-12-27 22:03:45 --> Controller Class Initialized
DEBUG - 2016-12-27 22:03:47 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:03:47 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:03:47 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-12-27 22:03:49 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-27 22:03:49 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:03:49 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:03:49 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-27 22:03:49 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-27 22:03:49 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-27 22:03:49 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:03:49 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:03:49 --> Final output sent to browser
DEBUG - 2016-12-27 22:03:49 --> Total execution time: 4.1812
DEBUG - 2016-12-27 22:03:49 --> Config Class Initialized
DEBUG - 2016-12-27 22:03:49 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:03:49 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:03:49 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:03:49 --> URI Class Initialized
DEBUG - 2016-12-27 22:03:49 --> Router Class Initialized
ERROR - 2016-12-27 22:03:49 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:03:50 --> Config Class Initialized
DEBUG - 2016-12-27 22:03:50 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:03:50 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:03:50 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:03:50 --> URI Class Initialized
DEBUG - 2016-12-27 22:03:50 --> Router Class Initialized
ERROR - 2016-12-27 22:03:50 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:04:48 --> Config Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:04:48 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:04:48 --> URI Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Router Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Output Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Security Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Input Class Initialized
DEBUG - 2016-12-27 22:04:48 --> XSS Filtering completed
DEBUG - 2016-12-27 22:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:04:48 --> Language Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Loader Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:04:48 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:04:48 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:04:48 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:04:48 --> Session Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:04:48 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Session routines successfully run
ERROR - 2016-12-27 22:04:48 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:04:48 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:04:48 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:04:48 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:04:48 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Table Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Model Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Model Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:04:48 --> Model Class Initialized
DEBUG - 2016-12-27 22:04:48 --> Controller Class Initialized
DEBUG - 2016-12-27 22:04:50 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:04:50 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:04:50 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:04:50 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:04:50 --> File loaded: application/views/signup/main.php
DEBUG - 2016-12-27 22:04:50 --> File loaded: application/views/signup/login.php
DEBUG - 2016-12-27 22:04:50 --> File loaded: application/views/signup/personal.php
ERROR - 2016-12-27 22:04:50 --> Could not find the language line "register"
DEBUG - 2016-12-27 22:04:50 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-12-27 22:04:50 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:04:50 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:04:50 --> Final output sent to browser
DEBUG - 2016-12-27 22:04:50 --> Total execution time: 2.2711
DEBUG - 2016-12-27 22:04:50 --> Config Class Initialized
DEBUG - 2016-12-27 22:04:50 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:04:50 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:04:50 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:04:50 --> URI Class Initialized
DEBUG - 2016-12-27 22:04:50 --> Router Class Initialized
ERROR - 2016-12-27 22:04:50 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:04:50 --> Config Class Initialized
DEBUG - 2016-12-27 22:04:50 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:04:50 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:04:50 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:04:50 --> URI Class Initialized
DEBUG - 2016-12-27 22:04:50 --> Router Class Initialized
ERROR - 2016-12-27 22:04:50 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:05:19 --> Config Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:05:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:05:19 --> URI Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Router Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Output Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Security Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Input Class Initialized
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> XSS Filtering completed
DEBUG - 2016-12-27 22:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:05:19 --> Language Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Loader Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:05:19 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:05:19 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:05:19 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:05:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:05:19 --> Session Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:05:19 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Session routines successfully run
ERROR - 2016-12-27 22:05:19 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:05:19 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:05:19 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:05:19 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:05:19 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Table Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Model Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Model Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:05:19 --> Model Class Initialized
DEBUG - 2016-12-27 22:05:19 --> Controller Class Initialized
DEBUG - 2016-12-27 22:05:20 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:05:20 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:05:20 --> Form Validation Class Initialized
ERROR - 2016-12-27 22:05:20 --> Could not find the language line "year"
ERROR - 2016-12-27 22:05:20 --> Could not find the language line "retype"
DEBUG - 2016-12-27 22:05:20 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-12-27 22:05:20 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:05:20 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:05:20 --> File loaded: application/views/signup/main.php
DEBUG - 2016-12-27 22:05:20 --> File loaded: application/views/signup/login.php
DEBUG - 2016-12-27 22:05:20 --> File loaded: application/views/signup/personal.php
ERROR - 2016-12-27 22:05:20 --> Could not find the language line "register"
DEBUG - 2016-12-27 22:05:20 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-12-27 22:05:20 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:05:20 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:05:20 --> Final output sent to browser
DEBUG - 2016-12-27 22:05:20 --> Total execution time: 1.7641
DEBUG - 2016-12-27 22:05:20 --> Config Class Initialized
DEBUG - 2016-12-27 22:05:20 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:05:20 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:05:20 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:05:20 --> URI Class Initialized
DEBUG - 2016-12-27 22:05:20 --> Router Class Initialized
ERROR - 2016-12-27 22:05:20 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:05:20 --> Config Class Initialized
DEBUG - 2016-12-27 22:05:20 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:05:20 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:05:20 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:05:20 --> URI Class Initialized
DEBUG - 2016-12-27 22:05:20 --> Router Class Initialized
ERROR - 2016-12-27 22:05:20 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:06:06 --> Config Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:06:06 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:06:06 --> URI Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Router Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Output Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Security Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Input Class Initialized
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:06:06 --> Language Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Loader Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:06:06 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:06:06 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:06:06 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:06:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:06:06 --> Session Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:06:06 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Session routines successfully run
ERROR - 2016-12-27 22:06:06 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:06:06 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:06:06 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:06:06 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:06:06 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Table Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Model Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Model Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:06:06 --> Model Class Initialized
DEBUG - 2016-12-27 22:06:06 --> Controller Class Initialized
DEBUG - 2016-12-27 22:06:07 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:06:07 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:06:07 --> Form Validation Class Initialized
ERROR - 2016-12-27 22:06:07 --> Could not find the language line "year"
ERROR - 2016-12-27 22:06:07 --> Could not find the language line "retype"
DEBUG - 2016-12-27 22:06:07 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-12-27 22:06:08 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:06:08 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:06:08 --> File loaded: application/views/signup/main.php
DEBUG - 2016-12-27 22:06:08 --> File loaded: application/views/signup/login.php
DEBUG - 2016-12-27 22:06:08 --> File loaded: application/views/signup/personal.php
ERROR - 2016-12-27 22:06:08 --> Could not find the language line "register"
DEBUG - 2016-12-27 22:06:08 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-12-27 22:06:08 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:06:08 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:06:08 --> Final output sent to browser
DEBUG - 2016-12-27 22:06:08 --> Total execution time: 2.3641
DEBUG - 2016-12-27 22:06:08 --> Config Class Initialized
DEBUG - 2016-12-27 22:06:08 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:06:08 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:06:08 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:06:08 --> URI Class Initialized
DEBUG - 2016-12-27 22:06:08 --> Router Class Initialized
ERROR - 2016-12-27 22:06:08 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:06:22 --> Config Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:06:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:06:22 --> URI Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Router Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Output Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Security Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Input Class Initialized
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:06:22 --> Language Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Loader Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:06:22 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:06:22 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:06:22 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:06:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:06:22 --> Session Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:06:22 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Session routines successfully run
ERROR - 2016-12-27 22:06:22 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:06:22 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:06:22 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:06:22 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:06:22 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Table Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Model Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Model Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:06:22 --> Model Class Initialized
DEBUG - 2016-12-27 22:06:22 --> Controller Class Initialized
DEBUG - 2016-12-27 22:06:23 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:06:23 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:06:23 --> Form Validation Class Initialized
ERROR - 2016-12-27 22:06:23 --> Could not find the language line "year"
ERROR - 2016-12-27 22:06:23 --> Could not find the language line "retype"
DEBUG - 2016-12-27 22:06:23 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:25 --> Config Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:06:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:06:25 --> URI Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Router Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Output Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Security Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Input Class Initialized
DEBUG - 2016-12-27 22:06:25 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:06:25 --> Language Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Loader Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:06:25 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:06:25 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:06:25 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:06:25 --> Session Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:06:25 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Session routines successfully run
ERROR - 2016-12-27 22:06:25 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:06:25 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:06:25 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:06:25 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:06:25 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Table Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Model Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Model Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:06:25 --> Model Class Initialized
DEBUG - 2016-12-27 22:06:25 --> Controller Class Initialized
DEBUG - 2016-12-27 22:06:26 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:06:26 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-27 22:06:26 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-27 22:06:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:06:26 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:06:26 --> File loaded: application/views/signup/complete.php
DEBUG - 2016-12-27 22:06:26 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:06:26 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:06:26 --> Final output sent to browser
DEBUG - 2016-12-27 22:06:26 --> Total execution time: 1.8321
DEBUG - 2016-12-27 22:06:26 --> Config Class Initialized
DEBUG - 2016-12-27 22:06:26 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:06:26 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:06:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:06:26 --> URI Class Initialized
DEBUG - 2016-12-27 22:06:26 --> Router Class Initialized
ERROR - 2016-12-27 22:06:26 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:06:57 --> Config Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:06:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:06:57 --> URI Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Router Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Output Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Security Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Input Class Initialized
DEBUG - 2016-12-27 22:06:57 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:57 --> XSS Filtering completed
DEBUG - 2016-12-27 22:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:06:57 --> Language Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Loader Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:06:57 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:06:57 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:06:57 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:06:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:06:57 --> Session Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:06:57 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Session routines successfully run
ERROR - 2016-12-27 22:06:57 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:06:57 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:06:57 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:06:57 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:06:57 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Table Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Model Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Model Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:06:57 --> Model Class Initialized
DEBUG - 2016-12-27 22:06:57 --> Controller Class Initialized
DEBUG - 2016-12-27 22:06:59 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:06:59 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:06:59 --> Upload Class Initialized
DEBUG - 2016-12-27 22:06:59 --> Image Lib Class Initialized
DEBUG - 2016-12-27 22:06:59 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:06:59 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:06:59 --> File loaded: application/views/signup/success.php
DEBUG - 2016-12-27 22:06:59 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:06:59 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:06:59 --> Final output sent to browser
DEBUG - 2016-12-27 22:06:59 --> Total execution time: 1.5851
DEBUG - 2016-12-27 22:06:59 --> Config Class Initialized
DEBUG - 2016-12-27 22:06:59 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:06:59 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:06:59 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:06:59 --> URI Class Initialized
DEBUG - 2016-12-27 22:06:59 --> Router Class Initialized
ERROR - 2016-12-27 22:06:59 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:06:59 --> Config Class Initialized
DEBUG - 2016-12-27 22:06:59 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:06:59 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:06:59 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:06:59 --> URI Class Initialized
DEBUG - 2016-12-27 22:06:59 --> Router Class Initialized
ERROR - 2016-12-27 22:06:59 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:07:44 --> Config Class Initialized
DEBUG - 2016-12-27 22:07:44 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:07:44 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:07:44 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:07:44 --> URI Class Initialized
DEBUG - 2016-12-27 22:07:44 --> Router Class Initialized
DEBUG - 2016-12-27 22:07:44 --> Output Class Initialized
DEBUG - 2016-12-27 22:07:44 --> Security Class Initialized
DEBUG - 2016-12-27 22:07:44 --> Input Class Initialized
DEBUG - 2016-12-27 22:07:44 --> XSS Filtering completed
DEBUG - 2016-12-27 22:07:44 --> XSS Filtering completed
DEBUG - 2016-12-27 22:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:07:44 --> Language Class Initialized
DEBUG - 2016-12-27 22:07:44 --> Loader Class Initialized
DEBUG - 2016-12-27 22:07:44 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:07:44 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:07:44 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:07:44 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:07:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:07:44 --> Session Class Initialized
DEBUG - 2016-12-27 22:07:44 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:07:44 --> Encrypt Class Initialized
ERROR - 2016-12-27 22:07:44 --> Session: The session cookie was not signed.
DEBUG - 2016-12-27 22:07:44 --> Session routines successfully run
ERROR - 2016-12-27 22:07:44 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:07:44 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:07:44 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:07:44 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:07:44 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:07:44 --> Table Class Initialized
DEBUG - 2016-12-27 22:07:44 --> Model Class Initialized
DEBUG - 2016-12-27 22:07:44 --> Model Class Initialized
DEBUG - 2016-12-27 22:07:44 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:07:44 --> Model Class Initialized
DEBUG - 2016-12-27 22:07:44 --> Controller Class Initialized
DEBUG - 2016-12-27 22:07:45 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:07:45 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:07:47 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-27 22:07:49 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:07:49 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:07:49 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-27 22:07:49 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-27 22:07:49 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-27 22:07:49 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:07:49 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:07:49 --> Final output sent to browser
DEBUG - 2016-12-27 22:07:49 --> Total execution time: 5.6423
DEBUG - 2016-12-27 22:07:49 --> Config Class Initialized
DEBUG - 2016-12-27 22:07:49 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:07:49 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:07:49 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:07:49 --> URI Class Initialized
DEBUG - 2016-12-27 22:07:50 --> Router Class Initialized
ERROR - 2016-12-27 22:07:50 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:07:53 --> Config Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:07:53 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:07:53 --> URI Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Router Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Output Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Security Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Input Class Initialized
DEBUG - 2016-12-27 22:07:53 --> XSS Filtering completed
DEBUG - 2016-12-27 22:07:53 --> XSS Filtering completed
DEBUG - 2016-12-27 22:07:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:07:53 --> Language Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Loader Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:07:53 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:07:53 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:07:53 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:07:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:07:53 --> Session Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:07:53 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Session routines successfully run
ERROR - 2016-12-27 22:07:53 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:07:53 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:07:53 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:07:53 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:07:53 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Table Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Model Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Model Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:07:53 --> Model Class Initialized
DEBUG - 2016-12-27 22:07:53 --> Controller Class Initialized
DEBUG - 2016-12-27 22:07:55 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:07:55 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:07:55 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:07:55 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:07:55 --> File loaded: application/views/signup/main.php
DEBUG - 2016-12-27 22:07:55 --> File loaded: application/views/signup/login.php
DEBUG - 2016-12-27 22:07:55 --> File loaded: application/views/signup/personal.php
ERROR - 2016-12-27 22:07:55 --> Could not find the language line "register"
DEBUG - 2016-12-27 22:07:55 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-12-27 22:07:55 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:07:55 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:07:55 --> Final output sent to browser
DEBUG - 2016-12-27 22:07:55 --> Total execution time: 2.2321
DEBUG - 2016-12-27 22:07:55 --> Config Class Initialized
DEBUG - 2016-12-27 22:07:55 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:07:55 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:07:55 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:07:55 --> URI Class Initialized
DEBUG - 2016-12-27 22:07:55 --> Router Class Initialized
ERROR - 2016-12-27 22:07:55 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:07:59 --> Config Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:07:59 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:07:59 --> URI Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Router Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Output Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Security Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Input Class Initialized
DEBUG - 2016-12-27 22:07:59 --> XSS Filtering completed
DEBUG - 2016-12-27 22:07:59 --> XSS Filtering completed
DEBUG - 2016-12-27 22:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:07:59 --> Language Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Loader Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:07:59 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:07:59 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:07:59 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:07:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:07:59 --> Session Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:07:59 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Session routines successfully run
ERROR - 2016-12-27 22:07:59 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:07:59 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:07:59 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:07:59 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:07:59 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Table Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Model Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Model Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:07:59 --> Model Class Initialized
DEBUG - 2016-12-27 22:07:59 --> Controller Class Initialized
DEBUG - 2016-12-27 22:08:00 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:08:00 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:08:00 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:08:00 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:08:00 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-27 22:08:00 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:08:00 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:08:00 --> Final output sent to browser
DEBUG - 2016-12-27 22:08:00 --> Total execution time: 0.1230
DEBUG - 2016-12-27 22:08:00 --> Config Class Initialized
DEBUG - 2016-12-27 22:08:00 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:08:00 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:08:00 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:08:00 --> URI Class Initialized
DEBUG - 2016-12-27 22:08:00 --> Router Class Initialized
ERROR - 2016-12-27 22:08:00 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:08:03 --> Config Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:08:03 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:08:03 --> URI Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Router Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Output Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Security Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Input Class Initialized
DEBUG - 2016-12-27 22:08:03 --> XSS Filtering completed
DEBUG - 2016-12-27 22:08:03 --> XSS Filtering completed
DEBUG - 2016-12-27 22:08:03 --> XSS Filtering completed
DEBUG - 2016-12-27 22:08:03 --> XSS Filtering completed
DEBUG - 2016-12-27 22:08:03 --> XSS Filtering completed
DEBUG - 2016-12-27 22:08:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:08:03 --> Language Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Loader Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:08:03 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:08:03 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:08:03 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:08:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:08:03 --> Session Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:08:03 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Session routines successfully run
ERROR - 2016-12-27 22:08:03 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:08:03 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:08:03 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:08:03 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:08:03 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Table Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Model Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Model Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:08:03 --> Model Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Controller Class Initialized
DEBUG - 2016-12-27 22:08:03 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:08:03 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:08:03 --> Model Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Config Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:08:06 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:08:06 --> URI Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Router Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Output Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Security Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Input Class Initialized
DEBUG - 2016-12-27 22:08:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:08:06 --> XSS Filtering completed
DEBUG - 2016-12-27 22:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:08:06 --> Language Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Loader Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:08:06 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:08:06 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:08:06 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:08:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:08:06 --> Session Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:08:06 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Session routines successfully run
ERROR - 2016-12-27 22:08:06 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:08:06 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:08:06 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:08:06 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:08:06 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Table Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Model Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Model Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:08:06 --> Model Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Controller Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:08:06 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:08:06 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:08:08 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:08:08 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:08:08 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:08:08 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-27 22:08:08 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-27 22:08:08 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:08:08 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:08:08 --> Final output sent to browser
DEBUG - 2016-12-27 22:08:08 --> Total execution time: 2.2721
DEBUG - 2016-12-27 22:08:08 --> Config Class Initialized
DEBUG - 2016-12-27 22:08:08 --> Config Class Initialized
DEBUG - 2016-12-27 22:08:08 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:08:08 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:08:08 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:08:08 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:08:08 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:08:08 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:08:08 --> URI Class Initialized
DEBUG - 2016-12-27 22:08:08 --> URI Class Initialized
DEBUG - 2016-12-27 22:08:08 --> Router Class Initialized
DEBUG - 2016-12-27 22:08:08 --> Router Class Initialized
ERROR - 2016-12-27 22:08:08 --> 404 Page Not Found --> application
ERROR - 2016-12-27 22:08:08 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:08:08 --> Config Class Initialized
DEBUG - 2016-12-27 22:08:08 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:08:08 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:08:08 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:08:08 --> URI Class Initialized
DEBUG - 2016-12-27 22:08:08 --> Router Class Initialized
ERROR - 2016-12-27 22:08:08 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:08:08 --> Config Class Initialized
DEBUG - 2016-12-27 22:08:08 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:08:08 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:08:08 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:08:08 --> URI Class Initialized
DEBUG - 2016-12-27 22:08:08 --> Router Class Initialized
ERROR - 2016-12-27 22:08:08 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:08:09 --> Config Class Initialized
DEBUG - 2016-12-27 22:08:09 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:08:09 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:08:09 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:08:09 --> URI Class Initialized
DEBUG - 2016-12-27 22:08:09 --> Router Class Initialized
ERROR - 2016-12-27 22:08:09 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:08:09 --> Config Class Initialized
DEBUG - 2016-12-27 22:08:09 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:08:09 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:08:09 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:08:09 --> URI Class Initialized
DEBUG - 2016-12-27 22:08:09 --> Router Class Initialized
ERROR - 2016-12-27 22:08:09 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:08:31 --> Config Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:08:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:08:31 --> URI Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Router Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Output Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Security Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Input Class Initialized
DEBUG - 2016-12-27 22:08:31 --> XSS Filtering completed
DEBUG - 2016-12-27 22:08:31 --> XSS Filtering completed
DEBUG - 2016-12-27 22:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:08:31 --> Language Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Loader Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:08:31 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:08:31 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:08:31 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:08:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:08:31 --> Session Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:08:31 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Session routines successfully run
ERROR - 2016-12-27 22:08:31 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:08:31 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:08:31 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:08:31 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:08:31 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Table Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Model Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Model Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:08:31 --> Model Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Controller Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:08:31 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:08:31 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-27 22:08:31 --> Could not find the language line "personal"
DEBUG - 2016-12-27 22:08:31 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:08:31 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:08:31 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:08:31 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-12-27 22:08:31 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:08:31 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:08:31 --> Final output sent to browser
DEBUG - 2016-12-27 22:08:31 --> Total execution time: 0.2180
DEBUG - 2016-12-27 22:31:13 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:13 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Router Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Output Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Security Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Input Class Initialized
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:31:13 --> Language Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Loader Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:31:13 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:31:13 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:31:13 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:31:13 --> Session Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:31:13 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Session routines successfully run
ERROR - 2016-12-27 22:31:13 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:31:13 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:31:13 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:31:13 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:31:13 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Table Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:31:13 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Controller Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:31:13 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:31:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-12-27 22:31:13 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-12-27 22:31:13 --> Unable to find validation rule: edit_unique
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:13 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Router Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Output Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Security Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Input Class Initialized
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:31:13 --> Language Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Loader Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:31:13 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:31:13 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:31:13 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:31:13 --> Session Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:31:13 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Session routines successfully run
ERROR - 2016-12-27 22:31:13 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:31:13 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:31:13 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:31:13 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:31:13 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Table Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:31:13 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Controller Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:31:13 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:31:13 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:31:16 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:31:16 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:31:16 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:31:16 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-27 22:31:16 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-27 22:31:16 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:31:16 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:31:16 --> Final output sent to browser
DEBUG - 2016-12-27 22:31:16 --> Total execution time: 2.3871
DEBUG - 2016-12-27 22:31:16 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:16 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Router Class Initialized
ERROR - 2016-12-27 22:31:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:31:16 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:16 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:16 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:16 --> Router Class Initialized
DEBUG - 2016-12-27 22:31:16 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Router Class Initialized
ERROR - 2016-12-27 22:31:16 --> 404 Page Not Found --> application
ERROR - 2016-12-27 22:31:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:31:16 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:16 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Router Class Initialized
ERROR - 2016-12-27 22:31:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:31:16 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:16 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:16 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:16 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Router Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Router Class Initialized
ERROR - 2016-12-27 22:31:16 --> 404 Page Not Found --> application
ERROR - 2016-12-27 22:31:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:31:16 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:16 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:16 --> Router Class Initialized
ERROR - 2016-12-27 22:31:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:31:23 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:23 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Router Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Output Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Security Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Input Class Initialized
DEBUG - 2016-12-27 22:31:23 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:23 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:31:23 --> Language Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Loader Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:31:23 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:31:23 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:31:23 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:31:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:31:23 --> Session Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:31:23 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Session routines successfully run
ERROR - 2016-12-27 22:31:23 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:31:23 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:31:23 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:31:23 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:31:23 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Table Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:31:23 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Controller Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:31:23 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:31:23 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:31:23 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:31:23 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-27 22:31:23 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:31:23 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:31:23 --> Final output sent to browser
DEBUG - 2016-12-27 22:31:23 --> Total execution time: 0.0960
DEBUG - 2016-12-27 22:31:23 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:23 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:23 --> Router Class Initialized
ERROR - 2016-12-27 22:31:23 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:31:26 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:26 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Router Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Output Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Security Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Input Class Initialized
DEBUG - 2016-12-27 22:31:26 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:26 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:26 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:26 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:26 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:31:26 --> Language Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Loader Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:31:26 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:31:26 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:31:26 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:31:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:31:26 --> Session Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:31:26 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:31:26 --> A session cookie was not found.
DEBUG - 2016-12-27 22:31:26 --> Session routines successfully run
ERROR - 2016-12-27 22:31:26 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:31:26 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:31:26 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:31:26 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:31:26 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Table Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:31:26 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Controller Class Initialized
DEBUG - 2016-12-27 22:31:26 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:31:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:31:26 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:27 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:31:27 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:31:27 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-27 22:31:27 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:31:27 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:31:27 --> Final output sent to browser
DEBUG - 2016-12-27 22:31:27 --> Total execution time: 0.4270
DEBUG - 2016-12-27 22:31:27 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:27 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:27 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:27 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:27 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:27 --> Router Class Initialized
ERROR - 2016-12-27 22:31:27 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:31:32 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:32 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:32 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Router Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Output Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Security Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Input Class Initialized
DEBUG - 2016-12-27 22:31:32 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:32 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:32 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:32 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:32 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:31:32 --> Language Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Loader Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:31:32 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:31:32 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:31:32 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:31:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:31:32 --> Session Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:31:32 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Session routines successfully run
ERROR - 2016-12-27 22:31:32 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:31:32 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:31:32 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:31:32 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:31:32 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Table Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:31:32 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Controller Class Initialized
DEBUG - 2016-12-27 22:31:32 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:31:32 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:31:32 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:35 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Router Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Output Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Security Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Input Class Initialized
DEBUG - 2016-12-27 22:31:35 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:35 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:31:35 --> Language Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Loader Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:31:35 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:31:35 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:31:35 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:31:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:31:35 --> Session Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:31:35 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Session routines successfully run
ERROR - 2016-12-27 22:31:35 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:31:35 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:31:35 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:31:35 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:31:35 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Table Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:31:35 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Controller Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:31:35 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:31:35 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:31:38 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:31:38 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:31:38 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:31:38 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-27 22:31:38 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-27 22:31:38 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:31:38 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:31:38 --> Final output sent to browser
DEBUG - 2016-12-27 22:31:38 --> Total execution time: 2.2381
DEBUG - 2016-12-27 22:31:38 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:38 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:38 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:38 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:38 --> Router Class Initialized
ERROR - 2016-12-27 22:31:38 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:31:38 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:38 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:38 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:38 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:38 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:38 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:38 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:38 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:38 --> Router Class Initialized
DEBUG - 2016-12-27 22:31:38 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:38 --> URI Class Initialized
ERROR - 2016-12-27 22:31:38 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:31:38 --> Router Class Initialized
ERROR - 2016-12-27 22:31:38 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:31:38 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:38 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:38 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:38 --> Router Class Initialized
ERROR - 2016-12-27 22:31:38 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:31:49 --> Config Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:31:49 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:31:49 --> URI Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Router Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Output Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Security Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Input Class Initialized
DEBUG - 2016-12-27 22:31:49 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:49 --> XSS Filtering completed
DEBUG - 2016-12-27 22:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:31:49 --> Language Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Loader Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:31:49 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:31:49 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:31:49 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:31:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:31:49 --> Session Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:31:49 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Session routines successfully run
ERROR - 2016-12-27 22:31:49 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:31:49 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:31:49 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:31:49 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:31:49 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Table Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:31:49 --> Model Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Controller Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:31:49 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:31:49 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-27 22:31:49 --> Could not find the language line "personal"
DEBUG - 2016-12-27 22:31:49 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:31:49 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:31:49 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:31:49 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-12-27 22:31:49 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:31:49 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:31:49 --> Final output sent to browser
DEBUG - 2016-12-27 22:31:49 --> Total execution time: 0.2250
DEBUG - 2016-12-27 22:32:05 --> Config Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:32:05 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:32:05 --> URI Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Router Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Output Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Security Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Input Class Initialized
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:32:05 --> Language Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Loader Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:32:05 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:32:05 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:32:05 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:32:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:32:05 --> Session Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:32:05 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Session routines successfully run
ERROR - 2016-12-27 22:32:05 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:32:05 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:32:05 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:32:05 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:32:05 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Table Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:32:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Controller Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:32:05 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:32:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-12-27 22:32:05 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-12-27 22:32:05 --> Unable to find validation rule: edit_unique
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> Config Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:32:05 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:32:05 --> URI Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Router Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Output Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Security Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Input Class Initialized
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:32:05 --> Language Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Loader Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:32:05 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:32:05 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:32:05 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:32:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:32:05 --> Session Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:32:05 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Session routines successfully run
ERROR - 2016-12-27 22:32:05 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:32:05 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:32:05 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:32:05 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:32:05 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Table Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:32:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Controller Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:32:05 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:32:05 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:32:07 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:32:07 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:32:07 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:32:07 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-27 22:32:07 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-27 22:32:07 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:32:07 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:32:07 --> Final output sent to browser
DEBUG - 2016-12-27 22:32:07 --> Total execution time: 1.7981
DEBUG - 2016-12-27 22:32:07 --> Config Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:32:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:32:07 --> URI Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Router Class Initialized
ERROR - 2016-12-27 22:32:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:32:07 --> Config Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:32:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:32:07 --> URI Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Router Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Config Class Initialized
ERROR - 2016-12-27 22:32:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:32:07 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:32:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:32:07 --> Config Class Initialized
DEBUG - 2016-12-27 22:32:07 --> URI Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Router Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:32:07 --> UTF-8 Support Enabled
ERROR - 2016-12-27 22:32:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:32:07 --> URI Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Router Class Initialized
ERROR - 2016-12-27 22:32:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:32:07 --> Config Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Config Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:32:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:32:07 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:32:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:32:07 --> URI Class Initialized
DEBUG - 2016-12-27 22:32:07 --> URI Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Router Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Router Class Initialized
ERROR - 2016-12-27 22:32:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:32:07 --> Config Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Config Class Initialized
ERROR - 2016-12-27 22:32:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:32:07 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:32:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:32:07 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:32:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:32:07 --> URI Class Initialized
DEBUG - 2016-12-27 22:32:07 --> Router Class Initialized
DEBUG - 2016-12-27 22:32:07 --> URI Class Initialized
ERROR - 2016-12-27 22:32:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:32:07 --> Router Class Initialized
ERROR - 2016-12-27 22:32:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:33:30 --> Config Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:33:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:33:30 --> URI Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Router Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Output Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Security Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Input Class Initialized
DEBUG - 2016-12-27 22:33:30 --> XSS Filtering completed
DEBUG - 2016-12-27 22:33:30 --> XSS Filtering completed
DEBUG - 2016-12-27 22:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:33:30 --> Language Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Loader Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:33:30 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:33:30 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:33:30 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:33:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:33:30 --> Session Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:33:30 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Session routines successfully run
ERROR - 2016-12-27 22:33:30 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:33:30 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:33:30 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:33:30 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:33:30 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Table Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Model Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Model Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:33:30 --> Model Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Controller Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:33:30 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:33:30 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-27 22:33:30 --> Could not find the language line "personal"
DEBUG - 2016-12-27 22:33:30 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:33:30 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:33:30 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:33:30 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-12-27 22:33:30 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:33:30 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:33:30 --> Final output sent to browser
DEBUG - 2016-12-27 22:33:30 --> Total execution time: 0.2510
DEBUG - 2016-12-27 22:33:32 --> Config Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:33:32 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:33:32 --> URI Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Router Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Output Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Security Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Input Class Initialized
DEBUG - 2016-12-27 22:33:32 --> XSS Filtering completed
DEBUG - 2016-12-27 22:33:32 --> XSS Filtering completed
DEBUG - 2016-12-27 22:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:33:32 --> Language Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Loader Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:33:32 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:33:32 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:33:32 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:33:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:33:32 --> Session Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:33:32 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Session routines successfully run
ERROR - 2016-12-27 22:33:32 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:33:32 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:33:32 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:33:32 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:33:32 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Table Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Model Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Model Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:33:32 --> Model Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Controller Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:33:32 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:33:32 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:33:34 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:33:34 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:33:34 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:33:34 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-27 22:33:34 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-27 22:33:34 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:33:34 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:33:34 --> Final output sent to browser
DEBUG - 2016-12-27 22:33:34 --> Total execution time: 1.6071
DEBUG - 2016-12-27 22:33:34 --> Config Class Initialized
DEBUG - 2016-12-27 22:33:34 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:33:34 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:33:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:33:34 --> URI Class Initialized
DEBUG - 2016-12-27 22:33:34 --> Router Class Initialized
ERROR - 2016-12-27 22:33:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:33:34 --> Config Class Initialized
DEBUG - 2016-12-27 22:33:34 --> Config Class Initialized
DEBUG - 2016-12-27 22:33:34 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:33:34 --> Config Class Initialized
DEBUG - 2016-12-27 22:33:34 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:33:34 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:33:34 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:33:34 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:33:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:33:34 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:33:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:33:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:33:34 --> URI Class Initialized
DEBUG - 2016-12-27 22:33:34 --> URI Class Initialized
DEBUG - 2016-12-27 22:33:34 --> URI Class Initialized
DEBUG - 2016-12-27 22:33:34 --> Router Class Initialized
DEBUG - 2016-12-27 22:33:34 --> Router Class Initialized
DEBUG - 2016-12-27 22:33:34 --> Router Class Initialized
ERROR - 2016-12-27 22:33:34 --> 404 Page Not Found --> application
ERROR - 2016-12-27 22:33:34 --> 404 Page Not Found --> application
ERROR - 2016-12-27 22:33:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:34:20 --> Config Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:34:20 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:34:20 --> URI Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Router Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Output Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Security Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Input Class Initialized
DEBUG - 2016-12-27 22:34:20 --> XSS Filtering completed
DEBUG - 2016-12-27 22:34:20 --> XSS Filtering completed
DEBUG - 2016-12-27 22:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:34:20 --> Language Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Loader Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:34:20 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:34:20 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:34:20 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:34:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:34:20 --> Session Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:34:20 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Session routines successfully run
ERROR - 2016-12-27 22:34:20 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:34:20 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:34:20 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:34:20 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:34:20 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Table Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Model Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Model Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:34:20 --> Model Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Controller Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:34:20 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:34:20 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:34:22 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:34:22 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:34:22 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:34:22 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-27 22:34:22 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-27 22:34:22 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:34:22 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:34:22 --> Final output sent to browser
DEBUG - 2016-12-27 22:34:22 --> Total execution time: 1.5321
DEBUG - 2016-12-27 22:34:22 --> Config Class Initialized
DEBUG - 2016-12-27 22:34:22 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:34:22 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:34:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:34:22 --> URI Class Initialized
DEBUG - 2016-12-27 22:34:22 --> Router Class Initialized
ERROR - 2016-12-27 22:34:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:34:22 --> Config Class Initialized
DEBUG - 2016-12-27 22:34:22 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:34:22 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:34:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:34:22 --> URI Class Initialized
DEBUG - 2016-12-27 22:34:22 --> Router Class Initialized
ERROR - 2016-12-27 22:34:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:34:22 --> Config Class Initialized
DEBUG - 2016-12-27 22:34:22 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:34:22 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:34:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:34:22 --> URI Class Initialized
DEBUG - 2016-12-27 22:34:22 --> Router Class Initialized
ERROR - 2016-12-27 22:34:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:34:22 --> Config Class Initialized
DEBUG - 2016-12-27 22:34:22 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:34:22 --> Config Class Initialized
DEBUG - 2016-12-27 22:34:22 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:34:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:34:22 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:34:22 --> URI Class Initialized
DEBUG - 2016-12-27 22:34:22 --> Router Class Initialized
ERROR - 2016-12-27 22:34:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:34:22 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:34:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:34:22 --> URI Class Initialized
DEBUG - 2016-12-27 22:34:22 --> Router Class Initialized
ERROR - 2016-12-27 22:34:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:34:24 --> Config Class Initialized
DEBUG - 2016-12-27 22:34:24 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:34:24 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:34:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:34:24 --> URI Class Initialized
DEBUG - 2016-12-27 22:34:24 --> Router Class Initialized
DEBUG - 2016-12-27 22:34:24 --> Output Class Initialized
DEBUG - 2016-12-27 22:34:24 --> Security Class Initialized
DEBUG - 2016-12-27 22:34:24 --> Input Class Initialized
DEBUG - 2016-12-27 22:34:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:34:24 --> XSS Filtering completed
DEBUG - 2016-12-27 22:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:34:24 --> Language Class Initialized
DEBUG - 2016-12-27 22:34:24 --> Loader Class Initialized
DEBUG - 2016-12-27 22:34:24 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:34:24 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:34:24 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:34:24 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:34:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:34:24 --> Session Class Initialized
DEBUG - 2016-12-27 22:34:24 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:34:25 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:34:25 --> Session routines successfully run
ERROR - 2016-12-27 22:34:25 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:34:25 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:34:25 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:34:25 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:34:25 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:34:25 --> Table Class Initialized
DEBUG - 2016-12-27 22:34:25 --> Model Class Initialized
DEBUG - 2016-12-27 22:34:25 --> Model Class Initialized
DEBUG - 2016-12-27 22:34:25 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:34:25 --> Model Class Initialized
DEBUG - 2016-12-27 22:34:25 --> Controller Class Initialized
DEBUG - 2016-12-27 22:34:25 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:34:25 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:34:25 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-27 22:34:25 --> Could not find the language line "personal"
DEBUG - 2016-12-27 22:34:25 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:34:25 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:34:25 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:34:25 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-12-27 22:34:25 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:34:25 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:34:25 --> Final output sent to browser
DEBUG - 2016-12-27 22:34:25 --> Total execution time: 0.2230
DEBUG - 2016-12-27 22:34:27 --> Config Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:34:27 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:34:27 --> URI Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Router Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Output Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Security Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Input Class Initialized
DEBUG - 2016-12-27 22:34:27 --> XSS Filtering completed
DEBUG - 2016-12-27 22:34:27 --> XSS Filtering completed
DEBUG - 2016-12-27 22:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:34:27 --> Language Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Loader Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:34:27 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:34:27 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:34:27 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:34:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:34:27 --> Session Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:34:27 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Session routines successfully run
ERROR - 2016-12-27 22:34:27 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:34:27 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:34:27 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:34:27 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:34:27 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Table Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Model Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Model Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:34:27 --> Model Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Controller Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:34:27 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:34:27 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-27 22:34:27 --> Could not find the language line "settings"
DEBUG - 2016-12-27 22:34:27 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:34:27 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:34:27 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:34:27 --> DB Transaction Failure
ERROR - 2016-12-27 22:34:27 --> Query error: Table 'univ_alumni_online1.lk9v6_control_values' doesn't exist
DEBUG - 2016-12-27 22:34:27 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-27 22:34:27 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-27 22:47:03 --> Config Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:47:03 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:47:03 --> URI Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Router Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Output Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Security Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Input Class Initialized
DEBUG - 2016-12-27 22:47:03 --> XSS Filtering completed
DEBUG - 2016-12-27 22:47:03 --> XSS Filtering completed
DEBUG - 2016-12-27 22:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:47:03 --> Language Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Loader Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:47:03 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:47:03 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:47:03 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:47:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:47:03 --> Session Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:47:03 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Session routines successfully run
ERROR - 2016-12-27 22:47:03 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:47:03 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:47:03 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:47:03 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:47:03 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Table Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Model Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Model Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:47:03 --> Model Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Controller Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:47:03 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:47:03 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-27 22:47:03 --> Could not find the language line "settings"
DEBUG - 2016-12-27 22:47:03 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:47:03 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:47:03 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:47:03 --> File loaded: application/views/admin/settings.php
DEBUG - 2016-12-27 22:47:03 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:47:03 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:47:03 --> Final output sent to browser
DEBUG - 2016-12-27 22:47:03 --> Total execution time: 0.2150
DEBUG - 2016-12-27 22:47:18 --> Config Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:47:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:47:18 --> URI Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Router Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Output Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Security Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Input Class Initialized
DEBUG - 2016-12-27 22:47:18 --> XSS Filtering completed
DEBUG - 2016-12-27 22:47:18 --> XSS Filtering completed
DEBUG - 2016-12-27 22:47:18 --> XSS Filtering completed
DEBUG - 2016-12-27 22:47:18 --> XSS Filtering completed
DEBUG - 2016-12-27 22:47:18 --> XSS Filtering completed
DEBUG - 2016-12-27 22:47:18 --> XSS Filtering completed
DEBUG - 2016-12-27 22:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:47:18 --> Language Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Loader Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:47:18 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:47:18 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:47:18 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:47:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:47:18 --> Session Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:47:18 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Session routines successfully run
ERROR - 2016-12-27 22:47:18 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:47:18 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:47:18 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:47:18 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:47:18 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Table Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Model Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Model Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:47:18 --> Model Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Controller Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:47:18 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-27 22:47:18 --> Could not find the language line "settings_updated"
DEBUG - 2016-12-27 22:47:18 --> Config Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:47:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:47:18 --> URI Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Router Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Output Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Security Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Input Class Initialized
DEBUG - 2016-12-27 22:47:18 --> XSS Filtering completed
DEBUG - 2016-12-27 22:47:18 --> XSS Filtering completed
DEBUG - 2016-12-27 22:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:47:18 --> Language Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Loader Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:47:18 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:47:18 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:47:18 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:47:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:47:18 --> Session Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:47:18 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Session routines successfully run
ERROR - 2016-12-27 22:47:18 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:47:18 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:47:18 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:47:18 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:47:18 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Table Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Model Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Model Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:47:18 --> Model Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Controller Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:47:18 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:47:18 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:47:20 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:47:20 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:47:20 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:47:20 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-27 22:47:20 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-27 22:47:20 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:47:20 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:47:20 --> Final output sent to browser
DEBUG - 2016-12-27 22:47:20 --> Total execution time: 1.8511
DEBUG - 2016-12-27 22:47:20 --> Config Class Initialized
DEBUG - 2016-12-27 22:47:20 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:47:20 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:47:20 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:47:20 --> URI Class Initialized
DEBUG - 2016-12-27 22:47:20 --> Router Class Initialized
DEBUG - 2016-12-27 22:47:20 --> Config Class Initialized
DEBUG - 2016-12-27 22:47:20 --> Hooks Class Initialized
ERROR - 2016-12-27 22:47:20 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:47:20 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:47:20 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:47:20 --> URI Class Initialized
DEBUG - 2016-12-27 22:47:20 --> Router Class Initialized
ERROR - 2016-12-27 22:47:20 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:47:39 --> Config Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:47:39 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:47:39 --> URI Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Router Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Output Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Security Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Input Class Initialized
DEBUG - 2016-12-27 22:47:39 --> XSS Filtering completed
DEBUG - 2016-12-27 22:47:39 --> XSS Filtering completed
DEBUG - 2016-12-27 22:47:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:47:39 --> Language Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Loader Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:47:39 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:47:39 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:47:39 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:47:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:47:39 --> Session Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:47:39 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Session routines successfully run
ERROR - 2016-12-27 22:47:39 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:47:39 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:47:39 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:47:39 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:47:39 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Table Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Model Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Model Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:47:39 --> Model Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Controller Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:47:39 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:47:39 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:47:39 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:47:39 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:47:39 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:47:39 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 22:47:39 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 22:47:39 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:47:39 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 22:47:39 --> Final output sent to browser
DEBUG - 2016-12-27 22:47:39 --> Total execution time: 0.4780
DEBUG - 2016-12-27 22:48:04 --> Config Class Initialized
DEBUG - 2016-12-27 22:48:04 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:48:04 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:48:04 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:48:04 --> URI Class Initialized
DEBUG - 2016-12-27 22:48:04 --> Router Class Initialized
DEBUG - 2016-12-27 22:48:04 --> Output Class Initialized
DEBUG - 2016-12-27 22:48:04 --> Security Class Initialized
DEBUG - 2016-12-27 22:48:04 --> Input Class Initialized
DEBUG - 2016-12-27 22:48:04 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:04 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:04 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:04 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:04 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:04 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:04 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:48:05 --> Language Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Loader Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:48:05 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:48:05 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:48:05 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:48:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:48:05 --> Session Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:48:05 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Session routines successfully run
ERROR - 2016-12-27 22:48:05 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:48:05 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:48:05 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:48:05 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:48:05 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Table Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:48:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Controller Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:48:05 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:48:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-12-27 22:48:05 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> Config Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:48:05 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:48:05 --> URI Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Router Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Output Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Security Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Input Class Initialized
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:48:05 --> Language Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Loader Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:48:05 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:48:05 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:48:05 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:48:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:48:05 --> Session Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:48:05 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Session routines successfully run
ERROR - 2016-12-27 22:48:05 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:48:05 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:48:05 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:48:05 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:48:05 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Table Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:48:05 --> Model Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Controller Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:48:05 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:48:05 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:48:07 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:48:07 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:48:07 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:48:07 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-27 22:48:07 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-27 22:48:07 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:48:07 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:48:07 --> Final output sent to browser
DEBUG - 2016-12-27 22:48:07 --> Total execution time: 2.1391
DEBUG - 2016-12-27 22:48:07 --> Config Class Initialized
DEBUG - 2016-12-27 22:48:07 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:48:07 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:48:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:48:07 --> URI Class Initialized
DEBUG - 2016-12-27 22:48:07 --> Router Class Initialized
ERROR - 2016-12-27 22:48:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:48:07 --> Config Class Initialized
DEBUG - 2016-12-27 22:48:07 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:48:07 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:48:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:48:07 --> URI Class Initialized
DEBUG - 2016-12-27 22:48:07 --> Router Class Initialized
ERROR - 2016-12-27 22:48:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:48:07 --> Config Class Initialized
DEBUG - 2016-12-27 22:48:07 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:48:07 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:48:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:48:07 --> URI Class Initialized
DEBUG - 2016-12-27 22:48:07 --> Router Class Initialized
ERROR - 2016-12-27 22:48:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:48:11 --> Config Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:48:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:48:11 --> URI Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Router Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Output Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Security Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Input Class Initialized
DEBUG - 2016-12-27 22:48:11 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:11 --> XSS Filtering completed
DEBUG - 2016-12-27 22:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:48:11 --> Language Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Loader Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:48:11 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:48:11 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:48:11 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:48:11 --> Session Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:48:11 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Session routines successfully run
ERROR - 2016-12-27 22:48:11 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:48:11 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:48:11 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:48:11 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:48:11 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Table Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Model Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Model Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:48:11 --> Model Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Controller Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:48:11 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:48:11 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:48:11 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:48:11 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:48:11 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:48:11 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 22:48:11 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 22:48:11 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:48:11 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 22:48:11 --> Final output sent to browser
DEBUG - 2016-12-27 22:48:11 --> Total execution time: 0.4610
DEBUG - 2016-12-27 22:50:27 --> Config Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:50:27 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:50:27 --> URI Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Router Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Output Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Security Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Input Class Initialized
DEBUG - 2016-12-27 22:50:27 --> XSS Filtering completed
DEBUG - 2016-12-27 22:50:27 --> XSS Filtering completed
DEBUG - 2016-12-27 22:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:50:27 --> Language Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Loader Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:50:27 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:50:27 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:50:27 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:50:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:50:27 --> Session Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:50:27 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Session routines successfully run
ERROR - 2016-12-27 22:50:27 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:50:27 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:50:27 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:50:27 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:50:27 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Table Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Model Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Model Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:50:27 --> Model Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Controller Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:50:27 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:50:27 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:50:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:50:28 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:50:28 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:50:28 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 22:50:28 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 22:50:28 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:50:28 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 22:50:28 --> Final output sent to browser
DEBUG - 2016-12-27 22:50:28 --> Total execution time: 0.4980
DEBUG - 2016-12-27 22:50:31 --> Config Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:50:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:50:31 --> URI Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Router Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Output Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Security Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Input Class Initialized
DEBUG - 2016-12-27 22:50:31 --> XSS Filtering completed
DEBUG - 2016-12-27 22:50:31 --> XSS Filtering completed
DEBUG - 2016-12-27 22:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:50:31 --> Language Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Loader Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:50:31 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:50:31 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:50:31 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:50:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:50:31 --> Session Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:50:31 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Session routines successfully run
ERROR - 2016-12-27 22:50:31 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:50:31 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:50:31 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:50:31 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:50:31 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Table Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Model Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Model Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:50:31 --> Model Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Controller Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:50:31 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:50:31 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:50:31 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:50:31 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:50:31 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:50:31 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 22:50:31 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 22:50:31 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:50:31 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 22:50:31 --> Final output sent to browser
DEBUG - 2016-12-27 22:50:31 --> Total execution time: 0.4390
DEBUG - 2016-12-27 22:51:04 --> Config Class Initialized
DEBUG - 2016-12-27 22:51:04 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:51:04 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:51:04 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:51:04 --> URI Class Initialized
DEBUG - 2016-12-27 22:51:04 --> Router Class Initialized
DEBUG - 2016-12-27 22:51:04 --> No URI present. Default controller set.
DEBUG - 2016-12-27 22:51:04 --> Output Class Initialized
DEBUG - 2016-12-27 22:51:04 --> Security Class Initialized
DEBUG - 2016-12-27 22:51:04 --> Input Class Initialized
DEBUG - 2016-12-27 22:51:04 --> XSS Filtering completed
DEBUG - 2016-12-27 22:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:51:04 --> Language Class Initialized
DEBUG - 2016-12-27 22:51:04 --> Loader Class Initialized
DEBUG - 2016-12-27 22:51:04 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:51:04 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:51:04 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:51:04 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:51:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:51:04 --> Session Class Initialized
DEBUG - 2016-12-27 22:51:04 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:51:04 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:51:04 --> Session routines successfully run
ERROR - 2016-12-27 22:51:04 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:51:04 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:51:04 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:51:04 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:51:04 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:51:04 --> Table Class Initialized
DEBUG - 2016-12-27 22:51:04 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:04 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:04 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:51:04 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:04 --> Controller Class Initialized
DEBUG - 2016-12-27 22:51:05 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:51:05 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:51:06 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-27 22:51:08 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:51:08 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:51:08 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-27 22:51:08 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-27 22:51:08 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-27 22:51:08 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:51:08 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:51:08 --> Final output sent to browser
DEBUG - 2016-12-27 22:51:08 --> Total execution time: 4.1912
DEBUG - 2016-12-27 22:51:08 --> Config Class Initialized
DEBUG - 2016-12-27 22:51:08 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:51:08 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:51:08 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:51:08 --> URI Class Initialized
DEBUG - 2016-12-27 22:51:08 --> Router Class Initialized
ERROR - 2016-12-27 22:51:08 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:51:16 --> Config Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:51:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:51:16 --> URI Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Router Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Output Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Security Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Input Class Initialized
DEBUG - 2016-12-27 22:51:16 --> XSS Filtering completed
DEBUG - 2016-12-27 22:51:16 --> XSS Filtering completed
DEBUG - 2016-12-27 22:51:16 --> XSS Filtering completed
DEBUG - 2016-12-27 22:51:16 --> XSS Filtering completed
DEBUG - 2016-12-27 22:51:16 --> XSS Filtering completed
DEBUG - 2016-12-27 22:51:16 --> XSS Filtering completed
DEBUG - 2016-12-27 22:51:16 --> XSS Filtering completed
DEBUG - 2016-12-27 22:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:51:16 --> Language Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Loader Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:51:16 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:51:16 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:51:16 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:51:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:51:16 --> Session Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:51:16 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Session routines successfully run
ERROR - 2016-12-27 22:51:16 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:51:16 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:51:16 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:51:16 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:51:16 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Table Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:51:16 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:16 --> Controller Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:51:18 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:51:18 --> Config Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:51:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:51:18 --> URI Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Router Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Output Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Security Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Input Class Initialized
DEBUG - 2016-12-27 22:51:18 --> XSS Filtering completed
DEBUG - 2016-12-27 22:51:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:51:18 --> Language Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Loader Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:51:18 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:51:18 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:51:18 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:51:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:51:18 --> Session Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:51:18 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Session routines successfully run
ERROR - 2016-12-27 22:51:18 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:51:18 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:51:18 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:51:18 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:51:18 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Table Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:51:18 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:18 --> Controller Class Initialized
DEBUG - 2016-12-27 22:51:20 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:51:20 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-27 22:51:20 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-27 22:51:20 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:51:20 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:51:20 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-27 22:51:20 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-27 22:51:20 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:51:20 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:51:20 --> Final output sent to browser
DEBUG - 2016-12-27 22:51:20 --> Total execution time: 1.7691
DEBUG - 2016-12-27 22:51:20 --> Config Class Initialized
DEBUG - 2016-12-27 22:51:20 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:51:20 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:51:20 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:51:20 --> URI Class Initialized
DEBUG - 2016-12-27 22:51:20 --> Router Class Initialized
ERROR - 2016-12-27 22:51:20 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:51:37 --> Config Class Initialized
DEBUG - 2016-12-27 22:51:37 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:51:37 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:51:37 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:51:37 --> URI Class Initialized
DEBUG - 2016-12-27 22:51:37 --> Router Class Initialized
DEBUG - 2016-12-27 22:51:37 --> Output Class Initialized
DEBUG - 2016-12-27 22:51:37 --> Security Class Initialized
DEBUG - 2016-12-27 22:51:37 --> Input Class Initialized
DEBUG - 2016-12-27 22:51:37 --> XSS Filtering completed
DEBUG - 2016-12-27 22:51:37 --> XSS Filtering completed
DEBUG - 2016-12-27 22:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:51:37 --> Language Class Initialized
DEBUG - 2016-12-27 22:51:37 --> Loader Class Initialized
DEBUG - 2016-12-27 22:51:37 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:51:37 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:51:37 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:51:37 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:51:38 --> Session Class Initialized
DEBUG - 2016-12-27 22:51:38 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:51:38 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:51:38 --> Session routines successfully run
ERROR - 2016-12-27 22:51:38 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:51:38 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:51:38 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:51:38 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:51:38 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:51:38 --> Table Class Initialized
DEBUG - 2016-12-27 22:51:38 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:38 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:38 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:51:38 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:38 --> Controller Class Initialized
DEBUG - 2016-12-27 22:51:38 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:51:38 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:51:38 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:51:38 --> Final output sent to browser
DEBUG - 2016-12-27 22:51:38 --> Total execution time: 0.1150
DEBUG - 2016-12-27 22:51:45 --> Config Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:51:45 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:51:45 --> URI Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Router Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Output Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Security Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Input Class Initialized
DEBUG - 2016-12-27 22:51:45 --> XSS Filtering completed
DEBUG - 2016-12-27 22:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:51:45 --> Language Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Loader Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:51:45 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:51:45 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:51:45 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:51:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:51:45 --> Session Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:51:45 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Session routines successfully run
ERROR - 2016-12-27 22:51:45 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:51:45 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:51:45 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:51:45 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:51:45 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Table Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:51:45 --> Model Class Initialized
DEBUG - 2016-12-27 22:51:45 --> Controller Class Initialized
DEBUG - 2016-12-27 22:51:47 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:51:47 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-27 22:51:47 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-27 22:51:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:51:47 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:51:47 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-27 22:51:47 --> File loaded: application/views/alumni_view_files/single.php
DEBUG - 2016-12-27 22:51:47 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-27 22:51:47 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:51:47 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:51:47 --> Final output sent to browser
DEBUG - 2016-12-27 22:51:47 --> Total execution time: 1.4741
DEBUG - 2016-12-27 22:51:47 --> Config Class Initialized
DEBUG - 2016-12-27 22:51:47 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:51:47 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:51:47 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:51:47 --> URI Class Initialized
DEBUG - 2016-12-27 22:51:47 --> Router Class Initialized
ERROR - 2016-12-27 22:51:47 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:56:23 --> Config Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:56:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:56:23 --> URI Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Router Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Output Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Security Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Input Class Initialized
DEBUG - 2016-12-27 22:56:23 --> XSS Filtering completed
DEBUG - 2016-12-27 22:56:23 --> XSS Filtering completed
DEBUG - 2016-12-27 22:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:56:23 --> Language Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Loader Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:56:23 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:56:23 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:56:23 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:56:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:56:23 --> Session Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:56:23 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Session routines successfully run
ERROR - 2016-12-27 22:56:23 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:56:23 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:56:23 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:56:23 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:56:23 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Table Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:56:23 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Controller Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:56:23 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:56:23 --> Config Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:56:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:56:23 --> URI Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Router Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Output Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Security Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Input Class Initialized
DEBUG - 2016-12-27 22:56:23 --> XSS Filtering completed
DEBUG - 2016-12-27 22:56:23 --> XSS Filtering completed
DEBUG - 2016-12-27 22:56:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:56:23 --> Language Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Loader Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:56:23 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:56:23 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:56:23 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:56:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:56:23 --> Session Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:56:23 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Session routines successfully run
ERROR - 2016-12-27 22:56:23 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:56:23 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:56:23 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:56:23 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:56:23 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Table Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:56:23 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Controller Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:56:23 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:56:23 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:56:25 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:56:25 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:56:25 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:56:25 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-27 22:56:25 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-27 22:56:25 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:56:25 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:56:25 --> Final output sent to browser
DEBUG - 2016-12-27 22:56:25 --> Total execution time: 1.6011
DEBUG - 2016-12-27 22:56:25 --> Config Class Initialized
DEBUG - 2016-12-27 22:56:25 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:56:25 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:56:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:56:25 --> URI Class Initialized
DEBUG - 2016-12-27 22:56:25 --> Router Class Initialized
ERROR - 2016-12-27 22:56:25 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:56:25 --> Config Class Initialized
DEBUG - 2016-12-27 22:56:25 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:56:25 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:56:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:56:25 --> URI Class Initialized
DEBUG - 2016-12-27 22:56:25 --> Router Class Initialized
ERROR - 2016-12-27 22:56:25 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:56:25 --> Config Class Initialized
DEBUG - 2016-12-27 22:56:25 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:56:25 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:56:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:56:25 --> URI Class Initialized
DEBUG - 2016-12-27 22:56:25 --> Router Class Initialized
ERROR - 2016-12-27 22:56:25 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:56:33 --> Config Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:56:33 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:56:33 --> URI Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Router Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Output Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Security Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Input Class Initialized
DEBUG - 2016-12-27 22:56:33 --> XSS Filtering completed
DEBUG - 2016-12-27 22:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:56:33 --> Language Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Loader Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:56:33 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:56:33 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:56:33 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:56:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:56:33 --> Session Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:56:33 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Session routines successfully run
ERROR - 2016-12-27 22:56:33 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:56:33 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:56:33 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:56:33 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:56:33 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Table Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:56:33 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:33 --> Controller Class Initialized
DEBUG - 2016-12-27 22:56:34 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:56:34 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-27 22:56:34 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-27 22:56:34 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:56:34 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:56:34 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-27 22:56:34 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-27 22:56:34 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:56:34 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:56:34 --> Final output sent to browser
DEBUG - 2016-12-27 22:56:34 --> Total execution time: 1.5861
DEBUG - 2016-12-27 22:56:34 --> Config Class Initialized
DEBUG - 2016-12-27 22:56:34 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:56:34 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:56:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:56:34 --> URI Class Initialized
DEBUG - 2016-12-27 22:56:34 --> Router Class Initialized
ERROR - 2016-12-27 22:56:34 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:56:34 --> Config Class Initialized
DEBUG - 2016-12-27 22:56:34 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:56:34 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:56:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:56:34 --> URI Class Initialized
DEBUG - 2016-12-27 22:56:34 --> Router Class Initialized
ERROR - 2016-12-27 22:56:34 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:56:46 --> Config Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:56:46 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:56:46 --> URI Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Router Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Output Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Security Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Input Class Initialized
DEBUG - 2016-12-27 22:56:46 --> XSS Filtering completed
DEBUG - 2016-12-27 22:56:46 --> XSS Filtering completed
DEBUG - 2016-12-27 22:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:56:46 --> Language Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Loader Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:56:46 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:56:46 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:56:46 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:56:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:56:46 --> Session Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:56:46 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Session routines successfully run
ERROR - 2016-12-27 22:56:46 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:56:46 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:56:46 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:56:46 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:56:46 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Table Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:56:46 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Controller Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:56:46 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:56:46 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:56:46 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:56:46 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:56:46 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:56:46 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 22:56:46 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 22:56:46 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:56:46 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 22:56:46 --> Final output sent to browser
DEBUG - 2016-12-27 22:56:46 --> Total execution time: 0.4370
DEBUG - 2016-12-27 22:56:49 --> Config Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:56:49 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:56:49 --> URI Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Router Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Output Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Security Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Input Class Initialized
DEBUG - 2016-12-27 22:56:49 --> XSS Filtering completed
DEBUG - 2016-12-27 22:56:49 --> XSS Filtering completed
DEBUG - 2016-12-27 22:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:56:49 --> Language Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Loader Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:56:49 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:56:49 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:56:49 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:56:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:56:49 --> Session Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:56:49 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Session routines successfully run
ERROR - 2016-12-27 22:56:49 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:56:49 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:56:49 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:56:49 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:56:49 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Table Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:56:49 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Controller Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:56:49 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:56:49 --> Config Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:56:49 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:56:49 --> URI Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Router Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Output Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Security Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Input Class Initialized
DEBUG - 2016-12-27 22:56:49 --> XSS Filtering completed
DEBUG - 2016-12-27 22:56:49 --> XSS Filtering completed
DEBUG - 2016-12-27 22:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:56:49 --> Language Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Loader Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:56:49 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:56:49 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:56:49 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:56:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:56:49 --> Session Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:56:49 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Session routines successfully run
ERROR - 2016-12-27 22:56:49 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:56:49 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:56:49 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:56:49 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:56:49 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Table Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:56:49 --> Model Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Controller Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:56:49 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:56:49 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:56:51 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:56:51 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:56:51 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:56:51 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-27 22:56:51 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-27 22:56:51 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:56:51 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-27 22:56:51 --> Final output sent to browser
DEBUG - 2016-12-27 22:56:51 --> Total execution time: 2.0381
DEBUG - 2016-12-27 22:56:51 --> Config Class Initialized
DEBUG - 2016-12-27 22:56:51 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:56:51 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:56:51 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:56:51 --> URI Class Initialized
DEBUG - 2016-12-27 22:56:51 --> Router Class Initialized
ERROR - 2016-12-27 22:56:51 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:56:51 --> Config Class Initialized
DEBUG - 2016-12-27 22:56:51 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:56:51 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:56:51 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:56:51 --> URI Class Initialized
DEBUG - 2016-12-27 22:56:51 --> Router Class Initialized
ERROR - 2016-12-27 22:56:51 --> 404 Page Not Found --> application
DEBUG - 2016-12-27 22:57:02 --> Config Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:57:02 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:57:02 --> URI Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Router Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Output Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Security Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Input Class Initialized
DEBUG - 2016-12-27 22:57:02 --> XSS Filtering completed
DEBUG - 2016-12-27 22:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:57:02 --> Language Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Loader Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:57:02 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:57:02 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:57:02 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:57:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:57:02 --> Session Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:57:02 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Session routines successfully run
ERROR - 2016-12-27 22:57:02 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:57:02 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:57:02 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:57:02 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:57:02 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Table Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Model Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Model Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:57:02 --> Model Class Initialized
DEBUG - 2016-12-27 22:57:02 --> Controller Class Initialized
DEBUG - 2016-12-27 22:57:03 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:57:03 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-27 22:57:03 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-27 22:57:03 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:57:03 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:57:03 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-27 22:57:03 --> File loaded: application/views/alumni_view_files/single.php
DEBUG - 2016-12-27 22:57:03 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-27 22:57:03 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:57:03 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:57:03 --> Final output sent to browser
DEBUG - 2016-12-27 22:57:03 --> Total execution time: 1.2931
DEBUG - 2016-12-27 22:57:03 --> Config Class Initialized
DEBUG - 2016-12-27 22:57:03 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:57:03 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:57:03 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:57:03 --> URI Class Initialized
DEBUG - 2016-12-27 22:57:03 --> Router Class Initialized
ERROR - 2016-12-27 22:57:03 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:57:31 --> Config Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:57:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:57:31 --> URI Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Router Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Output Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Security Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Input Class Initialized
DEBUG - 2016-12-27 22:57:31 --> XSS Filtering completed
DEBUG - 2016-12-27 22:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:57:31 --> Language Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Loader Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:57:31 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:57:31 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:57:31 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:57:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:57:31 --> Session Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:57:31 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Session routines successfully run
ERROR - 2016-12-27 22:57:31 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:57:31 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:57:31 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:57:31 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:57:31 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Table Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Model Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Model Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:57:31 --> Model Class Initialized
DEBUG - 2016-12-27 22:57:31 --> Controller Class Initialized
DEBUG - 2016-12-27 22:57:33 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:57:33 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:57:33 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:57:33 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-27 22:57:33 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-27 22:57:33 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-27 22:57:33 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-27 22:57:33 --> Final output sent to browser
DEBUG - 2016-12-27 22:57:33 --> Total execution time: 1.9831
DEBUG - 2016-12-27 22:57:33 --> Config Class Initialized
DEBUG - 2016-12-27 22:57:33 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:57:33 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:57:33 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:57:33 --> URI Class Initialized
DEBUG - 2016-12-27 22:57:33 --> Router Class Initialized
ERROR - 2016-12-27 22:57:33 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:57:33 --> Config Class Initialized
DEBUG - 2016-12-27 22:57:33 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:57:33 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:57:33 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:57:33 --> URI Class Initialized
DEBUG - 2016-12-27 22:57:33 --> Router Class Initialized
ERROR - 2016-12-27 22:57:33 --> 404 Page Not Found --> js
DEBUG - 2016-12-27 22:59:29 --> Config Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Hooks Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Utf8 Class Initialized
DEBUG - 2016-12-27 22:59:29 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 22:59:29 --> URI Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Router Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Output Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Security Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Input Class Initialized
DEBUG - 2016-12-27 22:59:29 --> XSS Filtering completed
DEBUG - 2016-12-27 22:59:29 --> XSS Filtering completed
DEBUG - 2016-12-27 22:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 22:59:29 --> Language Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Loader Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Helper loaded: url_helper
DEBUG - 2016-12-27 22:59:29 --> Helper loaded: form_helper
DEBUG - 2016-12-27 22:59:29 --> Helper loaded: func_helper
DEBUG - 2016-12-27 22:59:29 --> Database Driver Class Initialized
ERROR - 2016-12-27 22:59:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 22:59:29 --> Session Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Helper loaded: string_helper
DEBUG - 2016-12-27 22:59:29 --> Encrypt Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Session routines successfully run
ERROR - 2016-12-27 22:59:29 --> Could not find the language line "first_link"
ERROR - 2016-12-27 22:59:29 --> Could not find the language line "last_link"
ERROR - 2016-12-27 22:59:29 --> Could not find the language line "next_link"
ERROR - 2016-12-27 22:59:29 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 22:59:29 --> Pagination Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Table Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Model Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Model Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Helper loaded: file_helper
DEBUG - 2016-12-27 22:59:29 --> Model Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Controller Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Form Validation Class Initialized
DEBUG - 2016-12-27 22:59:29 --> Helper loaded: language_helper
DEBUG - 2016-12-27 22:59:29 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 22:59:29 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 22:59:29 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 22:59:29 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 22:59:29 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 22:59:29 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 22:59:29 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 22:59:29 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 22:59:29 --> Final output sent to browser
DEBUG - 2016-12-27 22:59:29 --> Total execution time: 0.4940
DEBUG - 2016-12-27 23:03:43 --> Config Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:03:43 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:03:43 --> URI Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Router Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Output Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Security Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Input Class Initialized
DEBUG - 2016-12-27 23:03:43 --> XSS Filtering completed
DEBUG - 2016-12-27 23:03:43 --> XSS Filtering completed
DEBUG - 2016-12-27 23:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:03:43 --> Language Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Loader Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:03:43 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:03:43 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:03:43 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:03:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:03:43 --> Session Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:03:43 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Session routines successfully run
ERROR - 2016-12-27 23:03:43 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:03:43 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:03:43 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:03:43 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:03:43 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Table Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Model Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Model Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:03:43 --> Model Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Controller Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:03:43 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:03:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:03:44 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:03:44 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:03:44 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:03:44 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:03:44 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:03:44 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:03:44 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:03:44 --> Final output sent to browser
DEBUG - 2016-12-27 23:03:44 --> Total execution time: 0.3640
DEBUG - 2016-12-27 23:03:44 --> Config Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:03:44 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:03:44 --> URI Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Router Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Output Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Security Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Input Class Initialized
DEBUG - 2016-12-27 23:03:44 --> XSS Filtering completed
DEBUG - 2016-12-27 23:03:44 --> XSS Filtering completed
DEBUG - 2016-12-27 23:03:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:03:44 --> Language Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Loader Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:03:44 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:03:44 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:03:44 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:03:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:03:44 --> Session Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:03:44 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Session routines successfully run
ERROR - 2016-12-27 23:03:44 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:03:44 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:03:44 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:03:44 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:03:44 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Table Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Model Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Model Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:03:44 --> Model Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Controller Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:03:44 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:03:44 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:03:45 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:03:45 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:03:45 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:03:45 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:03:45 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:03:45 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:03:45 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:03:45 --> Final output sent to browser
DEBUG - 2016-12-27 23:03:45 --> Total execution time: 0.2930
DEBUG - 2016-12-27 23:04:09 --> Config Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:04:09 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:04:09 --> URI Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Router Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Output Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Security Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Input Class Initialized
DEBUG - 2016-12-27 23:04:09 --> XSS Filtering completed
DEBUG - 2016-12-27 23:04:09 --> XSS Filtering completed
DEBUG - 2016-12-27 23:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:04:09 --> Language Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Loader Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:04:09 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:04:09 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:04:09 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:04:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:04:09 --> Session Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:04:09 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Session routines successfully run
ERROR - 2016-12-27 23:04:09 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:04:09 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:04:09 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:04:09 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:04:09 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Table Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:04:09 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Controller Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:04:09 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:04:09 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:04:09 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:04:09 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:04:09 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:04:09 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:04:09 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:04:09 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:04:09 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:04:09 --> Final output sent to browser
DEBUG - 2016-12-27 23:04:09 --> Total execution time: 0.2710
DEBUG - 2016-12-27 23:04:10 --> Config Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:04:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:04:10 --> URI Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Router Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Output Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Security Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Input Class Initialized
DEBUG - 2016-12-27 23:04:10 --> XSS Filtering completed
DEBUG - 2016-12-27 23:04:10 --> XSS Filtering completed
DEBUG - 2016-12-27 23:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:04:10 --> Language Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Loader Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:04:10 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:04:10 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:04:10 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:04:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:04:10 --> Session Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:04:10 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Session routines successfully run
ERROR - 2016-12-27 23:04:10 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:04:10 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:04:10 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:04:10 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:04:10 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Table Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:04:10 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Controller Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:04:10 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:04:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:04:10 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:04:10 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:04:10 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:04:10 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:04:10 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:04:10 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:04:10 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:04:10 --> Final output sent to browser
DEBUG - 2016-12-27 23:04:10 --> Total execution time: 0.2780
DEBUG - 2016-12-27 23:04:11 --> Config Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:04:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:04:11 --> URI Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Router Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Output Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Security Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Input Class Initialized
DEBUG - 2016-12-27 23:04:11 --> XSS Filtering completed
DEBUG - 2016-12-27 23:04:11 --> XSS Filtering completed
DEBUG - 2016-12-27 23:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:04:11 --> Language Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Loader Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:04:11 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:04:11 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:04:11 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:04:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:04:11 --> Session Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:04:11 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Session routines successfully run
ERROR - 2016-12-27 23:04:11 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:04:11 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:04:11 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:04:11 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:04:11 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Table Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:04:11 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Controller Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:04:11 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:04:11 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:04:11 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:04:11 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:04:11 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:04:11 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:04:11 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:04:11 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:04:11 --> Final output sent to browser
DEBUG - 2016-12-27 23:04:11 --> Total execution time: 0.2170
DEBUG - 2016-12-27 23:04:11 --> Config Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:04:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:04:11 --> URI Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Router Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Output Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Security Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Input Class Initialized
DEBUG - 2016-12-27 23:04:11 --> XSS Filtering completed
DEBUG - 2016-12-27 23:04:11 --> XSS Filtering completed
DEBUG - 2016-12-27 23:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:04:11 --> Language Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Loader Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:04:11 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:04:11 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:04:11 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:04:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:04:11 --> Session Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:04:11 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Session routines successfully run
ERROR - 2016-12-27 23:04:11 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:04:11 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:04:11 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:04:11 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:04:11 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Table Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:04:11 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Controller Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:04:11 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:04:11 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:04:12 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:04:12 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:04:12 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:04:12 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:04:12 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:04:12 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:04:12 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:04:12 --> Final output sent to browser
DEBUG - 2016-12-27 23:04:12 --> Total execution time: 0.2560
DEBUG - 2016-12-27 23:04:12 --> Config Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:04:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:04:12 --> URI Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Router Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Output Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Security Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Input Class Initialized
DEBUG - 2016-12-27 23:04:12 --> XSS Filtering completed
DEBUG - 2016-12-27 23:04:12 --> XSS Filtering completed
DEBUG - 2016-12-27 23:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:04:12 --> Language Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Loader Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:04:12 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:04:12 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:04:12 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:04:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:04:12 --> Session Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:04:12 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Session routines successfully run
ERROR - 2016-12-27 23:04:12 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:04:12 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:04:12 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:04:12 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:04:12 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Table Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:04:12 --> Model Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Controller Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:04:12 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:04:12 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:04:12 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:04:12 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:04:12 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:04:12 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:04:12 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:04:12 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:04:12 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:04:12 --> Final output sent to browser
DEBUG - 2016-12-27 23:04:12 --> Total execution time: 0.4280
DEBUG - 2016-12-27 23:05:24 --> Config Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:05:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:05:24 --> URI Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Router Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Output Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Security Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Input Class Initialized
DEBUG - 2016-12-27 23:05:24 --> XSS Filtering completed
DEBUG - 2016-12-27 23:05:24 --> XSS Filtering completed
DEBUG - 2016-12-27 23:05:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:05:24 --> Language Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Loader Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:05:24 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:05:24 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:05:24 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:05:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:05:24 --> Session Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:05:24 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Session routines successfully run
ERROR - 2016-12-27 23:05:24 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:05:24 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:05:24 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:05:24 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:05:24 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Table Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:05:24 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Controller Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:05:24 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:05:24 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:05:24 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:05:24 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:05:24 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:05:24 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:05:24 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:05:24 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:05:24 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:05:24 --> Final output sent to browser
DEBUG - 2016-12-27 23:05:24 --> Total execution time: 0.2530
DEBUG - 2016-12-27 23:05:25 --> Config Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:05:25 --> URI Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Router Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Output Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Security Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Input Class Initialized
DEBUG - 2016-12-27 23:05:25 --> XSS Filtering completed
DEBUG - 2016-12-27 23:05:25 --> XSS Filtering completed
DEBUG - 2016-12-27 23:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:05:25 --> Language Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Loader Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:05:25 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:05:25 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:05:25 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:05:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:05:25 --> Session Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:05:25 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Session routines successfully run
ERROR - 2016-12-27 23:05:25 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:05:25 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:05:25 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:05:25 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:05:25 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Table Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:05:25 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Controller Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:05:25 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:05:25 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:05:25 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:05:25 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:05:25 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:05:25 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:05:25 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:05:25 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:05:25 --> Final output sent to browser
DEBUG - 2016-12-27 23:05:25 --> Total execution time: 0.2480
DEBUG - 2016-12-27 23:05:25 --> Config Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:05:25 --> URI Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Router Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Output Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Security Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Input Class Initialized
DEBUG - 2016-12-27 23:05:25 --> XSS Filtering completed
DEBUG - 2016-12-27 23:05:25 --> XSS Filtering completed
DEBUG - 2016-12-27 23:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:05:25 --> Language Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Loader Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:05:25 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:05:25 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:05:25 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:05:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:05:25 --> Session Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:05:25 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Session routines successfully run
ERROR - 2016-12-27 23:05:25 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:05:25 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:05:25 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:05:25 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:05:25 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Table Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:05:25 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Controller Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:05:25 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:05:25 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:05:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:05:26 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:05:26 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:05:26 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:05:26 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:05:26 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:05:26 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:05:26 --> Final output sent to browser
DEBUG - 2016-12-27 23:05:26 --> Total execution time: 0.2950
DEBUG - 2016-12-27 23:05:26 --> Config Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:05:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:05:26 --> URI Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Router Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Output Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Security Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Input Class Initialized
DEBUG - 2016-12-27 23:05:26 --> XSS Filtering completed
DEBUG - 2016-12-27 23:05:26 --> XSS Filtering completed
DEBUG - 2016-12-27 23:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:05:26 --> Language Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Loader Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:05:26 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:05:26 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:05:26 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:05:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:05:26 --> Session Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:05:26 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Session routines successfully run
ERROR - 2016-12-27 23:05:26 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:05:26 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:05:26 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:05:26 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:05:26 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Table Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:05:26 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Controller Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:05:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:05:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:05:26 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:05:26 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:05:26 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:05:26 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:05:26 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:05:26 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:05:26 --> Final output sent to browser
DEBUG - 2016-12-27 23:05:26 --> Total execution time: 0.2680
DEBUG - 2016-12-27 23:05:26 --> Config Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:05:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:05:26 --> URI Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Router Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Output Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Security Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Input Class Initialized
DEBUG - 2016-12-27 23:05:26 --> XSS Filtering completed
DEBUG - 2016-12-27 23:05:26 --> XSS Filtering completed
DEBUG - 2016-12-27 23:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:05:26 --> Language Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Loader Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:05:26 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:05:26 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:05:26 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:05:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:05:26 --> Session Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:05:26 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Session routines successfully run
ERROR - 2016-12-27 23:05:26 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:05:26 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:05:26 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:05:26 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:05:26 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Table Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:05:26 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Controller Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:05:26 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:05:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:05:27 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:05:27 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:05:27 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:05:27 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:05:27 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:05:27 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:05:27 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:05:27 --> Final output sent to browser
DEBUG - 2016-12-27 23:05:27 --> Total execution time: 0.2140
DEBUG - 2016-12-27 23:05:27 --> Config Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:05:27 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:05:27 --> URI Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Router Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Output Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Security Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Input Class Initialized
DEBUG - 2016-12-27 23:05:27 --> XSS Filtering completed
DEBUG - 2016-12-27 23:05:27 --> XSS Filtering completed
DEBUG - 2016-12-27 23:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:05:27 --> Language Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Loader Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:05:27 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:05:27 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:05:27 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:05:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:05:27 --> Session Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:05:27 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Session routines successfully run
ERROR - 2016-12-27 23:05:27 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:05:27 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:05:27 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:05:27 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:05:27 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Table Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:05:27 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Controller Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:05:27 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:05:27 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:05:27 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:05:27 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:05:27 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:05:27 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:05:27 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:05:27 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:05:27 --> Final output sent to browser
DEBUG - 2016-12-27 23:05:27 --> Total execution time: 0.2720
DEBUG - 2016-12-27 23:05:27 --> Config Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:05:27 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:05:27 --> URI Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Router Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Output Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Security Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Input Class Initialized
DEBUG - 2016-12-27 23:05:27 --> XSS Filtering completed
DEBUG - 2016-12-27 23:05:27 --> XSS Filtering completed
DEBUG - 2016-12-27 23:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:05:27 --> Language Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Loader Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:05:27 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:05:27 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:05:27 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:05:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:05:27 --> Session Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:05:27 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Session routines successfully run
ERROR - 2016-12-27 23:05:27 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:05:27 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:05:27 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:05:27 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:05:27 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Table Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:05:27 --> Model Class Initialized
DEBUG - 2016-12-27 23:05:27 --> Controller Class Initialized
DEBUG - 2016-12-27 23:05:28 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:05:28 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:05:28 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:05:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:05:28 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:05:28 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:05:28 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:05:28 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:05:28 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:05:28 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:05:28 --> Final output sent to browser
DEBUG - 2016-12-27 23:05:28 --> Total execution time: 0.4410
DEBUG - 2016-12-27 23:06:24 --> Config Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:06:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:06:24 --> URI Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Router Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Output Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Security Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Input Class Initialized
DEBUG - 2016-12-27 23:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 23:06:24 --> XSS Filtering completed
DEBUG - 2016-12-27 23:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:06:24 --> Language Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Loader Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:06:24 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:06:24 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:06:24 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:06:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:06:24 --> Session Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:06:24 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Session routines successfully run
ERROR - 2016-12-27 23:06:24 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:06:24 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:06:24 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:06:24 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:06:24 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Table Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Model Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Model Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:06:24 --> Model Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Controller Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:06:24 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:06:24 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:06:24 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:06:24 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:06:24 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:06:24 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:06:24 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:06:24 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:06:24 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:06:24 --> Final output sent to browser
DEBUG - 2016-12-27 23:06:24 --> Total execution time: 0.2270
DEBUG - 2016-12-27 23:06:25 --> Config Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:06:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:06:25 --> URI Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Router Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Output Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Security Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Input Class Initialized
DEBUG - 2016-12-27 23:06:25 --> XSS Filtering completed
DEBUG - 2016-12-27 23:06:25 --> XSS Filtering completed
DEBUG - 2016-12-27 23:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:06:25 --> Language Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Loader Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:06:25 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:06:25 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:06:25 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:06:25 --> Session Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:06:25 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Session routines successfully run
ERROR - 2016-12-27 23:06:25 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:06:25 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:06:25 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:06:25 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:06:25 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Table Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Model Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Model Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:06:25 --> Model Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Controller Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:06:25 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:06:25 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:06:25 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:06:25 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:06:25 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:06:25 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:06:25 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:06:25 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:06:25 --> Final output sent to browser
DEBUG - 2016-12-27 23:06:25 --> Total execution time: 0.2150
DEBUG - 2016-12-27 23:06:25 --> Config Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:06:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:06:25 --> URI Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Router Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Output Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Security Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Input Class Initialized
DEBUG - 2016-12-27 23:06:25 --> XSS Filtering completed
DEBUG - 2016-12-27 23:06:25 --> XSS Filtering completed
DEBUG - 2016-12-27 23:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:06:25 --> Language Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Loader Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:06:25 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:06:25 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:06:25 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:06:25 --> Session Class Initialized
DEBUG - 2016-12-27 23:06:25 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:06:26 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Session routines successfully run
ERROR - 2016-12-27 23:06:26 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:06:26 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:06:26 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:06:26 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:06:26 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Table Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Model Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Model Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:06:26 --> Model Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Controller Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:06:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:06:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:06:26 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:06:26 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:06:26 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:06:26 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:06:26 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:06:26 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:06:26 --> Final output sent to browser
DEBUG - 2016-12-27 23:06:26 --> Total execution time: 0.2650
DEBUG - 2016-12-27 23:06:26 --> Config Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:06:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:06:26 --> URI Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Router Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Output Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Security Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Input Class Initialized
DEBUG - 2016-12-27 23:06:26 --> XSS Filtering completed
DEBUG - 2016-12-27 23:06:26 --> XSS Filtering completed
DEBUG - 2016-12-27 23:06:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:06:26 --> Language Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Loader Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:06:26 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:06:26 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:06:26 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:06:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:06:26 --> Session Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:06:26 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Session routines successfully run
ERROR - 2016-12-27 23:06:26 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:06:26 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:06:26 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:06:26 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:06:26 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Table Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Model Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Model Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:06:26 --> Model Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Controller Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:06:26 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:06:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:06:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:06:26 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:06:26 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:06:26 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:06:26 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:06:26 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:06:26 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:06:26 --> Final output sent to browser
DEBUG - 2016-12-27 23:06:26 --> Total execution time: 0.3490
DEBUG - 2016-12-27 23:08:29 --> Config Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Hooks Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Utf8 Class Initialized
DEBUG - 2016-12-27 23:08:29 --> UTF-8 Support Enabled
DEBUG - 2016-12-27 23:08:29 --> URI Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Router Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Output Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Security Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Input Class Initialized
DEBUG - 2016-12-27 23:08:29 --> XSS Filtering completed
DEBUG - 2016-12-27 23:08:29 --> XSS Filtering completed
DEBUG - 2016-12-27 23:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-27 23:08:29 --> Language Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Loader Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Helper loaded: url_helper
DEBUG - 2016-12-27 23:08:29 --> Helper loaded: form_helper
DEBUG - 2016-12-27 23:08:29 --> Helper loaded: func_helper
DEBUG - 2016-12-27 23:08:29 --> Database Driver Class Initialized
ERROR - 2016-12-27 23:08:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-27 23:08:29 --> Session Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Helper loaded: string_helper
DEBUG - 2016-12-27 23:08:29 --> Encrypt Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Session routines successfully run
ERROR - 2016-12-27 23:08:29 --> Could not find the language line "first_link"
ERROR - 2016-12-27 23:08:29 --> Could not find the language line "last_link"
ERROR - 2016-12-27 23:08:29 --> Could not find the language line "next_link"
ERROR - 2016-12-27 23:08:29 --> Could not find the language line "prev_link"
DEBUG - 2016-12-27 23:08:29 --> Pagination Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Table Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Model Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Model Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Helper loaded: file_helper
DEBUG - 2016-12-27 23:08:29 --> Model Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Controller Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Form Validation Class Initialized
DEBUG - 2016-12-27 23:08:29 --> Helper loaded: language_helper
DEBUG - 2016-12-27 23:08:29 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-27 23:08:29 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-27 23:08:29 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-27 23:08:29 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-27 23:08:29 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-12-27 23:08:29 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-12-27 23:08:29 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-27 23:08:29 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-12-27 23:08:29 --> Final output sent to browser
DEBUG - 2016-12-27 23:08:29 --> Total execution time: 0.2430
