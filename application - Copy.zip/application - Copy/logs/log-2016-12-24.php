<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-12-24 17:15:10 --> Config Class Initialized
DEBUG - 2016-12-24 17:15:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:15:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:15:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:15:10 --> URI Class Initialized
DEBUG - 2016-12-24 17:15:10 --> Router Class Initialized
DEBUG - 2016-12-24 17:15:10 --> No URI present. Default controller set.
DEBUG - 2016-12-24 17:15:10 --> Output Class Initialized
DEBUG - 2016-12-24 17:15:10 --> Security Class Initialized
DEBUG - 2016-12-24 17:15:10 --> Input Class Initialized
DEBUG - 2016-12-24 17:15:10 --> XSS Filtering completed
DEBUG - 2016-12-24 17:15:10 --> XSS Filtering completed
DEBUG - 2016-12-24 17:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 17:15:10 --> Language Class Initialized
DEBUG - 2016-12-24 17:15:10 --> Loader Class Initialized
DEBUG - 2016-12-24 17:15:10 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:15:10 --> Helper loaded: form_helper
DEBUG - 2016-12-24 17:15:10 --> Helper loaded: func_helper
DEBUG - 2016-12-24 17:15:11 --> Database Driver Class Initialized
ERROR - 2016-12-24 17:15:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 17:15:11 --> Session Class Initialized
DEBUG - 2016-12-24 17:15:11 --> Helper loaded: string_helper
DEBUG - 2016-12-24 17:15:11 --> Encrypt Class Initialized
ERROR - 2016-12-24 17:15:11 --> Session: The session cookie was not signed.
DEBUG - 2016-12-24 17:15:11 --> Session routines successfully run
ERROR - 2016-12-24 17:15:11 --> Could not find the language line "first_link"
ERROR - 2016-12-24 17:15:11 --> Could not find the language line "last_link"
ERROR - 2016-12-24 17:15:11 --> Could not find the language line "next_link"
ERROR - 2016-12-24 17:15:11 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 17:15:11 --> Pagination Class Initialized
DEBUG - 2016-12-24 17:15:11 --> Table Class Initialized
DEBUG - 2016-12-24 17:15:11 --> Model Class Initialized
DEBUG - 2016-12-24 17:15:11 --> Model Class Initialized
DEBUG - 2016-12-24 17:15:11 --> Helper loaded: file_helper
DEBUG - 2016-12-24 17:15:11 --> Model Class Initialized
DEBUG - 2016-12-24 17:15:11 --> Controller Class Initialized
DEBUG - 2016-12-24 17:15:14 --> Helper loaded: language_helper
DEBUG - 2016-12-24 17:15:14 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 17:15:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-24 17:15:19 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 17:15:19 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-24 17:15:19 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-24 17:15:19 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-24 17:15:19 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-24 17:15:19 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-24 17:15:19 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-24 17:15:19 --> Final output sent to browser
DEBUG - 2016-12-24 17:15:19 --> Total execution time: 9.3375
DEBUG - 2016-12-24 17:15:19 --> Config Class Initialized
DEBUG - 2016-12-24 17:15:19 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:15:19 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:15:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:15:19 --> URI Class Initialized
DEBUG - 2016-12-24 17:15:19 --> Router Class Initialized
ERROR - 2016-12-24 17:15:19 --> 404 Page Not Found --> js
DEBUG - 2016-12-24 17:15:19 --> Config Class Initialized
DEBUG - 2016-12-24 17:15:19 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:15:19 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:15:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:15:19 --> URI Class Initialized
DEBUG - 2016-12-24 17:15:19 --> Router Class Initialized
ERROR - 2016-12-24 17:15:19 --> 404 Page Not Found --> js
DEBUG - 2016-12-24 17:52:22 --> Config Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:52:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:52:23 --> URI Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Router Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Output Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Security Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Input Class Initialized
DEBUG - 2016-12-24 17:52:23 --> XSS Filtering completed
DEBUG - 2016-12-24 17:52:23 --> XSS Filtering completed
DEBUG - 2016-12-24 17:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 17:52:23 --> Language Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Loader Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:52:23 --> Helper loaded: form_helper
DEBUG - 2016-12-24 17:52:23 --> Helper loaded: func_helper
DEBUG - 2016-12-24 17:52:23 --> Database Driver Class Initialized
ERROR - 2016-12-24 17:52:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 17:52:23 --> Session Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Helper loaded: string_helper
DEBUG - 2016-12-24 17:52:23 --> Encrypt Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Session routines successfully run
ERROR - 2016-12-24 17:52:23 --> Could not find the language line "first_link"
ERROR - 2016-12-24 17:52:23 --> Could not find the language line "last_link"
ERROR - 2016-12-24 17:52:23 --> Could not find the language line "next_link"
ERROR - 2016-12-24 17:52:23 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 17:52:23 --> Pagination Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Table Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Model Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Model Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Helper loaded: file_helper
DEBUG - 2016-12-24 17:52:23 --> Model Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Controller Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Form Validation Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Config Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:52:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:52:23 --> URI Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Router Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Output Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Security Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Input Class Initialized
DEBUG - 2016-12-24 17:52:23 --> XSS Filtering completed
DEBUG - 2016-12-24 17:52:23 --> XSS Filtering completed
DEBUG - 2016-12-24 17:52:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 17:52:23 --> Language Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Loader Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:52:23 --> Helper loaded: form_helper
DEBUG - 2016-12-24 17:52:23 --> Helper loaded: func_helper
DEBUG - 2016-12-24 17:52:23 --> Database Driver Class Initialized
ERROR - 2016-12-24 17:52:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 17:52:23 --> Session Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Helper loaded: string_helper
DEBUG - 2016-12-24 17:52:23 --> Encrypt Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Session routines successfully run
ERROR - 2016-12-24 17:52:23 --> Could not find the language line "first_link"
ERROR - 2016-12-24 17:52:23 --> Could not find the language line "last_link"
ERROR - 2016-12-24 17:52:23 --> Could not find the language line "next_link"
ERROR - 2016-12-24 17:52:23 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 17:52:23 --> Pagination Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Table Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Model Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Model Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Helper loaded: file_helper
DEBUG - 2016-12-24 17:52:23 --> Model Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Controller Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Helper loaded: language_helper
DEBUG - 2016-12-24 17:52:23 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 17:52:23 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 17:52:23 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-24 17:52:23 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-24 17:52:23 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-24 17:52:23 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-24 17:52:23 --> Final output sent to browser
DEBUG - 2016-12-24 17:52:23 --> Total execution time: 0.0990
DEBUG - 2016-12-24 17:52:23 --> Config Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:52:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:52:23 --> URI Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Router Class Initialized
ERROR - 2016-12-24 17:52:23 --> 404 Page Not Found --> js
DEBUG - 2016-12-24 17:52:23 --> Config Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:52:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:52:23 --> URI Class Initialized
DEBUG - 2016-12-24 17:52:23 --> Router Class Initialized
ERROR - 2016-12-24 17:52:23 --> 404 Page Not Found --> js
DEBUG - 2016-12-24 17:52:33 --> Config Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:52:33 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:52:33 --> URI Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Router Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Output Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Security Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Input Class Initialized
DEBUG - 2016-12-24 17:52:33 --> XSS Filtering completed
DEBUG - 2016-12-24 17:52:33 --> XSS Filtering completed
DEBUG - 2016-12-24 17:52:33 --> XSS Filtering completed
DEBUG - 2016-12-24 17:52:33 --> XSS Filtering completed
DEBUG - 2016-12-24 17:52:33 --> XSS Filtering completed
DEBUG - 2016-12-24 17:52:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 17:52:33 --> Language Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Loader Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:52:33 --> Helper loaded: form_helper
DEBUG - 2016-12-24 17:52:33 --> Helper loaded: func_helper
DEBUG - 2016-12-24 17:52:33 --> Database Driver Class Initialized
ERROR - 2016-12-24 17:52:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 17:52:33 --> Session Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Helper loaded: string_helper
DEBUG - 2016-12-24 17:52:33 --> Encrypt Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Session routines successfully run
ERROR - 2016-12-24 17:52:33 --> Could not find the language line "first_link"
ERROR - 2016-12-24 17:52:33 --> Could not find the language line "last_link"
ERROR - 2016-12-24 17:52:33 --> Could not find the language line "next_link"
ERROR - 2016-12-24 17:52:33 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 17:52:33 --> Pagination Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Table Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Model Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Model Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Helper loaded: file_helper
DEBUG - 2016-12-24 17:52:33 --> Model Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Controller Class Initialized
DEBUG - 2016-12-24 17:52:33 --> Helper loaded: language_helper
DEBUG - 2016-12-24 17:52:33 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 17:52:33 --> Model Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Config Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:52:36 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:52:36 --> URI Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Router Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Output Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Security Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Input Class Initialized
DEBUG - 2016-12-24 17:52:36 --> XSS Filtering completed
DEBUG - 2016-12-24 17:52:36 --> XSS Filtering completed
DEBUG - 2016-12-24 17:52:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 17:52:36 --> Language Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Loader Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:52:36 --> Helper loaded: form_helper
DEBUG - 2016-12-24 17:52:36 --> Helper loaded: func_helper
DEBUG - 2016-12-24 17:52:36 --> Database Driver Class Initialized
ERROR - 2016-12-24 17:52:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 17:52:36 --> Session Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Helper loaded: string_helper
DEBUG - 2016-12-24 17:52:36 --> Encrypt Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Session routines successfully run
ERROR - 2016-12-24 17:52:36 --> Could not find the language line "first_link"
ERROR - 2016-12-24 17:52:36 --> Could not find the language line "last_link"
ERROR - 2016-12-24 17:52:36 --> Could not find the language line "next_link"
ERROR - 2016-12-24 17:52:36 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 17:52:36 --> Pagination Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Table Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Model Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Model Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Helper loaded: file_helper
DEBUG - 2016-12-24 17:52:36 --> Model Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Controller Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Form Validation Class Initialized
DEBUG - 2016-12-24 17:52:36 --> Helper loaded: language_helper
DEBUG - 2016-12-24 17:52:36 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 17:52:39 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 17:52:39 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 17:52:39 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 17:52:39 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 17:52:39 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 17:52:39 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 17:52:39 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 17:52:39 --> Final output sent to browser
DEBUG - 2016-12-24 17:52:39 --> Total execution time: 2.8962
DEBUG - 2016-12-24 17:52:39 --> Config Class Initialized
DEBUG - 2016-12-24 17:52:39 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:52:39 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:52:39 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:52:39 --> URI Class Initialized
DEBUG - 2016-12-24 17:52:39 --> Config Class Initialized
DEBUG - 2016-12-24 17:52:39 --> Router Class Initialized
DEBUG - 2016-12-24 17:52:39 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:52:39 --> Utf8 Class Initialized
ERROR - 2016-12-24 17:52:39 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:52:39 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:52:39 --> URI Class Initialized
DEBUG - 2016-12-24 17:52:39 --> Router Class Initialized
ERROR - 2016-12-24 17:52:39 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:52:39 --> Config Class Initialized
DEBUG - 2016-12-24 17:52:39 --> Config Class Initialized
DEBUG - 2016-12-24 17:52:39 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:52:39 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:52:39 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:52:39 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:52:39 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:52:39 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:52:39 --> URI Class Initialized
DEBUG - 2016-12-24 17:52:39 --> URI Class Initialized
DEBUG - 2016-12-24 17:52:39 --> Router Class Initialized
DEBUG - 2016-12-24 17:52:39 --> Router Class Initialized
ERROR - 2016-12-24 17:52:39 --> 404 Page Not Found --> application
ERROR - 2016-12-24 17:52:39 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:06 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:06 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:06 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Router Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Output Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Security Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Input Class Initialized
DEBUG - 2016-12-24 17:54:06 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:06 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:06 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 17:54:06 --> Language Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Loader Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:54:06 --> Helper loaded: form_helper
DEBUG - 2016-12-24 17:54:06 --> Helper loaded: func_helper
DEBUG - 2016-12-24 17:54:06 --> Database Driver Class Initialized
ERROR - 2016-12-24 17:54:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 17:54:06 --> Session Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Helper loaded: string_helper
DEBUG - 2016-12-24 17:54:06 --> Encrypt Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Session routines successfully run
ERROR - 2016-12-24 17:54:06 --> Could not find the language line "first_link"
ERROR - 2016-12-24 17:54:06 --> Could not find the language line "last_link"
ERROR - 2016-12-24 17:54:06 --> Could not find the language line "next_link"
ERROR - 2016-12-24 17:54:06 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 17:54:06 --> Pagination Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Table Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Helper loaded: file_helper
DEBUG - 2016-12-24 17:54:06 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Controller Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Form Validation Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Helper loaded: language_helper
DEBUG - 2016-12-24 17:54:06 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 17:54:06 --> Final output sent to browser
DEBUG - 2016-12-24 17:54:06 --> Total execution time: 0.2400
DEBUG - 2016-12-24 17:54:06 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:06 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:06 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Router Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Output Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Security Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Input Class Initialized
DEBUG - 2016-12-24 17:54:06 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:06 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 17:54:06 --> Language Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Loader Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:54:06 --> Helper loaded: form_helper
DEBUG - 2016-12-24 17:54:06 --> Helper loaded: func_helper
DEBUG - 2016-12-24 17:54:06 --> Database Driver Class Initialized
ERROR - 2016-12-24 17:54:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 17:54:06 --> Session Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Helper loaded: string_helper
DEBUG - 2016-12-24 17:54:06 --> Encrypt Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Session routines successfully run
ERROR - 2016-12-24 17:54:06 --> Could not find the language line "first_link"
ERROR - 2016-12-24 17:54:06 --> Could not find the language line "last_link"
ERROR - 2016-12-24 17:54:06 --> Could not find the language line "next_link"
ERROR - 2016-12-24 17:54:06 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 17:54:06 --> Pagination Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Table Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Helper loaded: file_helper
DEBUG - 2016-12-24 17:54:06 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Controller Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Form Validation Class Initialized
DEBUG - 2016-12-24 17:54:06 --> Helper loaded: language_helper
DEBUG - 2016-12-24 17:54:06 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 17:54:09 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 17:54:09 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 17:54:09 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 17:54:09 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 17:54:09 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 17:54:09 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 17:54:09 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 17:54:09 --> Final output sent to browser
DEBUG - 2016-12-24 17:54:09 --> Total execution time: 3.1292
DEBUG - 2016-12-24 17:54:09 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:09 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:09 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:09 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:09 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:09 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:09 --> Router Class Initialized
DEBUG - 2016-12-24 17:54:09 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:09 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:09 --> UTF-8 Support Enabled
ERROR - 2016-12-24 17:54:09 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:09 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:09 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:09 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:09 --> Router Class Initialized
DEBUG - 2016-12-24 17:54:09 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:09 --> UTF-8 Support Enabled
ERROR - 2016-12-24 17:54:09 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:09 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:09 --> Router Class Initialized
ERROR - 2016-12-24 17:54:09 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:09 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:09 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:09 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:09 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:09 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:09 --> Router Class Initialized
ERROR - 2016-12-24 17:54:09 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:27 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:27 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:27 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Router Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Output Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Security Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Input Class Initialized
DEBUG - 2016-12-24 17:54:27 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:27 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:27 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 17:54:27 --> Language Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Loader Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:54:27 --> Helper loaded: form_helper
DEBUG - 2016-12-24 17:54:27 --> Helper loaded: func_helper
DEBUG - 2016-12-24 17:54:27 --> Database Driver Class Initialized
ERROR - 2016-12-24 17:54:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 17:54:27 --> Session Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Helper loaded: string_helper
DEBUG - 2016-12-24 17:54:27 --> Encrypt Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Session routines successfully run
ERROR - 2016-12-24 17:54:27 --> Could not find the language line "first_link"
ERROR - 2016-12-24 17:54:27 --> Could not find the language line "last_link"
ERROR - 2016-12-24 17:54:27 --> Could not find the language line "next_link"
ERROR - 2016-12-24 17:54:27 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 17:54:27 --> Pagination Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Table Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Helper loaded: file_helper
DEBUG - 2016-12-24 17:54:27 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Controller Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Form Validation Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Helper loaded: language_helper
DEBUG - 2016-12-24 17:54:27 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 17:54:27 --> Final output sent to browser
DEBUG - 2016-12-24 17:54:27 --> Total execution time: 0.1910
DEBUG - 2016-12-24 17:54:27 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:27 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:27 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Router Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Output Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Security Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Input Class Initialized
DEBUG - 2016-12-24 17:54:27 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:27 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 17:54:27 --> Language Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Loader Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:54:27 --> Helper loaded: form_helper
DEBUG - 2016-12-24 17:54:27 --> Helper loaded: func_helper
DEBUG - 2016-12-24 17:54:27 --> Database Driver Class Initialized
ERROR - 2016-12-24 17:54:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 17:54:27 --> Session Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Helper loaded: string_helper
DEBUG - 2016-12-24 17:54:27 --> Encrypt Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Session routines successfully run
ERROR - 2016-12-24 17:54:27 --> Could not find the language line "first_link"
ERROR - 2016-12-24 17:54:27 --> Could not find the language line "last_link"
ERROR - 2016-12-24 17:54:27 --> Could not find the language line "next_link"
ERROR - 2016-12-24 17:54:27 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 17:54:27 --> Pagination Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Table Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Helper loaded: file_helper
DEBUG - 2016-12-24 17:54:27 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Controller Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Form Validation Class Initialized
DEBUG - 2016-12-24 17:54:27 --> Helper loaded: language_helper
DEBUG - 2016-12-24 17:54:27 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 17:54:30 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 17:54:30 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 17:54:30 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 17:54:30 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 17:54:30 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 17:54:30 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 17:54:30 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 17:54:30 --> Final output sent to browser
DEBUG - 2016-12-24 17:54:30 --> Total execution time: 3.3902
DEBUG - 2016-12-24 17:54:30 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:30 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:30 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:30 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:30 --> Router Class Initialized
DEBUG - 2016-12-24 17:54:30 --> Config Class Initialized
ERROR - 2016-12-24 17:54:30 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:30 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:30 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:30 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:30 --> Router Class Initialized
ERROR - 2016-12-24 17:54:31 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:31 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:31 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:31 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:31 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:31 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:31 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:31 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:31 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:31 --> Router Class Initialized
ERROR - 2016-12-24 17:54:31 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:31 --> Router Class Initialized
ERROR - 2016-12-24 17:54:31 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:35 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:35 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Router Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Output Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Security Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Input Class Initialized
DEBUG - 2016-12-24 17:54:35 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:35 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 17:54:35 --> Language Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Loader Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:54:35 --> Helper loaded: form_helper
DEBUG - 2016-12-24 17:54:35 --> Helper loaded: func_helper
DEBUG - 2016-12-24 17:54:35 --> Database Driver Class Initialized
ERROR - 2016-12-24 17:54:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 17:54:35 --> Session Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Helper loaded: string_helper
DEBUG - 2016-12-24 17:54:35 --> Encrypt Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Session routines successfully run
ERROR - 2016-12-24 17:54:35 --> Could not find the language line "first_link"
ERROR - 2016-12-24 17:54:35 --> Could not find the language line "last_link"
ERROR - 2016-12-24 17:54:35 --> Could not find the language line "next_link"
ERROR - 2016-12-24 17:54:35 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 17:54:35 --> Pagination Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Table Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Helper loaded: file_helper
DEBUG - 2016-12-24 17:54:35 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Controller Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Form Validation Class Initialized
DEBUG - 2016-12-24 17:54:35 --> Helper loaded: language_helper
DEBUG - 2016-12-24 17:54:35 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 17:54:35 --> Could not find the language line "settings"
DEBUG - 2016-12-24 17:54:35 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 17:54:35 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 17:54:35 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 17:54:35 --> File loaded: application/views/admin/settings.php
DEBUG - 2016-12-24 17:54:35 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 17:54:35 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 17:54:35 --> Final output sent to browser
DEBUG - 2016-12-24 17:54:35 --> Total execution time: 0.2890
DEBUG - 2016-12-24 17:54:49 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:49 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:49 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Router Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Output Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Security Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Input Class Initialized
DEBUG - 2016-12-24 17:54:49 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:49 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:49 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:49 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:49 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:49 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 17:54:49 --> Language Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Loader Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:54:49 --> Helper loaded: form_helper
DEBUG - 2016-12-24 17:54:49 --> Helper loaded: func_helper
DEBUG - 2016-12-24 17:54:49 --> Database Driver Class Initialized
ERROR - 2016-12-24 17:54:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 17:54:49 --> Session Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Helper loaded: string_helper
DEBUG - 2016-12-24 17:54:49 --> Encrypt Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Session routines successfully run
ERROR - 2016-12-24 17:54:49 --> Could not find the language line "first_link"
ERROR - 2016-12-24 17:54:49 --> Could not find the language line "last_link"
ERROR - 2016-12-24 17:54:49 --> Could not find the language line "next_link"
ERROR - 2016-12-24 17:54:49 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 17:54:49 --> Pagination Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Table Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Helper loaded: file_helper
DEBUG - 2016-12-24 17:54:49 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Controller Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Form Validation Class Initialized
DEBUG - 2016-12-24 17:54:49 --> Helper loaded: language_helper
DEBUG - 2016-12-24 17:54:49 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 17:54:49 --> Could not find the language line "settings_updated"
DEBUG - 2016-12-24 17:54:52 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 17:54:52 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 17:54:52 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 17:54:52 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 17:54:52 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 17:54:52 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 17:54:52 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 17:54:52 --> Final output sent to browser
DEBUG - 2016-12-24 17:54:52 --> Total execution time: 3.6022
DEBUG - 2016-12-24 17:54:53 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:53 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:53 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:53 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Router Class Initialized
DEBUG - 2016-12-24 17:54:53 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:53 --> URI Class Initialized
ERROR - 2016-12-24 17:54:53 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:53 --> Router Class Initialized
ERROR - 2016-12-24 17:54:53 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:53 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:53 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:53 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Router Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Utf8 Class Initialized
ERROR - 2016-12-24 17:54:53 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:53 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:53 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Router Class Initialized
ERROR - 2016-12-24 17:54:53 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:53 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:53 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:53 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Router Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Output Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Security Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Input Class Initialized
DEBUG - 2016-12-24 17:54:53 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:53 --> XSS Filtering completed
DEBUG - 2016-12-24 17:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 17:54:53 --> Language Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Loader Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:54:53 --> Helper loaded: form_helper
DEBUG - 2016-12-24 17:54:53 --> Helper loaded: func_helper
DEBUG - 2016-12-24 17:54:53 --> Database Driver Class Initialized
ERROR - 2016-12-24 17:54:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 17:54:53 --> Session Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Helper loaded: string_helper
DEBUG - 2016-12-24 17:54:53 --> Encrypt Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Session routines successfully run
ERROR - 2016-12-24 17:54:53 --> Could not find the language line "first_link"
ERROR - 2016-12-24 17:54:53 --> Could not find the language line "last_link"
ERROR - 2016-12-24 17:54:53 --> Could not find the language line "next_link"
ERROR - 2016-12-24 17:54:53 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 17:54:53 --> Pagination Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Table Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Helper loaded: file_helper
DEBUG - 2016-12-24 17:54:53 --> Model Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Controller Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Form Validation Class Initialized
DEBUG - 2016-12-24 17:54:53 --> Helper loaded: language_helper
DEBUG - 2016-12-24 17:54:53 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 17:54:57 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 17:54:57 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 17:54:57 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 17:54:57 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 17:54:57 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 17:54:57 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 17:54:57 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 17:54:57 --> Final output sent to browser
DEBUG - 2016-12-24 17:54:57 --> Total execution time: 3.4912
DEBUG - 2016-12-24 17:54:57 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:57 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:57 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:57 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:57 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:57 --> Router Class Initialized
DEBUG - 2016-12-24 17:54:57 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:57 --> Utf8 Class Initialized
ERROR - 2016-12-24 17:54:57 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:57 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:57 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:57 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:57 --> Router Class Initialized
DEBUG - 2016-12-24 17:54:57 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:57 --> UTF-8 Support Enabled
ERROR - 2016-12-24 17:54:57 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:57 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:57 --> Router Class Initialized
ERROR - 2016-12-24 17:54:57 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:54:57 --> Config Class Initialized
DEBUG - 2016-12-24 17:54:57 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:54:57 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:54:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:54:57 --> URI Class Initialized
DEBUG - 2016-12-24 17:54:57 --> Router Class Initialized
ERROR - 2016-12-24 17:54:57 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:55:08 --> Config Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:55:08 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:55:08 --> URI Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Router Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Output Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Security Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Input Class Initialized
DEBUG - 2016-12-24 17:55:08 --> XSS Filtering completed
DEBUG - 2016-12-24 17:55:08 --> XSS Filtering completed
DEBUG - 2016-12-24 17:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 17:55:08 --> Language Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Loader Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:55:08 --> Helper loaded: form_helper
DEBUG - 2016-12-24 17:55:08 --> Helper loaded: func_helper
DEBUG - 2016-12-24 17:55:08 --> Database Driver Class Initialized
ERROR - 2016-12-24 17:55:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 17:55:08 --> Session Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Helper loaded: string_helper
DEBUG - 2016-12-24 17:55:08 --> Encrypt Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Session routines successfully run
ERROR - 2016-12-24 17:55:08 --> Could not find the language line "first_link"
ERROR - 2016-12-24 17:55:08 --> Could not find the language line "last_link"
ERROR - 2016-12-24 17:55:08 --> Could not find the language line "next_link"
ERROR - 2016-12-24 17:55:08 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 17:55:08 --> Pagination Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Table Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Model Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Model Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Helper loaded: file_helper
DEBUG - 2016-12-24 17:55:08 --> Model Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Controller Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Form Validation Class Initialized
DEBUG - 2016-12-24 17:55:08 --> Helper loaded: language_helper
DEBUG - 2016-12-24 17:55:08 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 17:55:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 17:55:13 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 17:55:13 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 17:55:13 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 17:55:13 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 17:55:13 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 17:55:13 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 17:55:13 --> Final output sent to browser
DEBUG - 2016-12-24 17:55:13 --> Total execution time: 4.9033
DEBUG - 2016-12-24 17:55:25 --> Config Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:55:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:55:25 --> URI Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Router Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Output Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Security Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Input Class Initialized
DEBUG - 2016-12-24 17:55:25 --> XSS Filtering completed
DEBUG - 2016-12-24 17:55:25 --> XSS Filtering completed
DEBUG - 2016-12-24 17:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 17:55:25 --> Language Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Loader Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Helper loaded: url_helper
DEBUG - 2016-12-24 17:55:25 --> Helper loaded: form_helper
DEBUG - 2016-12-24 17:55:25 --> Helper loaded: func_helper
DEBUG - 2016-12-24 17:55:25 --> Database Driver Class Initialized
ERROR - 2016-12-24 17:55:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 17:55:25 --> Session Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Helper loaded: string_helper
DEBUG - 2016-12-24 17:55:25 --> Encrypt Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Session routines successfully run
ERROR - 2016-12-24 17:55:25 --> Could not find the language line "first_link"
ERROR - 2016-12-24 17:55:25 --> Could not find the language line "last_link"
ERROR - 2016-12-24 17:55:25 --> Could not find the language line "next_link"
ERROR - 2016-12-24 17:55:25 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 17:55:25 --> Pagination Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Table Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Model Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Model Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Helper loaded: file_helper
DEBUG - 2016-12-24 17:55:25 --> Model Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Controller Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Form Validation Class Initialized
DEBUG - 2016-12-24 17:55:25 --> Helper loaded: language_helper
DEBUG - 2016-12-24 17:55:25 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 17:55:27 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 17:55:27 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 17:55:27 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 17:55:27 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 17:55:27 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 17:55:27 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 17:55:27 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 17:55:27 --> Final output sent to browser
DEBUG - 2016-12-24 17:55:27 --> Total execution time: 2.4901
DEBUG - 2016-12-24 17:55:27 --> Config Class Initialized
DEBUG - 2016-12-24 17:55:27 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:55:27 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:55:27 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:55:27 --> Config Class Initialized
DEBUG - 2016-12-24 17:55:27 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:55:27 --> URI Class Initialized
DEBUG - 2016-12-24 17:55:27 --> Router Class Initialized
DEBUG - 2016-12-24 17:55:27 --> Config Class Initialized
DEBUG - 2016-12-24 17:55:27 --> Config Class Initialized
ERROR - 2016-12-24 17:55:27 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:55:27 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:55:27 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:55:27 --> Hooks Class Initialized
DEBUG - 2016-12-24 17:55:27 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:55:27 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:55:27 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 17:55:27 --> URI Class Initialized
DEBUG - 2016-12-24 17:55:27 --> URI Class Initialized
DEBUG - 2016-12-24 17:55:27 --> Router Class Initialized
DEBUG - 2016-12-24 17:55:27 --> Router Class Initialized
DEBUG - 2016-12-24 17:55:27 --> Utf8 Class Initialized
DEBUG - 2016-12-24 17:55:27 --> UTF-8 Support Enabled
ERROR - 2016-12-24 17:55:27 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 17:55:27 --> URI Class Initialized
DEBUG - 2016-12-24 17:55:27 --> Router Class Initialized
ERROR - 2016-12-24 17:55:27 --> 404 Page Not Found --> application
ERROR - 2016-12-24 17:55:27 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:03:25 --> Config Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:03:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:03:25 --> URI Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Router Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Output Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Security Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Input Class Initialized
DEBUG - 2016-12-24 18:03:25 --> XSS Filtering completed
DEBUG - 2016-12-24 18:03:25 --> XSS Filtering completed
DEBUG - 2016-12-24 18:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:03:25 --> Language Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Loader Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:03:25 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:03:25 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:03:25 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:03:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:03:25 --> Session Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:03:25 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Session routines successfully run
ERROR - 2016-12-24 18:03:25 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:03:25 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:03:25 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:03:25 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:03:25 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Table Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Model Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Model Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:03:25 --> Model Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Controller Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:03:25 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:03:25 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 18:03:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:03:28 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:03:28 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:03:28 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 18:03:28 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 18:03:28 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:03:28 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:03:28 --> Final output sent to browser
DEBUG - 2016-12-24 18:03:28 --> Total execution time: 2.6312
DEBUG - 2016-12-24 18:03:28 --> Config Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:03:28 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:03:28 --> Config Class Initialized
DEBUG - 2016-12-24 18:03:28 --> URI Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:03:28 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:03:28 --> URI Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Router Class Initialized
ERROR - 2016-12-24 18:03:28 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:03:28 --> Router Class Initialized
ERROR - 2016-12-24 18:03:28 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:03:28 --> Config Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:03:28 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:03:28 --> URI Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Router Class Initialized
ERROR - 2016-12-24 18:03:28 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:03:28 --> Config Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:03:28 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:03:28 --> URI Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Router Class Initialized
ERROR - 2016-12-24 18:03:28 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:03:28 --> Config Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Config Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:03:28 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:03:28 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:03:28 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:03:28 --> URI Class Initialized
DEBUG - 2016-12-24 18:03:28 --> URI Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Router Class Initialized
ERROR - 2016-12-24 18:03:28 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:03:28 --> Config Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Router Class Initialized
ERROR - 2016-12-24 18:03:28 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:03:28 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:03:28 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:03:28 --> URI Class Initialized
DEBUG - 2016-12-24 18:03:28 --> Router Class Initialized
ERROR - 2016-12-24 18:03:28 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:18 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:18 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Output Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Security Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Input Class Initialized
DEBUG - 2016-12-24 18:05:18 --> XSS Filtering completed
DEBUG - 2016-12-24 18:05:18 --> XSS Filtering completed
DEBUG - 2016-12-24 18:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:05:18 --> Language Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Loader Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:05:18 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:05:18 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:05:18 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:05:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:05:18 --> Session Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:05:18 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Session routines successfully run
ERROR - 2016-12-24 18:05:18 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:05:18 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:05:18 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:05:18 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:05:18 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Table Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Model Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Model Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:05:18 --> Model Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Controller Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:05:18 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:05:18 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 18:05:21 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:05:21 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:05:21 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:05:21 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 18:05:21 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 18:05:21 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:05:21 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:05:21 --> Final output sent to browser
DEBUG - 2016-12-24 18:05:21 --> Total execution time: 3.4052
DEBUG - 2016-12-24 18:05:21 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:21 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Router Class Initialized
ERROR - 2016-12-24 18:05:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:21 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:21 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:21 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:21 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Router Class Initialized
ERROR - 2016-12-24 18:05:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:21 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Config Class Initialized
ERROR - 2016-12-24 18:05:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:21 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:21 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:21 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:21 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:21 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:21 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:21 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:05:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:21 --> Config Class Initialized
ERROR - 2016-12-24 18:05:21 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:21 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:05:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:21 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:21 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Router Class Initialized
ERROR - 2016-12-24 18:05:21 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:21 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:21 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:21 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:21 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:21 --> URI Class Initialized
ERROR - 2016-12-24 18:05:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:21 --> Router Class Initialized
ERROR - 2016-12-24 18:05:21 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:21 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:21 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:21 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:22 --> Router Class Initialized
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:23 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:23 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:23 --> Router Class Initialized
ERROR - 2016-12-24 18:05:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:24 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:24 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Router Class Initialized
ERROR - 2016-12-24 18:05:24 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:24 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:24 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:24 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:24 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Router Class Initialized
ERROR - 2016-12-24 18:05:24 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:24 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:24 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:24 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:24 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Router Class Initialized
ERROR - 2016-12-24 18:05:24 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:24 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:24 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:24 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:24 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Router Class Initialized
ERROR - 2016-12-24 18:05:24 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:24 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:24 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:24 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:24 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:24 --> URI Class Initialized
ERROR - 2016-12-24 18:05:24 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:24 --> Router Class Initialized
ERROR - 2016-12-24 18:05:24 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:24 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:24 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:24 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Router Class Initialized
ERROR - 2016-12-24 18:05:24 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:24 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:24 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:24 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:24 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:24 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:24 --> Router Class Initialized
ERROR - 2016-12-24 18:05:24 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:24 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:25 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:25 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:25 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Router Class Initialized
ERROR - 2016-12-24 18:05:25 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:25 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:25 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:25 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:25 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Router Class Initialized
ERROR - 2016-12-24 18:05:25 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:25 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:25 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:25 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:25 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Router Class Initialized
ERROR - 2016-12-24 18:05:25 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:25 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:25 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:25 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Router Class Initialized
ERROR - 2016-12-24 18:05:25 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:25 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:25 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:25 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:25 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:25 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:25 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:25 --> Router Class Initialized
ERROR - 2016-12-24 18:05:25 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:25 --> Router Class Initialized
ERROR - 2016-12-24 18:05:25 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:25 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:25 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:26 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:26 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Router Class Initialized
ERROR - 2016-12-24 18:05:26 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:26 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:26 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:26 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:26 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Router Class Initialized
ERROR - 2016-12-24 18:05:26 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:26 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:26 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:26 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:26 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Router Class Initialized
ERROR - 2016-12-24 18:05:26 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:26 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:05:26 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Config Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:26 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:05:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:05:26 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:26 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:26 --> URI Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Router Class Initialized
DEBUG - 2016-12-24 18:05:26 --> Router Class Initialized
ERROR - 2016-12-24 18:05:26 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:26 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:05:26 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:12 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:12 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Output Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Security Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Input Class Initialized
DEBUG - 2016-12-24 18:07:12 --> XSS Filtering completed
DEBUG - 2016-12-24 18:07:12 --> XSS Filtering completed
DEBUG - 2016-12-24 18:07:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:07:12 --> Language Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Loader Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:07:12 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:07:12 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:07:12 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:07:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:07:12 --> Session Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:07:12 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Session routines successfully run
ERROR - 2016-12-24 18:07:12 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:07:12 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:07:12 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:07:12 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:07:12 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Table Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Model Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Model Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:07:12 --> Model Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Controller Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:07:12 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:07:12 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 18:07:15 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:07:15 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:07:15 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:07:15 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 18:07:15 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 18:07:15 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:07:15 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:07:15 --> Final output sent to browser
DEBUG - 2016-12-24 18:07:15 --> Total execution time: 2.9302
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
ERROR - 2016-12-24 18:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:15 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:15 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:15 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:16 --> Router Class Initialized
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:16 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:17 --> Router Class Initialized
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:17 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:18 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:18 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:18 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Utf8 Class Initialized
ERROR - 2016-12-24 18:07:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:18 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:18 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:18 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:18 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:18 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:07:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:18 --> URI Class Initialized
ERROR - 2016-12-24 18:07:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:18 --> Router Class Initialized
ERROR - 2016-12-24 18:07:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:18 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:18 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Router Class Initialized
ERROR - 2016-12-24 18:07:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:18 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:18 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:18 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Router Class Initialized
ERROR - 2016-12-24 18:07:18 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:18 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:18 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:18 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:18 --> URI Class Initialized
ERROR - 2016-12-24 18:07:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:18 --> Router Class Initialized
ERROR - 2016-12-24 18:07:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:18 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:18 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:18 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:18 --> Router Class Initialized
ERROR - 2016-12-24 18:07:18 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:19 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:19 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Router Class Initialized
ERROR - 2016-12-24 18:07:19 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:19 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:19 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Router Class Initialized
ERROR - 2016-12-24 18:07:19 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:19 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:19 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:19 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:19 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:19 --> URI Class Initialized
ERROR - 2016-12-24 18:07:19 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:19 --> Router Class Initialized
ERROR - 2016-12-24 18:07:19 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:19 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:19 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:19 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:19 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:19 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Router Class Initialized
ERROR - 2016-12-24 18:07:19 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:19 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:19 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:19 --> URI Class Initialized
ERROR - 2016-12-24 18:07:19 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:19 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:19 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:07:19 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:19 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Router Class Initialized
ERROR - 2016-12-24 18:07:19 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:19 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:19 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:19 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:19 --> Router Class Initialized
ERROR - 2016-12-24 18:07:19 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:07:19 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:20 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:20 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:20 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:20 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:20 --> Config Class Initialized
DEBUG - 2016-12-24 18:07:20 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:07:20 --> URI Class Initialized
DEBUG - 2016-12-24 18:07:20 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:07:20 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:07:20 --> Router Class Initialized
DEBUG - 2016-12-24 18:07:20 --> URI Class Initialized
ERROR - 2016-12-24 18:07:20 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:07:20 --> Router Class Initialized
ERROR - 2016-12-24 18:07:20 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:09:26 --> Config Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:09:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:09:26 --> URI Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Router Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Output Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Security Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Input Class Initialized
DEBUG - 2016-12-24 18:09:26 --> XSS Filtering completed
DEBUG - 2016-12-24 18:09:26 --> XSS Filtering completed
DEBUG - 2016-12-24 18:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:09:26 --> Language Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Loader Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:09:26 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:09:26 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:09:26 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:09:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:09:26 --> Session Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:09:26 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Session routines successfully run
ERROR - 2016-12-24 18:09:26 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:09:26 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:09:26 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:09:26 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:09:26 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Table Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Model Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Model Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:09:26 --> Model Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Controller Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:09:26 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:09:26 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 18:09:26 --> Could not find the language line "settings"
DEBUG - 2016-12-24 18:09:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:09:26 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:09:26 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:09:26 --> File loaded: application/views/admin/settings.php
DEBUG - 2016-12-24 18:09:26 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:09:26 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:09:26 --> Final output sent to browser
DEBUG - 2016-12-24 18:09:26 --> Total execution time: 0.2180
DEBUG - 2016-12-24 18:10:07 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:07 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Output Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Security Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Input Class Initialized
DEBUG - 2016-12-24 18:10:07 --> XSS Filtering completed
DEBUG - 2016-12-24 18:10:07 --> XSS Filtering completed
DEBUG - 2016-12-24 18:10:07 --> XSS Filtering completed
DEBUG - 2016-12-24 18:10:07 --> XSS Filtering completed
DEBUG - 2016-12-24 18:10:07 --> XSS Filtering completed
DEBUG - 2016-12-24 18:10:07 --> XSS Filtering completed
DEBUG - 2016-12-24 18:10:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:10:07 --> Language Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Loader Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:10:07 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:10:07 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:10:07 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:10:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:10:07 --> Session Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:10:07 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Session routines successfully run
ERROR - 2016-12-24 18:10:07 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:10:07 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:10:07 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:10:07 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:10:07 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Table Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Model Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Model Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:10:07 --> Model Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Controller Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:10:07 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:10:07 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 18:10:07 --> Could not find the language line "settings_updated"
DEBUG - 2016-12-24 18:10:09 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:10:10 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:10:10 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:10:10 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 18:10:10 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 18:10:10 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:10:10 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:10:10 --> Final output sent to browser
DEBUG - 2016-12-24 18:10:10 --> Total execution time: 2.9772
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:10 --> Router Class Initialized
ERROR - 2016-12-24 18:10:10 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Utf8 Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:11 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Router Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
ERROR - 2016-12-24 18:10:11 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:11 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:12 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Utf8 Class Initialized
ERROR - 2016-12-24 18:10:12 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:12 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:12 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:12 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:12 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:12 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:10:12 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:12 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:12 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Router Class Initialized
ERROR - 2016-12-24 18:10:12 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:12 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:12 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:12 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:12 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:12 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:12 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:12 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:12 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:12 --> Router Class Initialized
ERROR - 2016-12-24 18:10:12 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:12 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:12 --> URI Class Initialized
ERROR - 2016-12-24 18:10:12 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:12 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:12 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:12 --> URI Class Initialized
ERROR - 2016-12-24 18:10:12 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:12 --> Router Class Initialized
ERROR - 2016-12-24 18:10:12 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:12 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Config Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:12 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:10:12 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Utf8 Class Initialized
ERROR - 2016-12-24 18:10:12 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:12 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:10:12 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:12 --> URI Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Router Class Initialized
DEBUG - 2016-12-24 18:10:12 --> Router Class Initialized
ERROR - 2016-12-24 18:10:12 --> 404 Page Not Found --> application
ERROR - 2016-12-24 18:10:12 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:13:32 --> Config Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:13:32 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:13:32 --> URI Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Router Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Output Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Security Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Input Class Initialized
DEBUG - 2016-12-24 18:13:32 --> XSS Filtering completed
DEBUG - 2016-12-24 18:13:32 --> XSS Filtering completed
DEBUG - 2016-12-24 18:13:32 --> XSS Filtering completed
DEBUG - 2016-12-24 18:13:32 --> XSS Filtering completed
DEBUG - 2016-12-24 18:13:32 --> XSS Filtering completed
DEBUG - 2016-12-24 18:13:32 --> XSS Filtering completed
DEBUG - 2016-12-24 18:13:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:13:32 --> Language Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Loader Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:13:32 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:13:32 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:13:32 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:13:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:13:32 --> Session Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:13:32 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Session routines successfully run
ERROR - 2016-12-24 18:13:32 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:13:32 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:13:32 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:13:32 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:13:32 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Table Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Model Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Model Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:13:32 --> Model Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Controller Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:13:32 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:13:32 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 18:13:32 --> Could not find the language line "settings_updated"
DEBUG - 2016-12-24 18:13:35 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:13:35 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:13:35 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:13:35 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 18:13:35 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 18:13:35 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:13:35 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:13:35 --> Final output sent to browser
DEBUG - 2016-12-24 18:13:35 --> Total execution time: 3.1272
DEBUG - 2016-12-24 18:13:59 --> Config Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:13:59 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:13:59 --> URI Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Router Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Output Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Security Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Input Class Initialized
DEBUG - 2016-12-24 18:13:59 --> XSS Filtering completed
DEBUG - 2016-12-24 18:13:59 --> XSS Filtering completed
DEBUG - 2016-12-24 18:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:13:59 --> Language Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Loader Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:13:59 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:13:59 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:13:59 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:13:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:13:59 --> Session Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:13:59 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Session routines successfully run
ERROR - 2016-12-24 18:13:59 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:13:59 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:13:59 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:13:59 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:13:59 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Table Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Model Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Model Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:13:59 --> Model Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Controller Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:13:59 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:13:59 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 18:13:59 --> Could not find the language line "settings"
DEBUG - 2016-12-24 18:13:59 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:13:59 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:13:59 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:13:59 --> File loaded: application/views/admin/settings.php
DEBUG - 2016-12-24 18:13:59 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:13:59 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:13:59 --> Final output sent to browser
DEBUG - 2016-12-24 18:13:59 --> Total execution time: 0.2260
DEBUG - 2016-12-24 18:14:12 --> Config Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:14:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:14:12 --> URI Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Router Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Output Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Security Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Input Class Initialized
DEBUG - 2016-12-24 18:14:12 --> XSS Filtering completed
DEBUG - 2016-12-24 18:14:12 --> XSS Filtering completed
DEBUG - 2016-12-24 18:14:12 --> XSS Filtering completed
DEBUG - 2016-12-24 18:14:12 --> XSS Filtering completed
DEBUG - 2016-12-24 18:14:12 --> XSS Filtering completed
DEBUG - 2016-12-24 18:14:12 --> XSS Filtering completed
DEBUG - 2016-12-24 18:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:14:12 --> Language Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Loader Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:14:12 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:14:12 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:14:12 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:14:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:14:12 --> Session Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:14:12 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Session routines successfully run
ERROR - 2016-12-24 18:14:12 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:14:12 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:14:12 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:14:12 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:14:12 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Table Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Model Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Model Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:14:12 --> Model Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Controller Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:14:12 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:14:12 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 18:14:12 --> Could not find the language line "settings_updated"
DEBUG - 2016-12-24 18:14:15 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:14:15 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:14:15 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:14:15 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 18:14:15 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 18:14:15 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:14:15 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:14:15 --> Final output sent to browser
DEBUG - 2016-12-24 18:14:15 --> Total execution time: 2.8952
DEBUG - 2016-12-24 18:14:40 --> Config Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:14:40 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:14:40 --> URI Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Router Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Output Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Security Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Input Class Initialized
DEBUG - 2016-12-24 18:14:40 --> XSS Filtering completed
DEBUG - 2016-12-24 18:14:40 --> XSS Filtering completed
DEBUG - 2016-12-24 18:14:40 --> XSS Filtering completed
DEBUG - 2016-12-24 18:14:40 --> XSS Filtering completed
DEBUG - 2016-12-24 18:14:40 --> XSS Filtering completed
DEBUG - 2016-12-24 18:14:40 --> XSS Filtering completed
DEBUG - 2016-12-24 18:14:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:14:40 --> Language Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Loader Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:14:40 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:14:40 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:14:40 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:14:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:14:40 --> Session Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:14:40 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Session routines successfully run
ERROR - 2016-12-24 18:14:40 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:14:40 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:14:40 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:14:40 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:14:40 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Table Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Model Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Model Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:14:40 --> Model Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Controller Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:14:40 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:14:40 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 18:14:40 --> Could not find the language line "settings_updated"
DEBUG - 2016-12-24 18:14:43 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:14:43 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:14:43 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:14:43 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 18:14:43 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 18:14:43 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:14:43 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:14:43 --> Final output sent to browser
DEBUG - 2016-12-24 18:14:43 --> Total execution time: 3.0842
DEBUG - 2016-12-24 18:14:43 --> Config Class Initialized
DEBUG - 2016-12-24 18:14:43 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:14:43 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:14:43 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:14:43 --> URI Class Initialized
DEBUG - 2016-12-24 18:14:43 --> Router Class Initialized
ERROR - 2016-12-24 18:14:43 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:14:43 --> Config Class Initialized
DEBUG - 2016-12-24 18:14:43 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:14:43 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:14:43 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:14:43 --> URI Class Initialized
DEBUG - 2016-12-24 18:14:43 --> Router Class Initialized
ERROR - 2016-12-24 18:14:43 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:16:53 --> Config Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:16:53 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:16:53 --> URI Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Router Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Output Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Security Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Input Class Initialized
DEBUG - 2016-12-24 18:16:53 --> XSS Filtering completed
DEBUG - 2016-12-24 18:16:53 --> XSS Filtering completed
DEBUG - 2016-12-24 18:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:16:53 --> Language Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Loader Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:16:53 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:16:53 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:16:53 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:16:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:16:53 --> Session Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:16:53 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Session routines successfully run
ERROR - 2016-12-24 18:16:53 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:16:53 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:16:53 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:16:53 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:16:53 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Table Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Model Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Model Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:16:53 --> Model Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Controller Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:16:53 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:16:53 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 18:16:53 --> Could not find the language line "settings"
DEBUG - 2016-12-24 18:16:53 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:16:53 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:16:53 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:16:53 --> File loaded: application/views/admin/settings.php
DEBUG - 2016-12-24 18:16:53 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:16:53 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:16:53 --> Final output sent to browser
DEBUG - 2016-12-24 18:16:53 --> Total execution time: 0.2200
DEBUG - 2016-12-24 18:16:59 --> Config Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:16:59 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:16:59 --> URI Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Router Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Output Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Security Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Input Class Initialized
DEBUG - 2016-12-24 18:16:59 --> XSS Filtering completed
DEBUG - 2016-12-24 18:16:59 --> XSS Filtering completed
DEBUG - 2016-12-24 18:16:59 --> XSS Filtering completed
DEBUG - 2016-12-24 18:16:59 --> XSS Filtering completed
DEBUG - 2016-12-24 18:16:59 --> XSS Filtering completed
DEBUG - 2016-12-24 18:16:59 --> XSS Filtering completed
DEBUG - 2016-12-24 18:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:16:59 --> Language Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Loader Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:16:59 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:16:59 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:16:59 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:16:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:16:59 --> Session Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:16:59 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Session routines successfully run
ERROR - 2016-12-24 18:16:59 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:16:59 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:16:59 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:16:59 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:16:59 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Table Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Model Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Model Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:16:59 --> Model Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Controller Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:16:59 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:16:59 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 18:16:59 --> Could not find the language line "settings_updated"
DEBUG - 2016-12-24 18:17:02 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:17:02 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:17:02 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:17:02 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 18:17:02 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 18:17:02 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:17:02 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:17:02 --> Final output sent to browser
DEBUG - 2016-12-24 18:17:02 --> Total execution time: 3.1322
DEBUG - 2016-12-24 18:17:02 --> Config Class Initialized
DEBUG - 2016-12-24 18:17:02 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:17:02 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:17:02 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:17:02 --> Config Class Initialized
DEBUG - 2016-12-24 18:17:02 --> URI Class Initialized
DEBUG - 2016-12-24 18:17:02 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:17:02 --> Router Class Initialized
DEBUG - 2016-12-24 18:17:02 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:17:02 --> UTF-8 Support Enabled
ERROR - 2016-12-24 18:17:02 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:17:02 --> URI Class Initialized
DEBUG - 2016-12-24 18:17:02 --> Router Class Initialized
ERROR - 2016-12-24 18:17:02 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:17:07 --> Config Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:17:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:17:07 --> URI Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Router Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Output Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Security Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Input Class Initialized
DEBUG - 2016-12-24 18:17:07 --> XSS Filtering completed
DEBUG - 2016-12-24 18:17:07 --> XSS Filtering completed
DEBUG - 2016-12-24 18:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:17:07 --> Language Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Loader Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:17:07 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:17:07 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:17:07 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:17:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:17:07 --> Session Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:17:07 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Session routines successfully run
ERROR - 2016-12-24 18:17:07 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:17:07 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:17:07 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:17:07 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:17:07 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Table Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Model Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Model Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:17:07 --> Model Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Controller Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:17:07 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:17:07 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 18:17:07 --> Could not find the language line "personal"
DEBUG - 2016-12-24 18:17:07 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:17:07 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:17:07 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:17:07 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-12-24 18:17:07 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:17:07 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:17:07 --> Final output sent to browser
DEBUG - 2016-12-24 18:17:07 --> Total execution time: 0.3330
DEBUG - 2016-12-24 18:17:10 --> Config Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:17:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:17:10 --> URI Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Router Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Output Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Security Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Input Class Initialized
DEBUG - 2016-12-24 18:17:10 --> XSS Filtering completed
DEBUG - 2016-12-24 18:17:10 --> XSS Filtering completed
DEBUG - 2016-12-24 18:17:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:17:10 --> Language Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Loader Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:17:10 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:17:10 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:17:10 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:17:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:17:10 --> Session Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:17:10 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Session routines successfully run
ERROR - 2016-12-24 18:17:10 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:17:10 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:17:10 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:17:10 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:17:10 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Table Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Model Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Model Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:17:10 --> Model Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Controller Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:17:10 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:17:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 18:17:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:17:13 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:17:13 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:17:13 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 18:17:13 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 18:17:13 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:17:13 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:17:13 --> Final output sent to browser
DEBUG - 2016-12-24 18:17:13 --> Total execution time: 2.8702
DEBUG - 2016-12-24 18:19:24 --> Config Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:19:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:19:24 --> URI Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Router Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Output Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Security Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Input Class Initialized
DEBUG - 2016-12-24 18:19:24 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:24 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:19:24 --> Language Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Loader Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:19:24 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:19:24 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:19:24 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:19:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:19:24 --> Session Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:19:24 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Session routines successfully run
ERROR - 2016-12-24 18:19:24 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:19:24 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:19:24 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:19:24 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:19:24 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Table Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Model Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Model Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:19:24 --> Model Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Controller Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:19:24 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:19:24 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 18:19:24 --> Could not find the language line "settings"
DEBUG - 2016-12-24 18:19:24 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:19:24 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:19:24 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:19:24 --> File loaded: application/views/admin/settings.php
DEBUG - 2016-12-24 18:19:24 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:19:24 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:19:24 --> Final output sent to browser
DEBUG - 2016-12-24 18:19:24 --> Total execution time: 0.1960
DEBUG - 2016-12-24 18:19:30 --> Config Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:19:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:19:30 --> URI Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Router Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Output Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Security Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Input Class Initialized
DEBUG - 2016-12-24 18:19:30 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:30 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:30 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:30 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:30 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:30 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:19:30 --> Language Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Loader Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:19:30 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:19:30 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:19:30 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:19:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:19:30 --> Session Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:19:30 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Session routines successfully run
ERROR - 2016-12-24 18:19:30 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:19:30 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:19:30 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:19:30 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:19:30 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Table Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Model Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Model Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:19:30 --> Model Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Controller Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:19:30 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:19:30 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 18:19:30 --> Could not find the language line "settings_updated"
DEBUG - 2016-12-24 18:19:31 --> Config Class Initialized
DEBUG - 2016-12-24 18:19:31 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:19:31 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:19:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:19:31 --> URI Class Initialized
DEBUG - 2016-12-24 18:19:31 --> Router Class Initialized
ERROR - 2016-12-24 18:19:31 --> 404 Page Not Found --> administrator
DEBUG - 2016-12-24 18:19:58 --> Config Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:19:58 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:19:58 --> URI Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Router Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Output Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Security Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Input Class Initialized
DEBUG - 2016-12-24 18:19:58 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:58 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:58 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:58 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:58 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:58 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:19:58 --> Language Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Loader Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:19:58 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:19:58 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:19:58 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:19:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:19:58 --> Session Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:19:58 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Session routines successfully run
ERROR - 2016-12-24 18:19:58 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:19:58 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:19:58 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:19:58 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:19:58 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Table Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Model Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Model Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:19:58 --> Model Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Controller Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:19:58 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 18:19:58 --> Could not find the language line "settings_updated"
DEBUG - 2016-12-24 18:19:58 --> Config Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:19:58 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:19:58 --> URI Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Router Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Output Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Security Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Input Class Initialized
DEBUG - 2016-12-24 18:19:58 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:58 --> XSS Filtering completed
DEBUG - 2016-12-24 18:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 18:19:58 --> Language Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Loader Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Helper loaded: url_helper
DEBUG - 2016-12-24 18:19:58 --> Helper loaded: form_helper
DEBUG - 2016-12-24 18:19:58 --> Helper loaded: func_helper
DEBUG - 2016-12-24 18:19:58 --> Database Driver Class Initialized
ERROR - 2016-12-24 18:19:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 18:19:58 --> Session Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Helper loaded: string_helper
DEBUG - 2016-12-24 18:19:58 --> Encrypt Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Session routines successfully run
ERROR - 2016-12-24 18:19:58 --> Could not find the language line "first_link"
ERROR - 2016-12-24 18:19:58 --> Could not find the language line "last_link"
ERROR - 2016-12-24 18:19:58 --> Could not find the language line "next_link"
ERROR - 2016-12-24 18:19:58 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 18:19:58 --> Pagination Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Table Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Model Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Model Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Helper loaded: file_helper
DEBUG - 2016-12-24 18:19:58 --> Model Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Controller Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Form Validation Class Initialized
DEBUG - 2016-12-24 18:19:58 --> Helper loaded: language_helper
DEBUG - 2016-12-24 18:19:58 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 18:20:01 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-24 18:20:01 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-24 18:20:01 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-24 18:20:01 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-24 18:20:01 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-24 18:20:01 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-24 18:20:01 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-24 18:20:01 --> Final output sent to browser
DEBUG - 2016-12-24 18:20:01 --> Total execution time: 2.8232
DEBUG - 2016-12-24 18:20:01 --> Config Class Initialized
DEBUG - 2016-12-24 18:20:01 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:20:01 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:20:01 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:20:01 --> URI Class Initialized
DEBUG - 2016-12-24 18:20:01 --> Router Class Initialized
ERROR - 2016-12-24 18:20:01 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 18:20:01 --> Config Class Initialized
DEBUG - 2016-12-24 18:20:01 --> Hooks Class Initialized
DEBUG - 2016-12-24 18:20:01 --> Utf8 Class Initialized
DEBUG - 2016-12-24 18:20:01 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 18:20:01 --> URI Class Initialized
DEBUG - 2016-12-24 18:20:01 --> Router Class Initialized
ERROR - 2016-12-24 18:20:01 --> 404 Page Not Found --> application
DEBUG - 2016-12-24 20:55:59 --> Config Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Hooks Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Utf8 Class Initialized
DEBUG - 2016-12-24 20:55:59 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 20:55:59 --> URI Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Router Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Output Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Security Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Input Class Initialized
DEBUG - 2016-12-24 20:55:59 --> XSS Filtering completed
DEBUG - 2016-12-24 20:55:59 --> XSS Filtering completed
DEBUG - 2016-12-24 20:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 20:55:59 --> Language Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Loader Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Helper loaded: url_helper
DEBUG - 2016-12-24 20:55:59 --> Helper loaded: form_helper
DEBUG - 2016-12-24 20:55:59 --> Helper loaded: func_helper
DEBUG - 2016-12-24 20:55:59 --> Database Driver Class Initialized
ERROR - 2016-12-24 20:55:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 20:55:59 --> Session Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Helper loaded: string_helper
DEBUG - 2016-12-24 20:55:59 --> Encrypt Class Initialized
DEBUG - 2016-12-24 20:55:59 --> A session cookie was not found.
DEBUG - 2016-12-24 20:55:59 --> Session routines successfully run
ERROR - 2016-12-24 20:55:59 --> Could not find the language line "first_link"
ERROR - 2016-12-24 20:55:59 --> Could not find the language line "last_link"
ERROR - 2016-12-24 20:55:59 --> Could not find the language line "next_link"
ERROR - 2016-12-24 20:55:59 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 20:55:59 --> Pagination Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Table Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Model Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Model Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Helper loaded: file_helper
DEBUG - 2016-12-24 20:55:59 --> Model Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Controller Class Initialized
DEBUG - 2016-12-24 20:55:59 --> Helper loaded: language_helper
DEBUG - 2016-12-24 20:55:59 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-24 20:56:00 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-24 20:56:00 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-24 20:56:00 --> File loaded: application/views/me/myadmin_upload.php
DEBUG - 2016-12-24 20:56:00 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-24 20:56:00 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-24 20:56:00 --> Final output sent to browser
DEBUG - 2016-12-24 20:56:00 --> Total execution time: 0.1700
DEBUG - 2016-12-24 20:56:00 --> Config Class Initialized
DEBUG - 2016-12-24 20:56:00 --> Hooks Class Initialized
DEBUG - 2016-12-24 20:56:00 --> Utf8 Class Initialized
DEBUG - 2016-12-24 20:56:00 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 20:56:00 --> URI Class Initialized
DEBUG - 2016-12-24 20:56:00 --> Router Class Initialized
ERROR - 2016-12-24 20:56:00 --> 404 Page Not Found --> js
DEBUG - 2016-12-24 20:56:56 --> Config Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Hooks Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Utf8 Class Initialized
DEBUG - 2016-12-24 20:56:56 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 20:56:56 --> URI Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Router Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Output Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Security Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Input Class Initialized
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> XSS Filtering completed
DEBUG - 2016-12-24 20:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 20:56:56 --> Language Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Loader Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Helper loaded: url_helper
DEBUG - 2016-12-24 20:56:56 --> Helper loaded: form_helper
DEBUG - 2016-12-24 20:56:56 --> Helper loaded: func_helper
DEBUG - 2016-12-24 20:56:56 --> Database Driver Class Initialized
ERROR - 2016-12-24 20:56:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 20:56:56 --> Session Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Helper loaded: string_helper
DEBUG - 2016-12-24 20:56:56 --> Encrypt Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Session routines successfully run
ERROR - 2016-12-24 20:56:56 --> Could not find the language line "first_link"
ERROR - 2016-12-24 20:56:56 --> Could not find the language line "last_link"
ERROR - 2016-12-24 20:56:56 --> Could not find the language line "next_link"
ERROR - 2016-12-24 20:56:56 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 20:56:56 --> Pagination Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Table Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Model Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Model Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Helper loaded: file_helper
DEBUG - 2016-12-24 20:56:56 --> Model Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Controller Class Initialized
DEBUG - 2016-12-24 20:56:56 --> Helper loaded: language_helper
DEBUG - 2016-12-24 20:56:56 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 20:56:56 --> Model Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Config Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Hooks Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Utf8 Class Initialized
DEBUG - 2016-12-24 20:57:08 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 20:57:08 --> URI Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Router Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Output Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Security Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Input Class Initialized
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> XSS Filtering completed
DEBUG - 2016-12-24 20:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 20:57:08 --> Language Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Loader Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Helper loaded: url_helper
DEBUG - 2016-12-24 20:57:08 --> Helper loaded: form_helper
DEBUG - 2016-12-24 20:57:08 --> Helper loaded: func_helper
DEBUG - 2016-12-24 20:57:08 --> Database Driver Class Initialized
ERROR - 2016-12-24 20:57:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 20:57:08 --> Session Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Helper loaded: string_helper
DEBUG - 2016-12-24 20:57:08 --> Encrypt Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Session routines successfully run
ERROR - 2016-12-24 20:57:08 --> Could not find the language line "first_link"
ERROR - 2016-12-24 20:57:08 --> Could not find the language line "last_link"
ERROR - 2016-12-24 20:57:08 --> Could not find the language line "next_link"
ERROR - 2016-12-24 20:57:08 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 20:57:08 --> Pagination Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Table Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Model Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Model Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Helper loaded: file_helper
DEBUG - 2016-12-24 20:57:08 --> Model Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Controller Class Initialized
DEBUG - 2016-12-24 20:57:08 --> Helper loaded: language_helper
DEBUG - 2016-12-24 20:57:08 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 20:57:08 --> Model Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Config Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Hooks Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Utf8 Class Initialized
DEBUG - 2016-12-24 20:59:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 20:59:22 --> URI Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Router Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Output Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Security Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Input Class Initialized
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> XSS Filtering completed
DEBUG - 2016-12-24 20:59:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 20:59:22 --> Language Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Loader Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Helper loaded: url_helper
DEBUG - 2016-12-24 20:59:22 --> Helper loaded: form_helper
DEBUG - 2016-12-24 20:59:22 --> Helper loaded: func_helper
DEBUG - 2016-12-24 20:59:22 --> Database Driver Class Initialized
ERROR - 2016-12-24 20:59:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 20:59:22 --> Session Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Helper loaded: string_helper
DEBUG - 2016-12-24 20:59:22 --> Encrypt Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Session routines successfully run
ERROR - 2016-12-24 20:59:22 --> Could not find the language line "first_link"
ERROR - 2016-12-24 20:59:22 --> Could not find the language line "last_link"
ERROR - 2016-12-24 20:59:22 --> Could not find the language line "next_link"
ERROR - 2016-12-24 20:59:22 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 20:59:22 --> Pagination Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Table Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Model Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Model Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Helper loaded: file_helper
DEBUG - 2016-12-24 20:59:22 --> Model Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Controller Class Initialized
DEBUG - 2016-12-24 20:59:22 --> Helper loaded: language_helper
DEBUG - 2016-12-24 20:59:22 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 20:59:22 --> Model Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Config Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Hooks Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Utf8 Class Initialized
DEBUG - 2016-12-24 21:01:51 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 21:01:51 --> URI Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Router Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Output Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Security Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Input Class Initialized
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> XSS Filtering completed
DEBUG - 2016-12-24 21:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 21:01:51 --> Language Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Loader Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Helper loaded: url_helper
DEBUG - 2016-12-24 21:01:51 --> Helper loaded: form_helper
DEBUG - 2016-12-24 21:01:51 --> Helper loaded: func_helper
DEBUG - 2016-12-24 21:01:51 --> Database Driver Class Initialized
ERROR - 2016-12-24 21:01:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 21:01:51 --> Session Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Helper loaded: string_helper
DEBUG - 2016-12-24 21:01:51 --> Encrypt Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Session routines successfully run
ERROR - 2016-12-24 21:01:51 --> Could not find the language line "first_link"
ERROR - 2016-12-24 21:01:51 --> Could not find the language line "last_link"
ERROR - 2016-12-24 21:01:51 --> Could not find the language line "next_link"
ERROR - 2016-12-24 21:01:51 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 21:01:51 --> Pagination Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Table Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Model Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Model Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Helper loaded: file_helper
DEBUG - 2016-12-24 21:01:51 --> Model Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Controller Class Initialized
DEBUG - 2016-12-24 21:01:51 --> Helper loaded: language_helper
DEBUG - 2016-12-24 21:01:51 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 21:01:51 --> Model Class Initialized
ERROR - 2016-12-24 21:01:51 --> Severity: Notice  --> Undefined property: My_admin::$my_model C:\xampp\htdocs\www\alumni\application\controllers\my_admin.php 52
DEBUG - 2016-12-24 21:02:29 --> Config Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Hooks Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Utf8 Class Initialized
DEBUG - 2016-12-24 21:02:29 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 21:02:29 --> URI Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Router Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Output Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Security Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Input Class Initialized
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> XSS Filtering completed
DEBUG - 2016-12-24 21:02:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 21:02:29 --> Language Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Loader Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Helper loaded: url_helper
DEBUG - 2016-12-24 21:02:29 --> Helper loaded: form_helper
DEBUG - 2016-12-24 21:02:29 --> Helper loaded: func_helper
DEBUG - 2016-12-24 21:02:29 --> Database Driver Class Initialized
ERROR - 2016-12-24 21:02:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 21:02:29 --> Session Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Helper loaded: string_helper
DEBUG - 2016-12-24 21:02:29 --> Encrypt Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Session routines successfully run
ERROR - 2016-12-24 21:02:29 --> Could not find the language line "first_link"
ERROR - 2016-12-24 21:02:29 --> Could not find the language line "last_link"
ERROR - 2016-12-24 21:02:29 --> Could not find the language line "next_link"
ERROR - 2016-12-24 21:02:29 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 21:02:29 --> Pagination Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Table Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Model Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Model Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Helper loaded: file_helper
DEBUG - 2016-12-24 21:02:29 --> Model Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Controller Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Helper loaded: language_helper
DEBUG - 2016-12-24 21:02:29 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 21:02:29 --> Model Class Initialized
DEBUG - 2016-12-24 21:02:29 --> Upload Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Config Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Hooks Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Utf8 Class Initialized
DEBUG - 2016-12-24 21:04:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 21:04:07 --> URI Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Router Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Output Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Security Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Input Class Initialized
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 21:04:07 --> Language Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Loader Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Helper loaded: url_helper
DEBUG - 2016-12-24 21:04:07 --> Helper loaded: form_helper
DEBUG - 2016-12-24 21:04:07 --> Helper loaded: func_helper
DEBUG - 2016-12-24 21:04:07 --> Database Driver Class Initialized
ERROR - 2016-12-24 21:04:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 21:04:07 --> Session Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Helper loaded: string_helper
DEBUG - 2016-12-24 21:04:07 --> Encrypt Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Session routines successfully run
ERROR - 2016-12-24 21:04:07 --> Could not find the language line "first_link"
ERROR - 2016-12-24 21:04:07 --> Could not find the language line "last_link"
ERROR - 2016-12-24 21:04:07 --> Could not find the language line "next_link"
ERROR - 2016-12-24 21:04:07 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 21:04:07 --> Pagination Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Table Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Model Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Model Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Helper loaded: file_helper
DEBUG - 2016-12-24 21:04:07 --> Model Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Controller Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Helper loaded: language_helper
DEBUG - 2016-12-24 21:04:07 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 21:04:07 --> Model Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Upload Class Initialized
DEBUG - 2016-12-24 21:04:07 --> Language file loaded: language/arabic/upload_lang.php
ERROR - 2016-12-24 21:04:07 --> يبدو أن مسار رفع الملفات غير صحيح.
ERROR - 2016-12-24 21:04:08 --> Severity: Warning  --> file_get_contents(application/uploads/): failed to open stream: No such file or directory C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Shared\OLERead.php 85
ERROR - 2016-12-24 21:04:08 --> Severity: Warning  --> fopen(application/uploads/): failed to open stream: No such file or directory C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Reader\Abstract.php 200
DEBUG - 2016-12-24 21:04:35 --> Config Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Hooks Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Utf8 Class Initialized
DEBUG - 2016-12-24 21:04:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 21:04:35 --> URI Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Router Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Output Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Security Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Input Class Initialized
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> XSS Filtering completed
DEBUG - 2016-12-24 21:04:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 21:04:35 --> Language Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Loader Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Helper loaded: url_helper
DEBUG - 2016-12-24 21:04:35 --> Helper loaded: form_helper
DEBUG - 2016-12-24 21:04:35 --> Helper loaded: func_helper
DEBUG - 2016-12-24 21:04:35 --> Database Driver Class Initialized
ERROR - 2016-12-24 21:04:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 21:04:35 --> Session Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Helper loaded: string_helper
DEBUG - 2016-12-24 21:04:35 --> Encrypt Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Session routines successfully run
ERROR - 2016-12-24 21:04:35 --> Could not find the language line "first_link"
ERROR - 2016-12-24 21:04:35 --> Could not find the language line "last_link"
ERROR - 2016-12-24 21:04:35 --> Could not find the language line "next_link"
ERROR - 2016-12-24 21:04:35 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 21:04:35 --> Pagination Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Table Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Model Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Model Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Helper loaded: file_helper
DEBUG - 2016-12-24 21:04:35 --> Model Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Controller Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Helper loaded: language_helper
DEBUG - 2016-12-24 21:04:35 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 21:04:35 --> Model Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Upload Class Initialized
DEBUG - 2016-12-24 21:04:35 --> Language file loaded: language/arabic/upload_lang.php
ERROR - 2016-12-24 21:04:35 --> يبدو أن مسار رفع الملفات غير صحيح.
ERROR - 2016-12-24 21:04:35 --> Severity: Warning  --> file_get_contents(application/uploads/): failed to open stream: No such file or directory C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Shared\OLERead.php 85
ERROR - 2016-12-24 21:04:35 --> Severity: Warning  --> fopen(application/uploads/): failed to open stream: No such file or directory C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Reader\Abstract.php 200
DEBUG - 2016-12-24 21:05:14 --> Config Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Hooks Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Utf8 Class Initialized
DEBUG - 2016-12-24 21:05:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 21:05:14 --> URI Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Router Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Output Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Security Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Input Class Initialized
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 21:05:14 --> Language Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Loader Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Helper loaded: url_helper
DEBUG - 2016-12-24 21:05:14 --> Helper loaded: form_helper
DEBUG - 2016-12-24 21:05:14 --> Helper loaded: func_helper
DEBUG - 2016-12-24 21:05:14 --> Database Driver Class Initialized
ERROR - 2016-12-24 21:05:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 21:05:14 --> Session Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Helper loaded: string_helper
DEBUG - 2016-12-24 21:05:14 --> Encrypt Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Session routines successfully run
ERROR - 2016-12-24 21:05:14 --> Could not find the language line "first_link"
ERROR - 2016-12-24 21:05:14 --> Could not find the language line "last_link"
ERROR - 2016-12-24 21:05:14 --> Could not find the language line "next_link"
ERROR - 2016-12-24 21:05:14 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 21:05:14 --> Pagination Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Table Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Model Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Model Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Helper loaded: file_helper
DEBUG - 2016-12-24 21:05:14 --> Model Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Controller Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Helper loaded: language_helper
DEBUG - 2016-12-24 21:05:14 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 21:05:14 --> Model Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Upload Class Initialized
DEBUG - 2016-12-24 21:05:14 --> Language file loaded: language/arabic/upload_lang.php
ERROR - 2016-12-24 21:05:14 --> يبدو أن مسار رفع الملفات غير صحيح.
ERROR - 2016-12-24 21:05:14 --> Severity: Warning  --> file_get_contents(application/uploads/): failed to open stream: No such file or directory C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Shared\OLERead.php 85
ERROR - 2016-12-24 21:05:14 --> Severity: Warning  --> fopen(application/uploads/): failed to open stream: No such file or directory C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Reader\Abstract.php 200
DEBUG - 2016-12-24 21:05:47 --> Config Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Hooks Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Utf8 Class Initialized
DEBUG - 2016-12-24 21:05:47 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 21:05:47 --> URI Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Router Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Output Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Security Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Input Class Initialized
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> XSS Filtering completed
DEBUG - 2016-12-24 21:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 21:05:47 --> Language Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Loader Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Helper loaded: url_helper
DEBUG - 2016-12-24 21:05:47 --> Helper loaded: form_helper
DEBUG - 2016-12-24 21:05:47 --> Helper loaded: func_helper
DEBUG - 2016-12-24 21:05:47 --> Database Driver Class Initialized
ERROR - 2016-12-24 21:05:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 21:05:47 --> Session Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Helper loaded: string_helper
DEBUG - 2016-12-24 21:05:47 --> Encrypt Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Session routines successfully run
ERROR - 2016-12-24 21:05:47 --> Could not find the language line "first_link"
ERROR - 2016-12-24 21:05:47 --> Could not find the language line "last_link"
ERROR - 2016-12-24 21:05:47 --> Could not find the language line "next_link"
ERROR - 2016-12-24 21:05:47 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 21:05:47 --> Pagination Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Table Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Model Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Model Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Helper loaded: file_helper
DEBUG - 2016-12-24 21:05:47 --> Model Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Controller Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Helper loaded: language_helper
DEBUG - 2016-12-24 21:05:47 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 21:05:47 --> Model Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Upload Class Initialized
DEBUG - 2016-12-24 21:05:47 --> Language file loaded: language/arabic/upload_lang.php
ERROR - 2016-12-24 21:05:47 --> يبدو أن مسار رفع الملفات غير صحيح.
ERROR - 2016-12-24 21:05:48 --> Severity: Warning  --> file_get_contents(application/uploads/): failed to open stream: No such file or directory C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Shared\OLERead.php 85
ERROR - 2016-12-24 21:05:48 --> Severity: Warning  --> fopen(application/uploads/): failed to open stream: No such file or directory C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Reader\Abstract.php 200
DEBUG - 2016-12-24 21:15:25 --> Config Class Initialized
DEBUG - 2016-12-24 21:15:25 --> Hooks Class Initialized
DEBUG - 2016-12-24 21:15:25 --> Utf8 Class Initialized
DEBUG - 2016-12-24 21:15:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 21:15:25 --> URI Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Router Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Output Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Security Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Input Class Initialized
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> XSS Filtering completed
DEBUG - 2016-12-24 21:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 21:15:26 --> Language Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Loader Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Helper loaded: url_helper
DEBUG - 2016-12-24 21:15:26 --> Helper loaded: form_helper
DEBUG - 2016-12-24 21:15:26 --> Helper loaded: func_helper
DEBUG - 2016-12-24 21:15:26 --> Database Driver Class Initialized
ERROR - 2016-12-24 21:15:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 21:15:26 --> Session Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Helper loaded: string_helper
DEBUG - 2016-12-24 21:15:26 --> Encrypt Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Session routines successfully run
ERROR - 2016-12-24 21:15:26 --> Could not find the language line "first_link"
ERROR - 2016-12-24 21:15:26 --> Could not find the language line "last_link"
ERROR - 2016-12-24 21:15:26 --> Could not find the language line "next_link"
ERROR - 2016-12-24 21:15:26 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 21:15:26 --> Pagination Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Table Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Model Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Model Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Helper loaded: file_helper
DEBUG - 2016-12-24 21:15:26 --> Model Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Controller Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Helper loaded: language_helper
DEBUG - 2016-12-24 21:15:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 21:15:26 --> Model Class Initialized
DEBUG - 2016-12-24 21:15:26 --> Upload Class Initialized
ERROR - 2016-12-24 21:16:10 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-24 21:16:10 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-24 21:16:10 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-24 21:16:10 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-24 21:16:10 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-24 21:16:10 --> Final output sent to browser
DEBUG - 2016-12-24 21:16:10 --> Total execution time: 44.4065
DEBUG - 2016-12-24 21:16:10 --> Config Class Initialized
DEBUG - 2016-12-24 21:16:10 --> Hooks Class Initialized
DEBUG - 2016-12-24 21:16:10 --> Utf8 Class Initialized
DEBUG - 2016-12-24 21:16:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 21:16:10 --> URI Class Initialized
DEBUG - 2016-12-24 21:16:10 --> Router Class Initialized
ERROR - 2016-12-24 21:16:10 --> 404 Page Not Found --> js
DEBUG - 2016-12-24 22:00:31 --> Config Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Hooks Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Utf8 Class Initialized
DEBUG - 2016-12-24 22:00:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 22:00:31 --> URI Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Router Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Output Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Security Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Input Class Initialized
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> XSS Filtering completed
DEBUG - 2016-12-24 22:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 22:00:31 --> Language Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Loader Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Helper loaded: url_helper
DEBUG - 2016-12-24 22:00:31 --> Helper loaded: form_helper
DEBUG - 2016-12-24 22:00:31 --> Helper loaded: func_helper
DEBUG - 2016-12-24 22:00:31 --> Database Driver Class Initialized
ERROR - 2016-12-24 22:00:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 22:00:31 --> Session Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Helper loaded: string_helper
DEBUG - 2016-12-24 22:00:31 --> Encrypt Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Session routines successfully run
ERROR - 2016-12-24 22:00:31 --> Could not find the language line "first_link"
ERROR - 2016-12-24 22:00:31 --> Could not find the language line "last_link"
ERROR - 2016-12-24 22:00:31 --> Could not find the language line "next_link"
ERROR - 2016-12-24 22:00:31 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 22:00:31 --> Pagination Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Table Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Model Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Model Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Helper loaded: file_helper
DEBUG - 2016-12-24 22:00:31 --> Model Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Controller Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Helper loaded: language_helper
DEBUG - 2016-12-24 22:00:31 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 22:00:31 --> Model Class Initialized
DEBUG - 2016-12-24 22:00:31 --> Upload Class Initialized
ERROR - 2016-12-24 22:01:16 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-24 22:01:16 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-24 22:01:17 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-24 22:01:17 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-24 22:01:17 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-24 22:01:17 --> Final output sent to browser
DEBUG - 2016-12-24 22:01:17 --> Total execution time: 45.8236
DEBUG - 2016-12-24 22:01:17 --> Config Class Initialized
DEBUG - 2016-12-24 22:01:17 --> Hooks Class Initialized
DEBUG - 2016-12-24 22:01:17 --> Utf8 Class Initialized
DEBUG - 2016-12-24 22:01:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 22:01:17 --> URI Class Initialized
DEBUG - 2016-12-24 22:01:17 --> Router Class Initialized
ERROR - 2016-12-24 22:01:17 --> 404 Page Not Found --> js
DEBUG - 2016-12-24 22:01:46 --> Config Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Hooks Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Utf8 Class Initialized
DEBUG - 2016-12-24 22:01:46 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 22:01:46 --> URI Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Router Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Output Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Security Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Input Class Initialized
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> XSS Filtering completed
DEBUG - 2016-12-24 22:01:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-24 22:01:46 --> Language Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Loader Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Helper loaded: url_helper
DEBUG - 2016-12-24 22:01:46 --> Helper loaded: form_helper
DEBUG - 2016-12-24 22:01:46 --> Helper loaded: func_helper
DEBUG - 2016-12-24 22:01:46 --> Database Driver Class Initialized
ERROR - 2016-12-24 22:01:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-24 22:01:46 --> Session Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Helper loaded: string_helper
DEBUG - 2016-12-24 22:01:46 --> Encrypt Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Session routines successfully run
ERROR - 2016-12-24 22:01:46 --> Could not find the language line "first_link"
ERROR - 2016-12-24 22:01:46 --> Could not find the language line "last_link"
ERROR - 2016-12-24 22:01:46 --> Could not find the language line "next_link"
ERROR - 2016-12-24 22:01:46 --> Could not find the language line "prev_link"
DEBUG - 2016-12-24 22:01:46 --> Pagination Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Table Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Model Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Model Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Helper loaded: file_helper
DEBUG - 2016-12-24 22:01:46 --> Model Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Controller Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Helper loaded: language_helper
DEBUG - 2016-12-24 22:01:46 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-24 22:01:46 --> Model Class Initialized
DEBUG - 2016-12-24 22:01:46 --> Upload Class Initialized
ERROR - 2016-12-24 22:02:31 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-24 22:02:31 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-24 22:02:31 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-24 22:02:31 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-24 22:02:31 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-24 22:02:31 --> Final output sent to browser
DEBUG - 2016-12-24 22:02:31 --> Total execution time: 44.7766
DEBUG - 2016-12-24 22:02:31 --> Config Class Initialized
DEBUG - 2016-12-24 22:02:31 --> Hooks Class Initialized
DEBUG - 2016-12-24 22:02:31 --> Utf8 Class Initialized
DEBUG - 2016-12-24 22:02:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-24 22:02:31 --> URI Class Initialized
DEBUG - 2016-12-24 22:02:31 --> Router Class Initialized
ERROR - 2016-12-24 22:02:31 --> 404 Page Not Found --> js
