<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-29 22:19:34 --> Config Class Initialized
DEBUG - 2016-09-29 22:19:34 --> Hooks Class Initialized
DEBUG - 2016-09-29 22:19:35 --> Utf8 Class Initialized
DEBUG - 2016-09-29 22:19:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-29 22:19:35 --> URI Class Initialized
DEBUG - 2016-09-29 22:19:35 --> Router Class Initialized
DEBUG - 2016-09-29 22:19:35 --> Output Class Initialized
DEBUG - 2016-09-29 22:19:35 --> Security Class Initialized
DEBUG - 2016-09-29 22:19:35 --> Input Class Initialized
DEBUG - 2016-09-29 22:19:35 --> XSS Filtering completed
DEBUG - 2016-09-29 22:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-29 22:19:35 --> Language Class Initialized
DEBUG - 2016-09-29 22:19:35 --> Loader Class Initialized
DEBUG - 2016-09-29 22:19:36 --> Helper loaded: url_helper
DEBUG - 2016-09-29 22:19:36 --> Helper loaded: form_helper
DEBUG - 2016-09-29 22:19:36 --> Helper loaded: func_helper
DEBUG - 2016-09-29 22:19:37 --> Database Driver Class Initialized
ERROR - 2016-09-29 22:19:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-29 22:19:37 --> Session Class Initialized
DEBUG - 2016-09-29 22:19:37 --> Helper loaded: string_helper
DEBUG - 2016-09-29 22:19:37 --> Encrypt Class Initialized
ERROR - 2016-09-29 22:19:37 --> Session: The session cookie was not signed.
DEBUG - 2016-09-29 22:19:38 --> Session routines successfully run
ERROR - 2016-09-29 22:19:38 --> Could not find the language line "first_link"
ERROR - 2016-09-29 22:19:38 --> Could not find the language line "last_link"
ERROR - 2016-09-29 22:19:38 --> Could not find the language line "next_link"
ERROR - 2016-09-29 22:19:38 --> Could not find the language line "prev_link"
DEBUG - 2016-09-29 22:19:38 --> Pagination Class Initialized
DEBUG - 2016-09-29 22:19:38 --> Table Class Initialized
DEBUG - 2016-09-29 22:19:38 --> Model Class Initialized
DEBUG - 2016-09-29 22:19:38 --> Model Class Initialized
DEBUG - 2016-09-29 22:19:38 --> Helper loaded: file_helper
DEBUG - 2016-09-29 22:19:39 --> Model Class Initialized
DEBUG - 2016-09-29 22:19:39 --> Controller Class Initialized
DEBUG - 2016-09-29 22:19:39 --> Helper loaded: language_helper
DEBUG - 2016-09-29 22:19:39 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-29 22:19:39 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-29 22:19:39 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-29 22:19:39 --> File loaded: application/views/login_form.php
DEBUG - 2016-09-29 22:19:39 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-29 22:19:39 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-29 22:19:39 --> Final output sent to browser
DEBUG - 2016-09-29 22:19:39 --> Total execution time: 5.2813
DEBUG - 2016-09-29 22:19:43 --> Config Class Initialized
DEBUG - 2016-09-29 22:19:43 --> Hooks Class Initialized
DEBUG - 2016-09-29 22:19:43 --> Utf8 Class Initialized
DEBUG - 2016-09-29 22:19:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-29 22:19:43 --> URI Class Initialized
DEBUG - 2016-09-29 22:19:43 --> Router Class Initialized
ERROR - 2016-09-29 22:19:43 --> 404 Page Not Found --> js
DEBUG - 2016-09-29 22:19:45 --> Config Class Initialized
DEBUG - 2016-09-29 22:19:45 --> Hooks Class Initialized
DEBUG - 2016-09-29 22:19:45 --> Utf8 Class Initialized
DEBUG - 2016-09-29 22:19:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-29 22:19:45 --> URI Class Initialized
DEBUG - 2016-09-29 22:19:45 --> Router Class Initialized
ERROR - 2016-09-29 22:19:45 --> 404 Page Not Found --> js
