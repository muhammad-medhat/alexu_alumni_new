<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-30 13:05:05 --> Config Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Hooks Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Utf8 Class Initialized
DEBUG - 2016-09-30 13:05:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 13:05:05 --> URI Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Router Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Output Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Security Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Input Class Initialized
DEBUG - 2016-09-30 13:05:05 --> XSS Filtering completed
DEBUG - 2016-09-30 13:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 13:05:05 --> Language Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Loader Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Helper loaded: url_helper
DEBUG - 2016-09-30 13:05:05 --> Helper loaded: form_helper
DEBUG - 2016-09-30 13:05:05 --> Helper loaded: func_helper
DEBUG - 2016-09-30 13:05:05 --> Database Driver Class Initialized
ERROR - 2016-09-30 13:05:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 13:05:05 --> Session Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Helper loaded: string_helper
DEBUG - 2016-09-30 13:05:05 --> Encrypt Class Initialized
ERROR - 2016-09-30 13:05:05 --> Session: The session cookie was not signed.
DEBUG - 2016-09-30 13:05:05 --> Session routines successfully run
ERROR - 2016-09-30 13:05:05 --> Could not find the language line "first_link"
ERROR - 2016-09-30 13:05:05 --> Could not find the language line "last_link"
ERROR - 2016-09-30 13:05:05 --> Could not find the language line "next_link"
ERROR - 2016-09-30 13:05:05 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 13:05:05 --> Pagination Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Table Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Model Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Model Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Helper loaded: file_helper
DEBUG - 2016-09-30 13:05:05 --> Model Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Controller Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Helper loaded: language_helper
DEBUG - 2016-09-30 13:05:05 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 13:05:05 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 13:05:05 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-30 13:05:05 --> File loaded: application/views/login_form.php
DEBUG - 2016-09-30 13:05:05 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-30 13:05:05 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-30 13:05:05 --> Final output sent to browser
DEBUG - 2016-09-30 13:05:05 --> Total execution time: 0.1520
DEBUG - 2016-09-30 13:05:05 --> Config Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Hooks Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Utf8 Class Initialized
DEBUG - 2016-09-30 13:05:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 13:05:05 --> URI Class Initialized
DEBUG - 2016-09-30 13:05:05 --> Router Class Initialized
ERROR - 2016-09-30 13:05:05 --> 404 Page Not Found --> js
DEBUG - 2016-09-30 14:04:57 --> Config Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:04:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:04:57 --> URI Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Router Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Output Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Security Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Input Class Initialized
DEBUG - 2016-09-30 14:04:57 --> XSS Filtering completed
DEBUG - 2016-09-30 14:04:57 --> XSS Filtering completed
DEBUG - 2016-09-30 14:04:57 --> XSS Filtering completed
DEBUG - 2016-09-30 14:04:57 --> XSS Filtering completed
DEBUG - 2016-09-30 14:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:04:57 --> Language Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Loader Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:04:57 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:04:57 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:04:57 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:04:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:04:57 --> Session Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:04:57 --> Encrypt Class Initialized
ERROR - 2016-09-30 14:04:57 --> Session: The session cookie was not signed.
DEBUG - 2016-09-30 14:04:57 --> Session routines successfully run
ERROR - 2016-09-30 14:04:57 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:04:57 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:04:57 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:04:57 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:04:57 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Table Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Model Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Model Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:04:57 --> Model Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Controller Class Initialized
DEBUG - 2016-09-30 14:04:57 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:04:57 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:04:57 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:00 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Router Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Output Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Security Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Input Class Initialized
DEBUG - 2016-09-30 14:05:00 --> XSS Filtering completed
DEBUG - 2016-09-30 14:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:05:00 --> Language Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Loader Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:05:00 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:05:00 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:05:00 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:05:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:05:00 --> Session Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:05:00 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Session routines successfully run
ERROR - 2016-09-30 14:05:00 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:05:00 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:05:00 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:05:00 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:05:00 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Table Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:05:00 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Controller Class Initialized
DEBUG - 2016-09-30 14:05:00 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:05:01 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:05:01 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:05:03 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:05:03 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:05:03 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-30 14:05:03 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-30 14:05:03 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-30 14:05:03 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:05:03 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:05:03 --> Final output sent to browser
DEBUG - 2016-09-30 14:05:03 --> Total execution time: 2.9002
DEBUG - 2016-09-30 14:05:03 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:03 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:03 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:03 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:03 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:03 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:03 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:03 --> Router Class Initialized
DEBUG - 2016-09-30 14:05:03 --> URI Class Initialized
ERROR - 2016-09-30 14:05:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-30 14:05:03 --> Router Class Initialized
ERROR - 2016-09-30 14:05:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-30 14:05:03 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:03 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:03 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:03 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:03 --> Router Class Initialized
ERROR - 2016-09-30 14:05:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-30 14:05:03 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:03 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:03 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:03 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:03 --> Router Class Initialized
ERROR - 2016-09-30 14:05:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-30 14:05:10 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:10 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Router Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Output Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Security Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Input Class Initialized
DEBUG - 2016-09-30 14:05:10 --> XSS Filtering completed
DEBUG - 2016-09-30 14:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:05:10 --> Language Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Loader Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:05:10 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:05:10 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:05:10 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:05:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:05:10 --> Session Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:05:10 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Session routines successfully run
ERROR - 2016-09-30 14:05:10 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:05:10 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:05:10 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:05:10 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:05:10 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Table Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:05:10 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Controller Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:05:10 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:05:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:05:15 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:05:15 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:05:15 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-30 14:05:15 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-30 14:05:15 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-30 14:05:15 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:05:15 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:05:15 --> Final output sent to browser
DEBUG - 2016-09-30 14:05:15 --> Total execution time: 4.6063
DEBUG - 2016-09-30 14:05:19 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:19 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Router Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Output Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Security Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Input Class Initialized
DEBUG - 2016-09-30 14:05:19 --> XSS Filtering completed
DEBUG - 2016-09-30 14:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:05:19 --> Language Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Loader Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:05:19 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:05:19 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:05:19 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:05:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:05:19 --> Session Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:05:19 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Session routines successfully run
ERROR - 2016-09-30 14:05:19 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:05:19 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:05:19 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:05:19 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:05:19 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Table Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:05:19 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Controller Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:05:19 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:05:19 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:05:19 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:05:19 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:05:19 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:05:19 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:05:20 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:05:20 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:05:20 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:05:20 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:05:20 --> Final output sent to browser
DEBUG - 2016-09-30 14:05:20 --> Total execution time: 0.1500
DEBUG - 2016-09-30 14:05:55 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:55 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Router Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Output Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Security Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Input Class Initialized
DEBUG - 2016-09-30 14:05:55 --> XSS Filtering completed
DEBUG - 2016-09-30 14:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:05:55 --> Language Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Loader Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:05:55 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:05:55 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:05:55 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:05:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:05:55 --> Session Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:05:55 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Session routines successfully run
ERROR - 2016-09-30 14:05:55 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:05:55 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:05:55 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:05:55 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:05:55 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Table Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:05:55 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Controller Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:05:55 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:05:55 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:05:55 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:05:55 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:05:55 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:05:55 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:05:55 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:05:55 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:05:55 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:05:55 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:05:55 --> Final output sent to browser
DEBUG - 2016-09-30 14:05:55 --> Total execution time: 0.0890
DEBUG - 2016-09-30 14:05:56 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:56 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Router Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Output Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Security Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Input Class Initialized
DEBUG - 2016-09-30 14:05:56 --> XSS Filtering completed
DEBUG - 2016-09-30 14:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:05:56 --> Language Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Loader Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:05:56 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:05:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:05:56 --> Session Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:05:56 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Session routines successfully run
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:05:56 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Table Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:05:56 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Controller Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:05:56 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:05:56 --> Final output sent to browser
DEBUG - 2016-09-30 14:05:56 --> Total execution time: 0.1030
DEBUG - 2016-09-30 14:05:56 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:56 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Router Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Output Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Security Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Input Class Initialized
DEBUG - 2016-09-30 14:05:56 --> XSS Filtering completed
DEBUG - 2016-09-30 14:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:05:56 --> Language Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Loader Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:05:56 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:05:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:05:56 --> Session Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:05:56 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Session routines successfully run
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:05:56 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Table Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:05:56 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Controller Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:05:56 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:05:56 --> Final output sent to browser
DEBUG - 2016-09-30 14:05:56 --> Total execution time: 0.0780
DEBUG - 2016-09-30 14:05:56 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:56 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Router Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Output Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Security Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Input Class Initialized
DEBUG - 2016-09-30 14:05:56 --> XSS Filtering completed
DEBUG - 2016-09-30 14:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:05:56 --> Language Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Loader Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:05:56 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:05:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:05:56 --> Session Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:05:56 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Session routines successfully run
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:05:56 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Table Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:05:56 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Controller Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:05:56 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:05:56 --> Final output sent to browser
DEBUG - 2016-09-30 14:05:56 --> Total execution time: 0.0760
DEBUG - 2016-09-30 14:05:56 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:56 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Router Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Output Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Security Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Input Class Initialized
DEBUG - 2016-09-30 14:05:56 --> XSS Filtering completed
DEBUG - 2016-09-30 14:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:05:56 --> Language Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Loader Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:05:56 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:05:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:05:56 --> Session Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:05:56 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Session routines successfully run
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:05:56 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Table Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:05:56 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Controller Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:05:56 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:05:56 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:05:56 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:05:56 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:05:56 --> Final output sent to browser
DEBUG - 2016-09-30 14:05:56 --> Total execution time: 0.0890
DEBUG - 2016-09-30 14:05:57 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:57 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Router Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Output Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Security Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Input Class Initialized
DEBUG - 2016-09-30 14:05:57 --> XSS Filtering completed
DEBUG - 2016-09-30 14:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:05:57 --> Language Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Loader Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:05:57 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:05:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:05:57 --> Session Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:05:57 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Session routines successfully run
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:05:57 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Table Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:05:57 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Controller Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:05:57 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:05:57 --> Final output sent to browser
DEBUG - 2016-09-30 14:05:57 --> Total execution time: 0.0910
DEBUG - 2016-09-30 14:05:57 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:57 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Router Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Output Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Security Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Input Class Initialized
DEBUG - 2016-09-30 14:05:57 --> XSS Filtering completed
DEBUG - 2016-09-30 14:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:05:57 --> Language Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Loader Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:05:57 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:05:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:05:57 --> Session Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:05:57 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Session routines successfully run
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:05:57 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Table Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:05:57 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Controller Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:05:57 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:05:57 --> Final output sent to browser
DEBUG - 2016-09-30 14:05:57 --> Total execution time: 0.0910
DEBUG - 2016-09-30 14:05:57 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:57 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Router Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Output Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Security Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Input Class Initialized
DEBUG - 2016-09-30 14:05:57 --> XSS Filtering completed
DEBUG - 2016-09-30 14:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:05:57 --> Language Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Loader Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:05:57 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:05:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:05:57 --> Session Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:05:57 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Session routines successfully run
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:05:57 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Table Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:05:57 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Controller Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:05:57 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:05:57 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:05:57 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:05:57 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:05:57 --> Final output sent to browser
DEBUG - 2016-09-30 14:05:57 --> Total execution time: 0.0760
DEBUG - 2016-09-30 14:05:58 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:58 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Router Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Output Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Security Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Input Class Initialized
DEBUG - 2016-09-30 14:05:58 --> XSS Filtering completed
DEBUG - 2016-09-30 14:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:05:58 --> Language Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Loader Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:05:58 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:05:58 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:05:58 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:05:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:05:58 --> Session Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:05:58 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Session routines successfully run
ERROR - 2016-09-30 14:05:58 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:05:58 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:05:58 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:05:58 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:05:58 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Table Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:05:58 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Controller Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:05:58 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:05:58 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:05:58 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:05:58 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:05:58 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:05:58 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:05:58 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:05:58 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:05:58 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:05:58 --> Final output sent to browser
DEBUG - 2016-09-30 14:05:58 --> Total execution time: 0.0900
DEBUG - 2016-09-30 14:05:58 --> Config Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:05:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:05:58 --> URI Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Router Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Output Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Security Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Input Class Initialized
DEBUG - 2016-09-30 14:05:58 --> XSS Filtering completed
DEBUG - 2016-09-30 14:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:05:58 --> Language Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Loader Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:05:58 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:05:58 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:05:58 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:05:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:05:58 --> Session Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:05:58 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Session routines successfully run
ERROR - 2016-09-30 14:05:58 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:05:58 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:05:58 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:05:58 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:05:58 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Table Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:05:58 --> Model Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Controller Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:05:58 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:05:58 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:05:58 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:05:58 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:05:58 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:05:58 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:05:58 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:05:58 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:05:58 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:05:58 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:05:58 --> Final output sent to browser
DEBUG - 2016-09-30 14:05:58 --> Total execution time: 0.0920
DEBUG - 2016-09-30 14:06:50 --> Config Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:06:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:06:50 --> URI Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Router Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Output Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Security Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Input Class Initialized
DEBUG - 2016-09-30 14:06:50 --> XSS Filtering completed
DEBUG - 2016-09-30 14:06:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:06:50 --> Language Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Loader Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:06:50 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:06:50 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:06:50 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:06:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:06:50 --> Session Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:06:50 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Session routines successfully run
ERROR - 2016-09-30 14:06:50 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:06:50 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:06:50 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:06:50 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:06:50 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Table Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Model Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Model Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:06:50 --> Model Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Controller Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:06:50 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:06:50 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:06:50 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:06:50 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:06:50 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:06:50 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:06:50 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:06:50 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:06:50 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:06:50 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:06:50 --> Final output sent to browser
DEBUG - 2016-09-30 14:06:50 --> Total execution time: 0.0790
DEBUG - 2016-09-30 14:07:40 --> Config Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:07:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:07:40 --> URI Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Router Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Output Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Security Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Input Class Initialized
DEBUG - 2016-09-30 14:07:40 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:07:40 --> Language Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Loader Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:07:40 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:07:40 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:07:40 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:07:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:07:40 --> Session Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:07:40 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Session routines successfully run
ERROR - 2016-09-30 14:07:40 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:07:40 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:07:40 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:07:40 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:07:40 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Table Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Model Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Model Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:07:40 --> Model Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Controller Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:07:40 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:07:40 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:07:40 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:07:40 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:07:40 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:07:40 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:07:40 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:07:40 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:07:40 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:07:40 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:07:40 --> Final output sent to browser
DEBUG - 2016-09-30 14:07:40 --> Total execution time: 0.0940
DEBUG - 2016-09-30 14:07:48 --> Config Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:07:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:07:48 --> URI Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Router Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Output Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Security Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Input Class Initialized
DEBUG - 2016-09-30 14:07:48 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:48 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:48 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:48 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:48 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:48 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:48 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:07:48 --> Language Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Loader Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:07:48 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:07:48 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:07:48 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:07:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:07:48 --> Session Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:07:48 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Session routines successfully run
ERROR - 2016-09-30 14:07:48 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:07:48 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:07:48 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:07:48 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:07:48 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Table Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Model Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Model Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:07:48 --> Model Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Controller Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:07:48 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:07:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-09-30 14:07:48 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:07:48 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-30 14:07:48 --> Unable to find validation rule: edit_unique
DEBUG - 2016-09-30 14:07:48 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:48 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:48 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:48 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:48 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:48 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:48 --> Config Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:07:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:07:48 --> URI Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Router Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Output Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Security Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Input Class Initialized
DEBUG - 2016-09-30 14:07:48 --> XSS Filtering completed
DEBUG - 2016-09-30 14:07:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:07:48 --> Language Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Loader Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:07:48 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:07:48 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:07:48 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:07:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:07:48 --> Session Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:07:48 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Session routines successfully run
ERROR - 2016-09-30 14:07:48 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:07:48 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:07:48 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:07:48 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:07:48 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Table Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Model Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Model Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:07:48 --> Model Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Controller Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:07:48 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:07:48 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:07:51 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:07:51 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:07:51 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-30 14:07:51 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-30 14:07:51 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-30 14:07:51 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:07:51 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:07:51 --> Final output sent to browser
DEBUG - 2016-09-30 14:07:51 --> Total execution time: 2.7662
DEBUG - 2016-09-30 14:07:51 --> Config Class Initialized
DEBUG - 2016-09-30 14:07:51 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:07:51 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:07:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:07:51 --> URI Class Initialized
DEBUG - 2016-09-30 14:07:51 --> Router Class Initialized
DEBUG - 2016-09-30 14:07:51 --> Config Class Initialized
DEBUG - 2016-09-30 14:07:51 --> Hooks Class Initialized
ERROR - 2016-09-30 14:07:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-30 14:07:51 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:07:51 --> Config Class Initialized
DEBUG - 2016-09-30 14:07:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:07:51 --> URI Class Initialized
DEBUG - 2016-09-30 14:07:51 --> Router Class Initialized
DEBUG - 2016-09-30 14:07:51 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:07:51 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:07:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:07:51 --> URI Class Initialized
DEBUG - 2016-09-30 14:07:51 --> Config Class Initialized
ERROR - 2016-09-30 14:07:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-30 14:07:51 --> Router Class Initialized
DEBUG - 2016-09-30 14:07:51 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:07:51 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:07:51 --> UTF-8 Support Enabled
ERROR - 2016-09-30 14:07:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-30 14:07:51 --> URI Class Initialized
DEBUG - 2016-09-30 14:07:51 --> Router Class Initialized
ERROR - 2016-09-30 14:07:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-30 14:08:08 --> Config Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:08:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:08:08 --> URI Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Router Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Output Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Security Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Input Class Initialized
DEBUG - 2016-09-30 14:08:08 --> XSS Filtering completed
DEBUG - 2016-09-30 14:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:08:08 --> Language Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Loader Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:08:08 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:08:08 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:08:08 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:08:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:08:08 --> Session Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:08:08 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Session routines successfully run
ERROR - 2016-09-30 14:08:08 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:08:08 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:08:08 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:08:08 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:08:08 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Table Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Model Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Model Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:08:08 --> Model Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Controller Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:08:08 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:08:08 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:08:08 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:08:08 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:08:08 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:08:08 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:08:08 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:08:08 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:08:08 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:08:08 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:08:08 --> Final output sent to browser
DEBUG - 2016-09-30 14:08:08 --> Total execution time: 0.1770
DEBUG - 2016-09-30 14:08:26 --> Config Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:08:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:08:26 --> URI Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Router Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Output Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Security Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Input Class Initialized
DEBUG - 2016-09-30 14:08:26 --> XSS Filtering completed
DEBUG - 2016-09-30 14:08:26 --> XSS Filtering completed
DEBUG - 2016-09-30 14:08:26 --> XSS Filtering completed
DEBUG - 2016-09-30 14:08:26 --> XSS Filtering completed
DEBUG - 2016-09-30 14:08:26 --> XSS Filtering completed
DEBUG - 2016-09-30 14:08:26 --> XSS Filtering completed
DEBUG - 2016-09-30 14:08:26 --> XSS Filtering completed
DEBUG - 2016-09-30 14:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:08:26 --> Language Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Loader Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:08:26 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:08:26 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:08:26 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:08:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:08:26 --> Session Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:08:26 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Session routines successfully run
ERROR - 2016-09-30 14:08:26 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:08:26 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:08:26 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:08:26 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:08:26 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Table Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Model Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Model Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:08:26 --> Model Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Controller Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:08:26 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:08:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:08:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-09-30 14:08:26 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:08:26 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-30 14:08:26 --> Unable to find validation rule: edit_unique
ERROR - 2016-09-30 14:08:26 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:08:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:08:26 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:08:26 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:08:26 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:08:26 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:08:26 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:08:26 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:08:26 --> Final output sent to browser
DEBUG - 2016-09-30 14:08:26 --> Total execution time: 0.1050
DEBUG - 2016-09-30 14:11:24 --> Config Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:11:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:11:24 --> URI Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Router Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Output Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Security Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Input Class Initialized
DEBUG - 2016-09-30 14:11:24 --> XSS Filtering completed
DEBUG - 2016-09-30 14:11:24 --> XSS Filtering completed
DEBUG - 2016-09-30 14:11:24 --> XSS Filtering completed
DEBUG - 2016-09-30 14:11:24 --> XSS Filtering completed
DEBUG - 2016-09-30 14:11:24 --> XSS Filtering completed
DEBUG - 2016-09-30 14:11:24 --> XSS Filtering completed
DEBUG - 2016-09-30 14:11:24 --> XSS Filtering completed
DEBUG - 2016-09-30 14:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:11:24 --> Language Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Loader Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:11:24 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:11:24 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:11:24 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:11:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:11:24 --> Session Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:11:24 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Session routines successfully run
ERROR - 2016-09-30 14:11:24 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:11:24 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:11:24 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:11:24 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:11:24 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Table Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Model Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Model Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:11:24 --> Model Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Controller Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:11:24 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:11:24 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:11:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-09-30 14:11:24 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:11:24 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-30 14:11:24 --> Unable to find validation rule: edit_unique
ERROR - 2016-09-30 14:11:24 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:11:24 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:11:24 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:11:24 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:11:24 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:11:24 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:11:24 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:11:24 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:11:24 --> Final output sent to browser
DEBUG - 2016-09-30 14:11:24 --> Total execution time: 0.1256
DEBUG - 2016-09-30 14:13:52 --> Config Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:13:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:13:52 --> URI Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Router Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Output Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Security Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Input Class Initialized
DEBUG - 2016-09-30 14:13:52 --> XSS Filtering completed
DEBUG - 2016-09-30 14:13:52 --> XSS Filtering completed
DEBUG - 2016-09-30 14:13:52 --> XSS Filtering completed
DEBUG - 2016-09-30 14:13:52 --> XSS Filtering completed
DEBUG - 2016-09-30 14:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:13:52 --> Language Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Loader Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:13:52 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:13:52 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:13:52 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:13:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:13:52 --> Session Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:13:52 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:13:52 --> A session cookie was not found.
DEBUG - 2016-09-30 14:13:52 --> Session routines successfully run
ERROR - 2016-09-30 14:13:52 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:13:52 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:13:52 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:13:52 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:13:52 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Table Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Model Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Model Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:13:52 --> Model Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Controller Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Config Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:13:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:13:52 --> URI Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Router Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Output Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Security Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Input Class Initialized
DEBUG - 2016-09-30 14:13:52 --> XSS Filtering completed
DEBUG - 2016-09-30 14:13:52 --> XSS Filtering completed
DEBUG - 2016-09-30 14:13:52 --> XSS Filtering completed
DEBUG - 2016-09-30 14:13:52 --> XSS Filtering completed
DEBUG - 2016-09-30 14:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:13:52 --> Language Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Loader Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:13:52 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:13:52 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:13:52 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:13:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:13:52 --> Session Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:13:52 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Session routines successfully run
ERROR - 2016-09-30 14:13:52 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:13:52 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:13:52 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:13:52 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:13:52 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Table Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Model Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Model Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:13:52 --> Model Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Controller Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:13:52 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:13:52 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:13:52 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-30 14:13:52 --> File loaded: application/views/login_form.php
DEBUG - 2016-09-30 14:13:52 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-30 14:13:52 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-30 14:13:52 --> Final output sent to browser
DEBUG - 2016-09-30 14:13:52 --> Total execution time: 0.0600
DEBUG - 2016-09-30 14:13:52 --> Config Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:13:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:13:52 --> URI Class Initialized
DEBUG - 2016-09-30 14:13:52 --> Router Class Initialized
ERROR - 2016-09-30 14:13:52 --> 404 Page Not Found --> js
DEBUG - 2016-09-30 14:14:00 --> Config Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:14:00 --> URI Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Router Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Output Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Security Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Input Class Initialized
DEBUG - 2016-09-30 14:14:00 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:00 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:00 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:00 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:00 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:00 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:00 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:14:00 --> Language Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Loader Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:14:00 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:14:00 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:14:00 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:14:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:14:00 --> Session Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:14:00 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Session routines successfully run
ERROR - 2016-09-30 14:14:00 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:14:00 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:14:00 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:14:00 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:14:00 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Table Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Model Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Model Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:14:00 --> Model Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Controller Class Initialized
DEBUG - 2016-09-30 14:14:00 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:14:00 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:14:00 --> Model Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Config Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:14:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:14:03 --> URI Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Router Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Output Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Security Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Input Class Initialized
DEBUG - 2016-09-30 14:14:03 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:03 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:03 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:03 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:14:03 --> Language Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Loader Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:14:03 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:14:03 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:14:03 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:14:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:14:03 --> Session Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:14:03 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Session routines successfully run
ERROR - 2016-09-30 14:14:03 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:14:03 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:14:03 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:14:03 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:14:03 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Table Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Model Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Model Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:14:03 --> Model Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Controller Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:14:03 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:14:03 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:14:06 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:14:06 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:14:06 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-30 14:14:06 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-30 14:14:06 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-30 14:14:06 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:14:06 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:14:06 --> Final output sent to browser
DEBUG - 2016-09-30 14:14:06 --> Total execution time: 2.6051
DEBUG - 2016-09-30 14:14:06 --> Config Class Initialized
DEBUG - 2016-09-30 14:14:06 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:14:06 --> Config Class Initialized
DEBUG - 2016-09-30 14:14:06 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:14:06 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:14:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:14:06 --> URI Class Initialized
DEBUG - 2016-09-30 14:14:06 --> Config Class Initialized
DEBUG - 2016-09-30 14:14:06 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:14:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:14:06 --> Router Class Initialized
DEBUG - 2016-09-30 14:14:06 --> URI Class Initialized
DEBUG - 2016-09-30 14:14:06 --> Router Class Initialized
ERROR - 2016-09-30 14:14:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-30 14:14:06 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:14:06 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:14:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:14:06 --> URI Class Initialized
ERROR - 2016-09-30 14:14:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-30 14:14:06 --> Router Class Initialized
ERROR - 2016-09-30 14:14:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-30 14:14:06 --> Config Class Initialized
DEBUG - 2016-09-30 14:14:06 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:14:06 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:14:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:14:06 --> URI Class Initialized
DEBUG - 2016-09-30 14:14:06 --> Router Class Initialized
ERROR - 2016-09-30 14:14:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-30 14:14:09 --> Config Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:14:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:14:09 --> URI Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Router Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Output Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Security Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Input Class Initialized
DEBUG - 2016-09-30 14:14:09 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:09 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:09 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:09 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:14:09 --> Language Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Loader Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:14:09 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:14:09 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:14:09 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:14:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:14:09 --> Session Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:14:09 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Session routines successfully run
ERROR - 2016-09-30 14:14:09 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:14:09 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:14:09 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:14:09 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:14:09 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Table Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Model Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Model Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:14:09 --> Model Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Controller Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:14:09 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:14:09 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-30 14:14:09 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:14:09 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:14:09 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:14:09 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:14:09 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:14:09 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:14:09 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:14:09 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:14:09 --> Final output sent to browser
DEBUG - 2016-09-30 14:14:09 --> Total execution time: 0.1510
DEBUG - 2016-09-30 14:14:15 --> Config Class Initialized
DEBUG - 2016-09-30 14:14:15 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:14:15 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:14:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:14:16 --> URI Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Router Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Output Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Security Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Input Class Initialized
DEBUG - 2016-09-30 14:14:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:14:16 --> Language Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Loader Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:14:16 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:14:16 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:14:16 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:14:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:14:16 --> Session Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:14:16 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Session routines successfully run
ERROR - 2016-09-30 14:14:16 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:14:16 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:14:16 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:14:16 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:14:16 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Table Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Model Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Model Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:14:16 --> Model Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Controller Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:14:16 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:14:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:14:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-09-30 14:14:16 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:14:16 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-30 14:14:16 --> Unable to find validation rule: edit_unique
ERROR - 2016-09-30 14:14:16 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:14:16 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:14:16 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:14:16 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:14:16 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:14:16 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:14:16 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:14:16 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:14:16 --> Final output sent to browser
DEBUG - 2016-09-30 14:14:16 --> Total execution time: 0.1040
DEBUG - 2016-09-30 14:16:16 --> Config Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:16:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:16:16 --> URI Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Router Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Output Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Security Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Input Class Initialized
DEBUG - 2016-09-30 14:16:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:16:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:16:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:16:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:16:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:16:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:16:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:16:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:16:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:16:16 --> XSS Filtering completed
DEBUG - 2016-09-30 14:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:16:16 --> Language Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Loader Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:16:16 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:16:16 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:16:16 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:16:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:16:16 --> Session Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:16:16 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Session routines successfully run
ERROR - 2016-09-30 14:16:16 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:16:16 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:16:16 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:16:16 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:16:16 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Table Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Model Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Model Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:16:16 --> Model Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Controller Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:16:16 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:16:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:16:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-09-30 14:16:16 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:16:16 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-30 14:16:16 --> Unable to find validation rule: edit_unique
ERROR - 2016-09-30 14:16:16 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:16:16 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:16:16 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:16:16 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:16:16 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:16:16 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:16:16 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:16:16 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:16:16 --> Final output sent to browser
DEBUG - 2016-09-30 14:16:16 --> Total execution time: 0.1010
DEBUG - 2016-09-30 14:18:01 --> Config Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:18:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:18:01 --> URI Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Router Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Output Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Security Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Input Class Initialized
DEBUG - 2016-09-30 14:18:01 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:01 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:01 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:01 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:01 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:01 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:01 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:18:01 --> Language Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Loader Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:18:01 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:18:01 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:18:01 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:18:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:18:01 --> Session Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:18:01 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Session routines successfully run
ERROR - 2016-09-30 14:18:01 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:18:01 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:18:01 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:18:01 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:18:01 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Table Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:18:01 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Controller Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:18:01 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:18:01 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:18:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-09-30 14:18:01 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:01 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-30 14:18:01 --> Unable to find validation rule: edit_unique
ERROR - 2016-09-30 14:18:01 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:18:01 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:18:01 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:18:01 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:18:01 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:01 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:18:01 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:18:01 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:18:01 --> Final output sent to browser
DEBUG - 2016-09-30 14:18:01 --> Total execution time: 0.1140
DEBUG - 2016-09-30 14:18:04 --> Config Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:18:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:18:04 --> URI Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Router Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Output Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Security Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Input Class Initialized
DEBUG - 2016-09-30 14:18:04 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:04 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:04 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:04 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:04 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:04 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:04 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:18:04 --> Language Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Loader Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:18:04 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:18:04 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:18:04 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:18:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:18:04 --> Session Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:18:04 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Session routines successfully run
ERROR - 2016-09-30 14:18:04 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:18:04 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:18:04 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:18:04 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:18:04 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Table Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:18:04 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Controller Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:18:04 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:18:04 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:18:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-09-30 14:18:04 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:04 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-30 14:18:04 --> Unable to find validation rule: edit_unique
ERROR - 2016-09-30 14:18:04 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:18:04 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:18:04 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:18:04 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:18:04 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:04 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:18:04 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:18:04 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:18:04 --> Final output sent to browser
DEBUG - 2016-09-30 14:18:04 --> Total execution time: 0.1182
DEBUG - 2016-09-30 14:18:32 --> Config Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:18:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:18:32 --> URI Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Router Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Output Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Security Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Input Class Initialized
DEBUG - 2016-09-30 14:18:32 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:32 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:32 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:32 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:32 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:32 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:32 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:18:32 --> Language Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Loader Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:18:32 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:18:32 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:18:32 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:18:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:18:32 --> Session Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:18:32 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Session routines successfully run
ERROR - 2016-09-30 14:18:32 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:18:32 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:18:32 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:18:32 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:18:32 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Table Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:18:32 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Controller Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:18:32 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:18:32 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:18:32 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-09-30 14:18:32 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:32 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-30 14:18:32 --> Unable to find validation rule: edit_unique
ERROR - 2016-09-30 14:18:32 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:18:32 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:18:32 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:18:32 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:18:32 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:32 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:18:32 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:18:32 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:18:32 --> Final output sent to browser
DEBUG - 2016-09-30 14:18:32 --> Total execution time: 0.0990
DEBUG - 2016-09-30 14:18:33 --> Config Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:18:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:18:33 --> URI Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Router Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Output Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Security Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Input Class Initialized
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:18:33 --> Language Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Loader Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:18:33 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:18:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:18:33 --> Session Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:18:33 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Session routines successfully run
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:18:33 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Table Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:18:33 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Controller Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:18:33 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:18:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:33 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-30 14:18:33 --> Unable to find validation rule: edit_unique
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:18:33 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:18:33 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:18:33 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:33 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:18:33 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:18:33 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:18:33 --> Final output sent to browser
DEBUG - 2016-09-30 14:18:33 --> Total execution time: 0.0920
DEBUG - 2016-09-30 14:18:33 --> Config Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:18:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:18:33 --> URI Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Router Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Output Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Security Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Input Class Initialized
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:18:33 --> Language Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Loader Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:18:33 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:18:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:18:33 --> Session Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:18:33 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Session routines successfully run
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:18:33 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Table Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:18:33 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Controller Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:18:33 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:18:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:33 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-30 14:18:33 --> Unable to find validation rule: edit_unique
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:18:33 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:18:33 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:18:33 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:33 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:18:33 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:18:33 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:18:33 --> Final output sent to browser
DEBUG - 2016-09-30 14:18:33 --> Total execution time: 0.1286
DEBUG - 2016-09-30 14:18:33 --> Config Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:18:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:18:33 --> URI Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Router Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Output Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Security Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Input Class Initialized
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:18:33 --> Language Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Loader Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:18:33 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:18:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:18:33 --> Session Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:18:33 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Session routines successfully run
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:18:33 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Table Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:18:33 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Controller Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:18:33 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:18:33 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:18:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-09-30 14:18:33 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:33 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-30 14:18:33 --> Unable to find validation rule: edit_unique
ERROR - 2016-09-30 14:18:34 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:18:34 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:18:34 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:18:34 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:18:34 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:34 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:18:34 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:18:34 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:18:34 --> Final output sent to browser
DEBUG - 2016-09-30 14:18:34 --> Total execution time: 0.1390
DEBUG - 2016-09-30 14:18:34 --> Config Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:18:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:18:34 --> URI Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Router Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Output Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Security Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Input Class Initialized
DEBUG - 2016-09-30 14:18:34 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:34 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:34 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:34 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:34 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:34 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:34 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:18:34 --> Language Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Loader Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:18:34 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:18:34 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:18:34 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:18:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:18:34 --> Session Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:18:34 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Session routines successfully run
ERROR - 2016-09-30 14:18:34 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:18:34 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:18:34 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:18:34 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:18:34 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Table Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:18:34 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Controller Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:18:34 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:18:34 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:18:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-09-30 14:18:34 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:34 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-30 14:18:34 --> Unable to find validation rule: edit_unique
ERROR - 2016-09-30 14:18:34 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:18:34 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:18:34 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:18:34 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:18:34 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:34 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:18:34 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:18:34 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:18:34 --> Final output sent to browser
DEBUG - 2016-09-30 14:18:34 --> Total execution time: 0.1510
DEBUG - 2016-09-30 14:18:37 --> Config Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:18:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:18:37 --> URI Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Router Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Output Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Security Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Input Class Initialized
DEBUG - 2016-09-30 14:18:37 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:37 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:37 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:37 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:37 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:37 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:37 --> XSS Filtering completed
DEBUG - 2016-09-30 14:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:18:37 --> Language Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Loader Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:18:37 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:18:37 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:18:37 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:18:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:18:37 --> Session Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:18:37 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Session routines successfully run
ERROR - 2016-09-30 14:18:37 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:18:37 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:18:37 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:18:37 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:18:37 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Table Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:18:37 --> Model Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Controller Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:18:37 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:18:37 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:18:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-09-30 14:18:37 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:37 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-30 14:18:37 --> Unable to find validation rule: edit_unique
ERROR - 2016-09-30 14:18:37 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:18:37 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:18:37 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:18:37 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-30 14:18:37 --> Could not find the language line "confirm"
DEBUG - 2016-09-30 14:18:37 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:18:37 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:18:37 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:18:37 --> Final output sent to browser
DEBUG - 2016-09-30 14:18:37 --> Total execution time: 0.0950
DEBUG - 2016-09-30 14:21:55 --> Config Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Hooks Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Utf8 Class Initialized
DEBUG - 2016-09-30 14:21:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 14:21:55 --> URI Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Router Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Output Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Security Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Input Class Initialized
DEBUG - 2016-09-30 14:21:55 --> XSS Filtering completed
DEBUG - 2016-09-30 14:21:55 --> XSS Filtering completed
DEBUG - 2016-09-30 14:21:55 --> XSS Filtering completed
DEBUG - 2016-09-30 14:21:55 --> XSS Filtering completed
DEBUG - 2016-09-30 14:21:55 --> XSS Filtering completed
DEBUG - 2016-09-30 14:21:55 --> XSS Filtering completed
DEBUG - 2016-09-30 14:21:55 --> XSS Filtering completed
DEBUG - 2016-09-30 14:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 14:21:55 --> Language Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Loader Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Helper loaded: url_helper
DEBUG - 2016-09-30 14:21:55 --> Helper loaded: form_helper
DEBUG - 2016-09-30 14:21:55 --> Helper loaded: func_helper
DEBUG - 2016-09-30 14:21:55 --> Database Driver Class Initialized
ERROR - 2016-09-30 14:21:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 14:21:55 --> Session Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Helper loaded: string_helper
DEBUG - 2016-09-30 14:21:55 --> Encrypt Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Session routines successfully run
ERROR - 2016-09-30 14:21:55 --> Could not find the language line "first_link"
ERROR - 2016-09-30 14:21:55 --> Could not find the language line "last_link"
ERROR - 2016-09-30 14:21:55 --> Could not find the language line "next_link"
ERROR - 2016-09-30 14:21:55 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 14:21:55 --> Pagination Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Table Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Model Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Model Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Helper loaded: file_helper
DEBUG - 2016-09-30 14:21:55 --> Model Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Controller Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Form Validation Class Initialized
DEBUG - 2016-09-30 14:21:55 --> Helper loaded: language_helper
DEBUG - 2016-09-30 14:21:55 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 14:21:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-30 14:21:55 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-30 14:21:55 --> Unable to find validation rule: edit_unique
ERROR - 2016-09-30 14:21:55 --> Could not find the language line "personal"
DEBUG - 2016-09-30 14:21:55 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 14:21:55 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-30 14:21:55 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-30 14:21:55 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-30 14:21:55 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-30 14:21:55 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-30 14:21:55 --> Final output sent to browser
DEBUG - 2016-09-30 14:21:55 --> Total execution time: 0.1100
DEBUG - 2016-09-30 19:54:02 --> Config Class Initialized
DEBUG - 2016-09-30 19:54:03 --> Hooks Class Initialized
DEBUG - 2016-09-30 19:54:03 --> Utf8 Class Initialized
DEBUG - 2016-09-30 19:54:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-30 19:54:03 --> URI Class Initialized
DEBUG - 2016-09-30 19:54:03 --> Router Class Initialized
DEBUG - 2016-09-30 19:54:03 --> No URI present. Default controller set.
DEBUG - 2016-09-30 19:54:03 --> Output Class Initialized
DEBUG - 2016-09-30 19:54:03 --> Security Class Initialized
DEBUG - 2016-09-30 19:54:03 --> Input Class Initialized
DEBUG - 2016-09-30 19:54:03 --> XSS Filtering completed
DEBUG - 2016-09-30 19:54:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-30 19:54:03 --> Language Class Initialized
DEBUG - 2016-09-30 19:54:03 --> Loader Class Initialized
DEBUG - 2016-09-30 19:54:03 --> Helper loaded: url_helper
DEBUG - 2016-09-30 19:54:03 --> Helper loaded: form_helper
DEBUG - 2016-09-30 19:54:03 --> Helper loaded: func_helper
DEBUG - 2016-09-30 19:54:03 --> Database Driver Class Initialized
ERROR - 2016-09-30 19:54:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-30 19:54:03 --> Session Class Initialized
DEBUG - 2016-09-30 19:54:03 --> Helper loaded: string_helper
DEBUG - 2016-09-30 19:54:03 --> Encrypt Class Initialized
DEBUG - 2016-09-30 19:54:03 --> A session cookie was not found.
DEBUG - 2016-09-30 19:54:03 --> Session routines successfully run
ERROR - 2016-09-30 19:54:03 --> Could not find the language line "first_link"
ERROR - 2016-09-30 19:54:03 --> Could not find the language line "last_link"
ERROR - 2016-09-30 19:54:03 --> Could not find the language line "next_link"
ERROR - 2016-09-30 19:54:03 --> Could not find the language line "prev_link"
DEBUG - 2016-09-30 19:54:03 --> Pagination Class Initialized
DEBUG - 2016-09-30 19:54:03 --> Table Class Initialized
DEBUG - 2016-09-30 19:54:03 --> Model Class Initialized
DEBUG - 2016-09-30 19:54:03 --> Model Class Initialized
DEBUG - 2016-09-30 19:54:03 --> Helper loaded: file_helper
DEBUG - 2016-09-30 19:54:03 --> Model Class Initialized
DEBUG - 2016-09-30 19:54:03 --> Controller Class Initialized
DEBUG - 2016-09-30 19:54:05 --> Helper loaded: language_helper
DEBUG - 2016-09-30 19:54:05 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-30 19:54:08 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-30 19:54:11 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-30 19:54:11 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-30 19:54:11 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-30 19:54:11 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-30 19:54:11 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-30 19:54:11 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-30 19:54:11 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-30 19:54:11 --> Final output sent to browser
DEBUG - 2016-09-30 19:54:11 --> Total execution time: 8.8145
