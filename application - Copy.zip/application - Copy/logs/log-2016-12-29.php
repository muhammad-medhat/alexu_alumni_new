<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-12-29 03:53:49 --> Config Class Initialized
DEBUG - 2016-12-29 03:53:49 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:53:49 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:53:49 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:53:49 --> URI Class Initialized
DEBUG - 2016-12-29 03:53:49 --> Router Class Initialized
DEBUG - 2016-12-29 03:53:49 --> Output Class Initialized
DEBUG - 2016-12-29 03:53:49 --> Security Class Initialized
DEBUG - 2016-12-29 03:53:49 --> Input Class Initialized
DEBUG - 2016-12-29 03:53:49 --> XSS Filtering completed
DEBUG - 2016-12-29 03:53:49 --> XSS Filtering completed
DEBUG - 2016-12-29 03:53:49 --> XSS Filtering completed
DEBUG - 2016-12-29 03:53:49 --> XSS Filtering completed
DEBUG - 2016-12-29 03:53:49 --> XSS Filtering completed
DEBUG - 2016-12-29 03:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 03:53:49 --> Language Class Initialized
DEBUG - 2016-12-29 03:53:49 --> Loader Class Initialized
DEBUG - 2016-12-29 03:53:49 --> Helper loaded: url_helper
DEBUG - 2016-12-29 03:53:49 --> Helper loaded: form_helper
DEBUG - 2016-12-29 03:53:49 --> Helper loaded: func_helper
DEBUG - 2016-12-29 03:53:49 --> Database Driver Class Initialized
ERROR - 2016-12-29 03:53:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 03:53:50 --> Session Class Initialized
DEBUG - 2016-12-29 03:53:50 --> Helper loaded: string_helper
DEBUG - 2016-12-29 03:53:50 --> Encrypt Class Initialized
DEBUG - 2016-12-29 03:53:50 --> A session cookie was not found.
DEBUG - 2016-12-29 03:53:50 --> Session routines successfully run
ERROR - 2016-12-29 03:53:50 --> Could not find the language line "first_link"
ERROR - 2016-12-29 03:53:50 --> Could not find the language line "last_link"
ERROR - 2016-12-29 03:53:50 --> Could not find the language line "next_link"
ERROR - 2016-12-29 03:53:50 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 03:53:50 --> Pagination Class Initialized
DEBUG - 2016-12-29 03:53:50 --> Table Class Initialized
DEBUG - 2016-12-29 03:53:50 --> Model Class Initialized
DEBUG - 2016-12-29 03:53:50 --> Model Class Initialized
DEBUG - 2016-12-29 03:53:50 --> Helper loaded: file_helper
DEBUG - 2016-12-29 03:53:50 --> Model Class Initialized
DEBUG - 2016-12-29 03:53:50 --> Controller Class Initialized
DEBUG - 2016-12-29 03:53:50 --> Helper loaded: language_helper
DEBUG - 2016-12-29 03:53:50 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 03:53:50 --> Model Class Initialized
DEBUG - 2016-12-29 03:53:51 --> Config Class Initialized
DEBUG - 2016-12-29 03:53:51 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:53:51 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:53:51 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:53:51 --> URI Class Initialized
DEBUG - 2016-12-29 03:53:51 --> Router Class Initialized
DEBUG - 2016-12-29 03:53:51 --> Output Class Initialized
DEBUG - 2016-12-29 03:53:51 --> Security Class Initialized
DEBUG - 2016-12-29 03:53:51 --> Input Class Initialized
DEBUG - 2016-12-29 03:53:51 --> XSS Filtering completed
DEBUG - 2016-12-29 03:53:51 --> XSS Filtering completed
DEBUG - 2016-12-29 03:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 03:53:52 --> Language Class Initialized
DEBUG - 2016-12-29 03:53:52 --> Loader Class Initialized
DEBUG - 2016-12-29 03:53:52 --> Helper loaded: url_helper
DEBUG - 2016-12-29 03:53:52 --> Helper loaded: form_helper
DEBUG - 2016-12-29 03:53:52 --> Helper loaded: func_helper
DEBUG - 2016-12-29 03:53:52 --> Database Driver Class Initialized
ERROR - 2016-12-29 03:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 03:53:52 --> Session Class Initialized
DEBUG - 2016-12-29 03:53:52 --> Helper loaded: string_helper
DEBUG - 2016-12-29 03:53:52 --> Encrypt Class Initialized
DEBUG - 2016-12-29 03:53:52 --> Session routines successfully run
ERROR - 2016-12-29 03:53:52 --> Could not find the language line "first_link"
ERROR - 2016-12-29 03:53:52 --> Could not find the language line "last_link"
ERROR - 2016-12-29 03:53:52 --> Could not find the language line "next_link"
ERROR - 2016-12-29 03:53:52 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 03:53:52 --> Pagination Class Initialized
DEBUG - 2016-12-29 03:53:52 --> Table Class Initialized
DEBUG - 2016-12-29 03:53:52 --> Model Class Initialized
DEBUG - 2016-12-29 03:53:52 --> Model Class Initialized
DEBUG - 2016-12-29 03:53:52 --> Helper loaded: file_helper
DEBUG - 2016-12-29 03:53:52 --> Model Class Initialized
DEBUG - 2016-12-29 03:53:52 --> Controller Class Initialized
DEBUG - 2016-12-29 03:53:52 --> Form Validation Class Initialized
DEBUG - 2016-12-29 03:53:52 --> Helper loaded: language_helper
DEBUG - 2016-12-29 03:53:52 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 03:53:54 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 03:53:54 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 03:53:54 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 03:53:54 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 03:53:54 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 03:53:54 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 03:53:54 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 03:53:54 --> Final output sent to browser
DEBUG - 2016-12-29 03:53:54 --> Total execution time: 2.1901
DEBUG - 2016-12-29 03:53:54 --> Config Class Initialized
DEBUG - 2016-12-29 03:53:54 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:53:54 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:53:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:53:54 --> URI Class Initialized
DEBUG - 2016-12-29 03:53:54 --> Router Class Initialized
ERROR - 2016-12-29 03:53:54 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:53:54 --> Config Class Initialized
DEBUG - 2016-12-29 03:53:54 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:53:54 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:53:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:53:54 --> URI Class Initialized
DEBUG - 2016-12-29 03:53:54 --> Router Class Initialized
ERROR - 2016-12-29 03:53:54 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:53:54 --> Config Class Initialized
DEBUG - 2016-12-29 03:53:54 --> Config Class Initialized
DEBUG - 2016-12-29 03:53:54 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:53:54 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:53:54 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:53:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:53:54 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:53:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:53:54 --> URI Class Initialized
DEBUG - 2016-12-29 03:53:54 --> URI Class Initialized
DEBUG - 2016-12-29 03:53:54 --> Router Class Initialized
ERROR - 2016-12-29 03:53:54 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:53:54 --> Router Class Initialized
ERROR - 2016-12-29 03:53:54 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:53:54 --> Config Class Initialized
DEBUG - 2016-12-29 03:53:54 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:53:54 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:53:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:53:54 --> URI Class Initialized
DEBUG - 2016-12-29 03:53:54 --> Router Class Initialized
ERROR - 2016-12-29 03:53:54 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:54:35 --> Config Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:54:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:54:35 --> URI Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Router Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Output Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Security Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Input Class Initialized
DEBUG - 2016-12-29 03:54:35 --> XSS Filtering completed
DEBUG - 2016-12-29 03:54:35 --> XSS Filtering completed
DEBUG - 2016-12-29 03:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 03:54:35 --> Language Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Loader Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Helper loaded: url_helper
DEBUG - 2016-12-29 03:54:35 --> Helper loaded: form_helper
DEBUG - 2016-12-29 03:54:35 --> Helper loaded: func_helper
DEBUG - 2016-12-29 03:54:35 --> Database Driver Class Initialized
ERROR - 2016-12-29 03:54:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-12-29 03:54:35 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 03:54:35 --> Session Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Helper loaded: string_helper
DEBUG - 2016-12-29 03:54:35 --> Encrypt Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Session routines successfully run
ERROR - 2016-12-29 03:54:35 --> Could not find the language line "first_link"
ERROR - 2016-12-29 03:54:35 --> Could not find the language line "last_link"
ERROR - 2016-12-29 03:54:35 --> Could not find the language line "next_link"
ERROR - 2016-12-29 03:54:35 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 03:54:35 --> Pagination Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Table Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Model Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Model Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Helper loaded: file_helper
DEBUG - 2016-12-29 03:54:35 --> Model Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Controller Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Form Validation Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Helper loaded: language_helper
DEBUG - 2016-12-29 03:54:35 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 03:54:35 --> Config Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:54:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:54:35 --> URI Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Router Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Output Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Security Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Input Class Initialized
DEBUG - 2016-12-29 03:54:35 --> XSS Filtering completed
DEBUG - 2016-12-29 03:54:35 --> XSS Filtering completed
DEBUG - 2016-12-29 03:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 03:54:35 --> Language Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Loader Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Helper loaded: url_helper
DEBUG - 2016-12-29 03:54:35 --> Helper loaded: form_helper
DEBUG - 2016-12-29 03:54:35 --> Helper loaded: func_helper
DEBUG - 2016-12-29 03:54:35 --> Database Driver Class Initialized
ERROR - 2016-12-29 03:54:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 03:54:35 --> Session Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Helper loaded: string_helper
DEBUG - 2016-12-29 03:54:35 --> Encrypt Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Session routines successfully run
ERROR - 2016-12-29 03:54:35 --> Could not find the language line "first_link"
ERROR - 2016-12-29 03:54:35 --> Could not find the language line "last_link"
ERROR - 2016-12-29 03:54:35 --> Could not find the language line "next_link"
ERROR - 2016-12-29 03:54:35 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 03:54:35 --> Pagination Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Table Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Model Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Model Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Helper loaded: file_helper
DEBUG - 2016-12-29 03:54:35 --> Model Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Controller Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Form Validation Class Initialized
DEBUG - 2016-12-29 03:54:35 --> Helper loaded: language_helper
DEBUG - 2016-12-29 03:54:35 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 03:54:37 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 03:54:37 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 03:54:37 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 03:54:37 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 03:54:37 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 03:54:37 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 03:54:37 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 03:54:37 --> Final output sent to browser
DEBUG - 2016-12-29 03:54:37 --> Total execution time: 2.1341
DEBUG - 2016-12-29 03:54:59 --> Config Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:54:59 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:54:59 --> URI Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Router Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Output Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Security Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Input Class Initialized
DEBUG - 2016-12-29 03:54:59 --> XSS Filtering completed
DEBUG - 2016-12-29 03:54:59 --> XSS Filtering completed
DEBUG - 2016-12-29 03:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 03:54:59 --> Language Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Loader Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Helper loaded: url_helper
DEBUG - 2016-12-29 03:54:59 --> Helper loaded: form_helper
DEBUG - 2016-12-29 03:54:59 --> Helper loaded: func_helper
DEBUG - 2016-12-29 03:54:59 --> Database Driver Class Initialized
ERROR - 2016-12-29 03:54:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 03:54:59 --> Session Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Helper loaded: string_helper
DEBUG - 2016-12-29 03:54:59 --> Encrypt Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Session routines successfully run
ERROR - 2016-12-29 03:54:59 --> Could not find the language line "first_link"
ERROR - 2016-12-29 03:54:59 --> Could not find the language line "last_link"
ERROR - 2016-12-29 03:54:59 --> Could not find the language line "next_link"
ERROR - 2016-12-29 03:54:59 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 03:54:59 --> Pagination Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Table Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Model Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Model Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Helper loaded: file_helper
DEBUG - 2016-12-29 03:54:59 --> Model Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Controller Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Form Validation Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Helper loaded: language_helper
DEBUG - 2016-12-29 03:54:59 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 03:54:59 --> Config Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:54:59 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:54:59 --> URI Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Router Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Output Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Security Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Input Class Initialized
DEBUG - 2016-12-29 03:54:59 --> XSS Filtering completed
DEBUG - 2016-12-29 03:54:59 --> XSS Filtering completed
DEBUG - 2016-12-29 03:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 03:54:59 --> Language Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Loader Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Helper loaded: url_helper
DEBUG - 2016-12-29 03:54:59 --> Helper loaded: form_helper
DEBUG - 2016-12-29 03:54:59 --> Helper loaded: func_helper
DEBUG - 2016-12-29 03:54:59 --> Database Driver Class Initialized
ERROR - 2016-12-29 03:54:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 03:54:59 --> Session Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Helper loaded: string_helper
DEBUG - 2016-12-29 03:54:59 --> Encrypt Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Session routines successfully run
ERROR - 2016-12-29 03:54:59 --> Could not find the language line "first_link"
ERROR - 2016-12-29 03:54:59 --> Could not find the language line "last_link"
ERROR - 2016-12-29 03:54:59 --> Could not find the language line "next_link"
ERROR - 2016-12-29 03:54:59 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 03:54:59 --> Pagination Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Table Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Model Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Model Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Helper loaded: file_helper
DEBUG - 2016-12-29 03:54:59 --> Model Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Controller Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Form Validation Class Initialized
DEBUG - 2016-12-29 03:54:59 --> Helper loaded: language_helper
DEBUG - 2016-12-29 03:54:59 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 03:55:01 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 03:55:01 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 03:55:01 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 03:55:01 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 03:55:01 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 03:55:01 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 03:55:01 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 03:55:01 --> Final output sent to browser
DEBUG - 2016-12-29 03:55:01 --> Total execution time: 1.8591
DEBUG - 2016-12-29 03:58:12 --> Config Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:58:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:58:12 --> URI Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Router Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Output Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Security Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Input Class Initialized
DEBUG - 2016-12-29 03:58:12 --> XSS Filtering completed
DEBUG - 2016-12-29 03:58:12 --> XSS Filtering completed
DEBUG - 2016-12-29 03:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 03:58:12 --> Language Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Loader Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Helper loaded: url_helper
DEBUG - 2016-12-29 03:58:12 --> Helper loaded: form_helper
DEBUG - 2016-12-29 03:58:12 --> Helper loaded: func_helper
DEBUG - 2016-12-29 03:58:12 --> Database Driver Class Initialized
ERROR - 2016-12-29 03:58:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 03:58:12 --> Session Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Helper loaded: string_helper
DEBUG - 2016-12-29 03:58:12 --> Encrypt Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Session routines successfully run
ERROR - 2016-12-29 03:58:12 --> Could not find the language line "first_link"
ERROR - 2016-12-29 03:58:12 --> Could not find the language line "last_link"
ERROR - 2016-12-29 03:58:12 --> Could not find the language line "next_link"
ERROR - 2016-12-29 03:58:12 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 03:58:12 --> Pagination Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Table Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Model Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Model Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Helper loaded: file_helper
DEBUG - 2016-12-29 03:58:12 --> Model Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Controller Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Form Validation Class Initialized
DEBUG - 2016-12-29 03:58:12 --> Helper loaded: language_helper
DEBUG - 2016-12-29 03:58:12 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 03:58:14 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 03:58:14 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 03:58:14 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 03:58:14 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 03:58:14 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 03:58:14 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 03:58:14 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 03:58:14 --> Final output sent to browser
DEBUG - 2016-12-29 03:58:14 --> Total execution time: 2.1261
DEBUG - 2016-12-29 03:58:14 --> Config Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Config Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:58:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:58:14 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:58:14 --> URI Class Initialized
DEBUG - 2016-12-29 03:58:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:58:14 --> Config Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Router Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:58:14 --> URI Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Utf8 Class Initialized
ERROR - 2016-12-29 03:58:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:58:14 --> Router Class Initialized
DEBUG - 2016-12-29 03:58:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:58:14 --> URI Class Initialized
ERROR - 2016-12-29 03:58:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:58:14 --> Router Class Initialized
ERROR - 2016-12-29 03:58:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:58:14 --> Config Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:58:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:58:14 --> URI Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Router Class Initialized
ERROR - 2016-12-29 03:58:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:58:14 --> Config Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:58:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:58:14 --> Config Class Initialized
DEBUG - 2016-12-29 03:58:14 --> URI Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Router Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:58:14 --> UTF-8 Support Enabled
ERROR - 2016-12-29 03:58:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:58:14 --> URI Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Router Class Initialized
ERROR - 2016-12-29 03:58:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:58:14 --> Config Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:58:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:58:14 --> Config Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:58:14 --> URI Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:58:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:58:14 --> Router Class Initialized
DEBUG - 2016-12-29 03:58:14 --> URI Class Initialized
ERROR - 2016-12-29 03:58:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:58:14 --> Router Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Config Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Hooks Class Initialized
ERROR - 2016-12-29 03:58:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:58:14 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:58:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:58:14 --> URI Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Router Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Config Class Initialized
ERROR - 2016-12-29 03:58:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:58:14 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:58:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:58:14 --> URI Class Initialized
DEBUG - 2016-12-29 03:58:14 --> Router Class Initialized
ERROR - 2016-12-29 03:58:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:59:33 --> Config Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:59:33 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:59:33 --> URI Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Router Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Output Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Security Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Input Class Initialized
DEBUG - 2016-12-29 03:59:33 --> XSS Filtering completed
DEBUG - 2016-12-29 03:59:33 --> XSS Filtering completed
DEBUG - 2016-12-29 03:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 03:59:33 --> Language Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Loader Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Helper loaded: url_helper
DEBUG - 2016-12-29 03:59:33 --> Helper loaded: form_helper
DEBUG - 2016-12-29 03:59:33 --> Helper loaded: func_helper
DEBUG - 2016-12-29 03:59:33 --> Database Driver Class Initialized
ERROR - 2016-12-29 03:59:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 03:59:33 --> Session Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Helper loaded: string_helper
DEBUG - 2016-12-29 03:59:33 --> Encrypt Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Session routines successfully run
ERROR - 2016-12-29 03:59:33 --> Could not find the language line "first_link"
ERROR - 2016-12-29 03:59:33 --> Could not find the language line "last_link"
ERROR - 2016-12-29 03:59:33 --> Could not find the language line "next_link"
ERROR - 2016-12-29 03:59:33 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 03:59:33 --> Pagination Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Table Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Model Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Model Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Helper loaded: file_helper
DEBUG - 2016-12-29 03:59:33 --> Model Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Controller Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Form Validation Class Initialized
DEBUG - 2016-12-29 03:59:33 --> Helper loaded: language_helper
DEBUG - 2016-12-29 03:59:33 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 03:59:35 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 03:59:35 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 03:59:35 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 03:59:35 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 03:59:35 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 03:59:35 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 03:59:35 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 03:59:35 --> Final output sent to browser
DEBUG - 2016-12-29 03:59:35 --> Total execution time: 2.3291
DEBUG - 2016-12-29 03:59:35 --> Config Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Config Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:59:35 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:59:35 --> URI Class Initialized
DEBUG - 2016-12-29 03:59:35 --> URI Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Router Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Router Class Initialized
ERROR - 2016-12-29 03:59:35 --> 404 Page Not Found --> application
ERROR - 2016-12-29 03:59:35 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:59:35 --> Config Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Config Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Config Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:59:35 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:59:35 --> URI Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Router Class Initialized
DEBUG - 2016-12-29 03:59:35 --> URI Class Initialized
DEBUG - 2016-12-29 03:59:35 --> UTF-8 Support Enabled
ERROR - 2016-12-29 03:59:35 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:59:35 --> Router Class Initialized
DEBUG - 2016-12-29 03:59:35 --> URI Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Router Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Config Class Initialized
ERROR - 2016-12-29 03:59:35 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:59:35 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:59:35 --> URI Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Config Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Router Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Utf8 Class Initialized
ERROR - 2016-12-29 03:59:35 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:59:35 --> URI Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Router Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Config Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Hooks Class Initialized
ERROR - 2016-12-29 03:59:35 --> 404 Page Not Found --> application
ERROR - 2016-12-29 03:59:35 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:59:35 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:59:35 --> URI Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Router Class Initialized
ERROR - 2016-12-29 03:59:35 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:59:35 --> Config Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:59:35 --> Config Class Initialized
DEBUG - 2016-12-29 03:59:35 --> URI Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Hooks Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Router Class Initialized
DEBUG - 2016-12-29 03:59:35 --> Utf8 Class Initialized
DEBUG - 2016-12-29 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 03:59:35 --> URI Class Initialized
ERROR - 2016-12-29 03:59:35 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 03:59:35 --> Router Class Initialized
ERROR - 2016-12-29 03:59:35 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:00:19 --> Config Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:00:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:00:19 --> URI Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Router Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Output Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Security Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Input Class Initialized
DEBUG - 2016-12-29 04:00:19 --> XSS Filtering completed
DEBUG - 2016-12-29 04:00:19 --> XSS Filtering completed
DEBUG - 2016-12-29 04:00:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:00:19 --> Language Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Loader Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:00:19 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:00:19 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:00:19 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:00:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:00:19 --> Session Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:00:19 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Session routines successfully run
ERROR - 2016-12-29 04:00:19 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:00:19 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:00:19 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:00:19 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:00:19 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Table Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Model Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Model Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:00:19 --> Model Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Controller Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Form Validation Class Initialized
DEBUG - 2016-12-29 04:00:19 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:00:19 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:00:21 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:00:21 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 04:00:21 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 04:00:21 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 04:00:21 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 04:00:21 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 04:00:21 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 04:00:21 --> Final output sent to browser
DEBUG - 2016-12-29 04:00:21 --> Total execution time: 2.4461
DEBUG - 2016-12-29 04:00:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:00:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Router Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:00:21 --> URI Class Initialized
ERROR - 2016-12-29 04:00:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:00:21 --> Router Class Initialized
ERROR - 2016-12-29 04:00:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:00:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:00:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Router Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:00:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:00:21 --> URI Class Initialized
ERROR - 2016-12-29 04:00:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:00:21 --> Router Class Initialized
ERROR - 2016-12-29 04:00:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:00:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:00:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Router Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Hooks Class Initialized
ERROR - 2016-12-29 04:00:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:00:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:00:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:00:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:00:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:00:21 --> Router Class Initialized
DEBUG - 2016-12-29 04:00:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Router Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Router Class Initialized
ERROR - 2016-12-29 04:00:21 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:00:21 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:00:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:00:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:00:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:00:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:00:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Router Class Initialized
DEBUG - 2016-12-29 04:00:21 --> Router Class Initialized
ERROR - 2016-12-29 04:00:21 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:00:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:05:45 --> Config Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:05:45 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:05:45 --> URI Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Router Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Output Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Security Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Input Class Initialized
DEBUG - 2016-12-29 04:05:45 --> XSS Filtering completed
DEBUG - 2016-12-29 04:05:45 --> XSS Filtering completed
DEBUG - 2016-12-29 04:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:05:45 --> Language Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Loader Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:05:45 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:05:45 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:05:45 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:05:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:05:45 --> Session Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:05:45 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Session routines successfully run
ERROR - 2016-12-29 04:05:45 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:05:45 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:05:45 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:05:45 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:05:45 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Table Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Model Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Model Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:05:45 --> Model Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Controller Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Form Validation Class Initialized
DEBUG - 2016-12-29 04:05:45 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:05:45 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:05:46 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:05:46 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 04:05:46 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 04:05:46 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 04:05:46 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 04:05:46 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 04:05:46 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 04:05:46 --> Final output sent to browser
DEBUG - 2016-12-29 04:05:46 --> Total execution time: 1.8061
DEBUG - 2016-12-29 04:05:47 --> Config Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Config Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Config Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:05:47 --> Config Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:05:47 --> URI Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:05:47 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:05:47 --> URI Class Initialized
DEBUG - 2016-12-29 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:05:47 --> URI Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Router Class Initialized
DEBUG - 2016-12-29 04:05:47 --> URI Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Router Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Config Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Router Class Initialized
ERROR - 2016-12-29 04:05:47 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:05:47 --> Router Class Initialized
ERROR - 2016-12-29 04:05:47 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:05:47 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:05:47 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:05:47 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:05:47 --> URI Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Router Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Config Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:05:47 --> URI Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Router Class Initialized
ERROR - 2016-12-29 04:05:47 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:05:47 --> Config Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:05:47 --> URI Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Config Class Initialized
ERROR - 2016-12-29 04:05:47 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:05:47 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Router Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:05:47 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:05:47 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:05:47 --> Config Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Config Class Initialized
DEBUG - 2016-12-29 04:05:47 --> URI Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Router Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:05:47 --> Utf8 Class Initialized
ERROR - 2016-12-29 04:05:47 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:05:47 --> URI Class Initialized
DEBUG - 2016-12-29 04:05:47 --> Router Class Initialized
DEBUG - 2016-12-29 04:05:47 --> URI Class Initialized
ERROR - 2016-12-29 04:05:47 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:05:47 --> Router Class Initialized
ERROR - 2016-12-29 04:05:47 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:11 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:11 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Router Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Output Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Security Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Input Class Initialized
DEBUG - 2016-12-29 04:06:11 --> XSS Filtering completed
DEBUG - 2016-12-29 04:06:11 --> XSS Filtering completed
DEBUG - 2016-12-29 04:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:06:11 --> Language Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Loader Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:06:11 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:06:11 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:06:11 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:06:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:06:11 --> Session Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:06:11 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Session routines successfully run
ERROR - 2016-12-29 04:06:11 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:06:11 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:06:11 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:06:11 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:06:11 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Table Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Model Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Model Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:06:11 --> Model Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Controller Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Form Validation Class Initialized
DEBUG - 2016-12-29 04:06:11 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:06:11 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:06:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:06:13 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 04:06:13 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 04:06:13 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 04:06:13 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 04:06:13 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 04:06:13 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 04:06:13 --> Final output sent to browser
DEBUG - 2016-12-29 04:06:13 --> Total execution time: 2.0971
DEBUG - 2016-12-29 04:06:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Router Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Router Class Initialized
ERROR - 2016-12-29 04:06:13 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:06:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Router Class Initialized
ERROR - 2016-12-29 04:06:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Router Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Hooks Class Initialized
ERROR - 2016-12-29 04:06:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Router Class Initialized
DEBUG - 2016-12-29 04:06:13 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:06:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Router Class Initialized
ERROR - 2016-12-29 04:06:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Router Class Initialized
DEBUG - 2016-12-29 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:13 --> URI Class Initialized
ERROR - 2016-12-29 04:06:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Router Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Router Class Initialized
ERROR - 2016-12-29 04:06:13 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:06:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:13 --> Router Class Initialized
ERROR - 2016-12-29 04:06:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:20 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:20 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:20 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Router Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Output Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Security Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Input Class Initialized
DEBUG - 2016-12-29 04:06:20 --> XSS Filtering completed
DEBUG - 2016-12-29 04:06:20 --> XSS Filtering completed
DEBUG - 2016-12-29 04:06:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:06:20 --> Language Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Loader Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:06:20 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:06:20 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:06:20 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:06:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:06:20 --> Session Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:06:20 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Session routines successfully run
ERROR - 2016-12-29 04:06:20 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:06:20 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:06:20 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:06:20 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:06:20 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Table Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Model Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Model Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:06:20 --> Model Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Controller Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Form Validation Class Initialized
DEBUG - 2016-12-29 04:06:20 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:06:20 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:06:22 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:06:22 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 04:06:22 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 04:06:22 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 04:06:22 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 04:06:22 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 04:06:22 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 04:06:22 --> Final output sent to browser
DEBUG - 2016-12-29 04:06:22 --> Total execution time: 2.0561
DEBUG - 2016-12-29 04:06:22 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:22 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:22 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:22 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:22 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:22 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:22 --> Router Class Initialized
DEBUG - 2016-12-29 04:06:22 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:22 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:06:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:22 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:22 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:22 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:22 --> Router Class Initialized
DEBUG - 2016-12-29 04:06:22 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:22 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:22 --> Router Class Initialized
ERROR - 2016-12-29 04:06:22 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:06:22 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:22 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:22 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:23 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Router Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Utf8 Class Initialized
ERROR - 2016-12-29 04:06:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:23 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:23 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Router Class Initialized
DEBUG - 2016-12-29 04:06:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:23 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Router Class Initialized
ERROR - 2016-12-29 04:06:23 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:06:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:23 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:23 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:23 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:23 --> Router Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Hooks Class Initialized
ERROR - 2016-12-29 04:06:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:23 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:23 --> Router Class Initialized
DEBUG - 2016-12-29 04:06:23 --> URI Class Initialized
ERROR - 2016-12-29 04:06:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:23 --> Router Class Initialized
ERROR - 2016-12-29 04:06:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:06:23 --> Config Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:06:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:06:23 --> URI Class Initialized
DEBUG - 2016-12-29 04:06:23 --> Router Class Initialized
ERROR - 2016-12-29 04:06:23 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:07:12 --> Config Class Initialized
DEBUG - 2016-12-29 04:07:12 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:07:12 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:07:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:07:12 --> URI Class Initialized
DEBUG - 2016-12-29 04:07:12 --> Router Class Initialized
DEBUG - 2016-12-29 04:07:12 --> Output Class Initialized
DEBUG - 2016-12-29 04:07:12 --> Security Class Initialized
DEBUG - 2016-12-29 04:07:12 --> Input Class Initialized
DEBUG - 2016-12-29 04:07:12 --> XSS Filtering completed
DEBUG - 2016-12-29 04:07:12 --> XSS Filtering completed
DEBUG - 2016-12-29 04:07:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:07:12 --> Language Class Initialized
DEBUG - 2016-12-29 04:07:12 --> Loader Class Initialized
DEBUG - 2016-12-29 04:07:12 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:07:13 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:07:13 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:07:13 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:07:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:07:13 --> Session Class Initialized
DEBUG - 2016-12-29 04:07:13 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:07:13 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:07:13 --> Session routines successfully run
ERROR - 2016-12-29 04:07:13 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:07:13 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:07:13 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:07:13 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:07:13 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:07:13 --> Table Class Initialized
DEBUG - 2016-12-29 04:07:13 --> Model Class Initialized
DEBUG - 2016-12-29 04:07:13 --> Model Class Initialized
DEBUG - 2016-12-29 04:07:13 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:07:13 --> Model Class Initialized
DEBUG - 2016-12-29 04:07:13 --> Controller Class Initialized
DEBUG - 2016-12-29 04:07:13 --> Form Validation Class Initialized
DEBUG - 2016-12-29 04:07:13 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:07:13 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:07:15 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:07:15 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 04:07:15 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 04:07:15 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 04:07:15 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 04:07:15 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 04:07:15 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 04:07:15 --> Final output sent to browser
DEBUG - 2016-12-29 04:07:15 --> Total execution time: 2.2751
DEBUG - 2016-12-29 04:07:15 --> Config Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:07:15 --> URI Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Router Class Initialized
ERROR - 2016-12-29 04:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:07:15 --> Config Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:07:15 --> URI Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Router Class Initialized
ERROR - 2016-12-29 04:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:07:15 --> Config Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Config Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:07:15 --> URI Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:07:15 --> Router Class Initialized
DEBUG - 2016-12-29 04:07:15 --> URI Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Router Class Initialized
ERROR - 2016-12-29 04:07:15 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:07:15 --> Config Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:07:15 --> URI Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Router Class Initialized
ERROR - 2016-12-29 04:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:07:15 --> Config Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:07:15 --> URI Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Router Class Initialized
ERROR - 2016-12-29 04:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:07:15 --> Config Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:07:15 --> URI Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Router Class Initialized
ERROR - 2016-12-29 04:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:07:15 --> Config Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Config Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:07:15 --> URI Class Initialized
DEBUG - 2016-12-29 04:07:15 --> URI Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Config Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Router Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Router Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Utf8 Class Initialized
ERROR - 2016-12-29 04:07:15 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:07:15 --> URI Class Initialized
DEBUG - 2016-12-29 04:07:15 --> Router Class Initialized
ERROR - 2016-12-29 04:07:15 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:08:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:08:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:08:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:08:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:08:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:08:13 --> Router Class Initialized
DEBUG - 2016-12-29 04:08:13 --> Output Class Initialized
DEBUG - 2016-12-29 04:08:13 --> Security Class Initialized
DEBUG - 2016-12-29 04:08:13 --> Input Class Initialized
DEBUG - 2016-12-29 04:08:13 --> XSS Filtering completed
DEBUG - 2016-12-29 04:08:13 --> XSS Filtering completed
DEBUG - 2016-12-29 04:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:08:14 --> Language Class Initialized
DEBUG - 2016-12-29 04:08:14 --> Loader Class Initialized
DEBUG - 2016-12-29 04:08:14 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:08:14 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:08:14 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:08:14 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:08:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:08:14 --> Session Class Initialized
DEBUG - 2016-12-29 04:08:14 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:08:14 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:08:14 --> Session routines successfully run
ERROR - 2016-12-29 04:08:14 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:08:14 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:08:14 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:08:14 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:08:14 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:08:14 --> Table Class Initialized
DEBUG - 2016-12-29 04:08:14 --> Model Class Initialized
DEBUG - 2016-12-29 04:08:14 --> Model Class Initialized
DEBUG - 2016-12-29 04:08:14 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:08:14 --> Model Class Initialized
DEBUG - 2016-12-29 04:08:14 --> Controller Class Initialized
DEBUG - 2016-12-29 04:08:14 --> Form Validation Class Initialized
DEBUG - 2016-12-29 04:08:14 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:08:14 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:08:18 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:08:18 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 04:08:18 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 04:08:18 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 04:08:18 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 04:08:18 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 04:08:18 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 04:08:18 --> Final output sent to browser
DEBUG - 2016-12-29 04:08:18 --> Total execution time: 4.5033
DEBUG - 2016-12-29 04:08:18 --> Config Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:08:18 --> URI Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Router Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Config Class Initialized
ERROR - 2016-12-29 04:08:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:08:18 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Config Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Config Class Initialized
DEBUG - 2016-12-29 04:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:08:18 --> Config Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:08:18 --> URI Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:08:18 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Config Class Initialized
DEBUG - 2016-12-29 04:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:08:18 --> Router Class Initialized
DEBUG - 2016-12-29 04:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:08:18 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:08:18 --> URI Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:08:18 --> URI Class Initialized
ERROR - 2016-12-29 04:08:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:08:18 --> Router Class Initialized
DEBUG - 2016-12-29 04:08:18 --> URI Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Router Class Initialized
DEBUG - 2016-12-29 04:08:18 --> URI Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Config Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Router Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Hooks Class Initialized
ERROR - 2016-12-29 04:08:18 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:08:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:08:18 --> Router Class Initialized
ERROR - 2016-12-29 04:08:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:08:18 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:08:18 --> URI Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Router Class Initialized
ERROR - 2016-12-29 04:08:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:08:18 --> Config Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:08:18 --> URI Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Router Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Config Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Hooks Class Initialized
ERROR - 2016-12-29 04:08:18 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:08:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:08:18 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:08:18 --> URI Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Router Class Initialized
ERROR - 2016-12-29 04:08:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:08:18 --> Config Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:08:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:08:18 --> URI Class Initialized
DEBUG - 2016-12-29 04:08:18 --> Router Class Initialized
ERROR - 2016-12-29 04:08:18 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:10:40 --> Config Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:10:40 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:10:40 --> URI Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Router Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Output Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Security Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Input Class Initialized
DEBUG - 2016-12-29 04:10:40 --> XSS Filtering completed
DEBUG - 2016-12-29 04:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:10:40 --> Language Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Loader Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:10:40 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:10:40 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:10:40 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:10:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:10:40 --> Session Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:10:40 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:10:40 --> A session cookie was not found.
DEBUG - 2016-12-29 04:10:40 --> Session routines successfully run
ERROR - 2016-12-29 04:10:40 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:10:40 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:10:40 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:10:40 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:10:40 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Table Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Model Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Model Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:10:40 --> Model Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Controller Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:10:40 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:10:40 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:10:40 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-29 04:10:40 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-29 04:10:40 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-29 04:10:40 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-29 04:10:40 --> Final output sent to browser
DEBUG - 2016-12-29 04:10:40 --> Total execution time: 0.0950
DEBUG - 2016-12-29 04:10:40 --> Config Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:10:40 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:10:40 --> URI Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Router Class Initialized
ERROR - 2016-12-29 04:10:40 --> 404 Page Not Found --> js
DEBUG - 2016-12-29 04:10:40 --> Config Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:10:40 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:10:40 --> URI Class Initialized
DEBUG - 2016-12-29 04:10:40 --> Router Class Initialized
ERROR - 2016-12-29 04:10:40 --> 404 Page Not Found --> js
DEBUG - 2016-12-29 04:10:50 --> Config Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:10:50 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:10:50 --> URI Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Router Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Output Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Security Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Input Class Initialized
DEBUG - 2016-12-29 04:10:50 --> XSS Filtering completed
DEBUG - 2016-12-29 04:10:50 --> XSS Filtering completed
DEBUG - 2016-12-29 04:10:50 --> XSS Filtering completed
DEBUG - 2016-12-29 04:10:50 --> XSS Filtering completed
DEBUG - 2016-12-29 04:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:10:50 --> Language Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Loader Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:10:50 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:10:50 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:10:50 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:10:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:10:50 --> Session Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:10:50 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Session routines successfully run
ERROR - 2016-12-29 04:10:50 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:10:50 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:10:50 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:10:50 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:10:50 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Table Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Model Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Model Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:10:50 --> Model Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Controller Class Initialized
DEBUG - 2016-12-29 04:10:50 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:10:50 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:10:50 --> Model Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Config Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:10:52 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:10:52 --> URI Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Router Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Output Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Security Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Input Class Initialized
DEBUG - 2016-12-29 04:10:52 --> XSS Filtering completed
DEBUG - 2016-12-29 04:10:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:10:52 --> Language Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Loader Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:10:52 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:10:52 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:10:52 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:10:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:10:52 --> Session Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:10:52 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Session routines successfully run
ERROR - 2016-12-29 04:10:52 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:10:52 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:10:52 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:10:52 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:10:52 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Table Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Model Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Model Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:10:52 --> Model Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Controller Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Form Validation Class Initialized
DEBUG - 2016-12-29 04:10:52 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:10:52 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:10:54 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:10:54 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 04:10:54 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 04:10:54 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 04:10:54 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 04:10:54 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 04:10:54 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 04:10:54 --> Final output sent to browser
DEBUG - 2016-12-29 04:10:54 --> Total execution time: 2.1651
DEBUG - 2016-12-29 04:10:54 --> Config Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:10:54 --> Config Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:10:54 --> URI Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:10:54 --> Router Class Initialized
DEBUG - 2016-12-29 04:10:54 --> URI Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Router Class Initialized
ERROR - 2016-12-29 04:10:54 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:10:54 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:10:54 --> Config Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:10:54 --> URI Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Router Class Initialized
ERROR - 2016-12-29 04:10:54 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:10:54 --> Config Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:10:54 --> URI Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Router Class Initialized
ERROR - 2016-12-29 04:10:54 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:10:54 --> Config Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Config Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:10:54 --> URI Class Initialized
DEBUG - 2016-12-29 04:10:54 --> URI Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Router Class Initialized
ERROR - 2016-12-29 04:10:54 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:10:54 --> Router Class Initialized
ERROR - 2016-12-29 04:10:54 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:10:54 --> Config Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:10:54 --> URI Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Router Class Initialized
ERROR - 2016-12-29 04:10:54 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:10:54 --> Config Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:10:54 --> URI Class Initialized
DEBUG - 2016-12-29 04:10:54 --> Router Class Initialized
ERROR - 2016-12-29 04:10:54 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:05 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:05 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:05 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Router Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Output Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Security Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Input Class Initialized
DEBUG - 2016-12-29 04:11:05 --> XSS Filtering completed
DEBUG - 2016-12-29 04:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:11:05 --> Language Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Loader Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:11:05 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:11:05 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:11:05 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:11:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:11:05 --> Session Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:11:05 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Session routines successfully run
ERROR - 2016-12-29 04:11:05 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:11:05 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:11:05 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:11:05 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:11:05 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Table Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Model Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Model Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:11:05 --> Model Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Controller Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Form Validation Class Initialized
DEBUG - 2016-12-29 04:11:05 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:11:05 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:11:07 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:11:07 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 04:11:07 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 04:11:07 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 04:11:07 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 04:11:07 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 04:11:07 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 04:11:07 --> Final output sent to browser
DEBUG - 2016-12-29 04:11:07 --> Total execution time: 1.8851
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Utf8 Class Initialized
ERROR - 2016-12-29 04:11:07 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:07 --> Router Class Initialized
DEBUG - 2016-12-29 04:11:08 --> Config Class Initialized
ERROR - 2016-12-29 04:11:08 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:08 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:08 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:08 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:08 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:08 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:08 --> Config Class Initialized
DEBUG - 2016-12-29 04:11:08 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:11:08 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:08 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:08 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:11:08 --> Router Class Initialized
DEBUG - 2016-12-29 04:11:08 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:08 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:11:08 --> URI Class Initialized
DEBUG - 2016-12-29 04:11:08 --> URI Class Initialized
ERROR - 2016-12-29 04:11:08 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:11:08 --> Router Class Initialized
DEBUG - 2016-12-29 04:11:08 --> Router Class Initialized
ERROR - 2016-12-29 04:11:08 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:11:08 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:28 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:28 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:28 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Output Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Security Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Input Class Initialized
DEBUG - 2016-12-29 04:12:28 --> XSS Filtering completed
DEBUG - 2016-12-29 04:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:12:28 --> Language Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Loader Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:12:28 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:12:28 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:12:28 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:12:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:12:28 --> Session Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:12:28 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Session routines successfully run
ERROR - 2016-12-29 04:12:28 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:12:28 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:12:28 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:12:28 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:12:28 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Table Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Model Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Model Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:12:28 --> Model Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Controller Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Form Validation Class Initialized
DEBUG - 2016-12-29 04:12:28 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:12:28 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:12:30 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:12:30 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 04:12:30 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 04:12:30 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 04:12:30 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 04:12:30 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 04:12:30 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 04:12:30 --> Final output sent to browser
DEBUG - 2016-12-29 04:12:30 --> Total execution time: 2.3431
DEBUG - 2016-12-29 04:12:30 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:30 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Router Class Initialized
ERROR - 2016-12-29 04:12:30 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:30 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:30 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:30 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:30 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Utf8 Class Initialized
ERROR - 2016-12-29 04:12:30 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:30 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:30 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Utf8 Class Initialized
ERROR - 2016-12-29 04:12:30 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:30 --> Utf8 Class Initialized
ERROR - 2016-12-29 04:12:30 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:30 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:30 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Hooks Class Initialized
ERROR - 2016-12-29 04:12:30 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:30 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:30 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:30 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Config Class Initialized
ERROR - 2016-12-29 04:12:30 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:30 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:30 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:30 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:30 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:12:30 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:30 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:30 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:12:30 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:30 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Router Class Initialized
ERROR - 2016-12-29 04:12:30 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:12:30 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:30 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:30 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:30 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:30 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:31 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:31 --> Hooks Class Initialized
ERROR - 2016-12-29 04:12:31 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:31 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:31 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:31 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:31 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:31 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:12:31 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:31 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Router Class Initialized
ERROR - 2016-12-29 04:12:31 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:31 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:31 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:31 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:31 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:31 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:12:31 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:31 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Router Class Initialized
ERROR - 2016-12-29 04:12:31 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:31 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:31 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:12:31 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:31 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Router Class Initialized
ERROR - 2016-12-29 04:12:31 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:12:31 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:12:31 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Config Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:31 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:12:31 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:12:31 --> URI Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Router Class Initialized
DEBUG - 2016-12-29 04:12:31 --> Router Class Initialized
ERROR - 2016-12-29 04:12:31 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:12:31 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:55 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:55 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:55 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Router Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Output Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Security Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Input Class Initialized
DEBUG - 2016-12-29 04:14:55 --> XSS Filtering completed
DEBUG - 2016-12-29 04:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:14:55 --> Language Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Loader Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:14:55 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:14:55 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:14:55 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:14:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:14:55 --> Session Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:14:55 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Session routines successfully run
ERROR - 2016-12-29 04:14:55 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:14:55 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:14:55 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:14:55 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:14:55 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Table Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Model Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Model Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:14:55 --> Model Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Controller Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Form Validation Class Initialized
DEBUG - 2016-12-29 04:14:55 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:14:55 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:14:56 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:14:56 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 04:14:56 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 04:14:56 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 04:14:56 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 04:14:56 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 04:14:56 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 04:14:56 --> Final output sent to browser
DEBUG - 2016-12-29 04:14:56 --> Total execution time: 1.6741
DEBUG - 2016-12-29 04:14:56 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:56 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:56 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Router Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Utf8 Class Initialized
ERROR - 2016-12-29 04:14:56 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:56 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:56 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Router Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:56 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:56 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:56 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Router Class Initialized
DEBUG - 2016-12-29 04:14:56 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:56 --> Utf8 Class Initialized
ERROR - 2016-12-29 04:14:56 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:14:56 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:56 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:56 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:56 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Router Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:56 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:14:56 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:56 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:56 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Router Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Router Class Initialized
ERROR - 2016-12-29 04:14:56 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:56 --> Config Class Initialized
ERROR - 2016-12-29 04:14:56 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:56 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:56 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:56 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:56 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:56 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:56 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:56 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Router Class Initialized
DEBUG - 2016-12-29 04:14:56 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:56 --> Router Class Initialized
DEBUG - 2016-12-29 04:14:56 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Router Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Utf8 Class Initialized
ERROR - 2016-12-29 04:14:56 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:14:56 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:56 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:14:56 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:56 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:56 --> Router Class Initialized
ERROR - 2016-12-29 04:14:56 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:57 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:57 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Router Class Initialized
ERROR - 2016-12-29 04:14:57 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:57 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:57 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Router Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:57 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Router Class Initialized
ERROR - 2016-12-29 04:14:57 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:57 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Hooks Class Initialized
ERROR - 2016-12-29 04:14:57 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:57 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:57 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:57 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:57 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:57 --> Router Class Initialized
DEBUG - 2016-12-29 04:14:57 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:57 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Router Class Initialized
ERROR - 2016-12-29 04:14:57 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:57 --> Router Class Initialized
ERROR - 2016-12-29 04:14:57 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:14:57 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:57 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:57 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:57 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Router Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:14:57 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:14:57 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:57 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:14:57 --> Router Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Config Class Initialized
DEBUG - 2016-12-29 04:14:57 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Router Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Utf8 Class Initialized
ERROR - 2016-12-29 04:14:57 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:57 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:14:57 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:14:57 --> URI Class Initialized
DEBUG - 2016-12-29 04:14:57 --> Router Class Initialized
ERROR - 2016-12-29 04:14:57 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:32 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:32 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:32 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Router Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Output Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Security Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Input Class Initialized
DEBUG - 2016-12-29 04:15:32 --> XSS Filtering completed
DEBUG - 2016-12-29 04:15:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:15:32 --> Language Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Loader Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:15:32 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:15:32 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:15:32 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:15:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:15:32 --> Session Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:15:32 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Session routines successfully run
ERROR - 2016-12-29 04:15:32 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:15:32 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:15:32 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:15:32 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:15:32 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Table Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Model Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Model Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:15:32 --> Model Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Controller Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Form Validation Class Initialized
DEBUG - 2016-12-29 04:15:32 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:15:32 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:15:34 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:15:34 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 04:15:34 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 04:15:34 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 04:15:34 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 04:15:34 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 04:15:34 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 04:15:34 --> Final output sent to browser
DEBUG - 2016-12-29 04:15:34 --> Total execution time: 2.0311
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Config Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:15:34 --> URI Class Initialized
DEBUG - 2016-12-29 04:15:34 --> Router Class Initialized
ERROR - 2016-12-29 04:15:34 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:11 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:11 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Router Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Output Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Security Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Input Class Initialized
DEBUG - 2016-12-29 04:19:11 --> XSS Filtering completed
DEBUG - 2016-12-29 04:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:19:11 --> Language Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Loader Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:19:11 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:19:11 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:19:11 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:19:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:19:11 --> Session Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:19:11 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Session routines successfully run
ERROR - 2016-12-29 04:19:11 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:19:11 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:19:11 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:19:11 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:19:11 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Table Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Model Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Model Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:19:11 --> Model Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Controller Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Form Validation Class Initialized
DEBUG - 2016-12-29 04:19:11 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:19:11 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:19:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:19:13 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 04:19:13 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 04:19:13 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 04:19:13 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 04:19:13 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 04:19:13 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 04:19:13 --> Final output sent to browser
DEBUG - 2016-12-29 04:19:13 --> Total execution time: 2.2631
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Router Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Router Class Initialized
DEBUG - 2016-12-29 04:19:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Router Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Router Class Initialized
ERROR - 2016-12-29 04:19:13 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:19:13 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:19:13 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:19:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Router Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Router Class Initialized
ERROR - 2016-12-29 04:19:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
ERROR - 2016-12-29 04:19:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Router Class Initialized
DEBUG - 2016-12-29 04:19:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Router Class Initialized
ERROR - 2016-12-29 04:19:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Router Class Initialized
ERROR - 2016-12-29 04:19:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> URI Class Initialized
ERROR - 2016-12-29 04:19:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:13 --> Router Class Initialized
ERROR - 2016-12-29 04:19:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Router Class Initialized
ERROR - 2016-12-29 04:19:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Router Class Initialized
ERROR - 2016-12-29 04:19:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Router Class Initialized
DEBUG - 2016-12-29 04:19:13 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Router Class Initialized
ERROR - 2016-12-29 04:19:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:13 --> Utf8 Class Initialized
ERROR - 2016-12-29 04:19:13 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:13 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:14 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:14 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:14 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:14 --> Router Class Initialized
DEBUG - 2016-12-29 04:19:14 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:14 --> Utf8 Class Initialized
ERROR - 2016-12-29 04:19:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:14 --> Config Class Initialized
DEBUG - 2016-12-29 04:19:14 --> Router Class Initialized
DEBUG - 2016-12-29 04:19:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:14 --> URI Class Initialized
ERROR - 2016-12-29 04:19:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:14 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:14 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:14 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:14 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:14 --> Router Class Initialized
DEBUG - 2016-12-29 04:19:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:14 --> URI Class Initialized
ERROR - 2016-12-29 04:19:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:14 --> Router Class Initialized
DEBUG - 2016-12-29 04:19:14 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:14 --> Router Class Initialized
ERROR - 2016-12-29 04:19:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:14 --> Config Class Initialized
ERROR - 2016-12-29 04:19:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:19:14 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:19:14 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:19:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:19:14 --> URI Class Initialized
DEBUG - 2016-12-29 04:19:14 --> Router Class Initialized
ERROR - 2016-12-29 04:19:14 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:49:18 --> Config Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:49:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:49:18 --> URI Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Router Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Output Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Security Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Input Class Initialized
DEBUG - 2016-12-29 04:49:18 --> XSS Filtering completed
DEBUG - 2016-12-29 04:49:18 --> XSS Filtering completed
DEBUG - 2016-12-29 04:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:49:18 --> Language Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Loader Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:49:18 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:49:18 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:49:18 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:49:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:49:18 --> Session Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:49:18 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Session routines successfully run
ERROR - 2016-12-29 04:49:18 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:49:18 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:49:18 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:49:18 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:49:18 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Table Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Model Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Model Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:49:18 --> Model Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Controller Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Form Validation Class Initialized
DEBUG - 2016-12-29 04:49:18 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:49:18 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:49:21 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:49:21 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-29 04:49:21 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-29 04:49:21 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-29 04:49:21 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-29 04:49:21 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-29 04:49:21 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-29 04:49:21 --> Final output sent to browser
DEBUG - 2016-12-29 04:49:21 --> Total execution time: 2.8322
DEBUG - 2016-12-29 04:49:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:49:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Router Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:49:21 --> Hooks Class Initialized
ERROR - 2016-12-29 04:49:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:49:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:49:21 --> Router Class Initialized
DEBUG - 2016-12-29 04:49:21 --> URI Class Initialized
ERROR - 2016-12-29 04:49:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:49:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Router Class Initialized
ERROR - 2016-12-29 04:49:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:49:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:49:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Router Class Initialized
ERROR - 2016-12-29 04:49:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:49:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:49:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:49:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:49:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:49:21 --> Router Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Router Class Initialized
DEBUG - 2016-12-29 04:49:21 --> URI Class Initialized
ERROR - 2016-12-29 04:49:21 --> 404 Page Not Found --> application
ERROR - 2016-12-29 04:49:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:49:21 --> Router Class Initialized
ERROR - 2016-12-29 04:49:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:49:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:49:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:49:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Router Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:49:21 --> UTF-8 Support Enabled
ERROR - 2016-12-29 04:49:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:49:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Router Class Initialized
ERROR - 2016-12-29 04:49:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:49:21 --> Config Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:49:21 --> URI Class Initialized
DEBUG - 2016-12-29 04:49:21 --> Router Class Initialized
ERROR - 2016-12-29 04:49:21 --> 404 Page Not Found --> application
DEBUG - 2016-12-29 04:49:30 --> Config Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:49:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:49:30 --> URI Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Router Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Output Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Security Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Input Class Initialized
DEBUG - 2016-12-29 04:49:30 --> XSS Filtering completed
DEBUG - 2016-12-29 04:49:30 --> XSS Filtering completed
DEBUG - 2016-12-29 04:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 04:49:30 --> Language Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Loader Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Helper loaded: url_helper
DEBUG - 2016-12-29 04:49:30 --> Helper loaded: form_helper
DEBUG - 2016-12-29 04:49:30 --> Helper loaded: func_helper
DEBUG - 2016-12-29 04:49:30 --> Database Driver Class Initialized
ERROR - 2016-12-29 04:49:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 04:49:30 --> Session Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Helper loaded: string_helper
DEBUG - 2016-12-29 04:49:30 --> Encrypt Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Session routines successfully run
ERROR - 2016-12-29 04:49:30 --> Could not find the language line "first_link"
ERROR - 2016-12-29 04:49:30 --> Could not find the language line "last_link"
ERROR - 2016-12-29 04:49:30 --> Could not find the language line "next_link"
ERROR - 2016-12-29 04:49:30 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 04:49:30 --> Pagination Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Table Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Model Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Model Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Helper loaded: file_helper
DEBUG - 2016-12-29 04:49:30 --> Model Class Initialized
DEBUG - 2016-12-29 04:49:30 --> Controller Class Initialized
DEBUG - 2016-12-29 04:49:36 --> Helper loaded: language_helper
DEBUG - 2016-12-29 04:49:36 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 04:49:37 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 04:49:37 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-29 04:49:37 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-29 04:49:37 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-29 04:49:37 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-29 04:49:37 --> Final output sent to browser
DEBUG - 2016-12-29 04:49:37 --> Total execution time: 6.9684
DEBUG - 2016-12-29 04:49:37 --> Config Class Initialized
DEBUG - 2016-12-29 04:49:37 --> Hooks Class Initialized
DEBUG - 2016-12-29 04:49:37 --> Utf8 Class Initialized
DEBUG - 2016-12-29 04:49:37 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 04:49:37 --> URI Class Initialized
DEBUG - 2016-12-29 04:49:37 --> Router Class Initialized
ERROR - 2016-12-29 04:49:37 --> 404 Page Not Found --> js
DEBUG - 2016-12-29 12:10:09 --> Config Class Initialized
DEBUG - 2016-12-29 12:10:10 --> Hooks Class Initialized
DEBUG - 2016-12-29 12:10:10 --> Utf8 Class Initialized
DEBUG - 2016-12-29 12:10:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 12:10:10 --> URI Class Initialized
DEBUG - 2016-12-29 12:10:10 --> Router Class Initialized
DEBUG - 2016-12-29 12:10:11 --> Output Class Initialized
DEBUG - 2016-12-29 12:10:11 --> Security Class Initialized
DEBUG - 2016-12-29 12:10:11 --> Input Class Initialized
DEBUG - 2016-12-29 12:10:11 --> XSS Filtering completed
DEBUG - 2016-12-29 12:10:11 --> XSS Filtering completed
DEBUG - 2016-12-29 12:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 12:10:11 --> Language Class Initialized
DEBUG - 2016-12-29 12:10:11 --> Loader Class Initialized
DEBUG - 2016-12-29 12:10:11 --> Helper loaded: url_helper
DEBUG - 2016-12-29 12:10:11 --> Helper loaded: form_helper
DEBUG - 2016-12-29 12:10:12 --> Helper loaded: func_helper
DEBUG - 2016-12-29 12:10:13 --> Database Driver Class Initialized
ERROR - 2016-12-29 12:10:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 12:10:14 --> Session Class Initialized
DEBUG - 2016-12-29 12:10:14 --> Helper loaded: string_helper
DEBUG - 2016-12-29 12:10:14 --> Encrypt Class Initialized
DEBUG - 2016-12-29 12:10:14 --> A session cookie was not found.
DEBUG - 2016-12-29 12:10:14 --> Session routines successfully run
ERROR - 2016-12-29 12:10:14 --> Could not find the language line "first_link"
ERROR - 2016-12-29 12:10:14 --> Could not find the language line "last_link"
ERROR - 2016-12-29 12:10:14 --> Could not find the language line "next_link"
ERROR - 2016-12-29 12:10:14 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 12:10:14 --> Pagination Class Initialized
DEBUG - 2016-12-29 12:10:14 --> Table Class Initialized
DEBUG - 2016-12-29 12:10:15 --> Model Class Initialized
DEBUG - 2016-12-29 12:10:15 --> Model Class Initialized
DEBUG - 2016-12-29 12:10:15 --> Helper loaded: file_helper
DEBUG - 2016-12-29 12:10:15 --> Model Class Initialized
DEBUG - 2016-12-29 12:10:15 --> Controller Class Initialized
DEBUG - 2016-12-29 12:10:16 --> Form Validation Class Initialized
DEBUG - 2016-12-29 12:10:19 --> Config Class Initialized
DEBUG - 2016-12-29 12:10:19 --> Hooks Class Initialized
DEBUG - 2016-12-29 12:10:19 --> Utf8 Class Initialized
DEBUG - 2016-12-29 12:10:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 12:10:19 --> URI Class Initialized
DEBUG - 2016-12-29 12:10:19 --> Router Class Initialized
DEBUG - 2016-12-29 12:10:19 --> Output Class Initialized
DEBUG - 2016-12-29 12:10:19 --> Security Class Initialized
DEBUG - 2016-12-29 12:10:19 --> Input Class Initialized
DEBUG - 2016-12-29 12:10:19 --> XSS Filtering completed
DEBUG - 2016-12-29 12:10:19 --> XSS Filtering completed
DEBUG - 2016-12-29 12:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 12:10:19 --> Language Class Initialized
DEBUG - 2016-12-29 12:10:20 --> Loader Class Initialized
DEBUG - 2016-12-29 12:10:20 --> Helper loaded: url_helper
DEBUG - 2016-12-29 12:10:20 --> Helper loaded: form_helper
DEBUG - 2016-12-29 12:10:20 --> Helper loaded: func_helper
DEBUG - 2016-12-29 12:10:20 --> Database Driver Class Initialized
ERROR - 2016-12-29 12:10:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 12:10:20 --> Session Class Initialized
DEBUG - 2016-12-29 12:10:20 --> Helper loaded: string_helper
DEBUG - 2016-12-29 12:10:20 --> Encrypt Class Initialized
DEBUG - 2016-12-29 12:10:20 --> Session routines successfully run
ERROR - 2016-12-29 12:10:20 --> Could not find the language line "first_link"
ERROR - 2016-12-29 12:10:20 --> Could not find the language line "last_link"
ERROR - 2016-12-29 12:10:20 --> Could not find the language line "next_link"
ERROR - 2016-12-29 12:10:20 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 12:10:20 --> Pagination Class Initialized
DEBUG - 2016-12-29 12:10:20 --> Table Class Initialized
DEBUG - 2016-12-29 12:10:20 --> Model Class Initialized
DEBUG - 2016-12-29 12:10:20 --> Model Class Initialized
DEBUG - 2016-12-29 12:10:20 --> Helper loaded: file_helper
DEBUG - 2016-12-29 12:10:20 --> Model Class Initialized
DEBUG - 2016-12-29 12:10:20 --> Controller Class Initialized
DEBUG - 2016-12-29 12:10:20 --> Helper loaded: language_helper
DEBUG - 2016-12-29 12:10:20 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 12:10:20 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 12:10:20 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-29 12:10:21 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-29 12:10:21 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-29 12:10:21 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-29 12:10:21 --> Final output sent to browser
DEBUG - 2016-12-29 12:10:21 --> Total execution time: 1.5731
DEBUG - 2016-12-29 12:10:25 --> Config Class Initialized
DEBUG - 2016-12-29 12:10:25 --> Hooks Class Initialized
DEBUG - 2016-12-29 12:10:25 --> Utf8 Class Initialized
DEBUG - 2016-12-29 12:10:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 12:10:25 --> URI Class Initialized
DEBUG - 2016-12-29 12:10:25 --> Router Class Initialized
ERROR - 2016-12-29 12:10:25 --> 404 Page Not Found --> js
DEBUG - 2016-12-29 12:10:37 --> Config Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Hooks Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Utf8 Class Initialized
DEBUG - 2016-12-29 12:10:37 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 12:10:37 --> URI Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Router Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Output Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Security Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Input Class Initialized
DEBUG - 2016-12-29 12:10:37 --> XSS Filtering completed
DEBUG - 2016-12-29 12:10:37 --> XSS Filtering completed
DEBUG - 2016-12-29 12:10:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 12:10:37 --> Language Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Loader Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Helper loaded: url_helper
DEBUG - 2016-12-29 12:10:37 --> Helper loaded: form_helper
DEBUG - 2016-12-29 12:10:37 --> Helper loaded: func_helper
DEBUG - 2016-12-29 12:10:37 --> Database Driver Class Initialized
ERROR - 2016-12-29 12:10:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 12:10:37 --> Session Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Helper loaded: string_helper
DEBUG - 2016-12-29 12:10:37 --> Encrypt Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Session routines successfully run
ERROR - 2016-12-29 12:10:37 --> Could not find the language line "first_link"
ERROR - 2016-12-29 12:10:37 --> Could not find the language line "last_link"
ERROR - 2016-12-29 12:10:37 --> Could not find the language line "next_link"
ERROR - 2016-12-29 12:10:37 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 12:10:37 --> Pagination Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Table Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Model Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Model Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Helper loaded: file_helper
DEBUG - 2016-12-29 12:10:37 --> Model Class Initialized
DEBUG - 2016-12-29 12:10:37 --> Controller Class Initialized
DEBUG - 2016-12-29 12:10:49 --> Helper loaded: language_helper
DEBUG - 2016-12-29 12:10:49 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 12:10:53 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 12:10:53 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-29 12:10:53 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-29 12:10:53 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-29 12:10:53 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-29 12:10:53 --> Final output sent to browser
DEBUG - 2016-12-29 12:10:53 --> Total execution time: 15.6559
DEBUG - 2016-12-29 12:11:00 --> Config Class Initialized
DEBUG - 2016-12-29 12:11:00 --> Hooks Class Initialized
DEBUG - 2016-12-29 12:11:00 --> Utf8 Class Initialized
DEBUG - 2016-12-29 12:11:00 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 12:11:00 --> URI Class Initialized
DEBUG - 2016-12-29 12:11:00 --> Router Class Initialized
ERROR - 2016-12-29 12:11:00 --> 404 Page Not Found --> js
DEBUG - 2016-12-29 12:11:07 --> Config Class Initialized
DEBUG - 2016-12-29 12:11:07 --> Hooks Class Initialized
DEBUG - 2016-12-29 12:11:07 --> Utf8 Class Initialized
DEBUG - 2016-12-29 12:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 12:11:07 --> URI Class Initialized
DEBUG - 2016-12-29 12:11:07 --> Router Class Initialized
ERROR - 2016-12-29 12:11:07 --> 404 Page Not Found --> js
DEBUG - 2016-12-29 12:17:54 --> Config Class Initialized
DEBUG - 2016-12-29 12:17:54 --> Hooks Class Initialized
DEBUG - 2016-12-29 12:17:54 --> Utf8 Class Initialized
DEBUG - 2016-12-29 12:17:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 12:17:54 --> URI Class Initialized
DEBUG - 2016-12-29 12:17:54 --> Router Class Initialized
DEBUG - 2016-12-29 12:17:54 --> No URI present. Default controller set.
DEBUG - 2016-12-29 12:17:54 --> Output Class Initialized
DEBUG - 2016-12-29 12:17:54 --> Security Class Initialized
DEBUG - 2016-12-29 12:17:54 --> Input Class Initialized
DEBUG - 2016-12-29 12:17:54 --> XSS Filtering completed
DEBUG - 2016-12-29 12:17:54 --> XSS Filtering completed
DEBUG - 2016-12-29 12:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-29 12:17:54 --> Language Class Initialized
DEBUG - 2016-12-29 12:17:54 --> Loader Class Initialized
DEBUG - 2016-12-29 12:17:54 --> Helper loaded: url_helper
DEBUG - 2016-12-29 12:17:54 --> Helper loaded: form_helper
DEBUG - 2016-12-29 12:17:54 --> Helper loaded: func_helper
DEBUG - 2016-12-29 12:17:54 --> Database Driver Class Initialized
ERROR - 2016-12-29 12:17:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-29 12:17:54 --> Session Class Initialized
DEBUG - 2016-12-29 12:17:54 --> Helper loaded: string_helper
DEBUG - 2016-12-29 12:17:54 --> Encrypt Class Initialized
ERROR - 2016-12-29 12:17:54 --> Session: The session cookie was not signed.
DEBUG - 2016-12-29 12:17:54 --> Session routines successfully run
ERROR - 2016-12-29 12:17:54 --> Could not find the language line "first_link"
ERROR - 2016-12-29 12:17:54 --> Could not find the language line "last_link"
ERROR - 2016-12-29 12:17:54 --> Could not find the language line "next_link"
ERROR - 2016-12-29 12:17:54 --> Could not find the language line "prev_link"
DEBUG - 2016-12-29 12:17:54 --> Pagination Class Initialized
DEBUG - 2016-12-29 12:17:54 --> Table Class Initialized
DEBUG - 2016-12-29 12:17:54 --> Model Class Initialized
DEBUG - 2016-12-29 12:17:54 --> Model Class Initialized
DEBUG - 2016-12-29 12:17:54 --> Helper loaded: file_helper
DEBUG - 2016-12-29 12:17:54 --> Model Class Initialized
DEBUG - 2016-12-29 12:17:54 --> Controller Class Initialized
DEBUG - 2016-12-29 12:17:56 --> Helper loaded: language_helper
DEBUG - 2016-12-29 12:17:56 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-29 12:17:57 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-29 12:18:00 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-29 12:18:00 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-29 12:18:00 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-29 12:18:00 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-29 12:18:00 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-29 12:18:00 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-29 12:18:00 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-29 12:18:00 --> Final output sent to browser
DEBUG - 2016-12-29 12:18:00 --> Total execution time: 5.7753
DEBUG - 2016-12-29 12:18:00 --> Config Class Initialized
DEBUG - 2016-12-29 12:18:00 --> Hooks Class Initialized
DEBUG - 2016-12-29 12:18:00 --> Utf8 Class Initialized
DEBUG - 2016-12-29 12:18:00 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 12:18:00 --> URI Class Initialized
DEBUG - 2016-12-29 12:18:00 --> Router Class Initialized
ERROR - 2016-12-29 12:18:00 --> 404 Page Not Found --> js
DEBUG - 2016-12-29 12:18:03 --> Config Class Initialized
DEBUG - 2016-12-29 12:18:03 --> Hooks Class Initialized
DEBUG - 2016-12-29 12:18:03 --> Utf8 Class Initialized
DEBUG - 2016-12-29 12:18:03 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 12:18:03 --> URI Class Initialized
DEBUG - 2016-12-29 12:18:03 --> Router Class Initialized
ERROR - 2016-12-29 12:18:03 --> 404 Page Not Found --> sss
DEBUG - 2016-12-29 12:24:53 --> Config Class Initialized
DEBUG - 2016-12-29 12:24:53 --> Hooks Class Initialized
DEBUG - 2016-12-29 12:24:53 --> Utf8 Class Initialized
DEBUG - 2016-12-29 12:24:53 --> UTF-8 Support Enabled
DEBUG - 2016-12-29 12:24:53 --> URI Class Initialized
DEBUG - 2016-12-29 12:24:53 --> Router Class Initialized
ERROR - 2016-12-29 12:24:53 --> 404 Page Not Found --> sss
