<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-12-28 00:56:02 --> Config Class Initialized
DEBUG - 2016-12-28 00:56:02 --> Hooks Class Initialized
DEBUG - 2016-12-28 00:56:02 --> Utf8 Class Initialized
DEBUG - 2016-12-28 00:56:02 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 00:56:02 --> URI Class Initialized
DEBUG - 2016-12-28 00:56:02 --> Router Class Initialized
DEBUG - 2016-12-28 00:56:02 --> No URI present. Default controller set.
DEBUG - 2016-12-28 00:56:02 --> Output Class Initialized
DEBUG - 2016-12-28 00:56:02 --> Security Class Initialized
DEBUG - 2016-12-28 00:56:02 --> Input Class Initialized
DEBUG - 2016-12-28 00:56:02 --> XSS Filtering completed
DEBUG - 2016-12-28 00:56:02 --> XSS Filtering completed
DEBUG - 2016-12-28 00:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 00:56:02 --> Language Class Initialized
DEBUG - 2016-12-28 00:56:02 --> Loader Class Initialized
DEBUG - 2016-12-28 00:56:02 --> Helper loaded: url_helper
DEBUG - 2016-12-28 00:56:02 --> Helper loaded: form_helper
DEBUG - 2016-12-28 00:56:02 --> Helper loaded: func_helper
DEBUG - 2016-12-28 00:56:02 --> Database Driver Class Initialized
ERROR - 2016-12-28 00:56:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 00:56:02 --> Session Class Initialized
DEBUG - 2016-12-28 00:56:02 --> Helper loaded: string_helper
DEBUG - 2016-12-28 00:56:02 --> Encrypt Class Initialized
DEBUG - 2016-12-28 00:56:02 --> A session cookie was not found.
DEBUG - 2016-12-28 00:56:02 --> Session routines successfully run
ERROR - 2016-12-28 00:56:02 --> Could not find the language line "first_link"
ERROR - 2016-12-28 00:56:02 --> Could not find the language line "last_link"
ERROR - 2016-12-28 00:56:02 --> Could not find the language line "next_link"
ERROR - 2016-12-28 00:56:02 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 00:56:02 --> Pagination Class Initialized
DEBUG - 2016-12-28 00:56:02 --> Table Class Initialized
DEBUG - 2016-12-28 00:56:02 --> Model Class Initialized
DEBUG - 2016-12-28 00:56:02 --> Model Class Initialized
DEBUG - 2016-12-28 00:56:02 --> Helper loaded: file_helper
DEBUG - 2016-12-28 00:56:02 --> Model Class Initialized
DEBUG - 2016-12-28 00:56:02 --> Controller Class Initialized
DEBUG - 2016-12-28 00:56:02 --> DB Transaction Failure
ERROR - 2016-12-28 00:56:02 --> Query error: Table 'univ_alumni_online1.lk9v6_settings' doesn't exist
DEBUG - 2016-12-28 00:56:02 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-28 00:56:02 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-28 00:58:11 --> Config Class Initialized
DEBUG - 2016-12-28 00:58:11 --> Hooks Class Initialized
DEBUG - 2016-12-28 00:58:11 --> Utf8 Class Initialized
DEBUG - 2016-12-28 00:58:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 00:58:11 --> URI Class Initialized
DEBUG - 2016-12-28 00:58:11 --> Router Class Initialized
DEBUG - 2016-12-28 00:58:11 --> No URI present. Default controller set.
DEBUG - 2016-12-28 00:58:11 --> Output Class Initialized
DEBUG - 2016-12-28 00:58:11 --> Security Class Initialized
DEBUG - 2016-12-28 00:58:11 --> Input Class Initialized
DEBUG - 2016-12-28 00:58:11 --> XSS Filtering completed
DEBUG - 2016-12-28 00:58:11 --> XSS Filtering completed
DEBUG - 2016-12-28 00:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 00:58:11 --> Language Class Initialized
DEBUG - 2016-12-28 00:58:11 --> Loader Class Initialized
DEBUG - 2016-12-28 00:58:11 --> Helper loaded: url_helper
DEBUG - 2016-12-28 00:58:11 --> Helper loaded: form_helper
DEBUG - 2016-12-28 00:58:11 --> Helper loaded: func_helper
DEBUG - 2016-12-28 00:58:11 --> Database Driver Class Initialized
ERROR - 2016-12-28 00:58:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 00:58:11 --> Session Class Initialized
DEBUG - 2016-12-28 00:58:11 --> Helper loaded: string_helper
DEBUG - 2016-12-28 00:58:11 --> Encrypt Class Initialized
DEBUG - 2016-12-28 00:58:11 --> Session routines successfully run
ERROR - 2016-12-28 00:58:11 --> Could not find the language line "first_link"
ERROR - 2016-12-28 00:58:11 --> Could not find the language line "last_link"
ERROR - 2016-12-28 00:58:11 --> Could not find the language line "next_link"
ERROR - 2016-12-28 00:58:11 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 00:58:11 --> Pagination Class Initialized
DEBUG - 2016-12-28 00:58:11 --> Table Class Initialized
DEBUG - 2016-12-28 00:58:11 --> Model Class Initialized
DEBUG - 2016-12-28 00:58:11 --> Model Class Initialized
DEBUG - 2016-12-28 00:58:11 --> Helper loaded: file_helper
DEBUG - 2016-12-28 00:58:11 --> Model Class Initialized
DEBUG - 2016-12-28 00:58:11 --> Controller Class Initialized
DEBUG - 2016-12-28 00:58:13 --> DB Transaction Failure
ERROR - 2016-12-28 00:58:13 --> Query error: Table 'univ_alumni_online1.lk9v6_debug' doesn't exist
DEBUG - 2016-12-28 00:58:13 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-28 00:58:13 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-28 00:59:27 --> Config Class Initialized
DEBUG - 2016-12-28 00:59:27 --> Hooks Class Initialized
DEBUG - 2016-12-28 00:59:27 --> Utf8 Class Initialized
DEBUG - 2016-12-28 00:59:27 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 00:59:27 --> URI Class Initialized
DEBUG - 2016-12-28 00:59:27 --> Router Class Initialized
DEBUG - 2016-12-28 00:59:27 --> No URI present. Default controller set.
DEBUG - 2016-12-28 00:59:27 --> Output Class Initialized
DEBUG - 2016-12-28 00:59:27 --> Security Class Initialized
DEBUG - 2016-12-28 00:59:27 --> Input Class Initialized
DEBUG - 2016-12-28 00:59:27 --> XSS Filtering completed
DEBUG - 2016-12-28 00:59:27 --> XSS Filtering completed
DEBUG - 2016-12-28 00:59:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 00:59:27 --> Language Class Initialized
DEBUG - 2016-12-28 00:59:27 --> Loader Class Initialized
DEBUG - 2016-12-28 00:59:27 --> Helper loaded: url_helper
DEBUG - 2016-12-28 00:59:27 --> Helper loaded: form_helper
DEBUG - 2016-12-28 00:59:27 --> Helper loaded: func_helper
DEBUG - 2016-12-28 00:59:27 --> Database Driver Class Initialized
ERROR - 2016-12-28 00:59:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 00:59:27 --> Session Class Initialized
DEBUG - 2016-12-28 00:59:27 --> Helper loaded: string_helper
DEBUG - 2016-12-28 00:59:27 --> Encrypt Class Initialized
DEBUG - 2016-12-28 00:59:27 --> Session routines successfully run
ERROR - 2016-12-28 00:59:27 --> Could not find the language line "first_link"
ERROR - 2016-12-28 00:59:27 --> Could not find the language line "last_link"
ERROR - 2016-12-28 00:59:27 --> Could not find the language line "next_link"
ERROR - 2016-12-28 00:59:27 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 00:59:27 --> Pagination Class Initialized
DEBUG - 2016-12-28 00:59:27 --> Table Class Initialized
DEBUG - 2016-12-28 00:59:27 --> Model Class Initialized
DEBUG - 2016-12-28 00:59:27 --> Model Class Initialized
DEBUG - 2016-12-28 00:59:27 --> Helper loaded: file_helper
DEBUG - 2016-12-28 00:59:27 --> Model Class Initialized
DEBUG - 2016-12-28 00:59:27 --> Controller Class Initialized
DEBUG - 2016-12-28 00:59:28 --> Helper loaded: language_helper
DEBUG - 2016-12-28 00:59:28 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 00:59:30 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-28 00:59:32 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 00:59:32 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 00:59:32 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 00:59:32 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 00:59:32 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 00:59:32 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 00:59:32 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 00:59:32 --> Final output sent to browser
DEBUG - 2016-12-28 00:59:32 --> Total execution time: 5.8063
DEBUG - 2016-12-28 00:59:32 --> Config Class Initialized
DEBUG - 2016-12-28 00:59:32 --> Hooks Class Initialized
DEBUG - 2016-12-28 00:59:32 --> Utf8 Class Initialized
DEBUG - 2016-12-28 00:59:32 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 00:59:32 --> URI Class Initialized
DEBUG - 2016-12-28 00:59:32 --> Router Class Initialized
ERROR - 2016-12-28 00:59:32 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 00:59:50 --> Config Class Initialized
DEBUG - 2016-12-28 00:59:50 --> Hooks Class Initialized
DEBUG - 2016-12-28 00:59:50 --> Utf8 Class Initialized
DEBUG - 2016-12-28 00:59:50 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 00:59:50 --> URI Class Initialized
DEBUG - 2016-12-28 00:59:50 --> Router Class Initialized
DEBUG - 2016-12-28 00:59:50 --> Output Class Initialized
DEBUG - 2016-12-28 00:59:50 --> Security Class Initialized
DEBUG - 2016-12-28 00:59:50 --> Input Class Initialized
DEBUG - 2016-12-28 00:59:50 --> XSS Filtering completed
DEBUG - 2016-12-28 00:59:51 --> XSS Filtering completed
DEBUG - 2016-12-28 00:59:51 --> XSS Filtering completed
DEBUG - 2016-12-28 00:59:51 --> XSS Filtering completed
DEBUG - 2016-12-28 00:59:51 --> XSS Filtering completed
DEBUG - 2016-12-28 00:59:51 --> XSS Filtering completed
DEBUG - 2016-12-28 00:59:51 --> XSS Filtering completed
DEBUG - 2016-12-28 00:59:51 --> XSS Filtering completed
DEBUG - 2016-12-28 00:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 00:59:51 --> Language Class Initialized
DEBUG - 2016-12-28 00:59:51 --> Loader Class Initialized
DEBUG - 2016-12-28 00:59:51 --> Helper loaded: url_helper
DEBUG - 2016-12-28 00:59:51 --> Helper loaded: form_helper
DEBUG - 2016-12-28 00:59:51 --> Helper loaded: func_helper
DEBUG - 2016-12-28 00:59:51 --> Database Driver Class Initialized
ERROR - 2016-12-28 00:59:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 00:59:51 --> Session Class Initialized
DEBUG - 2016-12-28 00:59:51 --> Helper loaded: string_helper
DEBUG - 2016-12-28 00:59:51 --> Encrypt Class Initialized
DEBUG - 2016-12-28 00:59:51 --> Session routines successfully run
ERROR - 2016-12-28 00:59:51 --> Could not find the language line "first_link"
ERROR - 2016-12-28 00:59:51 --> Could not find the language line "last_link"
ERROR - 2016-12-28 00:59:51 --> Could not find the language line "next_link"
ERROR - 2016-12-28 00:59:51 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 00:59:51 --> Pagination Class Initialized
DEBUG - 2016-12-28 00:59:51 --> Table Class Initialized
DEBUG - 2016-12-28 00:59:51 --> Model Class Initialized
DEBUG - 2016-12-28 00:59:51 --> Model Class Initialized
DEBUG - 2016-12-28 00:59:51 --> Helper loaded: file_helper
DEBUG - 2016-12-28 00:59:51 --> Model Class Initialized
DEBUG - 2016-12-28 00:59:51 --> Controller Class Initialized
DEBUG - 2016-12-28 00:59:52 --> DB Transaction Failure
ERROR - 2016-12-28 00:59:52 --> Query error: Duplicate entry '0' for key 'PRIMARY'
DEBUG - 2016-12-28 00:59:52 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-28 00:59:52 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-28 01:01:39 --> Config Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:01:39 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:01:39 --> URI Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Router Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Output Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Security Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Input Class Initialized
DEBUG - 2016-12-28 01:01:39 --> XSS Filtering completed
DEBUG - 2016-12-28 01:01:39 --> XSS Filtering completed
DEBUG - 2016-12-28 01:01:39 --> XSS Filtering completed
DEBUG - 2016-12-28 01:01:39 --> XSS Filtering completed
DEBUG - 2016-12-28 01:01:39 --> XSS Filtering completed
DEBUG - 2016-12-28 01:01:39 --> XSS Filtering completed
DEBUG - 2016-12-28 01:01:39 --> XSS Filtering completed
DEBUG - 2016-12-28 01:01:39 --> XSS Filtering completed
DEBUG - 2016-12-28 01:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:01:39 --> Language Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Loader Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:01:39 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:01:39 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:01:39 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:01:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:01:39 --> Session Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:01:39 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Session routines successfully run
ERROR - 2016-12-28 01:01:39 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:01:39 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:01:39 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:01:39 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:01:39 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Table Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Model Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Model Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:01:39 --> Model Class Initialized
DEBUG - 2016-12-28 01:01:39 --> Controller Class Initialized
DEBUG - 2016-12-28 01:01:41 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:01:41 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:01:42 --> Config Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:01:42 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:01:42 --> URI Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Router Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Output Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Security Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Input Class Initialized
DEBUG - 2016-12-28 01:01:42 --> XSS Filtering completed
DEBUG - 2016-12-28 01:01:42 --> XSS Filtering completed
DEBUG - 2016-12-28 01:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:01:42 --> Language Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Loader Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:01:42 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:01:42 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:01:42 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:01:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:01:42 --> Session Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:01:42 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Session routines successfully run
ERROR - 2016-12-28 01:01:42 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:01:42 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:01:42 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:01:42 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:01:42 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Table Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Model Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Model Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:01:42 --> Model Class Initialized
DEBUG - 2016-12-28 01:01:42 --> Controller Class Initialized
DEBUG - 2016-12-28 01:01:44 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:01:44 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:01:44 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-12-28 01:01:45 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-28 01:01:45 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:01:45 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:01:45 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 01:01:45 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 01:01:45 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 01:01:45 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:01:45 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:01:45 --> Final output sent to browser
DEBUG - 2016-12-28 01:01:45 --> Total execution time: 2.6161
DEBUG - 2016-12-28 01:01:45 --> Config Class Initialized
DEBUG - 2016-12-28 01:01:45 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:01:45 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:01:45 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:01:45 --> URI Class Initialized
DEBUG - 2016-12-28 01:01:45 --> Router Class Initialized
ERROR - 2016-12-28 01:01:45 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:01:52 --> Config Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:01:52 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:01:52 --> URI Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Router Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Output Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Security Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Input Class Initialized
DEBUG - 2016-12-28 01:01:52 --> XSS Filtering completed
DEBUG - 2016-12-28 01:01:52 --> XSS Filtering completed
DEBUG - 2016-12-28 01:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:01:52 --> Language Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Loader Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:01:52 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:01:52 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:01:52 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:01:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:01:52 --> Session Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:01:52 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Session routines successfully run
ERROR - 2016-12-28 01:01:52 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:01:52 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:01:52 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:01:52 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:01:52 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Table Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Model Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Model Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:01:52 --> Model Class Initialized
DEBUG - 2016-12-28 01:01:52 --> Controller Class Initialized
DEBUG - 2016-12-28 01:01:55 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:01:55 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:01:55 --> DB Transaction Failure
ERROR - 2016-12-28 01:01:55 --> Query error: Table 'univ_alumni_online1.lk9v6_alumni_data_other' doesn't exist
DEBUG - 2016-12-28 01:01:55 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-28 01:01:55 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-28 01:04:52 --> Config Class Initialized
DEBUG - 2016-12-28 01:04:52 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:04:52 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:04:52 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:04:52 --> URI Class Initialized
DEBUG - 2016-12-28 01:04:52 --> Router Class Initialized
DEBUG - 2016-12-28 01:04:52 --> Output Class Initialized
DEBUG - 2016-12-28 01:04:52 --> Security Class Initialized
DEBUG - 2016-12-28 01:04:52 --> Input Class Initialized
DEBUG - 2016-12-28 01:04:52 --> XSS Filtering completed
DEBUG - 2016-12-28 01:04:52 --> XSS Filtering completed
DEBUG - 2016-12-28 01:04:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:04:52 --> Language Class Initialized
DEBUG - 2016-12-28 01:04:52 --> Loader Class Initialized
DEBUG - 2016-12-28 01:04:52 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:04:52 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:04:52 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:04:52 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:04:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:04:52 --> Session Class Initialized
DEBUG - 2016-12-28 01:04:52 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:04:52 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:04:52 --> Session routines successfully run
ERROR - 2016-12-28 01:04:52 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:04:53 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:04:53 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:04:53 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:04:53 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:04:53 --> Table Class Initialized
DEBUG - 2016-12-28 01:04:53 --> Model Class Initialized
DEBUG - 2016-12-28 01:04:53 --> Model Class Initialized
DEBUG - 2016-12-28 01:04:53 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:04:53 --> Model Class Initialized
DEBUG - 2016-12-28 01:04:53 --> Controller Class Initialized
DEBUG - 2016-12-28 01:04:54 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:04:54 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:04:55 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:04:55 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:04:55 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-28 01:04:55 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:04:55 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:04:55 --> Final output sent to browser
DEBUG - 2016-12-28 01:04:55 --> Total execution time: 2.0801
DEBUG - 2016-12-28 01:04:55 --> Config Class Initialized
DEBUG - 2016-12-28 01:04:55 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:04:55 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:04:55 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:04:55 --> URI Class Initialized
DEBUG - 2016-12-28 01:04:55 --> Router Class Initialized
ERROR - 2016-12-28 01:04:55 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:04:55 --> Config Class Initialized
DEBUG - 2016-12-28 01:04:55 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:04:55 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:04:55 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:04:55 --> URI Class Initialized
DEBUG - 2016-12-28 01:04:55 --> Router Class Initialized
ERROR - 2016-12-28 01:04:55 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:05:10 --> Config Class Initialized
DEBUG - 2016-12-28 01:05:10 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:05:10 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:05:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:05:10 --> URI Class Initialized
DEBUG - 2016-12-28 01:05:10 --> Router Class Initialized
DEBUG - 2016-12-28 01:05:10 --> No URI present. Default controller set.
DEBUG - 2016-12-28 01:05:10 --> Output Class Initialized
DEBUG - 2016-12-28 01:05:10 --> Security Class Initialized
DEBUG - 2016-12-28 01:05:10 --> Input Class Initialized
DEBUG - 2016-12-28 01:05:10 --> XSS Filtering completed
DEBUG - 2016-12-28 01:05:10 --> XSS Filtering completed
DEBUG - 2016-12-28 01:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:05:10 --> Language Class Initialized
DEBUG - 2016-12-28 01:05:10 --> Loader Class Initialized
DEBUG - 2016-12-28 01:05:10 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:05:10 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:05:10 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:05:10 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:05:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:05:10 --> Session Class Initialized
DEBUG - 2016-12-28 01:05:10 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:05:10 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:05:10 --> Session routines successfully run
ERROR - 2016-12-28 01:05:10 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:05:10 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:05:10 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:05:10 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:05:10 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:05:10 --> Table Class Initialized
DEBUG - 2016-12-28 01:05:10 --> Model Class Initialized
DEBUG - 2016-12-28 01:05:10 --> Model Class Initialized
DEBUG - 2016-12-28 01:05:10 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:05:10 --> Model Class Initialized
DEBUG - 2016-12-28 01:05:10 --> Controller Class Initialized
DEBUG - 2016-12-28 01:05:12 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:05:12 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:05:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-28 01:05:18 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:05:18 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:05:18 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 01:05:18 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 01:05:18 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 01:05:18 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:05:18 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:05:18 --> Final output sent to browser
DEBUG - 2016-12-28 01:05:18 --> Total execution time: 8.0085
DEBUG - 2016-12-28 01:05:18 --> Config Class Initialized
DEBUG - 2016-12-28 01:05:18 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:05:18 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:05:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:05:18 --> URI Class Initialized
DEBUG - 2016-12-28 01:05:18 --> Router Class Initialized
ERROR - 2016-12-28 01:05:18 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:05:26 --> Config Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:05:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:05:26 --> URI Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Router Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Output Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Security Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Input Class Initialized
DEBUG - 2016-12-28 01:05:26 --> XSS Filtering completed
DEBUG - 2016-12-28 01:05:26 --> XSS Filtering completed
DEBUG - 2016-12-28 01:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:05:26 --> Language Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Loader Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:05:26 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:05:26 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:05:26 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:05:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:05:26 --> Session Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:05:26 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Session routines successfully run
ERROR - 2016-12-28 01:05:26 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:05:26 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:05:26 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:05:26 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:05:26 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Table Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Model Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Model Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:05:26 --> Model Class Initialized
DEBUG - 2016-12-28 01:05:26 --> Controller Class Initialized
DEBUG - 2016-12-28 01:05:27 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:05:27 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:05:27 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:05:27 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:05:27 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-28 01:05:27 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:05:27 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:05:27 --> Final output sent to browser
DEBUG - 2016-12-28 01:05:27 --> Total execution time: 1.3501
DEBUG - 2016-12-28 01:05:28 --> Config Class Initialized
DEBUG - 2016-12-28 01:05:28 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:05:28 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:05:28 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:05:28 --> URI Class Initialized
DEBUG - 2016-12-28 01:05:28 --> Router Class Initialized
ERROR - 2016-12-28 01:05:28 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:06:14 --> Config Class Initialized
DEBUG - 2016-12-28 01:06:14 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:06:14 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:06:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:06:14 --> URI Class Initialized
DEBUG - 2016-12-28 01:06:14 --> Router Class Initialized
DEBUG - 2016-12-28 01:06:14 --> No URI present. Default controller set.
DEBUG - 2016-12-28 01:06:14 --> Output Class Initialized
DEBUG - 2016-12-28 01:06:14 --> Security Class Initialized
DEBUG - 2016-12-28 01:06:14 --> Input Class Initialized
DEBUG - 2016-12-28 01:06:14 --> XSS Filtering completed
DEBUG - 2016-12-28 01:06:14 --> XSS Filtering completed
DEBUG - 2016-12-28 01:06:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:06:14 --> Language Class Initialized
DEBUG - 2016-12-28 01:06:14 --> Loader Class Initialized
DEBUG - 2016-12-28 01:06:14 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:06:14 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:06:14 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:06:14 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:06:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:06:14 --> Session Class Initialized
DEBUG - 2016-12-28 01:06:14 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:06:14 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:06:14 --> Session routines successfully run
ERROR - 2016-12-28 01:06:14 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:06:14 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:06:14 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:06:14 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:06:14 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:06:14 --> Table Class Initialized
DEBUG - 2016-12-28 01:06:14 --> Model Class Initialized
DEBUG - 2016-12-28 01:06:14 --> Model Class Initialized
DEBUG - 2016-12-28 01:06:14 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:06:14 --> Model Class Initialized
DEBUG - 2016-12-28 01:06:14 --> Controller Class Initialized
DEBUG - 2016-12-28 01:06:16 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:06:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:06:17 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-28 01:06:19 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:06:19 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:06:19 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 01:06:19 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 01:06:19 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 01:06:19 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:06:19 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:06:19 --> Final output sent to browser
DEBUG - 2016-12-28 01:06:19 --> Total execution time: 4.6123
DEBUG - 2016-12-28 01:06:19 --> Config Class Initialized
DEBUG - 2016-12-28 01:06:19 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:06:19 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:06:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:06:19 --> URI Class Initialized
DEBUG - 2016-12-28 01:06:19 --> Router Class Initialized
ERROR - 2016-12-28 01:06:19 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:06:24 --> Config Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:06:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:06:24 --> URI Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Router Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Output Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Security Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Input Class Initialized
DEBUG - 2016-12-28 01:06:24 --> XSS Filtering completed
DEBUG - 2016-12-28 01:06:24 --> XSS Filtering completed
DEBUG - 2016-12-28 01:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:06:24 --> Language Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Loader Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:06:24 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:06:24 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:06:24 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:06:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:06:24 --> Session Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:06:24 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Session routines successfully run
ERROR - 2016-12-28 01:06:24 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:06:24 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:06:24 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:06:24 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:06:24 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Table Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Model Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Model Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:06:24 --> Model Class Initialized
DEBUG - 2016-12-28 01:06:24 --> Controller Class Initialized
DEBUG - 2016-12-28 01:06:26 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:06:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:06:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:06:26 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:06:26 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-28 01:06:26 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:06:26 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:06:26 --> Final output sent to browser
DEBUG - 2016-12-28 01:06:26 --> Total execution time: 1.7511
DEBUG - 2016-12-28 01:06:26 --> Config Class Initialized
DEBUG - 2016-12-28 01:06:26 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:06:26 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:06:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:06:26 --> URI Class Initialized
DEBUG - 2016-12-28 01:06:26 --> Router Class Initialized
ERROR - 2016-12-28 01:06:26 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:07:34 --> Config Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:07:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:07:34 --> URI Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Router Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Output Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Security Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Input Class Initialized
DEBUG - 2016-12-28 01:07:34 --> XSS Filtering completed
DEBUG - 2016-12-28 01:07:34 --> XSS Filtering completed
DEBUG - 2016-12-28 01:07:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:07:34 --> Language Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Loader Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:07:34 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:07:34 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:07:34 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:07:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:07:34 --> Session Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:07:34 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Session routines successfully run
ERROR - 2016-12-28 01:07:34 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:07:34 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:07:34 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:07:34 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:07:34 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Table Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Model Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Model Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:07:34 --> Model Class Initialized
DEBUG - 2016-12-28 01:07:34 --> Controller Class Initialized
DEBUG - 2016-12-28 01:07:35 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:07:35 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:07:35 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:07:35 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:07:35 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-28 01:07:35 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:07:35 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:07:35 --> Final output sent to browser
DEBUG - 2016-12-28 01:07:35 --> Total execution time: 1.6891
DEBUG - 2016-12-28 01:07:35 --> Config Class Initialized
DEBUG - 2016-12-28 01:07:35 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:07:35 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:07:35 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:07:35 --> URI Class Initialized
DEBUG - 2016-12-28 01:07:35 --> Router Class Initialized
ERROR - 2016-12-28 01:07:35 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:14:17 --> Config Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:14:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:14:17 --> URI Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Router Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Output Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Security Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Input Class Initialized
DEBUG - 2016-12-28 01:14:17 --> XSS Filtering completed
DEBUG - 2016-12-28 01:14:17 --> XSS Filtering completed
DEBUG - 2016-12-28 01:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:14:17 --> Language Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Loader Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:14:17 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:14:17 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:14:17 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:14:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:14:17 --> Session Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:14:17 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Session routines successfully run
ERROR - 2016-12-28 01:14:17 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:14:17 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:14:17 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:14:17 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:14:17 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Table Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Model Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Model Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:14:17 --> Model Class Initialized
DEBUG - 2016-12-28 01:14:17 --> Controller Class Initialized
DEBUG - 2016-12-28 01:14:17 --> DB Transaction Failure
ERROR - 2016-12-28 01:14:17 --> Query error: Table 'univ_alumni_online1.lk9v6_settings' doesn't exist
DEBUG - 2016-12-28 01:14:17 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-28 01:14:17 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-28 01:16:39 --> Config Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:16:39 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:16:39 --> URI Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Router Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Output Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Security Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Input Class Initialized
DEBUG - 2016-12-28 01:16:39 --> XSS Filtering completed
DEBUG - 2016-12-28 01:16:39 --> XSS Filtering completed
DEBUG - 2016-12-28 01:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:16:39 --> Language Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Loader Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:16:39 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:16:39 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:16:39 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:16:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:16:39 --> Session Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:16:39 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Session routines successfully run
ERROR - 2016-12-28 01:16:39 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:16:39 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:16:39 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:16:39 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:16:39 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Table Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Model Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Model Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:16:39 --> Model Class Initialized
DEBUG - 2016-12-28 01:16:39 --> Controller Class Initialized
DEBUG - 2016-12-28 01:16:40 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:16:40 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:16:41 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:16:41 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:16:41 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-28 01:16:41 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:16:41 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:16:41 --> Final output sent to browser
DEBUG - 2016-12-28 01:16:41 --> Total execution time: 2.0261
DEBUG - 2016-12-28 01:16:41 --> Config Class Initialized
DEBUG - 2016-12-28 01:16:41 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:16:41 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:16:41 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:16:41 --> URI Class Initialized
DEBUG - 2016-12-28 01:16:41 --> Router Class Initialized
ERROR - 2016-12-28 01:16:41 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:25:38 --> Config Class Initialized
DEBUG - 2016-12-28 01:25:38 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:25:38 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:25:38 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:25:38 --> URI Class Initialized
DEBUG - 2016-12-28 01:25:38 --> Router Class Initialized
DEBUG - 2016-12-28 01:25:38 --> Output Class Initialized
DEBUG - 2016-12-28 01:25:38 --> Security Class Initialized
DEBUG - 2016-12-28 01:25:38 --> Input Class Initialized
DEBUG - 2016-12-28 01:25:38 --> XSS Filtering completed
DEBUG - 2016-12-28 01:25:38 --> XSS Filtering completed
DEBUG - 2016-12-28 01:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:25:38 --> Language Class Initialized
DEBUG - 2016-12-28 01:25:38 --> Loader Class Initialized
DEBUG - 2016-12-28 01:25:38 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:25:38 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:25:38 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:25:38 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:25:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:25:38 --> Session Class Initialized
DEBUG - 2016-12-28 01:25:38 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:25:38 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:25:38 --> Session routines successfully run
ERROR - 2016-12-28 01:25:38 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:25:38 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:25:38 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:25:38 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:25:38 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:25:38 --> Table Class Initialized
DEBUG - 2016-12-28 01:25:38 --> Model Class Initialized
DEBUG - 2016-12-28 01:25:38 --> Model Class Initialized
DEBUG - 2016-12-28 01:25:38 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:25:38 --> Model Class Initialized
DEBUG - 2016-12-28 01:25:39 --> Controller Class Initialized
DEBUG - 2016-12-28 01:25:42 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:25:42 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:25:43 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:25:43 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:25:43 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-28 01:25:43 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:25:43 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:25:43 --> Final output sent to browser
DEBUG - 2016-12-28 01:25:43 --> Total execution time: 4.8083
DEBUG - 2016-12-28 01:25:43 --> Config Class Initialized
DEBUG - 2016-12-28 01:25:43 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:25:43 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:25:43 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:25:43 --> URI Class Initialized
DEBUG - 2016-12-28 01:25:43 --> Router Class Initialized
ERROR - 2016-12-28 01:25:43 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:46:55 --> Config Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:46:55 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:46:55 --> URI Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Router Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Output Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Security Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Input Class Initialized
DEBUG - 2016-12-28 01:46:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:46:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:46:55 --> Language Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Loader Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:46:55 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:46:55 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:46:55 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:46:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:46:55 --> Session Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:46:55 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Session routines successfully run
ERROR - 2016-12-28 01:46:55 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:46:55 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:46:55 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:46:55 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:46:55 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Table Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Model Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Model Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:46:55 --> Model Class Initialized
DEBUG - 2016-12-28 01:46:55 --> Controller Class Initialized
DEBUG - 2016-12-28 01:46:55 --> DB Transaction Failure
ERROR - 2016-12-28 01:46:55 --> Query error: Table 'univ_alumni_online1.lk9v6_settings' doesn't exist
DEBUG - 2016-12-28 01:46:55 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-28 01:46:55 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-28 01:46:58 --> Config Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:46:58 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:46:58 --> URI Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Router Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Output Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Security Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Input Class Initialized
DEBUG - 2016-12-28 01:46:58 --> XSS Filtering completed
DEBUG - 2016-12-28 01:46:58 --> XSS Filtering completed
DEBUG - 2016-12-28 01:46:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:46:58 --> Language Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Loader Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:46:58 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:46:58 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:46:58 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:46:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:46:58 --> Session Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:46:58 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Session routines successfully run
ERROR - 2016-12-28 01:46:58 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:46:58 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:46:58 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:46:58 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:46:58 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Table Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Model Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Model Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:46:58 --> Model Class Initialized
DEBUG - 2016-12-28 01:46:58 --> Controller Class Initialized
DEBUG - 2016-12-28 01:46:58 --> DB Transaction Failure
ERROR - 2016-12-28 01:46:58 --> Query error: Table 'univ_alumni_online1.lk9v6_settings' doesn't exist
DEBUG - 2016-12-28 01:46:58 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-28 01:46:58 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-28 01:49:05 --> Config Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:49:05 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:49:05 --> URI Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Router Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Output Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Security Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Input Class Initialized
DEBUG - 2016-12-28 01:49:05 --> XSS Filtering completed
DEBUG - 2016-12-28 01:49:05 --> XSS Filtering completed
DEBUG - 2016-12-28 01:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:49:05 --> Language Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Loader Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:49:05 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:49:05 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:49:05 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:49:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:49:05 --> Session Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:49:05 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Session routines successfully run
ERROR - 2016-12-28 01:49:05 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:49:05 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:49:05 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:49:05 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:49:05 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Table Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Model Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Model Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:49:05 --> Model Class Initialized
DEBUG - 2016-12-28 01:49:05 --> Controller Class Initialized
DEBUG - 2016-12-28 01:49:05 --> DB Transaction Failure
ERROR - 2016-12-28 01:49:05 --> Query error: Table 'univ_alumni_online1.lk9v6_settings' doesn't exist
DEBUG - 2016-12-28 01:49:05 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-28 01:49:05 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-28 01:50:04 --> Config Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:50:04 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:50:04 --> URI Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Router Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Output Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Security Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Input Class Initialized
DEBUG - 2016-12-28 01:50:04 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:04 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:50:04 --> Language Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Loader Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:50:04 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:50:04 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:50:04 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:50:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:50:04 --> Session Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:50:04 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Session routines successfully run
ERROR - 2016-12-28 01:50:04 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:50:04 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:50:04 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:50:04 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:50:04 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Table Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:50:04 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:04 --> Controller Class Initialized
DEBUG - 2016-12-28 01:50:06 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:50:06 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:50:06 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:50:06 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:50:06 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-28 01:50:06 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:50:06 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:50:06 --> Final output sent to browser
DEBUG - 2016-12-28 01:50:06 --> Total execution time: 2.0961
DEBUG - 2016-12-28 01:50:06 --> Config Class Initialized
DEBUG - 2016-12-28 01:50:06 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:50:06 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:50:06 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:50:06 --> URI Class Initialized
DEBUG - 2016-12-28 01:50:06 --> Router Class Initialized
ERROR - 2016-12-28 01:50:06 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:50:16 --> Config Class Initialized
DEBUG - 2016-12-28 01:50:16 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:50:16 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:50:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:50:16 --> URI Class Initialized
DEBUG - 2016-12-28 01:50:16 --> Router Class Initialized
DEBUG - 2016-12-28 01:50:16 --> No URI present. Default controller set.
DEBUG - 2016-12-28 01:50:16 --> Output Class Initialized
DEBUG - 2016-12-28 01:50:16 --> Security Class Initialized
DEBUG - 2016-12-28 01:50:16 --> Input Class Initialized
DEBUG - 2016-12-28 01:50:16 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:16 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:50:16 --> Language Class Initialized
DEBUG - 2016-12-28 01:50:16 --> Loader Class Initialized
DEBUG - 2016-12-28 01:50:16 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:50:16 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:50:16 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:50:16 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:50:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:50:16 --> Session Class Initialized
DEBUG - 2016-12-28 01:50:16 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:50:16 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:50:16 --> Session routines successfully run
ERROR - 2016-12-28 01:50:16 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:50:16 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:50:16 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:50:16 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:50:16 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:50:16 --> Table Class Initialized
DEBUG - 2016-12-28 01:50:16 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:16 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:16 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:50:16 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:16 --> Controller Class Initialized
DEBUG - 2016-12-28 01:50:17 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:50:17 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:50:19 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-28 01:50:20 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:50:20 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:50:20 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 01:50:20 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 01:50:20 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 01:50:20 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:50:20 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:50:20 --> Final output sent to browser
DEBUG - 2016-12-28 01:50:20 --> Total execution time: 4.6043
DEBUG - 2016-12-28 01:50:20 --> Config Class Initialized
DEBUG - 2016-12-28 01:50:20 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:50:20 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:50:20 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:50:20 --> URI Class Initialized
DEBUG - 2016-12-28 01:50:20 --> Router Class Initialized
ERROR - 2016-12-28 01:50:20 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:50:28 --> Config Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:50:28 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:50:28 --> URI Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Router Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Output Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Security Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Input Class Initialized
DEBUG - 2016-12-28 01:50:28 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:28 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:28 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:28 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:28 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:28 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:28 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:28 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:50:28 --> Language Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Loader Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:50:28 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:50:28 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:50:28 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:50:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:50:28 --> Session Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:50:28 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Session routines successfully run
ERROR - 2016-12-28 01:50:28 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:50:28 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:50:28 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:50:28 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:50:28 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Table Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:50:28 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:28 --> Controller Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:50:29 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:50:29 --> Config Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:50:29 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:50:29 --> URI Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Router Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Output Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Security Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Input Class Initialized
DEBUG - 2016-12-28 01:50:29 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:29 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:50:29 --> Language Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Loader Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:50:29 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:50:29 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:50:29 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:50:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:50:29 --> Session Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:50:29 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Session routines successfully run
ERROR - 2016-12-28 01:50:29 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:50:29 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:50:29 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:50:29 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:50:29 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Table Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:50:29 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:29 --> Controller Class Initialized
DEBUG - 2016-12-28 01:50:31 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:50:31 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-28 01:50:31 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-28 01:50:31 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:50:31 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:50:31 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 01:50:31 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 01:50:31 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:50:31 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:50:31 --> Final output sent to browser
DEBUG - 2016-12-28 01:50:31 --> Total execution time: 1.8231
DEBUG - 2016-12-28 01:50:31 --> Config Class Initialized
DEBUG - 2016-12-28 01:50:31 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:50:31 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:50:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:50:31 --> URI Class Initialized
DEBUG - 2016-12-28 01:50:31 --> Router Class Initialized
ERROR - 2016-12-28 01:50:31 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:50:45 --> Config Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:50:45 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:50:45 --> URI Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Router Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Output Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Security Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Input Class Initialized
DEBUG - 2016-12-28 01:50:45 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:45 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:45 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:45 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:45 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:45 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:45 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:45 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:50:45 --> Language Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Loader Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:50:45 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:50:45 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:50:45 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:50:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:50:45 --> Session Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:50:45 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Session routines successfully run
ERROR - 2016-12-28 01:50:45 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:50:45 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:50:45 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:50:45 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:50:45 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Table Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:50:45 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:45 --> Controller Class Initialized
DEBUG - 2016-12-28 01:50:47 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:50:47 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:50:48 --> Config Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:50:48 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:50:48 --> URI Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Router Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Output Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Security Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Input Class Initialized
DEBUG - 2016-12-28 01:50:48 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:48 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:50:48 --> Language Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Loader Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:50:48 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:50:48 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:50:48 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:50:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:50:48 --> Session Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:50:48 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Session routines successfully run
ERROR - 2016-12-28 01:50:48 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:50:48 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:50:48 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:50:48 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:50:48 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Table Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:50:48 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:48 --> Controller Class Initialized
DEBUG - 2016-12-28 01:50:49 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:50:49 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:50:49 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-12-28 01:50:50 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-28 01:50:50 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:50:50 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:50:50 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 01:50:50 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 01:50:50 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 01:50:50 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:50:50 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:50:50 --> Final output sent to browser
DEBUG - 2016-12-28 01:50:50 --> Total execution time: 2.3591
DEBUG - 2016-12-28 01:50:50 --> Config Class Initialized
DEBUG - 2016-12-28 01:50:50 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:50:50 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:50:50 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:50:50 --> URI Class Initialized
DEBUG - 2016-12-28 01:50:50 --> Router Class Initialized
ERROR - 2016-12-28 01:50:50 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:50:50 --> Config Class Initialized
DEBUG - 2016-12-28 01:50:50 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:50:50 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:50:50 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:50:50 --> URI Class Initialized
DEBUG - 2016-12-28 01:50:50 --> Router Class Initialized
ERROR - 2016-12-28 01:50:50 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:50:58 --> Config Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:50:58 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:50:58 --> URI Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Router Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Output Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Security Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Input Class Initialized
DEBUG - 2016-12-28 01:50:58 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:58 --> XSS Filtering completed
DEBUG - 2016-12-28 01:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:50:58 --> Language Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Loader Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:50:58 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:50:58 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:50:58 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:50:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:50:58 --> Session Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:50:58 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Session routines successfully run
ERROR - 2016-12-28 01:50:58 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:50:58 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:50:58 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:50:58 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:50:58 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Table Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:50:58 --> Model Class Initialized
DEBUG - 2016-12-28 01:50:58 --> Controller Class Initialized
DEBUG - 2016-12-28 01:50:59 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:50:59 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:50:59 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-12-28 01:51:00 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-28 01:51:00 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:51:00 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:51:00 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 01:51:00 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 01:51:00 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 01:51:00 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:51:00 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:51:00 --> Final output sent to browser
DEBUG - 2016-12-28 01:51:00 --> Total execution time: 1.7881
DEBUG - 2016-12-28 01:51:00 --> Config Class Initialized
DEBUG - 2016-12-28 01:51:00 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:51:00 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:51:00 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:51:00 --> URI Class Initialized
DEBUG - 2016-12-28 01:51:00 --> Router Class Initialized
ERROR - 2016-12-28 01:51:00 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:51:07 --> Config Class Initialized
DEBUG - 2016-12-28 01:51:07 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:51:08 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:51:08 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:51:08 --> URI Class Initialized
DEBUG - 2016-12-28 01:51:08 --> Router Class Initialized
DEBUG - 2016-12-28 01:51:08 --> Output Class Initialized
DEBUG - 2016-12-28 01:51:08 --> Security Class Initialized
DEBUG - 2016-12-28 01:51:08 --> Input Class Initialized
DEBUG - 2016-12-28 01:51:08 --> XSS Filtering completed
DEBUG - 2016-12-28 01:51:08 --> XSS Filtering completed
DEBUG - 2016-12-28 01:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:51:08 --> Language Class Initialized
DEBUG - 2016-12-28 01:51:08 --> Loader Class Initialized
DEBUG - 2016-12-28 01:51:08 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:51:08 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:51:08 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:51:08 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:51:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:51:08 --> Session Class Initialized
DEBUG - 2016-12-28 01:51:08 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:51:08 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:51:08 --> Session routines successfully run
ERROR - 2016-12-28 01:51:08 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:51:08 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:51:08 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:51:08 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:51:08 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:51:08 --> Table Class Initialized
DEBUG - 2016-12-28 01:51:08 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:08 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:08 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:51:08 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:08 --> Controller Class Initialized
DEBUG - 2016-12-28 01:51:09 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:51:09 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:51:09 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-12-28 01:51:10 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-28 01:51:10 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:51:10 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:51:10 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 01:51:10 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 01:51:10 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 01:51:10 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:51:10 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:51:10 --> Final output sent to browser
DEBUG - 2016-12-28 01:51:10 --> Total execution time: 2.2771
DEBUG - 2016-12-28 01:51:10 --> Config Class Initialized
DEBUG - 2016-12-28 01:51:10 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:51:10 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:51:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:51:10 --> URI Class Initialized
DEBUG - 2016-12-28 01:51:10 --> Router Class Initialized
ERROR - 2016-12-28 01:51:10 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:51:19 --> Config Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:51:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:51:19 --> URI Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Router Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Output Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Security Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Input Class Initialized
DEBUG - 2016-12-28 01:51:19 --> XSS Filtering completed
DEBUG - 2016-12-28 01:51:19 --> XSS Filtering completed
DEBUG - 2016-12-28 01:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:51:19 --> Language Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Loader Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:51:19 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:51:19 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:51:19 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:51:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:51:19 --> Session Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:51:19 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Session routines successfully run
ERROR - 2016-12-28 01:51:19 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:51:19 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:51:19 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:51:19 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:51:19 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Table Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:51:19 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:19 --> Controller Class Initialized
DEBUG - 2016-12-28 01:51:21 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:51:21 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:51:21 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-12-28 01:51:22 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-28 01:51:22 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:51:22 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:51:22 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 01:51:22 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 01:51:22 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 01:51:22 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:51:22 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:51:22 --> Final output sent to browser
DEBUG - 2016-12-28 01:51:22 --> Total execution time: 2.5011
DEBUG - 2016-12-28 01:51:22 --> Config Class Initialized
DEBUG - 2016-12-28 01:51:22 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:51:22 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:51:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:51:22 --> URI Class Initialized
DEBUG - 2016-12-28 01:51:22 --> Router Class Initialized
ERROR - 2016-12-28 01:51:22 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:51:31 --> Config Class Initialized
DEBUG - 2016-12-28 01:51:31 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:51:31 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:51:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:51:32 --> URI Class Initialized
DEBUG - 2016-12-28 01:51:32 --> Router Class Initialized
DEBUG - 2016-12-28 01:51:32 --> Output Class Initialized
DEBUG - 2016-12-28 01:51:32 --> Security Class Initialized
DEBUG - 2016-12-28 01:51:32 --> Input Class Initialized
DEBUG - 2016-12-28 01:51:32 --> XSS Filtering completed
DEBUG - 2016-12-28 01:51:32 --> XSS Filtering completed
DEBUG - 2016-12-28 01:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:51:32 --> Language Class Initialized
DEBUG - 2016-12-28 01:51:32 --> Loader Class Initialized
DEBUG - 2016-12-28 01:51:32 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:51:32 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:51:32 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:51:32 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:51:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:51:32 --> Session Class Initialized
DEBUG - 2016-12-28 01:51:32 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:51:32 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:51:32 --> Session routines successfully run
ERROR - 2016-12-28 01:51:32 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:51:32 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:51:32 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:51:32 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:51:32 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:51:32 --> Table Class Initialized
DEBUG - 2016-12-28 01:51:32 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:32 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:32 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:51:32 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:32 --> Controller Class Initialized
DEBUG - 2016-12-28 01:51:33 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:51:33 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:51:33 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-12-28 01:51:34 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-28 01:51:34 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:51:34 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:51:34 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 01:51:34 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 01:51:34 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 01:51:34 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:51:34 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:51:34 --> Final output sent to browser
DEBUG - 2016-12-28 01:51:34 --> Total execution time: 2.8562
DEBUG - 2016-12-28 01:51:34 --> Config Class Initialized
DEBUG - 2016-12-28 01:51:34 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:51:34 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:51:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:51:34 --> URI Class Initialized
DEBUG - 2016-12-28 01:51:34 --> Router Class Initialized
ERROR - 2016-12-28 01:51:34 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:51:41 --> Config Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:51:41 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:51:41 --> URI Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Router Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Output Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Security Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Input Class Initialized
DEBUG - 2016-12-28 01:51:41 --> XSS Filtering completed
DEBUG - 2016-12-28 01:51:41 --> XSS Filtering completed
DEBUG - 2016-12-28 01:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:51:41 --> Language Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Loader Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:51:41 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:51:41 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:51:41 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:51:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:51:41 --> Session Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:51:41 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Session routines successfully run
ERROR - 2016-12-28 01:51:41 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:51:41 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:51:41 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:51:41 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:51:41 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Table Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:51:41 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:41 --> Controller Class Initialized
DEBUG - 2016-12-28 01:51:42 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:51:42 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:51:42 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-12-28 01:51:43 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-28 01:51:43 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:51:43 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:51:43 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 01:51:43 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 01:51:43 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 01:51:43 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:51:43 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:51:43 --> Final output sent to browser
DEBUG - 2016-12-28 01:51:43 --> Total execution time: 1.9061
DEBUG - 2016-12-28 01:51:43 --> Config Class Initialized
DEBUG - 2016-12-28 01:51:43 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:51:43 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:51:43 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:51:43 --> URI Class Initialized
DEBUG - 2016-12-28 01:51:43 --> Router Class Initialized
ERROR - 2016-12-28 01:51:43 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:51:48 --> Config Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:51:48 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:51:48 --> URI Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Router Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Output Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Security Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Input Class Initialized
DEBUG - 2016-12-28 01:51:48 --> XSS Filtering completed
DEBUG - 2016-12-28 01:51:48 --> XSS Filtering completed
DEBUG - 2016-12-28 01:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:51:48 --> Language Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Loader Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:51:48 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:51:48 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:51:48 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:51:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:51:48 --> Session Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:51:48 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Session routines successfully run
ERROR - 2016-12-28 01:51:48 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:51:48 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:51:48 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:51:48 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:51:48 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Table Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:51:48 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:48 --> Controller Class Initialized
DEBUG - 2016-12-28 01:51:49 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:51:49 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:51:49 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-12-28 01:51:50 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-28 01:51:50 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:51:50 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:51:50 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 01:51:50 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 01:51:50 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 01:51:50 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:51:50 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:51:50 --> Final output sent to browser
DEBUG - 2016-12-28 01:51:50 --> Total execution time: 1.6401
DEBUG - 2016-12-28 01:51:50 --> Config Class Initialized
DEBUG - 2016-12-28 01:51:50 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:51:50 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:51:50 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:51:50 --> URI Class Initialized
DEBUG - 2016-12-28 01:51:50 --> Router Class Initialized
ERROR - 2016-12-28 01:51:50 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:51:59 --> Config Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:51:59 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:51:59 --> URI Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Router Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Output Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Security Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Input Class Initialized
DEBUG - 2016-12-28 01:51:59 --> XSS Filtering completed
DEBUG - 2016-12-28 01:51:59 --> XSS Filtering completed
DEBUG - 2016-12-28 01:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:51:59 --> Language Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Loader Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:51:59 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:51:59 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:51:59 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:51:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:51:59 --> Session Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:51:59 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Session routines successfully run
ERROR - 2016-12-28 01:51:59 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:51:59 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:51:59 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:51:59 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:51:59 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Table Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:51:59 --> Model Class Initialized
DEBUG - 2016-12-28 01:51:59 --> Controller Class Initialized
DEBUG - 2016-12-28 01:52:01 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:52:01 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:52:01 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:52:01 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:52:01 --> File loaded: application/views/signup/main.php
DEBUG - 2016-12-28 01:52:01 --> File loaded: application/views/signup/login.php
DEBUG - 2016-12-28 01:52:01 --> File loaded: application/views/signup/personal.php
ERROR - 2016-12-28 01:52:01 --> Could not find the language line "register"
DEBUG - 2016-12-28 01:52:01 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-12-28 01:52:01 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:52:01 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:52:01 --> Final output sent to browser
DEBUG - 2016-12-28 01:52:01 --> Total execution time: 1.7511
DEBUG - 2016-12-28 01:52:01 --> Config Class Initialized
DEBUG - 2016-12-28 01:52:01 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:52:01 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:52:01 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:52:01 --> URI Class Initialized
DEBUG - 2016-12-28 01:52:01 --> Router Class Initialized
ERROR - 2016-12-28 01:52:01 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:52:25 --> Config Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:52:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:52:25 --> URI Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Router Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Output Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Security Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Input Class Initialized
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:52:25 --> Language Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Loader Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:52:25 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:52:25 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:52:25 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:52:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:52:25 --> Session Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:52:25 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Session routines successfully run
ERROR - 2016-12-28 01:52:25 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:52:25 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:52:25 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:52:25 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:52:25 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Table Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Model Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Model Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:52:25 --> Model Class Initialized
DEBUG - 2016-12-28 01:52:25 --> Controller Class Initialized
DEBUG - 2016-12-28 01:52:27 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:52:27 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:52:27 --> Form Validation Class Initialized
ERROR - 2016-12-28 01:52:27 --> Could not find the language line "year"
ERROR - 2016-12-28 01:52:27 --> Could not find the language line "retype"
DEBUG - 2016-12-28 01:52:27 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-12-28 01:52:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:52:28 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:52:28 --> File loaded: application/views/signup/main.php
DEBUG - 2016-12-28 01:52:28 --> File loaded: application/views/signup/login.php
DEBUG - 2016-12-28 01:52:28 --> File loaded: application/views/signup/personal.php
ERROR - 2016-12-28 01:52:28 --> Could not find the language line "register"
DEBUG - 2016-12-28 01:52:28 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-12-28 01:52:28 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:52:28 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:52:28 --> Final output sent to browser
DEBUG - 2016-12-28 01:52:28 --> Total execution time: 2.5141
DEBUG - 2016-12-28 01:52:28 --> Config Class Initialized
DEBUG - 2016-12-28 01:52:28 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:52:28 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:52:28 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:52:28 --> URI Class Initialized
DEBUG - 2016-12-28 01:52:28 --> Router Class Initialized
ERROR - 2016-12-28 01:52:28 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:52:37 --> Config Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:52:37 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:52:37 --> URI Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Router Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Output Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Security Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Input Class Initialized
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:52:37 --> Language Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Loader Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:52:37 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:52:37 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:52:37 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:52:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:52:37 --> Session Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:52:37 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Session routines successfully run
ERROR - 2016-12-28 01:52:37 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:52:37 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:52:37 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:52:37 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:52:37 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Table Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Model Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Model Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:52:37 --> Model Class Initialized
DEBUG - 2016-12-28 01:52:37 --> Controller Class Initialized
DEBUG - 2016-12-28 01:52:39 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:52:39 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:52:39 --> Form Validation Class Initialized
ERROR - 2016-12-28 01:52:39 --> Could not find the language line "year"
ERROR - 2016-12-28 01:52:39 --> Could not find the language line "retype"
DEBUG - 2016-12-28 01:52:39 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-12-28 01:52:39 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:52:39 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:52:39 --> File loaded: application/views/signup/main.php
DEBUG - 2016-12-28 01:52:39 --> File loaded: application/views/signup/login.php
DEBUG - 2016-12-28 01:52:39 --> File loaded: application/views/signup/personal.php
ERROR - 2016-12-28 01:52:39 --> Could not find the language line "register"
DEBUG - 2016-12-28 01:52:39 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-12-28 01:52:39 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:52:39 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:52:39 --> Final output sent to browser
DEBUG - 2016-12-28 01:52:39 --> Total execution time: 1.8881
DEBUG - 2016-12-28 01:52:39 --> Config Class Initialized
DEBUG - 2016-12-28 01:52:39 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:52:39 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:52:39 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:52:39 --> URI Class Initialized
DEBUG - 2016-12-28 01:52:39 --> Router Class Initialized
ERROR - 2016-12-28 01:52:39 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:52:55 --> Config Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:52:55 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:52:55 --> URI Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Router Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Output Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Security Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Input Class Initialized
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:52:55 --> Language Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Loader Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:52:55 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:52:55 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:52:55 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:52:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:52:55 --> Session Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:52:55 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Session routines successfully run
ERROR - 2016-12-28 01:52:55 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:52:55 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:52:55 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:52:55 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:52:55 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Table Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Model Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Model Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:52:55 --> Model Class Initialized
DEBUG - 2016-12-28 01:52:55 --> Controller Class Initialized
DEBUG - 2016-12-28 01:52:56 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:52:56 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:52:56 --> Form Validation Class Initialized
ERROR - 2016-12-28 01:52:56 --> Could not find the language line "year"
ERROR - 2016-12-28 01:52:56 --> Could not find the language line "retype"
DEBUG - 2016-12-28 01:52:56 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> Config Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:52:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:52:57 --> URI Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Router Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Output Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Security Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Input Class Initialized
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> XSS Filtering completed
DEBUG - 2016-12-28 01:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:52:57 --> Language Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Loader Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:52:57 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:52:57 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:52:57 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:52:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:52:57 --> Session Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:52:57 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Session routines successfully run
ERROR - 2016-12-28 01:52:57 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:52:57 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:52:57 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:52:57 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:52:57 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Table Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Model Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Model Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:52:57 --> Model Class Initialized
DEBUG - 2016-12-28 01:52:57 --> Controller Class Initialized
DEBUG - 2016-12-28 01:52:59 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:52:59 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-28 01:52:59 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-28 01:52:59 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:52:59 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:52:59 --> File loaded: application/views/signup/complete.php
DEBUG - 2016-12-28 01:52:59 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:52:59 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:52:59 --> Final output sent to browser
DEBUG - 2016-12-28 01:52:59 --> Total execution time: 1.9451
DEBUG - 2016-12-28 01:52:59 --> Config Class Initialized
DEBUG - 2016-12-28 01:52:59 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:52:59 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:52:59 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:52:59 --> URI Class Initialized
DEBUG - 2016-12-28 01:52:59 --> Router Class Initialized
ERROR - 2016-12-28 01:52:59 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:53:20 --> Config Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:53:20 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:53:20 --> URI Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Router Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Output Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Security Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Input Class Initialized
DEBUG - 2016-12-28 01:53:20 --> XSS Filtering completed
DEBUG - 2016-12-28 01:53:20 --> XSS Filtering completed
DEBUG - 2016-12-28 01:53:20 --> XSS Filtering completed
DEBUG - 2016-12-28 01:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:53:20 --> Language Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Loader Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:53:20 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:53:20 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:53:20 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:53:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:53:20 --> Session Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:53:20 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Session routines successfully run
ERROR - 2016-12-28 01:53:20 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:53:20 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:53:20 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:53:20 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:53:20 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Table Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Model Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Model Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:53:20 --> Model Class Initialized
DEBUG - 2016-12-28 01:53:20 --> Controller Class Initialized
DEBUG - 2016-12-28 01:53:21 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:53:21 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:53:21 --> Upload Class Initialized
DEBUG - 2016-12-28 01:53:21 --> Language file loaded: language/arabic/upload_lang.php
ERROR - 2016-12-28 01:53:21 --> لم تختر ملف لرفعه.
DEBUG - 2016-12-28 01:53:21 --> Language file loaded: language/arabic/imglib_lang.php
ERROR - 2016-12-28 01:53:21 --> مسار الصورة غير صحيح.
DEBUG - 2016-12-28 01:53:21 --> Image Lib Class Initialized
ERROR - 2016-12-28 01:53:21 --> الخادم لا يدعم دوال مكتبة GD المطلوبة للتعامل مع نوع الصاورة.
DEBUG - 2016-12-28 01:53:21 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:53:21 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:53:21 --> File loaded: application/views/signup/success.php
DEBUG - 2016-12-28 01:53:21 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:53:21 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:53:21 --> Final output sent to browser
DEBUG - 2016-12-28 01:53:21 --> Total execution time: 1.7381
DEBUG - 2016-12-28 01:53:21 --> Config Class Initialized
DEBUG - 2016-12-28 01:53:21 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:53:21 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:53:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:53:21 --> URI Class Initialized
DEBUG - 2016-12-28 01:53:21 --> Router Class Initialized
ERROR - 2016-12-28 01:53:21 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:54:16 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:16 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Router Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Output Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Security Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Input Class Initialized
DEBUG - 2016-12-28 01:54:16 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:16 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:16 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:54:16 --> Language Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Loader Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:54:16 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:54:16 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:54:16 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:54:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:54:16 --> Session Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:54:16 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Session routines successfully run
ERROR - 2016-12-28 01:54:16 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:54:16 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:54:16 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:54:16 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:54:16 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Table Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:54:16 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:16 --> Controller Class Initialized
DEBUG - 2016-12-28 01:54:18 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:54:18 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:54:18 --> Upload Class Initialized
DEBUG - 2016-12-28 01:54:18 --> Image Lib Class Initialized
DEBUG - 2016-12-28 01:54:18 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:54:18 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:54:18 --> File loaded: application/views/signup/success.php
DEBUG - 2016-12-28 01:54:18 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:54:18 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:54:18 --> Final output sent to browser
DEBUG - 2016-12-28 01:54:18 --> Total execution time: 2.2011
DEBUG - 2016-12-28 01:54:18 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:18 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:18 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:18 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:18 --> Router Class Initialized
ERROR - 2016-12-28 01:54:18 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:54:22 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:22 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Router Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Output Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Security Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Input Class Initialized
DEBUG - 2016-12-28 01:54:22 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:22 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:54:22 --> Language Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Loader Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:54:22 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:54:22 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:54:22 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:54:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:54:22 --> Session Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:54:22 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Session routines successfully run
ERROR - 2016-12-28 01:54:22 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:54:22 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:54:22 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:54:22 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:54:22 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Table Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:54:22 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Controller Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:54:22 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:54:22 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:54:22 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:54:22 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-28 01:54:22 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:54:22 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:54:22 --> Final output sent to browser
DEBUG - 2016-12-28 01:54:22 --> Total execution time: 0.1110
DEBUG - 2016-12-28 01:54:22 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:22 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:22 --> Router Class Initialized
ERROR - 2016-12-28 01:54:22 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:54:29 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:29 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:29 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Router Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Output Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Security Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Input Class Initialized
DEBUG - 2016-12-28 01:54:29 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:29 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:29 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:29 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:29 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:54:29 --> Language Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Loader Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:54:29 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:54:29 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:54:29 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:54:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:54:29 --> Session Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:54:29 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Session routines successfully run
ERROR - 2016-12-28 01:54:29 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:54:29 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:54:29 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:54:29 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:54:29 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Table Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:54:29 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Controller Class Initialized
DEBUG - 2016-12-28 01:54:29 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:54:29 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:54:29 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:32 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:32 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Router Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Output Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Security Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Input Class Initialized
DEBUG - 2016-12-28 01:54:32 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:32 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:54:32 --> Language Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Loader Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:54:32 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:54:32 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:54:32 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:54:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:54:32 --> Session Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:54:32 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Session routines successfully run
ERROR - 2016-12-28 01:54:32 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:54:32 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:54:32 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:54:32 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:54:32 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Table Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:54:32 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:32 --> Controller Class Initialized
DEBUG - 2016-12-28 01:54:33 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:54:33 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:54:34 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:54:34 --> File loaded: application/views/includes/header.php
ERROR - 2016-12-28 01:54:34 --> Could not find the language line "not_found_message"
DEBUG - 2016-12-28 01:54:34 --> File loaded: application/views/not_found.php
DEBUG - 2016-12-28 01:54:34 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:54:34 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:54:34 --> Final output sent to browser
DEBUG - 2016-12-28 01:54:34 --> Total execution time: 1.9121
DEBUG - 2016-12-28 01:54:34 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:34 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:34 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:34 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:34 --> Router Class Initialized
ERROR - 2016-12-28 01:54:34 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:54:38 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:38 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:38 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:38 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:38 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:38 --> Router Class Initialized
DEBUG - 2016-12-28 01:54:38 --> Output Class Initialized
DEBUG - 2016-12-28 01:54:38 --> Security Class Initialized
DEBUG - 2016-12-28 01:54:38 --> Input Class Initialized
DEBUG - 2016-12-28 01:54:38 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:38 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:54:38 --> Language Class Initialized
DEBUG - 2016-12-28 01:54:38 --> Loader Class Initialized
DEBUG - 2016-12-28 01:54:38 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:54:38 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:54:38 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:54:38 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:54:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:54:38 --> Session Class Initialized
DEBUG - 2016-12-28 01:54:38 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:54:38 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:54:39 --> Session routines successfully run
ERROR - 2016-12-28 01:54:39 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:54:39 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:54:39 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:54:39 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:54:39 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:54:39 --> Table Class Initialized
DEBUG - 2016-12-28 01:54:39 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:39 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:39 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:54:39 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:39 --> Controller Class Initialized
DEBUG - 2016-12-28 01:54:39 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:54:39 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:54:39 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:54:39 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:54:39 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-28 01:54:39 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:54:39 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:54:39 --> Final output sent to browser
DEBUG - 2016-12-28 01:54:39 --> Total execution time: 0.1380
DEBUG - 2016-12-28 01:54:39 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:39 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:39 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:39 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:39 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:39 --> Router Class Initialized
ERROR - 2016-12-28 01:54:39 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:54:44 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:44 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:44 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Router Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Output Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Security Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Input Class Initialized
DEBUG - 2016-12-28 01:54:44 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:44 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:44 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:44 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:44 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:54:44 --> Language Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Loader Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:54:44 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:54:44 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:54:44 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:54:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:54:44 --> Session Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:54:44 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Session routines successfully run
ERROR - 2016-12-28 01:54:44 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:54:44 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:54:44 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:54:44 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:54:44 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Table Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:54:44 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Controller Class Initialized
DEBUG - 2016-12-28 01:54:44 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:54:44 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:54:44 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:46 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:46 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Router Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Output Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Security Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Input Class Initialized
DEBUG - 2016-12-28 01:54:46 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:46 --> XSS Filtering completed
DEBUG - 2016-12-28 01:54:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:54:46 --> Language Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Loader Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:54:46 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:54:46 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:54:46 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:54:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:54:46 --> Session Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:54:46 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Session routines successfully run
ERROR - 2016-12-28 01:54:46 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:54:46 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:54:46 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:54:46 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:54:46 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Table Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:54:46 --> Model Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Controller Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Form Validation Class Initialized
DEBUG - 2016-12-28 01:54:46 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:54:46 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:54:48 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:54:48 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-28 01:54:48 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-28 01:54:48 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-28 01:54:48 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-28 01:54:48 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-28 01:54:48 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-28 01:54:48 --> Final output sent to browser
DEBUG - 2016-12-28 01:54:48 --> Total execution time: 1.9321
DEBUG - 2016-12-28 01:54:48 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:48 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:48 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:48 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:48 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:48 --> Router Class Initialized
ERROR - 2016-12-28 01:54:48 --> 404 Page Not Found --> application
DEBUG - 2016-12-28 01:54:48 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:48 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:48 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:48 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:48 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:48 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:48 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:48 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:48 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:48 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:48 --> Router Class Initialized
DEBUG - 2016-12-28 01:54:48 --> Router Class Initialized
ERROR - 2016-12-28 01:54:48 --> 404 Page Not Found --> application
ERROR - 2016-12-28 01:54:48 --> 404 Page Not Found --> application
DEBUG - 2016-12-28 01:54:48 --> Config Class Initialized
DEBUG - 2016-12-28 01:54:48 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:54:48 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:54:48 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:54:48 --> URI Class Initialized
DEBUG - 2016-12-28 01:54:48 --> Router Class Initialized
ERROR - 2016-12-28 01:54:48 --> 404 Page Not Found --> application
DEBUG - 2016-12-28 01:55:09 --> Config Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:55:09 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:55:09 --> URI Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Router Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Output Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Security Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Input Class Initialized
DEBUG - 2016-12-28 01:55:09 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:09 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:55:09 --> Language Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Loader Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:55:09 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:55:09 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:55:09 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:55:09 --> Session Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:55:09 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Session routines successfully run
ERROR - 2016-12-28 01:55:09 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:55:09 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:55:09 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:55:09 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:55:09 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Table Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:55:09 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Controller Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Form Validation Class Initialized
DEBUG - 2016-12-28 01:55:09 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:55:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:55:10 --> Config Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:55:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:55:10 --> URI Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Router Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Output Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Security Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Input Class Initialized
DEBUG - 2016-12-28 01:55:10 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:10 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:55:10 --> Language Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Loader Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:55:10 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:55:10 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:55:10 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:55:10 --> Session Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:55:10 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Session routines successfully run
ERROR - 2016-12-28 01:55:10 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:55:10 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:55:10 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:55:10 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:55:10 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Table Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:55:10 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Controller Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Form Validation Class Initialized
DEBUG - 2016-12-28 01:55:10 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:55:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:55:11 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:55:11 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-28 01:55:11 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-28 01:55:11 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-28 01:55:11 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-28 01:55:11 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-28 01:55:11 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-28 01:55:11 --> Final output sent to browser
DEBUG - 2016-12-28 01:55:11 --> Total execution time: 1.7531
DEBUG - 2016-12-28 01:55:16 --> Config Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:55:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:55:16 --> URI Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Router Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Output Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Security Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Input Class Initialized
DEBUG - 2016-12-28 01:55:16 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:16 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:55:16 --> Language Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Loader Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:55:16 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:55:16 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:55:16 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:55:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:55:16 --> Session Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:55:16 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Session routines successfully run
ERROR - 2016-12-28 01:55:16 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:55:16 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:55:16 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:55:16 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:55:16 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Table Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:55:16 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Controller Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:55:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:55:16 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:55:16 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:55:16 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-28 01:55:16 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:55:16 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:55:16 --> Final output sent to browser
DEBUG - 2016-12-28 01:55:16 --> Total execution time: 0.1170
DEBUG - 2016-12-28 01:55:16 --> Config Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:55:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:55:16 --> URI Class Initialized
DEBUG - 2016-12-28 01:55:16 --> Router Class Initialized
ERROR - 2016-12-28 01:55:16 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:55:18 --> Config Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:55:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:55:18 --> URI Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Router Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Output Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Security Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Input Class Initialized
DEBUG - 2016-12-28 01:55:18 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:18 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:55:18 --> Language Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Loader Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:55:18 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:55:18 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:55:18 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:55:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:55:18 --> Session Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:55:18 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:55:18 --> A session cookie was not found.
DEBUG - 2016-12-28 01:55:18 --> Session routines successfully run
ERROR - 2016-12-28 01:55:18 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:55:18 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:55:18 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:55:18 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:55:18 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Table Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:55:18 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Controller Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:55:18 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:55:18 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:55:18 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:55:18 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-28 01:55:18 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:55:18 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:55:18 --> Final output sent to browser
DEBUG - 2016-12-28 01:55:18 --> Total execution time: 0.0770
DEBUG - 2016-12-28 01:55:18 --> Config Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:55:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:55:18 --> URI Class Initialized
DEBUG - 2016-12-28 01:55:18 --> Router Class Initialized
ERROR - 2016-12-28 01:55:18 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:55:25 --> Config Class Initialized
DEBUG - 2016-12-28 01:55:25 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:55:25 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:55:25 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:55:25 --> URI Class Initialized
DEBUG - 2016-12-28 01:55:25 --> Router Class Initialized
DEBUG - 2016-12-28 01:55:25 --> Output Class Initialized
DEBUG - 2016-12-28 01:55:25 --> Security Class Initialized
DEBUG - 2016-12-28 01:55:25 --> Input Class Initialized
DEBUG - 2016-12-28 01:55:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:25 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:55:25 --> Language Class Initialized
DEBUG - 2016-12-28 01:55:25 --> Loader Class Initialized
DEBUG - 2016-12-28 01:55:25 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:55:25 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:55:25 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:55:25 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:55:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:55:25 --> Session Class Initialized
DEBUG - 2016-12-28 01:55:25 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:55:25 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:55:25 --> Session routines successfully run
ERROR - 2016-12-28 01:55:26 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:55:26 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:55:26 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:55:26 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:55:26 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:55:26 --> Table Class Initialized
DEBUG - 2016-12-28 01:55:26 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:26 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:26 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:55:26 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:26 --> Controller Class Initialized
DEBUG - 2016-12-28 01:55:26 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:55:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:55:26 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Config Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:55:28 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:55:28 --> URI Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Router Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Output Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Security Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Input Class Initialized
DEBUG - 2016-12-28 01:55:28 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:28 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:55:28 --> Language Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Loader Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:55:28 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:55:28 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:55:28 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:55:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:55:28 --> Session Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:55:28 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Session routines successfully run
ERROR - 2016-12-28 01:55:28 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:55:28 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:55:28 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:55:28 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:55:28 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Table Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:55:28 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:28 --> Controller Class Initialized
DEBUG - 2016-12-28 01:55:30 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:55:30 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:55:30 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:55:30 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:55:30 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-28 01:55:30 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:55:30 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:55:30 --> Final output sent to browser
DEBUG - 2016-12-28 01:55:30 --> Total execution time: 1.9351
DEBUG - 2016-12-28 01:55:30 --> Config Class Initialized
DEBUG - 2016-12-28 01:55:30 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:55:30 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:55:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:55:30 --> URI Class Initialized
DEBUG - 2016-12-28 01:55:30 --> Router Class Initialized
ERROR - 2016-12-28 01:55:30 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:55:41 --> Config Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:55:41 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:55:41 --> URI Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Router Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Output Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Security Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Input Class Initialized
DEBUG - 2016-12-28 01:55:41 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:41 --> XSS Filtering completed
DEBUG - 2016-12-28 01:55:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:55:41 --> Language Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Loader Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:55:41 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:55:41 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:55:41 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:55:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:55:41 --> Session Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:55:41 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Session routines successfully run
ERROR - 2016-12-28 01:55:41 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:55:41 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:55:41 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:55:41 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:55:41 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Table Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:55:41 --> Model Class Initialized
DEBUG - 2016-12-28 01:55:41 --> Controller Class Initialized
DEBUG - 2016-12-28 01:55:43 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:55:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:55:43 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:55:43 --> File loaded: application/views/includes/header.php
ERROR - 2016-12-28 01:55:43 --> Could not find the language line "id"
DEBUG - 2016-12-28 01:55:43 --> File loaded: application/views/signup/personal_edit.php
DEBUG - 2016-12-28 01:55:43 --> File loaded: application/views/alumni_edit_view.php
DEBUG - 2016-12-28 01:55:43 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:55:43 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:55:43 --> Final output sent to browser
DEBUG - 2016-12-28 01:55:43 --> Total execution time: 2.0741
DEBUG - 2016-12-28 01:55:43 --> Config Class Initialized
DEBUG - 2016-12-28 01:55:43 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:55:43 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:55:43 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:55:43 --> URI Class Initialized
DEBUG - 2016-12-28 01:55:43 --> Router Class Initialized
ERROR - 2016-12-28 01:55:43 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 01:56:06 --> Config Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:56:06 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:56:06 --> URI Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Router Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Output Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Security Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Input Class Initialized
DEBUG - 2016-12-28 01:56:06 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:06 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:06 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:06 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:06 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:06 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:06 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:06 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:06 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:06 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:06 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:06 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 01:56:06 --> Language Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Loader Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Helper loaded: url_helper
DEBUG - 2016-12-28 01:56:06 --> Helper loaded: form_helper
DEBUG - 2016-12-28 01:56:06 --> Helper loaded: func_helper
DEBUG - 2016-12-28 01:56:06 --> Database Driver Class Initialized
ERROR - 2016-12-28 01:56:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 01:56:06 --> Session Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Helper loaded: string_helper
DEBUG - 2016-12-28 01:56:06 --> Encrypt Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Session routines successfully run
ERROR - 2016-12-28 01:56:06 --> Could not find the language line "first_link"
ERROR - 2016-12-28 01:56:06 --> Could not find the language line "last_link"
ERROR - 2016-12-28 01:56:06 --> Could not find the language line "next_link"
ERROR - 2016-12-28 01:56:06 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 01:56:06 --> Pagination Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Table Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Model Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Model Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Helper loaded: file_helper
DEBUG - 2016-12-28 01:56:06 --> Model Class Initialized
DEBUG - 2016-12-28 01:56:06 --> Controller Class Initialized
DEBUG - 2016-12-28 01:56:07 --> Helper loaded: language_helper
DEBUG - 2016-12-28 01:56:07 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 01:56:07 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:07 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:07 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:07 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:07 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:07 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:07 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:07 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:07 --> XSS Filtering completed
DEBUG - 2016-12-28 01:56:07 --> XSS Filtering completed
ERROR - 2016-12-28 01:56:08 --> Severity: Notice  --> Undefined variable: email C:\xampp\htdocs\www\alumni\application\models\Alumni_model.php 332
DEBUG - 2016-12-28 01:56:08 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 01:56:08 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 01:56:08 --> File loaded: application/views/messages/success_edit.php
DEBUG - 2016-12-28 01:56:08 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 01:56:08 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 01:56:08 --> Final output sent to browser
DEBUG - 2016-12-28 01:56:08 --> Total execution time: 2.0001
DEBUG - 2016-12-28 01:56:08 --> Config Class Initialized
DEBUG - 2016-12-28 01:56:08 --> Hooks Class Initialized
DEBUG - 2016-12-28 01:56:08 --> Utf8 Class Initialized
DEBUG - 2016-12-28 01:56:08 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 01:56:08 --> URI Class Initialized
DEBUG - 2016-12-28 01:56:08 --> Router Class Initialized
ERROR - 2016-12-28 01:56:08 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 02:57:07 --> Config Class Initialized
DEBUG - 2016-12-28 02:57:07 --> Hooks Class Initialized
DEBUG - 2016-12-28 02:57:07 --> Utf8 Class Initialized
DEBUG - 2016-12-28 02:57:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 02:57:07 --> URI Class Initialized
DEBUG - 2016-12-28 02:57:07 --> Router Class Initialized
DEBUG - 2016-12-28 02:57:07 --> No URI present. Default controller set.
DEBUG - 2016-12-28 02:57:07 --> Output Class Initialized
DEBUG - 2016-12-28 02:57:07 --> Security Class Initialized
DEBUG - 2016-12-28 02:57:07 --> Input Class Initialized
DEBUG - 2016-12-28 02:57:07 --> XSS Filtering completed
DEBUG - 2016-12-28 02:57:07 --> XSS Filtering completed
DEBUG - 2016-12-28 02:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 02:57:07 --> Language Class Initialized
DEBUG - 2016-12-28 02:57:07 --> Loader Class Initialized
DEBUG - 2016-12-28 02:57:07 --> Helper loaded: url_helper
DEBUG - 2016-12-28 02:57:07 --> Helper loaded: form_helper
DEBUG - 2016-12-28 02:57:07 --> Helper loaded: func_helper
DEBUG - 2016-12-28 02:57:07 --> Database Driver Class Initialized
ERROR - 2016-12-28 02:57:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 02:57:07 --> Session Class Initialized
DEBUG - 2016-12-28 02:57:07 --> Helper loaded: string_helper
DEBUG - 2016-12-28 02:57:07 --> Encrypt Class Initialized
DEBUG - 2016-12-28 02:57:07 --> A session cookie was not found.
DEBUG - 2016-12-28 02:57:07 --> Session routines successfully run
ERROR - 2016-12-28 02:57:07 --> Could not find the language line "first_link"
ERROR - 2016-12-28 02:57:07 --> Could not find the language line "last_link"
ERROR - 2016-12-28 02:57:07 --> Could not find the language line "next_link"
ERROR - 2016-12-28 02:57:07 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 02:57:07 --> Pagination Class Initialized
DEBUG - 2016-12-28 02:57:07 --> Table Class Initialized
DEBUG - 2016-12-28 02:57:07 --> Model Class Initialized
DEBUG - 2016-12-28 02:57:07 --> Model Class Initialized
DEBUG - 2016-12-28 02:57:07 --> Helper loaded: file_helper
DEBUG - 2016-12-28 02:57:07 --> Model Class Initialized
DEBUG - 2016-12-28 02:57:07 --> Controller Class Initialized
DEBUG - 2016-12-28 02:57:07 --> DB Transaction Failure
ERROR - 2016-12-28 02:57:07 --> Query error: Table 'univ_alumni_online1.lk9v6_settings' doesn't exist
DEBUG - 2016-12-28 02:57:07 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-28 02:57:07 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-28 02:58:01 --> Config Class Initialized
DEBUG - 2016-12-28 02:58:01 --> Hooks Class Initialized
DEBUG - 2016-12-28 02:58:01 --> Utf8 Class Initialized
DEBUG - 2016-12-28 02:58:01 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 02:58:01 --> URI Class Initialized
DEBUG - 2016-12-28 02:58:01 --> Router Class Initialized
DEBUG - 2016-12-28 02:58:01 --> No URI present. Default controller set.
DEBUG - 2016-12-28 02:58:01 --> Output Class Initialized
DEBUG - 2016-12-28 02:58:01 --> Security Class Initialized
DEBUG - 2016-12-28 02:58:01 --> Input Class Initialized
DEBUG - 2016-12-28 02:58:01 --> XSS Filtering completed
DEBUG - 2016-12-28 02:58:01 --> XSS Filtering completed
DEBUG - 2016-12-28 02:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 02:58:01 --> Language Class Initialized
DEBUG - 2016-12-28 02:58:01 --> Loader Class Initialized
DEBUG - 2016-12-28 02:58:01 --> Helper loaded: url_helper
DEBUG - 2016-12-28 02:58:01 --> Helper loaded: form_helper
DEBUG - 2016-12-28 02:58:01 --> Helper loaded: func_helper
DEBUG - 2016-12-28 02:58:01 --> Database Driver Class Initialized
ERROR - 2016-12-28 02:58:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 02:58:01 --> Session Class Initialized
DEBUG - 2016-12-28 02:58:01 --> Helper loaded: string_helper
DEBUG - 2016-12-28 02:58:01 --> Encrypt Class Initialized
DEBUG - 2016-12-28 02:58:01 --> Session routines successfully run
ERROR - 2016-12-28 02:58:01 --> Could not find the language line "first_link"
ERROR - 2016-12-28 02:58:01 --> Could not find the language line "last_link"
ERROR - 2016-12-28 02:58:01 --> Could not find the language line "next_link"
ERROR - 2016-12-28 02:58:01 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 02:58:01 --> Pagination Class Initialized
DEBUG - 2016-12-28 02:58:01 --> Table Class Initialized
DEBUG - 2016-12-28 02:58:01 --> Model Class Initialized
DEBUG - 2016-12-28 02:58:01 --> Model Class Initialized
DEBUG - 2016-12-28 02:58:01 --> Helper loaded: file_helper
DEBUG - 2016-12-28 02:58:01 --> Model Class Initialized
DEBUG - 2016-12-28 02:58:01 --> Controller Class Initialized
DEBUG - 2016-12-28 02:58:03 --> DB Transaction Failure
ERROR - 2016-12-28 02:58:03 --> Query error: Table 'univ_alumni_online1.lk9v6_debug' doesn't exist
DEBUG - 2016-12-28 02:58:03 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-28 02:58:03 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-28 02:59:02 --> Config Class Initialized
DEBUG - 2016-12-28 02:59:02 --> Hooks Class Initialized
DEBUG - 2016-12-28 02:59:02 --> Utf8 Class Initialized
DEBUG - 2016-12-28 02:59:02 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 02:59:02 --> URI Class Initialized
DEBUG - 2016-12-28 02:59:02 --> Router Class Initialized
DEBUG - 2016-12-28 02:59:02 --> No URI present. Default controller set.
DEBUG - 2016-12-28 02:59:02 --> Output Class Initialized
DEBUG - 2016-12-28 02:59:02 --> Security Class Initialized
DEBUG - 2016-12-28 02:59:02 --> Input Class Initialized
DEBUG - 2016-12-28 02:59:02 --> XSS Filtering completed
DEBUG - 2016-12-28 02:59:02 --> XSS Filtering completed
DEBUG - 2016-12-28 02:59:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 02:59:02 --> Language Class Initialized
DEBUG - 2016-12-28 02:59:02 --> Loader Class Initialized
DEBUG - 2016-12-28 02:59:02 --> Helper loaded: url_helper
DEBUG - 2016-12-28 02:59:02 --> Helper loaded: form_helper
DEBUG - 2016-12-28 02:59:02 --> Helper loaded: func_helper
DEBUG - 2016-12-28 02:59:02 --> Database Driver Class Initialized
ERROR - 2016-12-28 02:59:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 02:59:02 --> Session Class Initialized
DEBUG - 2016-12-28 02:59:02 --> Helper loaded: string_helper
DEBUG - 2016-12-28 02:59:02 --> Encrypt Class Initialized
DEBUG - 2016-12-28 02:59:02 --> Session routines successfully run
ERROR - 2016-12-28 02:59:02 --> Could not find the language line "first_link"
ERROR - 2016-12-28 02:59:02 --> Could not find the language line "last_link"
ERROR - 2016-12-28 02:59:02 --> Could not find the language line "next_link"
ERROR - 2016-12-28 02:59:02 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 02:59:02 --> Pagination Class Initialized
DEBUG - 2016-12-28 02:59:02 --> Table Class Initialized
DEBUG - 2016-12-28 02:59:02 --> Model Class Initialized
DEBUG - 2016-12-28 02:59:02 --> Model Class Initialized
DEBUG - 2016-12-28 02:59:02 --> Helper loaded: file_helper
DEBUG - 2016-12-28 02:59:02 --> Model Class Initialized
DEBUG - 2016-12-28 02:59:02 --> Controller Class Initialized
DEBUG - 2016-12-28 02:59:04 --> Helper loaded: language_helper
DEBUG - 2016-12-28 02:59:04 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 02:59:05 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-28 02:59:07 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 02:59:07 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 02:59:07 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 02:59:07 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 02:59:07 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 02:59:07 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 02:59:07 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 02:59:07 --> Final output sent to browser
DEBUG - 2016-12-28 02:59:07 --> Total execution time: 4.6593
DEBUG - 2016-12-28 02:59:07 --> Config Class Initialized
DEBUG - 2016-12-28 02:59:07 --> Hooks Class Initialized
DEBUG - 2016-12-28 02:59:07 --> Utf8 Class Initialized
DEBUG - 2016-12-28 02:59:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 02:59:07 --> URI Class Initialized
DEBUG - 2016-12-28 02:59:07 --> Router Class Initialized
ERROR - 2016-12-28 02:59:07 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 02:59:14 --> Config Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Hooks Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Utf8 Class Initialized
DEBUG - 2016-12-28 02:59:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 02:59:14 --> URI Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Router Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Output Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Security Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Input Class Initialized
DEBUG - 2016-12-28 02:59:14 --> XSS Filtering completed
DEBUG - 2016-12-28 02:59:14 --> XSS Filtering completed
DEBUG - 2016-12-28 02:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 02:59:14 --> Language Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Loader Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Helper loaded: url_helper
DEBUG - 2016-12-28 02:59:14 --> Helper loaded: form_helper
DEBUG - 2016-12-28 02:59:14 --> Helper loaded: func_helper
DEBUG - 2016-12-28 02:59:14 --> Database Driver Class Initialized
ERROR - 2016-12-28 02:59:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 02:59:14 --> Session Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Helper loaded: string_helper
DEBUG - 2016-12-28 02:59:14 --> Encrypt Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Session routines successfully run
ERROR - 2016-12-28 02:59:14 --> Could not find the language line "first_link"
ERROR - 2016-12-28 02:59:14 --> Could not find the language line "last_link"
ERROR - 2016-12-28 02:59:14 --> Could not find the language line "next_link"
ERROR - 2016-12-28 02:59:14 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 02:59:14 --> Pagination Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Table Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Model Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Model Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Helper loaded: file_helper
DEBUG - 2016-12-28 02:59:14 --> Model Class Initialized
DEBUG - 2016-12-28 02:59:14 --> Controller Class Initialized
DEBUG - 2016-12-28 02:59:16 --> Helper loaded: language_helper
DEBUG - 2016-12-28 02:59:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 02:59:16 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 02:59:16 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 02:59:16 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-28 02:59:16 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 02:59:16 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 02:59:16 --> Final output sent to browser
DEBUG - 2016-12-28 02:59:16 --> Total execution time: 2.1221
DEBUG - 2016-12-28 02:59:16 --> Config Class Initialized
DEBUG - 2016-12-28 02:59:16 --> Hooks Class Initialized
DEBUG - 2016-12-28 02:59:16 --> Utf8 Class Initialized
DEBUG - 2016-12-28 02:59:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 02:59:16 --> URI Class Initialized
DEBUG - 2016-12-28 02:59:16 --> Router Class Initialized
ERROR - 2016-12-28 02:59:16 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 02:59:26 --> Config Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Hooks Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Utf8 Class Initialized
DEBUG - 2016-12-28 02:59:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 02:59:26 --> URI Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Router Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Output Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Security Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Input Class Initialized
DEBUG - 2016-12-28 02:59:26 --> XSS Filtering completed
DEBUG - 2016-12-28 02:59:26 --> XSS Filtering completed
DEBUG - 2016-12-28 02:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 02:59:26 --> Language Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Loader Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Helper loaded: url_helper
DEBUG - 2016-12-28 02:59:26 --> Helper loaded: form_helper
DEBUG - 2016-12-28 02:59:26 --> Helper loaded: func_helper
DEBUG - 2016-12-28 02:59:26 --> Database Driver Class Initialized
ERROR - 2016-12-28 02:59:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 02:59:26 --> Session Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Helper loaded: string_helper
DEBUG - 2016-12-28 02:59:26 --> Encrypt Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Session routines successfully run
ERROR - 2016-12-28 02:59:26 --> Could not find the language line "first_link"
ERROR - 2016-12-28 02:59:26 --> Could not find the language line "last_link"
ERROR - 2016-12-28 02:59:26 --> Could not find the language line "next_link"
ERROR - 2016-12-28 02:59:26 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 02:59:26 --> Pagination Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Table Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Model Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Model Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Helper loaded: file_helper
DEBUG - 2016-12-28 02:59:26 --> Model Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Controller Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Helper loaded: language_helper
DEBUG - 2016-12-28 02:59:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 02:59:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 02:59:26 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 02:59:26 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-28 02:59:26 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 02:59:26 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 02:59:26 --> Final output sent to browser
DEBUG - 2016-12-28 02:59:26 --> Total execution time: 0.1160
DEBUG - 2016-12-28 02:59:26 --> Config Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Hooks Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Utf8 Class Initialized
DEBUG - 2016-12-28 02:59:26 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 02:59:26 --> URI Class Initialized
DEBUG - 2016-12-28 02:59:26 --> Router Class Initialized
ERROR - 2016-12-28 02:59:26 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 02:59:30 --> Config Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Hooks Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Utf8 Class Initialized
DEBUG - 2016-12-28 02:59:30 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 02:59:30 --> URI Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Router Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Output Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Security Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Input Class Initialized
DEBUG - 2016-12-28 02:59:30 --> XSS Filtering completed
DEBUG - 2016-12-28 02:59:30 --> XSS Filtering completed
DEBUG - 2016-12-28 02:59:30 --> XSS Filtering completed
DEBUG - 2016-12-28 02:59:30 --> XSS Filtering completed
DEBUG - 2016-12-28 02:59:30 --> XSS Filtering completed
DEBUG - 2016-12-28 02:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 02:59:30 --> Language Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Loader Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Helper loaded: url_helper
DEBUG - 2016-12-28 02:59:30 --> Helper loaded: form_helper
DEBUG - 2016-12-28 02:59:30 --> Helper loaded: func_helper
DEBUG - 2016-12-28 02:59:30 --> Database Driver Class Initialized
ERROR - 2016-12-28 02:59:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 02:59:30 --> Session Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Helper loaded: string_helper
DEBUG - 2016-12-28 02:59:30 --> Encrypt Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Session routines successfully run
ERROR - 2016-12-28 02:59:30 --> Could not find the language line "first_link"
ERROR - 2016-12-28 02:59:30 --> Could not find the language line "last_link"
ERROR - 2016-12-28 02:59:30 --> Could not find the language line "next_link"
ERROR - 2016-12-28 02:59:30 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 02:59:30 --> Pagination Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Table Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Model Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Model Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Helper loaded: file_helper
DEBUG - 2016-12-28 02:59:30 --> Model Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Controller Class Initialized
DEBUG - 2016-12-28 02:59:30 --> Helper loaded: language_helper
DEBUG - 2016-12-28 02:59:30 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 02:59:30 --> Model Class Initialized
DEBUG - 2016-12-28 02:59:31 --> DB Transaction Failure
ERROR - 2016-12-28 02:59:31 --> Query error: Table 'univ_alumni_online1.lk9v6_alumni_data_other' doesn't exist
DEBUG - 2016-12-28 02:59:31 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-28 02:59:31 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-28 03:04:41 --> Config Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Hooks Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Utf8 Class Initialized
DEBUG - 2016-12-28 03:04:41 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 03:04:41 --> URI Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Router Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Output Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Security Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Input Class Initialized
DEBUG - 2016-12-28 03:04:41 --> XSS Filtering completed
DEBUG - 2016-12-28 03:04:41 --> XSS Filtering completed
DEBUG - 2016-12-28 03:04:41 --> XSS Filtering completed
DEBUG - 2016-12-28 03:04:41 --> XSS Filtering completed
DEBUG - 2016-12-28 03:04:41 --> XSS Filtering completed
DEBUG - 2016-12-28 03:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 03:04:41 --> Language Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Loader Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Helper loaded: url_helper
DEBUG - 2016-12-28 03:04:41 --> Helper loaded: form_helper
DEBUG - 2016-12-28 03:04:41 --> Helper loaded: func_helper
DEBUG - 2016-12-28 03:04:41 --> Database Driver Class Initialized
ERROR - 2016-12-28 03:04:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 03:04:41 --> Session Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Helper loaded: string_helper
DEBUG - 2016-12-28 03:04:41 --> Encrypt Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Session routines successfully run
ERROR - 2016-12-28 03:04:41 --> Could not find the language line "first_link"
ERROR - 2016-12-28 03:04:41 --> Could not find the language line "last_link"
ERROR - 2016-12-28 03:04:41 --> Could not find the language line "next_link"
ERROR - 2016-12-28 03:04:41 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 03:04:41 --> Pagination Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Table Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Model Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Model Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Helper loaded: file_helper
DEBUG - 2016-12-28 03:04:41 --> Model Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Controller Class Initialized
DEBUG - 2016-12-28 03:04:41 --> Helper loaded: language_helper
DEBUG - 2016-12-28 03:04:41 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 03:04:41 --> Model Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Config Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Hooks Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Utf8 Class Initialized
DEBUG - 2016-12-28 03:04:44 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 03:04:44 --> URI Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Router Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Output Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Security Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Input Class Initialized
DEBUG - 2016-12-28 03:04:44 --> XSS Filtering completed
DEBUG - 2016-12-28 03:04:44 --> XSS Filtering completed
DEBUG - 2016-12-28 03:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 03:04:44 --> Language Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Loader Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Helper loaded: url_helper
DEBUG - 2016-12-28 03:04:44 --> Helper loaded: form_helper
DEBUG - 2016-12-28 03:04:44 --> Helper loaded: func_helper
DEBUG - 2016-12-28 03:04:44 --> Database Driver Class Initialized
ERROR - 2016-12-28 03:04:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 03:04:44 --> Session Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Helper loaded: string_helper
DEBUG - 2016-12-28 03:04:44 --> Encrypt Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Session routines successfully run
ERROR - 2016-12-28 03:04:44 --> Could not find the language line "first_link"
ERROR - 2016-12-28 03:04:44 --> Could not find the language line "last_link"
ERROR - 2016-12-28 03:04:44 --> Could not find the language line "next_link"
ERROR - 2016-12-28 03:04:44 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 03:04:44 --> Pagination Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Table Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Model Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Model Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Helper loaded: file_helper
DEBUG - 2016-12-28 03:04:44 --> Model Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Controller Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Form Validation Class Initialized
DEBUG - 2016-12-28 03:04:44 --> Helper loaded: language_helper
DEBUG - 2016-12-28 03:04:44 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 03:04:46 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 03:04:46 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-28 03:04:46 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-28 03:04:46 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-12-28 03:04:46 --> File loaded: application/views/admin_view.php
DEBUG - 2016-12-28 03:04:46 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-28 03:04:46 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-28 03:04:46 --> Final output sent to browser
DEBUG - 2016-12-28 03:04:46 --> Total execution time: 1.8441
DEBUG - 2016-12-28 03:04:46 --> Config Class Initialized
DEBUG - 2016-12-28 03:04:46 --> Hooks Class Initialized
DEBUG - 2016-12-28 03:04:46 --> Config Class Initialized
DEBUG - 2016-12-28 03:04:46 --> Hooks Class Initialized
DEBUG - 2016-12-28 03:04:46 --> Utf8 Class Initialized
DEBUG - 2016-12-28 03:04:46 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 03:04:46 --> URI Class Initialized
DEBUG - 2016-12-28 03:04:46 --> Utf8 Class Initialized
DEBUG - 2016-12-28 03:04:46 --> Router Class Initialized
DEBUG - 2016-12-28 03:04:46 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 03:04:46 --> URI Class Initialized
DEBUG - 2016-12-28 03:04:46 --> Config Class Initialized
DEBUG - 2016-12-28 03:04:46 --> Router Class Initialized
DEBUG - 2016-12-28 03:04:46 --> Hooks Class Initialized
DEBUG - 2016-12-28 03:04:46 --> Utf8 Class Initialized
DEBUG - 2016-12-28 03:04:46 --> UTF-8 Support Enabled
ERROR - 2016-12-28 03:04:46 --> 404 Page Not Found --> application
ERROR - 2016-12-28 03:04:46 --> 404 Page Not Found --> application
DEBUG - 2016-12-28 03:04:46 --> URI Class Initialized
DEBUG - 2016-12-28 03:04:46 --> Router Class Initialized
ERROR - 2016-12-28 03:04:46 --> 404 Page Not Found --> application
DEBUG - 2016-12-28 03:04:46 --> Config Class Initialized
DEBUG - 2016-12-28 03:04:46 --> Hooks Class Initialized
DEBUG - 2016-12-28 03:04:46 --> Utf8 Class Initialized
DEBUG - 2016-12-28 03:04:46 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 03:04:46 --> URI Class Initialized
DEBUG - 2016-12-28 03:04:46 --> Router Class Initialized
ERROR - 2016-12-28 03:04:46 --> 404 Page Not Found --> application
DEBUG - 2016-12-28 03:05:15 --> Config Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Hooks Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Utf8 Class Initialized
DEBUG - 2016-12-28 03:05:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 03:05:15 --> URI Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Router Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Output Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Security Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Input Class Initialized
DEBUG - 2016-12-28 03:05:15 --> XSS Filtering completed
DEBUG - 2016-12-28 03:05:15 --> XSS Filtering completed
DEBUG - 2016-12-28 03:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 03:05:15 --> Language Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Loader Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Helper loaded: url_helper
DEBUG - 2016-12-28 03:05:15 --> Helper loaded: form_helper
DEBUG - 2016-12-28 03:05:15 --> Helper loaded: func_helper
DEBUG - 2016-12-28 03:05:15 --> Database Driver Class Initialized
ERROR - 2016-12-28 03:05:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 03:05:15 --> Session Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Helper loaded: string_helper
DEBUG - 2016-12-28 03:05:15 --> Encrypt Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Session routines successfully run
ERROR - 2016-12-28 03:05:15 --> Could not find the language line "first_link"
ERROR - 2016-12-28 03:05:15 --> Could not find the language line "last_link"
ERROR - 2016-12-28 03:05:15 --> Could not find the language line "next_link"
ERROR - 2016-12-28 03:05:15 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 03:05:15 --> Pagination Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Table Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Model Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Model Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Helper loaded: file_helper
DEBUG - 2016-12-28 03:05:15 --> Model Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Controller Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Form Validation Class Initialized
DEBUG - 2016-12-28 03:05:15 --> Helper loaded: language_helper
DEBUG - 2016-12-28 03:05:15 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-28 03:05:15 --> Could not find the language line "settings"
DEBUG - 2016-12-28 03:05:15 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 03:05:15 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-12-28 03:05:15 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-12-28 03:05:15 --> File loaded: application/views/admin/settings.php
DEBUG - 2016-12-28 03:05:15 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-12-28 03:05:15 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-12-28 03:05:15 --> Final output sent to browser
DEBUG - 2016-12-28 03:05:15 --> Total execution time: 0.1850
DEBUG - 2016-12-28 12:44:09 --> Config Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Hooks Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Utf8 Class Initialized
DEBUG - 2016-12-28 12:44:09 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 12:44:09 --> URI Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Router Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Output Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Security Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Input Class Initialized
DEBUG - 2016-12-28 12:44:09 --> XSS Filtering completed
DEBUG - 2016-12-28 12:44:09 --> XSS Filtering completed
DEBUG - 2016-12-28 12:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 12:44:09 --> Language Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Loader Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Helper loaded: url_helper
DEBUG - 2016-12-28 12:44:09 --> Helper loaded: form_helper
DEBUG - 2016-12-28 12:44:09 --> Helper loaded: func_helper
DEBUG - 2016-12-28 12:44:09 --> Database Driver Class Initialized
ERROR - 2016-12-28 12:44:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 12:44:09 --> Session Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Helper loaded: string_helper
DEBUG - 2016-12-28 12:44:09 --> Encrypt Class Initialized
DEBUG - 2016-12-28 12:44:09 --> A session cookie was not found.
DEBUG - 2016-12-28 12:44:09 --> Session routines successfully run
ERROR - 2016-12-28 12:44:09 --> Could not find the language line "first_link"
ERROR - 2016-12-28 12:44:09 --> Could not find the language line "last_link"
ERROR - 2016-12-28 12:44:09 --> Could not find the language line "next_link"
ERROR - 2016-12-28 12:44:09 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 12:44:09 --> Pagination Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Table Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Model Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Model Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Helper loaded: file_helper
DEBUG - 2016-12-28 12:44:09 --> Model Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Controller Class Initialized
DEBUG - 2016-12-28 12:44:09 --> Form Validation Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Config Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Hooks Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Utf8 Class Initialized
DEBUG - 2016-12-28 12:44:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 12:44:10 --> URI Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Router Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Output Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Security Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Input Class Initialized
DEBUG - 2016-12-28 12:44:10 --> XSS Filtering completed
DEBUG - 2016-12-28 12:44:10 --> XSS Filtering completed
DEBUG - 2016-12-28 12:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 12:44:10 --> Language Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Loader Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Helper loaded: url_helper
DEBUG - 2016-12-28 12:44:10 --> Helper loaded: form_helper
DEBUG - 2016-12-28 12:44:10 --> Helper loaded: func_helper
DEBUG - 2016-12-28 12:44:10 --> Database Driver Class Initialized
ERROR - 2016-12-28 12:44:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 12:44:10 --> Session Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Helper loaded: string_helper
DEBUG - 2016-12-28 12:44:10 --> Encrypt Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Session routines successfully run
ERROR - 2016-12-28 12:44:10 --> Could not find the language line "first_link"
ERROR - 2016-12-28 12:44:10 --> Could not find the language line "last_link"
ERROR - 2016-12-28 12:44:10 --> Could not find the language line "next_link"
ERROR - 2016-12-28 12:44:10 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 12:44:10 --> Pagination Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Table Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Model Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Model Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Helper loaded: file_helper
DEBUG - 2016-12-28 12:44:10 --> Model Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Controller Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Helper loaded: language_helper
DEBUG - 2016-12-28 12:44:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 12:44:10 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 12:44:10 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 12:44:10 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-28 12:44:10 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 12:44:10 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 12:44:10 --> Final output sent to browser
DEBUG - 2016-12-28 12:44:10 --> Total execution time: 0.2750
DEBUG - 2016-12-28 12:44:10 --> Config Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Hooks Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Utf8 Class Initialized
DEBUG - 2016-12-28 12:44:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 12:44:10 --> URI Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Router Class Initialized
ERROR - 2016-12-28 12:44:10 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 12:44:10 --> Config Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Hooks Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Utf8 Class Initialized
DEBUG - 2016-12-28 12:44:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 12:44:10 --> URI Class Initialized
DEBUG - 2016-12-28 12:44:10 --> Router Class Initialized
ERROR - 2016-12-28 12:44:10 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 17:39:44 --> Config Class Initialized
DEBUG - 2016-12-28 17:39:45 --> Hooks Class Initialized
DEBUG - 2016-12-28 17:39:45 --> Utf8 Class Initialized
DEBUG - 2016-12-28 17:39:45 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 17:39:45 --> URI Class Initialized
DEBUG - 2016-12-28 17:39:45 --> Router Class Initialized
DEBUG - 2016-12-28 17:39:46 --> Output Class Initialized
DEBUG - 2016-12-28 17:39:46 --> Security Class Initialized
DEBUG - 2016-12-28 17:39:46 --> Input Class Initialized
DEBUG - 2016-12-28 17:39:46 --> XSS Filtering completed
DEBUG - 2016-12-28 17:39:46 --> XSS Filtering completed
DEBUG - 2016-12-28 17:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 17:39:46 --> Language Class Initialized
DEBUG - 2016-12-28 17:39:46 --> Loader Class Initialized
DEBUG - 2016-12-28 17:39:46 --> Helper loaded: url_helper
DEBUG - 2016-12-28 17:39:46 --> Helper loaded: form_helper
DEBUG - 2016-12-28 17:39:47 --> Helper loaded: func_helper
DEBUG - 2016-12-28 17:39:47 --> Database Driver Class Initialized
ERROR - 2016-12-28 17:39:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 17:39:47 --> Session Class Initialized
DEBUG - 2016-12-28 17:39:47 --> Helper loaded: string_helper
DEBUG - 2016-12-28 17:39:48 --> Encrypt Class Initialized
DEBUG - 2016-12-28 17:39:48 --> A session cookie was not found.
DEBUG - 2016-12-28 17:39:48 --> Session routines successfully run
ERROR - 2016-12-28 17:39:48 --> Could not find the language line "first_link"
ERROR - 2016-12-28 17:39:48 --> Could not find the language line "last_link"
ERROR - 2016-12-28 17:39:48 --> Could not find the language line "next_link"
ERROR - 2016-12-28 17:39:48 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 17:39:48 --> Pagination Class Initialized
DEBUG - 2016-12-28 17:39:48 --> Table Class Initialized
DEBUG - 2016-12-28 17:39:48 --> Model Class Initialized
DEBUG - 2016-12-28 17:39:48 --> Model Class Initialized
DEBUG - 2016-12-28 17:39:48 --> Helper loaded: file_helper
DEBUG - 2016-12-28 17:39:48 --> Model Class Initialized
DEBUG - 2016-12-28 17:39:48 --> Controller Class Initialized
DEBUG - 2016-12-28 17:39:49 --> Helper loaded: language_helper
DEBUG - 2016-12-28 17:39:49 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 17:39:51 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 17:39:51 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 17:39:51 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-28 17:39:51 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 17:39:51 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 17:39:52 --> Final output sent to browser
DEBUG - 2016-12-28 17:39:52 --> Total execution time: 8.6365
DEBUG - 2016-12-28 17:39:55 --> Config Class Initialized
DEBUG - 2016-12-28 17:39:55 --> Hooks Class Initialized
DEBUG - 2016-12-28 17:39:55 --> Utf8 Class Initialized
DEBUG - 2016-12-28 17:39:55 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 17:39:55 --> URI Class Initialized
DEBUG - 2016-12-28 17:39:55 --> Router Class Initialized
ERROR - 2016-12-28 17:39:55 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 17:39:57 --> Config Class Initialized
DEBUG - 2016-12-28 17:39:57 --> Hooks Class Initialized
DEBUG - 2016-12-28 17:39:57 --> Utf8 Class Initialized
DEBUG - 2016-12-28 17:39:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 17:39:57 --> URI Class Initialized
DEBUG - 2016-12-28 17:39:57 --> Router Class Initialized
ERROR - 2016-12-28 17:39:57 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 18:18:41 --> Config Class Initialized
DEBUG - 2016-12-28 18:18:41 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:18:41 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:18:41 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:18:41 --> URI Class Initialized
DEBUG - 2016-12-28 18:18:41 --> Router Class Initialized
DEBUG - 2016-12-28 18:18:41 --> No URI present. Default controller set.
DEBUG - 2016-12-28 18:18:41 --> Output Class Initialized
DEBUG - 2016-12-28 18:18:41 --> Security Class Initialized
DEBUG - 2016-12-28 18:18:41 --> Input Class Initialized
DEBUG - 2016-12-28 18:18:41 --> XSS Filtering completed
DEBUG - 2016-12-28 18:18:41 --> XSS Filtering completed
DEBUG - 2016-12-28 18:18:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 18:18:41 --> Language Class Initialized
DEBUG - 2016-12-28 18:18:41 --> Loader Class Initialized
DEBUG - 2016-12-28 18:18:41 --> Helper loaded: url_helper
DEBUG - 2016-12-28 18:18:41 --> Helper loaded: form_helper
DEBUG - 2016-12-28 18:18:41 --> Helper loaded: func_helper
DEBUG - 2016-12-28 18:18:41 --> Database Driver Class Initialized
ERROR - 2016-12-28 18:18:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 18:18:41 --> Session Class Initialized
DEBUG - 2016-12-28 18:18:41 --> Helper loaded: string_helper
DEBUG - 2016-12-28 18:18:41 --> Encrypt Class Initialized
ERROR - 2016-12-28 18:18:41 --> Session: The session cookie was not signed.
DEBUG - 2016-12-28 18:18:41 --> Session routines successfully run
ERROR - 2016-12-28 18:18:41 --> Could not find the language line "first_link"
ERROR - 2016-12-28 18:18:41 --> Could not find the language line "last_link"
ERROR - 2016-12-28 18:18:41 --> Could not find the language line "next_link"
ERROR - 2016-12-28 18:18:41 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 18:18:41 --> Pagination Class Initialized
DEBUG - 2016-12-28 18:18:41 --> Table Class Initialized
DEBUG - 2016-12-28 18:18:41 --> Model Class Initialized
DEBUG - 2016-12-28 18:18:41 --> Model Class Initialized
DEBUG - 2016-12-28 18:18:41 --> Helper loaded: file_helper
DEBUG - 2016-12-28 18:18:41 --> Model Class Initialized
DEBUG - 2016-12-28 18:18:41 --> Controller Class Initialized
DEBUG - 2016-12-28 18:18:43 --> Helper loaded: language_helper
DEBUG - 2016-12-28 18:18:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 18:18:44 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-28 18:18:46 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 18:18:46 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 18:18:46 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 18:18:46 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 18:18:46 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 18:18:46 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 18:18:46 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 18:18:46 --> Final output sent to browser
DEBUG - 2016-12-28 18:18:46 --> Total execution time: 4.6403
DEBUG - 2016-12-28 18:18:46 --> Config Class Initialized
DEBUG - 2016-12-28 18:18:46 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:18:46 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:18:46 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:18:46 --> URI Class Initialized
DEBUG - 2016-12-28 18:18:46 --> Router Class Initialized
ERROR - 2016-12-28 18:18:46 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 18:24:29 --> Config Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:24:29 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:24:29 --> URI Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Router Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Output Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Security Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Input Class Initialized
DEBUG - 2016-12-28 18:24:29 --> XSS Filtering completed
DEBUG - 2016-12-28 18:24:29 --> XSS Filtering completed
DEBUG - 2016-12-28 18:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 18:24:29 --> Language Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Loader Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Helper loaded: url_helper
DEBUG - 2016-12-28 18:24:29 --> Helper loaded: form_helper
DEBUG - 2016-12-28 18:24:29 --> Helper loaded: func_helper
DEBUG - 2016-12-28 18:24:29 --> Database Driver Class Initialized
ERROR - 2016-12-28 18:24:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 18:24:29 --> Session Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Helper loaded: string_helper
DEBUG - 2016-12-28 18:24:29 --> Encrypt Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Session routines successfully run
ERROR - 2016-12-28 18:24:29 --> Could not find the language line "first_link"
ERROR - 2016-12-28 18:24:29 --> Could not find the language line "last_link"
ERROR - 2016-12-28 18:24:29 --> Could not find the language line "next_link"
ERROR - 2016-12-28 18:24:29 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 18:24:29 --> Pagination Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Table Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Model Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Model Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Helper loaded: file_helper
DEBUG - 2016-12-28 18:24:29 --> Model Class Initialized
DEBUG - 2016-12-28 18:24:29 --> Controller Class Initialized
DEBUG - 2016-12-28 18:24:31 --> Helper loaded: language_helper
DEBUG - 2016-12-28 18:24:31 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 18:24:31 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 18:24:31 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 18:24:31 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-28 18:24:31 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 18:24:31 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 18:24:31 --> Final output sent to browser
DEBUG - 2016-12-28 18:24:31 --> Total execution time: 2.3371
DEBUG - 2016-12-28 18:24:31 --> Config Class Initialized
DEBUG - 2016-12-28 18:24:31 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:24:31 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:24:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:24:31 --> URI Class Initialized
DEBUG - 2016-12-28 18:24:31 --> Router Class Initialized
ERROR - 2016-12-28 18:24:31 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 18:28:52 --> Config Class Initialized
DEBUG - 2016-12-28 18:28:52 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:28:52 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:28:52 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:28:52 --> URI Class Initialized
DEBUG - 2016-12-28 18:28:52 --> Router Class Initialized
DEBUG - 2016-12-28 18:28:52 --> No URI present. Default controller set.
DEBUG - 2016-12-28 18:28:52 --> Output Class Initialized
DEBUG - 2016-12-28 18:28:52 --> Security Class Initialized
DEBUG - 2016-12-28 18:28:52 --> Input Class Initialized
DEBUG - 2016-12-28 18:28:52 --> XSS Filtering completed
DEBUG - 2016-12-28 18:28:52 --> XSS Filtering completed
DEBUG - 2016-12-28 18:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 18:28:52 --> Language Class Initialized
DEBUG - 2016-12-28 18:28:52 --> Loader Class Initialized
DEBUG - 2016-12-28 18:28:52 --> Helper loaded: url_helper
DEBUG - 2016-12-28 18:28:52 --> Helper loaded: form_helper
DEBUG - 2016-12-28 18:28:52 --> Helper loaded: func_helper
DEBUG - 2016-12-28 18:28:52 --> Database Driver Class Initialized
ERROR - 2016-12-28 18:28:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 18:28:52 --> Session Class Initialized
DEBUG - 2016-12-28 18:28:52 --> Helper loaded: string_helper
DEBUG - 2016-12-28 18:28:52 --> Encrypt Class Initialized
DEBUG - 2016-12-28 18:28:52 --> Session routines successfully run
ERROR - 2016-12-28 18:28:52 --> Could not find the language line "first_link"
ERROR - 2016-12-28 18:28:52 --> Could not find the language line "last_link"
ERROR - 2016-12-28 18:28:52 --> Could not find the language line "next_link"
ERROR - 2016-12-28 18:28:52 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 18:28:52 --> Pagination Class Initialized
DEBUG - 2016-12-28 18:28:52 --> Table Class Initialized
DEBUG - 2016-12-28 18:28:52 --> Model Class Initialized
DEBUG - 2016-12-28 18:28:52 --> Model Class Initialized
DEBUG - 2016-12-28 18:28:52 --> Helper loaded: file_helper
DEBUG - 2016-12-28 18:28:52 --> Model Class Initialized
DEBUG - 2016-12-28 18:28:52 --> Controller Class Initialized
DEBUG - 2016-12-28 18:28:54 --> Helper loaded: language_helper
DEBUG - 2016-12-28 18:28:54 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 18:28:55 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-28 18:28:57 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 18:28:57 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 18:28:57 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 18:28:57 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 18:28:57 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 18:28:57 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 18:28:57 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 18:28:57 --> Final output sent to browser
DEBUG - 2016-12-28 18:28:57 --> Total execution time: 4.7863
DEBUG - 2016-12-28 18:28:57 --> Config Class Initialized
DEBUG - 2016-12-28 18:28:57 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:28:57 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:28:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:28:57 --> URI Class Initialized
DEBUG - 2016-12-28 18:28:57 --> Router Class Initialized
ERROR - 2016-12-28 18:28:57 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 18:29:04 --> Config Class Initialized
DEBUG - 2016-12-28 18:29:04 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:29:04 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:29:04 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:29:04 --> URI Class Initialized
DEBUG - 2016-12-28 18:29:04 --> Router Class Initialized
ERROR - 2016-12-28 18:29:04 --> 404 Page Not Found --> index
DEBUG - 2016-12-28 18:29:15 --> Config Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:29:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:29:15 --> URI Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Router Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Output Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Security Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Input Class Initialized
DEBUG - 2016-12-28 18:29:15 --> XSS Filtering completed
DEBUG - 2016-12-28 18:29:15 --> XSS Filtering completed
DEBUG - 2016-12-28 18:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 18:29:15 --> Language Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Loader Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Helper loaded: url_helper
DEBUG - 2016-12-28 18:29:15 --> Helper loaded: form_helper
DEBUG - 2016-12-28 18:29:15 --> Helper loaded: func_helper
DEBUG - 2016-12-28 18:29:15 --> Database Driver Class Initialized
ERROR - 2016-12-28 18:29:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 18:29:15 --> Session Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Helper loaded: string_helper
DEBUG - 2016-12-28 18:29:15 --> Encrypt Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Session routines successfully run
ERROR - 2016-12-28 18:29:15 --> Could not find the language line "first_link"
ERROR - 2016-12-28 18:29:15 --> Could not find the language line "last_link"
ERROR - 2016-12-28 18:29:15 --> Could not find the language line "next_link"
ERROR - 2016-12-28 18:29:15 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 18:29:15 --> Pagination Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Table Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Model Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Model Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Helper loaded: file_helper
DEBUG - 2016-12-28 18:29:15 --> Model Class Initialized
DEBUG - 2016-12-28 18:29:15 --> Controller Class Initialized
DEBUG - 2016-12-28 18:29:16 --> Helper loaded: language_helper
DEBUG - 2016-12-28 18:29:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 18:29:16 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 18:29:16 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 18:29:16 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-28 18:29:16 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 18:29:16 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 18:29:16 --> Final output sent to browser
DEBUG - 2016-12-28 18:29:16 --> Total execution time: 1.8371
DEBUG - 2016-12-28 18:29:16 --> Config Class Initialized
DEBUG - 2016-12-28 18:29:16 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:29:16 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:29:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:29:16 --> URI Class Initialized
DEBUG - 2016-12-28 18:29:16 --> Router Class Initialized
ERROR - 2016-12-28 18:29:16 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 18:29:16 --> Config Class Initialized
DEBUG - 2016-12-28 18:29:16 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:29:16 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:29:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:29:16 --> URI Class Initialized
DEBUG - 2016-12-28 18:29:16 --> Router Class Initialized
ERROR - 2016-12-28 18:29:16 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 18:29:44 --> Config Class Initialized
DEBUG - 2016-12-28 18:29:44 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:29:44 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:29:44 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:29:44 --> URI Class Initialized
DEBUG - 2016-12-28 18:29:44 --> Router Class Initialized
ERROR - 2016-12-28 18:29:44 --> 404 Page Not Found --> index
DEBUG - 2016-12-28 18:29:52 --> Config Class Initialized
DEBUG - 2016-12-28 18:29:52 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:29:52 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:29:52 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:29:52 --> URI Class Initialized
DEBUG - 2016-12-28 18:29:52 --> Router Class Initialized
DEBUG - 2016-12-28 18:29:52 --> No URI present. Default controller set.
DEBUG - 2016-12-28 18:29:52 --> Output Class Initialized
DEBUG - 2016-12-28 18:29:52 --> Security Class Initialized
DEBUG - 2016-12-28 18:29:52 --> Input Class Initialized
DEBUG - 2016-12-28 18:29:52 --> XSS Filtering completed
DEBUG - 2016-12-28 18:29:52 --> XSS Filtering completed
DEBUG - 2016-12-28 18:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 18:29:52 --> Language Class Initialized
DEBUG - 2016-12-28 18:29:52 --> Loader Class Initialized
DEBUG - 2016-12-28 18:29:52 --> Helper loaded: url_helper
DEBUG - 2016-12-28 18:29:52 --> Helper loaded: form_helper
DEBUG - 2016-12-28 18:29:52 --> Helper loaded: func_helper
DEBUG - 2016-12-28 18:29:52 --> Database Driver Class Initialized
ERROR - 2016-12-28 18:29:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 18:29:52 --> Session Class Initialized
DEBUG - 2016-12-28 18:29:52 --> Helper loaded: string_helper
DEBUG - 2016-12-28 18:29:52 --> Encrypt Class Initialized
DEBUG - 2016-12-28 18:29:52 --> Session routines successfully run
ERROR - 2016-12-28 18:29:52 --> Could not find the language line "first_link"
ERROR - 2016-12-28 18:29:52 --> Could not find the language line "last_link"
ERROR - 2016-12-28 18:29:52 --> Could not find the language line "next_link"
ERROR - 2016-12-28 18:29:52 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 18:29:52 --> Pagination Class Initialized
DEBUG - 2016-12-28 18:29:52 --> Table Class Initialized
DEBUG - 2016-12-28 18:29:52 --> Model Class Initialized
DEBUG - 2016-12-28 18:29:52 --> Model Class Initialized
DEBUG - 2016-12-28 18:29:52 --> Helper loaded: file_helper
DEBUG - 2016-12-28 18:29:52 --> Model Class Initialized
DEBUG - 2016-12-28 18:29:52 --> Controller Class Initialized
DEBUG - 2016-12-28 18:29:54 --> Helper loaded: language_helper
DEBUG - 2016-12-28 18:29:54 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 18:29:55 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-28 18:29:57 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 18:29:57 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 18:29:57 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 18:29:57 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 18:29:57 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 18:29:57 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 18:29:57 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 18:29:57 --> Final output sent to browser
DEBUG - 2016-12-28 18:29:57 --> Total execution time: 4.7523
DEBUG - 2016-12-28 18:29:57 --> Config Class Initialized
DEBUG - 2016-12-28 18:29:57 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:29:57 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:29:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:29:57 --> URI Class Initialized
DEBUG - 2016-12-28 18:29:57 --> Router Class Initialized
ERROR - 2016-12-28 18:29:57 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 18:30:05 --> Config Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:30:05 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:30:05 --> URI Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Router Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Output Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Security Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Input Class Initialized
DEBUG - 2016-12-28 18:30:05 --> XSS Filtering completed
DEBUG - 2016-12-28 18:30:05 --> XSS Filtering completed
DEBUG - 2016-12-28 18:30:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 18:30:05 --> Language Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Loader Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Helper loaded: url_helper
DEBUG - 2016-12-28 18:30:05 --> Helper loaded: form_helper
DEBUG - 2016-12-28 18:30:05 --> Helper loaded: func_helper
DEBUG - 2016-12-28 18:30:05 --> Database Driver Class Initialized
ERROR - 2016-12-28 18:30:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 18:30:05 --> Session Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Helper loaded: string_helper
DEBUG - 2016-12-28 18:30:05 --> Encrypt Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Session routines successfully run
ERROR - 2016-12-28 18:30:05 --> Could not find the language line "first_link"
ERROR - 2016-12-28 18:30:05 --> Could not find the language line "last_link"
ERROR - 2016-12-28 18:30:05 --> Could not find the language line "next_link"
ERROR - 2016-12-28 18:30:05 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 18:30:05 --> Pagination Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Table Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Model Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Model Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Helper loaded: file_helper
DEBUG - 2016-12-28 18:30:05 --> Model Class Initialized
DEBUG - 2016-12-28 18:30:05 --> Controller Class Initialized
DEBUG - 2016-12-28 18:30:07 --> Helper loaded: language_helper
DEBUG - 2016-12-28 18:30:07 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 18:30:07 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 18:30:07 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 18:30:07 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-28 18:30:07 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 18:30:07 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 18:30:07 --> Final output sent to browser
DEBUG - 2016-12-28 18:30:07 --> Total execution time: 2.1781
DEBUG - 2016-12-28 18:30:07 --> Config Class Initialized
DEBUG - 2016-12-28 18:30:07 --> Hooks Class Initialized
DEBUG - 2016-12-28 18:30:07 --> Utf8 Class Initialized
DEBUG - 2016-12-28 18:30:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 18:30:07 --> URI Class Initialized
DEBUG - 2016-12-28 18:30:07 --> Router Class Initialized
ERROR - 2016-12-28 18:30:07 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 20:25:03 --> Config Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:25:03 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:25:03 --> URI Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Router Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Output Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Security Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Input Class Initialized
DEBUG - 2016-12-28 20:25:03 --> XSS Filtering completed
DEBUG - 2016-12-28 20:25:03 --> XSS Filtering completed
DEBUG - 2016-12-28 20:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 20:25:03 --> Language Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Loader Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Helper loaded: url_helper
DEBUG - 2016-12-28 20:25:03 --> Helper loaded: form_helper
DEBUG - 2016-12-28 20:25:03 --> Helper loaded: func_helper
DEBUG - 2016-12-28 20:25:03 --> Database Driver Class Initialized
ERROR - 2016-12-28 20:25:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 20:25:03 --> Session Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Helper loaded: string_helper
DEBUG - 2016-12-28 20:25:03 --> Encrypt Class Initialized
DEBUG - 2016-12-28 20:25:03 --> A session cookie was not found.
DEBUG - 2016-12-28 20:25:03 --> Session routines successfully run
ERROR - 2016-12-28 20:25:03 --> Could not find the language line "first_link"
ERROR - 2016-12-28 20:25:03 --> Could not find the language line "last_link"
ERROR - 2016-12-28 20:25:03 --> Could not find the language line "next_link"
ERROR - 2016-12-28 20:25:03 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 20:25:03 --> Pagination Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Table Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Model Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Model Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Helper loaded: file_helper
DEBUG - 2016-12-28 20:25:03 --> Model Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Controller Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Helper loaded: language_helper
DEBUG - 2016-12-28 20:25:03 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-28 20:25:03 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-28 20:25:03 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-28 20:25:03 --> File loaded: application/views/me/myadmin_upload.php
DEBUG - 2016-12-28 20:25:03 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-28 20:25:03 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-28 20:25:03 --> Final output sent to browser
DEBUG - 2016-12-28 20:25:03 --> Total execution time: 0.1420
DEBUG - 2016-12-28 20:25:03 --> Config Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:25:03 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:25:03 --> URI Class Initialized
DEBUG - 2016-12-28 20:25:03 --> Router Class Initialized
ERROR - 2016-12-28 20:25:03 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 20:26:07 --> Config Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:26:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:26:07 --> URI Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Router Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Output Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Security Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Input Class Initialized
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> XSS Filtering completed
DEBUG - 2016-12-28 20:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 20:26:07 --> Language Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Loader Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Helper loaded: url_helper
DEBUG - 2016-12-28 20:26:07 --> Helper loaded: form_helper
DEBUG - 2016-12-28 20:26:07 --> Helper loaded: func_helper
DEBUG - 2016-12-28 20:26:07 --> Database Driver Class Initialized
ERROR - 2016-12-28 20:26:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 20:26:07 --> Session Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Helper loaded: string_helper
DEBUG - 2016-12-28 20:26:07 --> Encrypt Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Session routines successfully run
ERROR - 2016-12-28 20:26:07 --> Could not find the language line "first_link"
ERROR - 2016-12-28 20:26:07 --> Could not find the language line "last_link"
ERROR - 2016-12-28 20:26:07 --> Could not find the language line "next_link"
ERROR - 2016-12-28 20:26:07 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 20:26:07 --> Pagination Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Table Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Model Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Model Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Helper loaded: file_helper
DEBUG - 2016-12-28 20:26:07 --> Model Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Controller Class Initialized
DEBUG - 2016-12-28 20:26:07 --> Helper loaded: language_helper
DEBUG - 2016-12-28 20:26:07 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 20:26:08 --> Model Class Initialized
DEBUG - 2016-12-28 20:26:08 --> Upload Class Initialized
ERROR - 2016-12-28 20:26:08 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:08 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:08 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:08 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:08 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:08 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:08 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:08 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:09 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:09 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:09 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:32 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:32 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:32 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:32 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:32 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:32 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:26:35 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-28 20:26:35 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-28 20:26:36 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-28 20:26:36 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-28 20:26:36 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-28 20:26:36 --> Final output sent to browser
DEBUG - 2016-12-28 20:26:36 --> Total execution time: 28.2376
DEBUG - 2016-12-28 20:26:36 --> Config Class Initialized
DEBUG - 2016-12-28 20:26:36 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:26:36 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:26:36 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:26:36 --> URI Class Initialized
DEBUG - 2016-12-28 20:26:36 --> Router Class Initialized
ERROR - 2016-12-28 20:26:36 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 20:32:53 --> Config Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:32:53 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:32:53 --> URI Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Router Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Output Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Security Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Input Class Initialized
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> XSS Filtering completed
DEBUG - 2016-12-28 20:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 20:32:53 --> Language Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Loader Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Helper loaded: url_helper
DEBUG - 2016-12-28 20:32:53 --> Helper loaded: form_helper
DEBUG - 2016-12-28 20:32:53 --> Helper loaded: func_helper
DEBUG - 2016-12-28 20:32:53 --> Database Driver Class Initialized
ERROR - 2016-12-28 20:32:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 20:32:53 --> Session Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Helper loaded: string_helper
DEBUG - 2016-12-28 20:32:53 --> Encrypt Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Session routines successfully run
ERROR - 2016-12-28 20:32:53 --> Could not find the language line "first_link"
ERROR - 2016-12-28 20:32:53 --> Could not find the language line "last_link"
ERROR - 2016-12-28 20:32:53 --> Could not find the language line "next_link"
ERROR - 2016-12-28 20:32:53 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 20:32:53 --> Pagination Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Table Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Model Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Model Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Helper loaded: file_helper
DEBUG - 2016-12-28 20:32:53 --> Model Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Controller Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Helper loaded: language_helper
DEBUG - 2016-12-28 20:32:53 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 20:32:53 --> Model Class Initialized
DEBUG - 2016-12-28 20:32:53 --> Upload Class Initialized
ERROR - 2016-12-28 20:32:53 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:32:53 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:32:53 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:32:53 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:32:53 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:32:53 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:32:53 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:32:53 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:32:54 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:32:54 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:32:54 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:33:14 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:33:14 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:33:14 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:33:14 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:33:14 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:33:14 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:33:16 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-28 20:33:16 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-28 20:33:17 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-28 20:33:17 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-28 20:33:17 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-28 20:33:17 --> Final output sent to browser
DEBUG - 2016-12-28 20:33:17 --> Total execution time: 23.5133
DEBUG - 2016-12-28 20:33:17 --> Config Class Initialized
DEBUG - 2016-12-28 20:33:17 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:33:17 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:33:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:33:17 --> URI Class Initialized
DEBUG - 2016-12-28 20:33:17 --> Router Class Initialized
ERROR - 2016-12-28 20:33:17 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 20:35:45 --> Config Class Initialized
DEBUG - 2016-12-28 20:35:45 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:35:45 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:35:45 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:35:45 --> URI Class Initialized
DEBUG - 2016-12-28 20:35:45 --> Router Class Initialized
DEBUG - 2016-12-28 20:35:45 --> Output Class Initialized
DEBUG - 2016-12-28 20:35:45 --> Security Class Initialized
DEBUG - 2016-12-28 20:35:45 --> Input Class Initialized
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> XSS Filtering completed
DEBUG - 2016-12-28 20:35:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 20:35:45 --> Language Class Initialized
DEBUG - 2016-12-28 20:35:45 --> Loader Class Initialized
DEBUG - 2016-12-28 20:35:45 --> Helper loaded: url_helper
DEBUG - 2016-12-28 20:35:45 --> Helper loaded: form_helper
DEBUG - 2016-12-28 20:35:45 --> Helper loaded: func_helper
DEBUG - 2016-12-28 20:35:45 --> Database Driver Class Initialized
ERROR - 2016-12-28 20:35:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 20:35:45 --> Session Class Initialized
DEBUG - 2016-12-28 20:35:45 --> Helper loaded: string_helper
DEBUG - 2016-12-28 20:35:45 --> Encrypt Class Initialized
DEBUG - 2016-12-28 20:35:46 --> Session routines successfully run
ERROR - 2016-12-28 20:35:46 --> Could not find the language line "first_link"
ERROR - 2016-12-28 20:35:46 --> Could not find the language line "last_link"
ERROR - 2016-12-28 20:35:46 --> Could not find the language line "next_link"
ERROR - 2016-12-28 20:35:46 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 20:35:46 --> Pagination Class Initialized
DEBUG - 2016-12-28 20:35:46 --> Table Class Initialized
DEBUG - 2016-12-28 20:35:46 --> Model Class Initialized
DEBUG - 2016-12-28 20:35:46 --> Model Class Initialized
DEBUG - 2016-12-28 20:35:46 --> Helper loaded: file_helper
DEBUG - 2016-12-28 20:35:46 --> Model Class Initialized
DEBUG - 2016-12-28 20:35:46 --> Controller Class Initialized
DEBUG - 2016-12-28 20:35:46 --> Helper loaded: language_helper
DEBUG - 2016-12-28 20:35:46 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 20:35:46 --> Model Class Initialized
DEBUG - 2016-12-28 20:35:46 --> Upload Class Initialized
ERROR - 2016-12-28 20:35:46 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:35:46 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:35:46 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:35:46 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:35:46 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:35:46 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:35:46 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:35:46 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:35:47 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:35:47 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:35:47 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:36:07 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:36:07 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:36:07 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:36:07 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:36:07 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:36:07 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:36:10 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-28 20:36:10 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-28 20:36:10 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-28 20:36:10 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-28 20:36:10 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-28 20:36:10 --> Final output sent to browser
DEBUG - 2016-12-28 20:36:10 --> Total execution time: 24.3914
DEBUG - 2016-12-28 20:36:10 --> Config Class Initialized
DEBUG - 2016-12-28 20:36:10 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:36:10 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:36:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:36:10 --> URI Class Initialized
DEBUG - 2016-12-28 20:36:10 --> Router Class Initialized
ERROR - 2016-12-28 20:36:10 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 20:36:12 --> Config Class Initialized
DEBUG - 2016-12-28 20:36:12 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:36:12 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:36:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:36:12 --> URI Class Initialized
DEBUG - 2016-12-28 20:36:12 --> Router Class Initialized
DEBUG - 2016-12-28 20:36:12 --> No URI present. Default controller set.
DEBUG - 2016-12-28 20:36:12 --> Output Class Initialized
DEBUG - 2016-12-28 20:36:12 --> Security Class Initialized
DEBUG - 2016-12-28 20:36:12 --> Input Class Initialized
DEBUG - 2016-12-28 20:36:12 --> XSS Filtering completed
DEBUG - 2016-12-28 20:36:12 --> XSS Filtering completed
DEBUG - 2016-12-28 20:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 20:36:12 --> Language Class Initialized
DEBUG - 2016-12-28 20:36:12 --> Loader Class Initialized
DEBUG - 2016-12-28 20:36:12 --> Helper loaded: url_helper
DEBUG - 2016-12-28 20:36:12 --> Helper loaded: form_helper
DEBUG - 2016-12-28 20:36:12 --> Helper loaded: func_helper
DEBUG - 2016-12-28 20:36:12 --> Database Driver Class Initialized
ERROR - 2016-12-28 20:36:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 20:36:12 --> Session Class Initialized
DEBUG - 2016-12-28 20:36:12 --> Helper loaded: string_helper
DEBUG - 2016-12-28 20:36:12 --> Encrypt Class Initialized
DEBUG - 2016-12-28 20:36:12 --> Session routines successfully run
ERROR - 2016-12-28 20:36:12 --> Could not find the language line "first_link"
ERROR - 2016-12-28 20:36:12 --> Could not find the language line "last_link"
ERROR - 2016-12-28 20:36:12 --> Could not find the language line "next_link"
ERROR - 2016-12-28 20:36:12 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 20:36:12 --> Pagination Class Initialized
DEBUG - 2016-12-28 20:36:12 --> Table Class Initialized
DEBUG - 2016-12-28 20:36:12 --> Model Class Initialized
DEBUG - 2016-12-28 20:36:12 --> Model Class Initialized
DEBUG - 2016-12-28 20:36:12 --> Helper loaded: file_helper
DEBUG - 2016-12-28 20:36:12 --> Model Class Initialized
DEBUG - 2016-12-28 20:36:12 --> Controller Class Initialized
DEBUG - 2016-12-28 20:36:14 --> Helper loaded: language_helper
DEBUG - 2016-12-28 20:36:14 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 20:36:16 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-28 20:36:18 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 20:36:18 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 20:36:18 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 20:36:18 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 20:36:18 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 20:36:18 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 20:36:18 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 20:36:18 --> Final output sent to browser
DEBUG - 2016-12-28 20:36:18 --> Total execution time: 5.7923
DEBUG - 2016-12-28 20:36:18 --> Config Class Initialized
DEBUG - 2016-12-28 20:36:18 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:36:18 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:36:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:36:18 --> URI Class Initialized
DEBUG - 2016-12-28 20:36:18 --> Router Class Initialized
ERROR - 2016-12-28 20:36:18 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 20:37:11 --> Config Class Initialized
DEBUG - 2016-12-28 20:37:11 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:37:11 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:37:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:37:11 --> URI Class Initialized
DEBUG - 2016-12-28 20:37:11 --> Router Class Initialized
DEBUG - 2016-12-28 20:37:11 --> No URI present. Default controller set.
DEBUG - 2016-12-28 20:37:11 --> Output Class Initialized
DEBUG - 2016-12-28 20:37:11 --> Security Class Initialized
DEBUG - 2016-12-28 20:37:11 --> Input Class Initialized
DEBUG - 2016-12-28 20:37:11 --> XSS Filtering completed
DEBUG - 2016-12-28 20:37:11 --> XSS Filtering completed
DEBUG - 2016-12-28 20:37:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 20:37:11 --> Language Class Initialized
DEBUG - 2016-12-28 20:37:11 --> Loader Class Initialized
DEBUG - 2016-12-28 20:37:11 --> Helper loaded: url_helper
DEBUG - 2016-12-28 20:37:11 --> Helper loaded: form_helper
DEBUG - 2016-12-28 20:37:11 --> Helper loaded: func_helper
DEBUG - 2016-12-28 20:37:11 --> Database Driver Class Initialized
ERROR - 2016-12-28 20:37:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 20:37:11 --> Session Class Initialized
DEBUG - 2016-12-28 20:37:11 --> Helper loaded: string_helper
DEBUG - 2016-12-28 20:37:11 --> Encrypt Class Initialized
DEBUG - 2016-12-28 20:37:11 --> Session routines successfully run
ERROR - 2016-12-28 20:37:11 --> Could not find the language line "first_link"
ERROR - 2016-12-28 20:37:11 --> Could not find the language line "last_link"
ERROR - 2016-12-28 20:37:11 --> Could not find the language line "next_link"
ERROR - 2016-12-28 20:37:11 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 20:37:11 --> Pagination Class Initialized
DEBUG - 2016-12-28 20:37:11 --> Table Class Initialized
DEBUG - 2016-12-28 20:37:11 --> Model Class Initialized
DEBUG - 2016-12-28 20:37:11 --> Model Class Initialized
DEBUG - 2016-12-28 20:37:11 --> Helper loaded: file_helper
DEBUG - 2016-12-28 20:37:11 --> Model Class Initialized
DEBUG - 2016-12-28 20:37:11 --> Controller Class Initialized
DEBUG - 2016-12-28 20:37:13 --> Helper loaded: language_helper
DEBUG - 2016-12-28 20:37:13 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 20:37:15 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-28 20:37:17 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 20:37:17 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 20:37:17 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-28 20:37:17 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-28 20:37:17 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-28 20:37:17 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 20:37:17 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 20:37:17 --> Final output sent to browser
DEBUG - 2016-12-28 20:37:17 --> Total execution time: 5.6113
DEBUG - 2016-12-28 20:37:17 --> Config Class Initialized
DEBUG - 2016-12-28 20:37:17 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:37:17 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:37:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:37:17 --> URI Class Initialized
DEBUG - 2016-12-28 20:37:17 --> Router Class Initialized
ERROR - 2016-12-28 20:37:17 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 20:38:14 --> Config Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:38:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:38:14 --> URI Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Router Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Output Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Security Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Input Class Initialized
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> XSS Filtering completed
DEBUG - 2016-12-28 20:38:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 20:38:14 --> Language Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Loader Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Helper loaded: url_helper
DEBUG - 2016-12-28 20:38:14 --> Helper loaded: form_helper
DEBUG - 2016-12-28 20:38:14 --> Helper loaded: func_helper
DEBUG - 2016-12-28 20:38:14 --> Database Driver Class Initialized
ERROR - 2016-12-28 20:38:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 20:38:14 --> Session Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Helper loaded: string_helper
DEBUG - 2016-12-28 20:38:14 --> Encrypt Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Session routines successfully run
ERROR - 2016-12-28 20:38:14 --> Could not find the language line "first_link"
ERROR - 2016-12-28 20:38:14 --> Could not find the language line "last_link"
ERROR - 2016-12-28 20:38:14 --> Could not find the language line "next_link"
ERROR - 2016-12-28 20:38:14 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 20:38:14 --> Pagination Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Table Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Model Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Model Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Helper loaded: file_helper
DEBUG - 2016-12-28 20:38:14 --> Model Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Controller Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Helper loaded: language_helper
DEBUG - 2016-12-28 20:38:14 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 20:38:14 --> Model Class Initialized
DEBUG - 2016-12-28 20:38:14 --> Upload Class Initialized
ERROR - 2016-12-28 20:38:14 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:14 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:14 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:14 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:14 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:14 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:14 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:14 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:15 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:15 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:15 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:34 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:34 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:34 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:34 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:34 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:34 --> Severity: Notice  --> Undefined variable: options C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Settings.php 384
ERROR - 2016-12-28 20:38:36 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-28 20:38:36 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-28 20:38:37 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-28 20:38:37 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-28 20:38:37 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-28 20:38:37 --> Final output sent to browser
DEBUG - 2016-12-28 20:38:37 --> Total execution time: 22.8263
DEBUG - 2016-12-28 20:38:37 --> Config Class Initialized
DEBUG - 2016-12-28 20:38:37 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:38:37 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:38:37 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:38:37 --> URI Class Initialized
DEBUG - 2016-12-28 20:38:37 --> Router Class Initialized
ERROR - 2016-12-28 20:38:37 --> 404 Page Not Found --> js
DEBUG - 2016-12-28 20:41:10 --> Config Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:41:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:41:10 --> URI Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Router Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Output Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Security Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Input Class Initialized
DEBUG - 2016-12-28 20:41:10 --> XSS Filtering completed
DEBUG - 2016-12-28 20:41:10 --> XSS Filtering completed
DEBUG - 2016-12-28 20:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-28 20:41:10 --> Language Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Loader Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Helper loaded: url_helper
DEBUG - 2016-12-28 20:41:10 --> Helper loaded: form_helper
DEBUG - 2016-12-28 20:41:10 --> Helper loaded: func_helper
DEBUG - 2016-12-28 20:41:10 --> Database Driver Class Initialized
ERROR - 2016-12-28 20:41:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-28 20:41:10 --> Session Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Helper loaded: string_helper
DEBUG - 2016-12-28 20:41:10 --> Encrypt Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Session routines successfully run
ERROR - 2016-12-28 20:41:10 --> Could not find the language line "first_link"
ERROR - 2016-12-28 20:41:10 --> Could not find the language line "last_link"
ERROR - 2016-12-28 20:41:10 --> Could not find the language line "next_link"
ERROR - 2016-12-28 20:41:10 --> Could not find the language line "prev_link"
DEBUG - 2016-12-28 20:41:10 --> Pagination Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Table Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Model Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Model Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Helper loaded: file_helper
DEBUG - 2016-12-28 20:41:10 --> Model Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Controller Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Helper loaded: language_helper
DEBUG - 2016-12-28 20:41:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-28 20:41:10 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-28 20:41:10 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-28 20:41:10 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-28 20:41:10 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-28 20:41:10 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-28 20:41:10 --> Final output sent to browser
DEBUG - 2016-12-28 20:41:10 --> Total execution time: 0.1240
DEBUG - 2016-12-28 20:41:10 --> Config Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Hooks Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Utf8 Class Initialized
DEBUG - 2016-12-28 20:41:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-28 20:41:10 --> URI Class Initialized
DEBUG - 2016-12-28 20:41:10 --> Router Class Initialized
ERROR - 2016-12-28 20:41:10 --> 404 Page Not Found --> js
