<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-12-26 19:03:11 --> Config Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Hooks Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Utf8 Class Initialized
DEBUG - 2016-12-26 19:03:11 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 19:03:11 --> URI Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Router Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Output Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Security Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Input Class Initialized
DEBUG - 2016-12-26 19:03:11 --> XSS Filtering completed
DEBUG - 2016-12-26 19:03:11 --> XSS Filtering completed
DEBUG - 2016-12-26 19:03:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 19:03:11 --> Language Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Loader Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Helper loaded: url_helper
DEBUG - 2016-12-26 19:03:11 --> Helper loaded: form_helper
DEBUG - 2016-12-26 19:03:11 --> Helper loaded: func_helper
DEBUG - 2016-12-26 19:03:11 --> Database Driver Class Initialized
ERROR - 2016-12-26 19:03:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 19:03:11 --> Session Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Helper loaded: string_helper
DEBUG - 2016-12-26 19:03:11 --> Encrypt Class Initialized
ERROR - 2016-12-26 19:03:11 --> Session: The session cookie was not signed.
DEBUG - 2016-12-26 19:03:11 --> Session routines successfully run
ERROR - 2016-12-26 19:03:11 --> Could not find the language line "first_link"
ERROR - 2016-12-26 19:03:11 --> Could not find the language line "last_link"
ERROR - 2016-12-26 19:03:11 --> Could not find the language line "next_link"
ERROR - 2016-12-26 19:03:11 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 19:03:11 --> Pagination Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Table Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Model Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Model Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Helper loaded: file_helper
DEBUG - 2016-12-26 19:03:11 --> Model Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Controller Class Initialized
DEBUG - 2016-12-26 19:03:11 --> Helper loaded: language_helper
DEBUG - 2016-12-26 19:03:11 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-26 19:03:11 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-26 19:03:11 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-26 19:03:11 --> File loaded: application/views/me/myadmin_upload.php
DEBUG - 2016-12-26 19:03:11 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-26 19:03:11 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-26 19:03:11 --> Final output sent to browser
DEBUG - 2016-12-26 19:03:11 --> Total execution time: 0.5750
DEBUG - 2016-12-26 19:03:12 --> Config Class Initialized
DEBUG - 2016-12-26 19:03:12 --> Hooks Class Initialized
DEBUG - 2016-12-26 19:03:12 --> Utf8 Class Initialized
DEBUG - 2016-12-26 19:03:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 19:03:12 --> URI Class Initialized
DEBUG - 2016-12-26 19:03:12 --> Router Class Initialized
ERROR - 2016-12-26 19:03:12 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 19:05:00 --> Config Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Hooks Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Utf8 Class Initialized
DEBUG - 2016-12-26 19:05:00 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 19:05:00 --> URI Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Router Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Output Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Security Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Input Class Initialized
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> XSS Filtering completed
DEBUG - 2016-12-26 19:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 19:05:00 --> Language Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Loader Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Helper loaded: url_helper
DEBUG - 2016-12-26 19:05:00 --> Helper loaded: form_helper
DEBUG - 2016-12-26 19:05:00 --> Helper loaded: func_helper
DEBUG - 2016-12-26 19:05:00 --> Database Driver Class Initialized
ERROR - 2016-12-26 19:05:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 19:05:00 --> Session Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Helper loaded: string_helper
DEBUG - 2016-12-26 19:05:00 --> Encrypt Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Session routines successfully run
ERROR - 2016-12-26 19:05:00 --> Could not find the language line "first_link"
ERROR - 2016-12-26 19:05:00 --> Could not find the language line "last_link"
ERROR - 2016-12-26 19:05:00 --> Could not find the language line "next_link"
ERROR - 2016-12-26 19:05:00 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 19:05:00 --> Pagination Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Table Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Model Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Model Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Helper loaded: file_helper
DEBUG - 2016-12-26 19:05:00 --> Model Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Controller Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Helper loaded: language_helper
DEBUG - 2016-12-26 19:05:00 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 19:05:00 --> Model Class Initialized
DEBUG - 2016-12-26 19:05:00 --> Upload Class Initialized
DEBUG - 2016-12-26 19:05:52 --> DB Transaction Failure
ERROR - 2016-12-26 19:05:52 --> Query error: Table 'univ_alumni.lk9v6_alumni_main' doesn't exist
DEBUG - 2016-12-26 19:05:52 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-26 19:05:52 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-26 21:04:56 --> Config Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:04:56 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:04:56 --> URI Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Router Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Output Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Security Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Input Class Initialized
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> XSS Filtering completed
DEBUG - 2016-12-26 21:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 21:04:56 --> Language Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Loader Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:04:56 --> Helper loaded: form_helper
DEBUG - 2016-12-26 21:04:56 --> Helper loaded: func_helper
DEBUG - 2016-12-26 21:04:56 --> Database Driver Class Initialized
ERROR - 2016-12-26 21:04:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 21:04:56 --> Session Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Helper loaded: string_helper
DEBUG - 2016-12-26 21:04:56 --> Encrypt Class Initialized
DEBUG - 2016-12-26 21:04:56 --> A session cookie was not found.
DEBUG - 2016-12-26 21:04:56 --> Session routines successfully run
ERROR - 2016-12-26 21:04:56 --> Could not find the language line "first_link"
ERROR - 2016-12-26 21:04:56 --> Could not find the language line "last_link"
ERROR - 2016-12-26 21:04:56 --> Could not find the language line "next_link"
ERROR - 2016-12-26 21:04:56 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 21:04:56 --> Pagination Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Table Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Model Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Model Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Helper loaded: file_helper
DEBUG - 2016-12-26 21:04:56 --> Model Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Controller Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Helper loaded: language_helper
DEBUG - 2016-12-26 21:04:56 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 21:04:56 --> Model Class Initialized
DEBUG - 2016-12-26 21:04:56 --> Upload Class Initialized
DEBUG - 2016-12-26 21:05:49 --> DB Transaction Failure
ERROR - 2016-12-26 21:05:49 --> Query error: Table 'univ_alumni.lk9v6_alumni_main' doesn't exist
DEBUG - 2016-12-26 21:05:49 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-26 21:05:49 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-26 21:06:37 --> Config Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:06:37 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:06:37 --> URI Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Router Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Output Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Security Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Input Class Initialized
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> XSS Filtering completed
DEBUG - 2016-12-26 21:06:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 21:06:37 --> Language Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Loader Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:06:37 --> Helper loaded: form_helper
DEBUG - 2016-12-26 21:06:37 --> Helper loaded: func_helper
DEBUG - 2016-12-26 21:06:37 --> Database Driver Class Initialized
ERROR - 2016-12-26 21:06:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 21:06:37 --> Session Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Helper loaded: string_helper
DEBUG - 2016-12-26 21:06:37 --> Encrypt Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Session routines successfully run
ERROR - 2016-12-26 21:06:37 --> Could not find the language line "first_link"
ERROR - 2016-12-26 21:06:37 --> Could not find the language line "last_link"
ERROR - 2016-12-26 21:06:37 --> Could not find the language line "next_link"
ERROR - 2016-12-26 21:06:37 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 21:06:37 --> Pagination Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Table Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Model Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Model Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Helper loaded: file_helper
DEBUG - 2016-12-26 21:06:37 --> Model Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Controller Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Helper loaded: language_helper
DEBUG - 2016-12-26 21:06:37 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 21:06:37 --> Model Class Initialized
DEBUG - 2016-12-26 21:06:37 --> Upload Class Initialized
ERROR - 2016-12-26 21:07:30 --> Severity: Notice  --> Undefined variable: bdate C:\xampp\htdocs\www\alumni\application\models\My_admin_model.php 104
DEBUG - 2016-12-26 21:07:30 --> DB Transaction Failure
ERROR - 2016-12-26 21:07:30 --> Query error: Unknown column 'job' in 'field list'
DEBUG - 2016-12-26 21:07:30 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-26 21:07:30 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-26 21:14:10 --> Config Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:14:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:14:10 --> URI Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Router Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Output Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Security Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Input Class Initialized
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 21:14:10 --> Language Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Loader Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:14:10 --> Helper loaded: form_helper
DEBUG - 2016-12-26 21:14:10 --> Helper loaded: func_helper
DEBUG - 2016-12-26 21:14:10 --> Database Driver Class Initialized
ERROR - 2016-12-26 21:14:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 21:14:10 --> Session Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Helper loaded: string_helper
DEBUG - 2016-12-26 21:14:10 --> Encrypt Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Session routines successfully run
ERROR - 2016-12-26 21:14:10 --> Could not find the language line "first_link"
ERROR - 2016-12-26 21:14:10 --> Could not find the language line "last_link"
ERROR - 2016-12-26 21:14:10 --> Could not find the language line "next_link"
ERROR - 2016-12-26 21:14:10 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 21:14:10 --> Pagination Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Table Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Model Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Model Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Helper loaded: file_helper
DEBUG - 2016-12-26 21:14:10 --> Model Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Controller Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Helper loaded: language_helper
DEBUG - 2016-12-26 21:14:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 21:14:10 --> Model Class Initialized
DEBUG - 2016-12-26 21:14:10 --> Upload Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Config Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:14:32 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:14:32 --> URI Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Router Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Output Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Security Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Input Class Initialized
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> XSS Filtering completed
DEBUG - 2016-12-26 21:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 21:14:32 --> Language Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Loader Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:14:32 --> Helper loaded: form_helper
DEBUG - 2016-12-26 21:14:32 --> Helper loaded: func_helper
DEBUG - 2016-12-26 21:14:32 --> Database Driver Class Initialized
ERROR - 2016-12-26 21:14:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 21:14:32 --> Session Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Helper loaded: string_helper
DEBUG - 2016-12-26 21:14:32 --> Encrypt Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Session routines successfully run
ERROR - 2016-12-26 21:14:32 --> Could not find the language line "first_link"
ERROR - 2016-12-26 21:14:32 --> Could not find the language line "last_link"
ERROR - 2016-12-26 21:14:32 --> Could not find the language line "next_link"
ERROR - 2016-12-26 21:14:32 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 21:14:32 --> Pagination Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Table Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Model Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Model Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Helper loaded: file_helper
DEBUG - 2016-12-26 21:14:32 --> Model Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Controller Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Helper loaded: language_helper
DEBUG - 2016-12-26 21:14:32 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 21:14:32 --> Model Class Initialized
DEBUG - 2016-12-26 21:14:32 --> Upload Class Initialized
ERROR - 2016-12-26 21:15:17 --> Severity: Notice  --> Undefined variable: bdate C:\xampp\htdocs\www\alumni\application\models\My_admin_model.php 104
DEBUG - 2016-12-26 21:15:17 --> DB Transaction Failure
ERROR - 2016-12-26 21:15:17 --> Query error: Unknown column 'job' in 'field list'
DEBUG - 2016-12-26 21:15:17 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-26 21:15:17 --> Could not find the language line "db_error_heading"
ERROR - 2016-12-26 21:15:41 --> Severity: Notice  --> Undefined variable: bdate C:\xampp\htdocs\www\alumni\application\models\My_admin_model.php 104
DEBUG - 2016-12-26 21:15:41 --> DB Transaction Failure
ERROR - 2016-12-26 21:15:41 --> Query error: Unknown column 'job' in 'field list'
DEBUG - 2016-12-26 21:15:41 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-26 21:15:41 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-26 21:39:14 --> Config Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:39:14 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:39:14 --> URI Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Router Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Output Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Security Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Input Class Initialized
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> XSS Filtering completed
DEBUG - 2016-12-26 21:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 21:39:14 --> Language Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Loader Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:39:14 --> Helper loaded: form_helper
DEBUG - 2016-12-26 21:39:14 --> Helper loaded: func_helper
DEBUG - 2016-12-26 21:39:14 --> Database Driver Class Initialized
ERROR - 2016-12-26 21:39:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 21:39:14 --> Session Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Helper loaded: string_helper
DEBUG - 2016-12-26 21:39:14 --> Encrypt Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Session routines successfully run
ERROR - 2016-12-26 21:39:14 --> Could not find the language line "first_link"
ERROR - 2016-12-26 21:39:14 --> Could not find the language line "last_link"
ERROR - 2016-12-26 21:39:14 --> Could not find the language line "next_link"
ERROR - 2016-12-26 21:39:14 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 21:39:14 --> Pagination Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Table Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Model Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Model Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Helper loaded: file_helper
DEBUG - 2016-12-26 21:39:14 --> Model Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Controller Class Initialized
DEBUG - 2016-12-26 21:39:14 --> Helper loaded: language_helper
DEBUG - 2016-12-26 21:39:14 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 21:40:00 --> Config Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:40:00 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:40:00 --> URI Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Router Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Output Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Security Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Input Class Initialized
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 21:40:00 --> Language Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Loader Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:40:00 --> Helper loaded: form_helper
DEBUG - 2016-12-26 21:40:00 --> Helper loaded: func_helper
DEBUG - 2016-12-26 21:40:00 --> Database Driver Class Initialized
ERROR - 2016-12-26 21:40:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 21:40:00 --> Session Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Helper loaded: string_helper
DEBUG - 2016-12-26 21:40:00 --> Encrypt Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Session routines successfully run
ERROR - 2016-12-26 21:40:00 --> Could not find the language line "first_link"
ERROR - 2016-12-26 21:40:00 --> Could not find the language line "last_link"
ERROR - 2016-12-26 21:40:00 --> Could not find the language line "next_link"
ERROR - 2016-12-26 21:40:00 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 21:40:00 --> Pagination Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Table Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Model Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Model Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Helper loaded: file_helper
DEBUG - 2016-12-26 21:40:00 --> Model Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Controller Class Initialized
DEBUG - 2016-12-26 21:40:00 --> Helper loaded: language_helper
DEBUG - 2016-12-26 21:40:00 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 21:40:44 --> Config Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:40:44 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:40:44 --> URI Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Router Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Output Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Security Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Input Class Initialized
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> XSS Filtering completed
DEBUG - 2016-12-26 21:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 21:40:44 --> Language Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Loader Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:40:44 --> Helper loaded: form_helper
DEBUG - 2016-12-26 21:40:44 --> Helper loaded: func_helper
DEBUG - 2016-12-26 21:40:44 --> Database Driver Class Initialized
ERROR - 2016-12-26 21:40:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 21:40:44 --> Session Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Helper loaded: string_helper
DEBUG - 2016-12-26 21:40:44 --> Encrypt Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Session routines successfully run
ERROR - 2016-12-26 21:40:44 --> Could not find the language line "first_link"
ERROR - 2016-12-26 21:40:44 --> Could not find the language line "last_link"
ERROR - 2016-12-26 21:40:44 --> Could not find the language line "next_link"
ERROR - 2016-12-26 21:40:44 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 21:40:44 --> Pagination Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Table Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Model Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Model Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Helper loaded: file_helper
DEBUG - 2016-12-26 21:40:44 --> Model Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Controller Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Helper loaded: language_helper
DEBUG - 2016-12-26 21:40:44 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 21:40:44 --> Model Class Initialized
DEBUG - 2016-12-26 21:40:44 --> Upload Class Initialized
ERROR - 2016-12-26 21:41:39 --> Severity: Notice  --> Undefined variable: bdate C:\xampp\htdocs\www\alumni\application\models\My_admin_model.php 112
DEBUG - 2016-12-26 21:41:39 --> DB Transaction Failure
ERROR - 2016-12-26 21:41:39 --> Query error: Unknown column 'birthdate' in 'field list'
DEBUG - 2016-12-26 21:41:39 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-12-26 21:41:39 --> Could not find the language line "db_error_heading"
DEBUG - 2016-12-26 21:49:21 --> Config Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:49:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:49:21 --> URI Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Router Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Output Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Security Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Input Class Initialized
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> XSS Filtering completed
DEBUG - 2016-12-26 21:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 21:49:21 --> Language Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Loader Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:49:21 --> Helper loaded: form_helper
DEBUG - 2016-12-26 21:49:21 --> Helper loaded: func_helper
DEBUG - 2016-12-26 21:49:21 --> Database Driver Class Initialized
ERROR - 2016-12-26 21:49:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 21:49:21 --> Session Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Helper loaded: string_helper
DEBUG - 2016-12-26 21:49:21 --> Encrypt Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Session routines successfully run
ERROR - 2016-12-26 21:49:21 --> Could not find the language line "first_link"
ERROR - 2016-12-26 21:49:21 --> Could not find the language line "last_link"
ERROR - 2016-12-26 21:49:21 --> Could not find the language line "next_link"
ERROR - 2016-12-26 21:49:21 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 21:49:21 --> Pagination Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Table Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Model Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Model Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Helper loaded: file_helper
DEBUG - 2016-12-26 21:49:21 --> Model Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Controller Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Helper loaded: language_helper
DEBUG - 2016-12-26 21:49:21 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 21:49:21 --> Model Class Initialized
DEBUG - 2016-12-26 21:49:21 --> Upload Class Initialized
ERROR - 2016-12-26 21:49:22 --> Severity: Notice  --> Undefined variable: s C:\xampp\htdocs\www\alumni\application\controllers\My_admin.php 130
ERROR - 2016-12-26 21:49:22 --> Severity: Notice  --> Undefined variable: s C:\xampp\htdocs\www\alumni\application\controllers\My_admin.php 130
ERROR - 2016-12-26 21:49:22 --> Severity: Notice  --> Undefined variable: s C:\xampp\htdocs\www\alumni\application\controllers\My_admin.php 130
ERROR - 2016-12-26 21:49:22 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-26 21:49:22 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-26 21:49:22 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-26 21:49:22 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-26 21:49:22 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-26 21:49:22 --> Final output sent to browser
DEBUG - 2016-12-26 21:49:22 --> Total execution time: 0.6110
DEBUG - 2016-12-26 21:49:22 --> Config Class Initialized
DEBUG - 2016-12-26 21:49:22 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:49:22 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:49:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:49:22 --> URI Class Initialized
DEBUG - 2016-12-26 21:49:22 --> Router Class Initialized
ERROR - 2016-12-26 21:49:22 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 21:50:23 --> Config Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:50:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:50:23 --> URI Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Router Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Output Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Security Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Input Class Initialized
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> XSS Filtering completed
DEBUG - 2016-12-26 21:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 21:50:23 --> Language Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Loader Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:50:23 --> Helper loaded: form_helper
DEBUG - 2016-12-26 21:50:23 --> Helper loaded: func_helper
DEBUG - 2016-12-26 21:50:23 --> Database Driver Class Initialized
ERROR - 2016-12-26 21:50:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 21:50:23 --> Session Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Helper loaded: string_helper
DEBUG - 2016-12-26 21:50:23 --> Encrypt Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Session routines successfully run
ERROR - 2016-12-26 21:50:23 --> Could not find the language line "first_link"
ERROR - 2016-12-26 21:50:23 --> Could not find the language line "last_link"
ERROR - 2016-12-26 21:50:23 --> Could not find the language line "next_link"
ERROR - 2016-12-26 21:50:23 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 21:50:23 --> Pagination Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Table Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Model Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Model Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Helper loaded: file_helper
DEBUG - 2016-12-26 21:50:23 --> Model Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Controller Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Helper loaded: language_helper
DEBUG - 2016-12-26 21:50:23 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 21:50:23 --> Model Class Initialized
DEBUG - 2016-12-26 21:50:23 --> Upload Class Initialized
ERROR - 2016-12-26 21:50:24 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-26 21:50:24 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-26 21:50:24 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-26 21:50:24 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-26 21:50:24 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-26 21:50:24 --> Final output sent to browser
DEBUG - 2016-12-26 21:50:24 --> Total execution time: 0.5460
DEBUG - 2016-12-26 21:50:24 --> Config Class Initialized
DEBUG - 2016-12-26 21:50:24 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:50:24 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:50:24 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:50:24 --> URI Class Initialized
DEBUG - 2016-12-26 21:50:24 --> Router Class Initialized
ERROR - 2016-12-26 21:50:24 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 21:51:04 --> Config Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:51:04 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:51:04 --> URI Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Router Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Output Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Security Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Input Class Initialized
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> XSS Filtering completed
DEBUG - 2016-12-26 21:51:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 21:51:04 --> Language Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Loader Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Helper loaded: url_helper
DEBUG - 2016-12-26 21:51:04 --> Helper loaded: form_helper
DEBUG - 2016-12-26 21:51:04 --> Helper loaded: func_helper
DEBUG - 2016-12-26 21:51:04 --> Database Driver Class Initialized
ERROR - 2016-12-26 21:51:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 21:51:04 --> Session Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Helper loaded: string_helper
DEBUG - 2016-12-26 21:51:04 --> Encrypt Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Session routines successfully run
ERROR - 2016-12-26 21:51:04 --> Could not find the language line "first_link"
ERROR - 2016-12-26 21:51:04 --> Could not find the language line "last_link"
ERROR - 2016-12-26 21:51:04 --> Could not find the language line "next_link"
ERROR - 2016-12-26 21:51:04 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 21:51:04 --> Pagination Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Table Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Model Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Model Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Helper loaded: file_helper
DEBUG - 2016-12-26 21:51:04 --> Model Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Controller Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Helper loaded: language_helper
DEBUG - 2016-12-26 21:51:04 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 21:51:04 --> Model Class Initialized
DEBUG - 2016-12-26 21:51:04 --> Upload Class Initialized
ERROR - 2016-12-26 21:51:05 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-26 21:51:05 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-26 21:51:05 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-26 21:51:05 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-26 21:51:05 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-26 21:51:05 --> Final output sent to browser
DEBUG - 2016-12-26 21:51:05 --> Total execution time: 0.5750
DEBUG - 2016-12-26 21:51:05 --> Config Class Initialized
DEBUG - 2016-12-26 21:51:05 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:51:05 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:51:05 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:51:05 --> URI Class Initialized
DEBUG - 2016-12-26 21:51:05 --> Router Class Initialized
ERROR - 2016-12-26 21:51:05 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 21:51:05 --> Config Class Initialized
DEBUG - 2016-12-26 21:51:05 --> Hooks Class Initialized
DEBUG - 2016-12-26 21:51:05 --> Utf8 Class Initialized
DEBUG - 2016-12-26 21:51:05 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 21:51:05 --> URI Class Initialized
DEBUG - 2016-12-26 21:51:05 --> Router Class Initialized
ERROR - 2016-12-26 21:51:05 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 22:49:15 --> Config Class Initialized
DEBUG - 2016-12-26 22:49:15 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:49:15 --> Utf8 Class Initialized
DEBUG - 2016-12-26 22:49:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 22:49:15 --> URI Class Initialized
DEBUG - 2016-12-26 22:49:15 --> Router Class Initialized
DEBUG - 2016-12-26 22:49:15 --> No URI present. Default controller set.
DEBUG - 2016-12-26 22:49:15 --> Output Class Initialized
DEBUG - 2016-12-26 22:49:15 --> Security Class Initialized
DEBUG - 2016-12-26 22:49:15 --> Input Class Initialized
DEBUG - 2016-12-26 22:49:15 --> XSS Filtering completed
DEBUG - 2016-12-26 22:49:15 --> XSS Filtering completed
DEBUG - 2016-12-26 22:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 22:49:15 --> Language Class Initialized
DEBUG - 2016-12-26 22:49:15 --> Loader Class Initialized
DEBUG - 2016-12-26 22:49:15 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:49:15 --> Helper loaded: form_helper
DEBUG - 2016-12-26 22:49:15 --> Helper loaded: func_helper
DEBUG - 2016-12-26 22:49:15 --> Database Driver Class Initialized
ERROR - 2016-12-26 22:49:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 22:49:15 --> Session Class Initialized
DEBUG - 2016-12-26 22:49:15 --> Helper loaded: string_helper
DEBUG - 2016-12-26 22:49:15 --> Encrypt Class Initialized
DEBUG - 2016-12-26 22:49:15 --> Session routines successfully run
ERROR - 2016-12-26 22:49:15 --> Could not find the language line "first_link"
ERROR - 2016-12-26 22:49:15 --> Could not find the language line "last_link"
ERROR - 2016-12-26 22:49:15 --> Could not find the language line "next_link"
ERROR - 2016-12-26 22:49:15 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 22:49:15 --> Pagination Class Initialized
DEBUG - 2016-12-26 22:49:15 --> Table Class Initialized
DEBUG - 2016-12-26 22:49:15 --> Model Class Initialized
DEBUG - 2016-12-26 22:49:15 --> Model Class Initialized
DEBUG - 2016-12-26 22:49:15 --> Helper loaded: file_helper
DEBUG - 2016-12-26 22:49:15 --> Model Class Initialized
DEBUG - 2016-12-26 22:49:15 --> Controller Class Initialized
DEBUG - 2016-12-26 22:49:17 --> Helper loaded: language_helper
DEBUG - 2016-12-26 22:49:17 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 22:49:20 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-26 22:49:23 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 22:49:23 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 22:49:23 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-26 22:49:23 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-26 22:49:23 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-26 22:49:23 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 22:49:23 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 22:49:23 --> Final output sent to browser
DEBUG - 2016-12-26 22:49:23 --> Total execution time: 8.1015
DEBUG - 2016-12-26 22:49:23 --> Config Class Initialized
DEBUG - 2016-12-26 22:49:23 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:49:23 --> Utf8 Class Initialized
DEBUG - 2016-12-26 22:49:23 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 22:49:23 --> URI Class Initialized
DEBUG - 2016-12-26 22:49:23 --> Router Class Initialized
ERROR - 2016-12-26 22:49:23 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 22:49:31 --> Config Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Utf8 Class Initialized
DEBUG - 2016-12-26 22:49:31 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 22:49:31 --> URI Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Router Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Output Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Security Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Input Class Initialized
DEBUG - 2016-12-26 22:49:31 --> XSS Filtering completed
DEBUG - 2016-12-26 22:49:31 --> XSS Filtering completed
DEBUG - 2016-12-26 22:49:31 --> XSS Filtering completed
DEBUG - 2016-12-26 22:49:31 --> XSS Filtering completed
DEBUG - 2016-12-26 22:49:31 --> XSS Filtering completed
DEBUG - 2016-12-26 22:49:31 --> XSS Filtering completed
DEBUG - 2016-12-26 22:49:31 --> XSS Filtering completed
DEBUG - 2016-12-26 22:49:31 --> XSS Filtering completed
DEBUG - 2016-12-26 22:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 22:49:31 --> Language Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Loader Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:49:31 --> Helper loaded: form_helper
DEBUG - 2016-12-26 22:49:31 --> Helper loaded: func_helper
DEBUG - 2016-12-26 22:49:31 --> Database Driver Class Initialized
ERROR - 2016-12-26 22:49:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 22:49:31 --> Session Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Helper loaded: string_helper
DEBUG - 2016-12-26 22:49:31 --> Encrypt Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Session routines successfully run
ERROR - 2016-12-26 22:49:31 --> Could not find the language line "first_link"
ERROR - 2016-12-26 22:49:31 --> Could not find the language line "last_link"
ERROR - 2016-12-26 22:49:31 --> Could not find the language line "next_link"
ERROR - 2016-12-26 22:49:31 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 22:49:31 --> Pagination Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Table Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Model Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Model Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Helper loaded: file_helper
DEBUG - 2016-12-26 22:49:31 --> Model Class Initialized
DEBUG - 2016-12-26 22:49:31 --> Controller Class Initialized
DEBUG - 2016-12-26 22:49:33 --> Helper loaded: language_helper
DEBUG - 2016-12-26 22:49:33 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 22:49:34 --> Config Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Utf8 Class Initialized
DEBUG - 2016-12-26 22:49:34 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 22:49:34 --> URI Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Router Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Output Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Security Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Input Class Initialized
DEBUG - 2016-12-26 22:49:34 --> XSS Filtering completed
DEBUG - 2016-12-26 22:49:34 --> XSS Filtering completed
DEBUG - 2016-12-26 22:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 22:49:34 --> Language Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Loader Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:49:34 --> Helper loaded: form_helper
DEBUG - 2016-12-26 22:49:34 --> Helper loaded: func_helper
DEBUG - 2016-12-26 22:49:34 --> Database Driver Class Initialized
ERROR - 2016-12-26 22:49:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 22:49:34 --> Session Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Helper loaded: string_helper
DEBUG - 2016-12-26 22:49:34 --> Encrypt Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Session routines successfully run
ERROR - 2016-12-26 22:49:34 --> Could not find the language line "first_link"
ERROR - 2016-12-26 22:49:34 --> Could not find the language line "last_link"
ERROR - 2016-12-26 22:49:34 --> Could not find the language line "next_link"
ERROR - 2016-12-26 22:49:34 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 22:49:34 --> Pagination Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Table Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Model Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Model Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Helper loaded: file_helper
DEBUG - 2016-12-26 22:49:34 --> Model Class Initialized
DEBUG - 2016-12-26 22:49:34 --> Controller Class Initialized
DEBUG - 2016-12-26 22:49:37 --> Helper loaded: language_helper
DEBUG - 2016-12-26 22:49:37 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-26 22:49:37 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-26 22:49:37 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 22:49:37 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 22:49:37 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-26 22:49:37 --> File loaded: application/views/alumni_view_files/single.php
DEBUG - 2016-12-26 22:49:37 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-26 22:49:37 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 22:49:37 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 22:49:37 --> Final output sent to browser
DEBUG - 2016-12-26 22:49:37 --> Total execution time: 3.0142
DEBUG - 2016-12-26 22:49:37 --> Config Class Initialized
DEBUG - 2016-12-26 22:49:37 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:49:37 --> Utf8 Class Initialized
DEBUG - 2016-12-26 22:49:37 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 22:49:37 --> URI Class Initialized
DEBUG - 2016-12-26 22:49:37 --> Router Class Initialized
ERROR - 2016-12-26 22:49:37 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 22:50:03 --> Config Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Utf8 Class Initialized
DEBUG - 2016-12-26 22:50:03 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 22:50:03 --> URI Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Router Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Output Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Security Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Input Class Initialized
DEBUG - 2016-12-26 22:50:03 --> XSS Filtering completed
DEBUG - 2016-12-26 22:50:03 --> XSS Filtering completed
DEBUG - 2016-12-26 22:50:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 22:50:03 --> Language Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Loader Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:50:03 --> Helper loaded: form_helper
DEBUG - 2016-12-26 22:50:03 --> Helper loaded: func_helper
DEBUG - 2016-12-26 22:50:03 --> Database Driver Class Initialized
ERROR - 2016-12-26 22:50:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 22:50:03 --> Session Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Helper loaded: string_helper
DEBUG - 2016-12-26 22:50:03 --> Encrypt Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Session routines successfully run
ERROR - 2016-12-26 22:50:03 --> Could not find the language line "first_link"
ERROR - 2016-12-26 22:50:03 --> Could not find the language line "last_link"
ERROR - 2016-12-26 22:50:03 --> Could not find the language line "next_link"
ERROR - 2016-12-26 22:50:03 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 22:50:03 --> Pagination Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Table Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Model Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Model Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Helper loaded: file_helper
DEBUG - 2016-12-26 22:50:03 --> Model Class Initialized
DEBUG - 2016-12-26 22:50:03 --> Controller Class Initialized
DEBUG - 2016-12-26 22:50:05 --> Helper loaded: language_helper
DEBUG - 2016-12-26 22:50:05 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 22:50:05 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 22:50:05 --> File loaded: application/views/includes/header.php
ERROR - 2016-12-26 22:50:05 --> Could not find the language line "id"
DEBUG - 2016-12-26 22:50:05 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 22:50:05 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 22:50:05 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 22:50:05 --> Final output sent to browser
DEBUG - 2016-12-26 22:50:05 --> Total execution time: 2.3301
DEBUG - 2016-12-26 22:50:05 --> Config Class Initialized
DEBUG - 2016-12-26 22:50:05 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:50:05 --> Utf8 Class Initialized
DEBUG - 2016-12-26 22:50:05 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 22:50:05 --> URI Class Initialized
DEBUG - 2016-12-26 22:50:05 --> Router Class Initialized
ERROR - 2016-12-26 22:50:05 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 22:50:46 --> Config Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Utf8 Class Initialized
DEBUG - 2016-12-26 22:50:46 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 22:50:46 --> URI Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Router Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Output Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Security Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Input Class Initialized
DEBUG - 2016-12-26 22:50:46 --> XSS Filtering completed
DEBUG - 2016-12-26 22:50:46 --> XSS Filtering completed
DEBUG - 2016-12-26 22:50:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 22:50:46 --> Language Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Loader Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Helper loaded: url_helper
DEBUG - 2016-12-26 22:50:46 --> Helper loaded: form_helper
DEBUG - 2016-12-26 22:50:46 --> Helper loaded: func_helper
DEBUG - 2016-12-26 22:50:46 --> Database Driver Class Initialized
ERROR - 2016-12-26 22:50:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 22:50:46 --> Session Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Helper loaded: string_helper
DEBUG - 2016-12-26 22:50:46 --> Encrypt Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Session routines successfully run
ERROR - 2016-12-26 22:50:46 --> Could not find the language line "first_link"
ERROR - 2016-12-26 22:50:46 --> Could not find the language line "last_link"
ERROR - 2016-12-26 22:50:46 --> Could not find the language line "next_link"
ERROR - 2016-12-26 22:50:46 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 22:50:46 --> Pagination Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Table Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Model Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Model Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Helper loaded: file_helper
DEBUG - 2016-12-26 22:50:46 --> Model Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Controller Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Helper loaded: language_helper
DEBUG - 2016-12-26 22:50:46 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 22:50:46 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 22:50:46 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 22:50:46 --> File loaded: application/views/login_form.php
DEBUG - 2016-12-26 22:50:46 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 22:50:46 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 22:50:46 --> Final output sent to browser
DEBUG - 2016-12-26 22:50:46 --> Total execution time: 0.1500
DEBUG - 2016-12-26 22:50:46 --> Config Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Hooks Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Utf8 Class Initialized
DEBUG - 2016-12-26 22:50:46 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 22:50:46 --> URI Class Initialized
DEBUG - 2016-12-26 22:50:46 --> Router Class Initialized
ERROR - 2016-12-26 22:50:46 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:08:05 --> Config Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:08:05 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:08:05 --> URI Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Router Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Output Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Security Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Input Class Initialized
DEBUG - 2016-12-26 23:08:05 --> XSS Filtering completed
DEBUG - 2016-12-26 23:08:05 --> XSS Filtering completed
DEBUG - 2016-12-26 23:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:08:05 --> Language Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Loader Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:08:05 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:08:05 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:08:05 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:08:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:08:05 --> Session Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:08:05 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Session routines successfully run
ERROR - 2016-12-26 23:08:05 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:08:05 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:08:05 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:08:05 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:08:05 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Table Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Model Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Model Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:08:05 --> Model Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Controller Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:08:05 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-26 23:08:05 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-26 23:08:05 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-26 23:08:05 --> File loaded: application/views/me/myadmin_upload.php
DEBUG - 2016-12-26 23:08:05 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-26 23:08:05 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-26 23:08:05 --> Final output sent to browser
DEBUG - 2016-12-26 23:08:05 --> Total execution time: 0.1710
DEBUG - 2016-12-26 23:08:05 --> Config Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:08:05 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:08:05 --> URI Class Initialized
DEBUG - 2016-12-26 23:08:05 --> Router Class Initialized
ERROR - 2016-12-26 23:08:05 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:09:12 --> Config Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:09:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:09:12 --> URI Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Router Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Output Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Security Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Input Class Initialized
DEBUG - 2016-12-26 23:09:12 --> XSS Filtering completed
DEBUG - 2016-12-26 23:09:12 --> XSS Filtering completed
DEBUG - 2016-12-26 23:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:09:12 --> Language Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Loader Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:09:12 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:09:12 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:09:12 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:09:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:09:12 --> Session Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:09:12 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Session routines successfully run
ERROR - 2016-12-26 23:09:12 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:09:12 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:09:12 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:09:12 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:09:12 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Table Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Model Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Model Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:09:12 --> Model Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Controller Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:09:12 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-26 23:09:12 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-26 23:09:12 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-26 23:09:12 --> File loaded: application/views/me/myadmin_upload.php
DEBUG - 2016-12-26 23:09:12 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-26 23:09:12 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-26 23:09:12 --> Final output sent to browser
DEBUG - 2016-12-26 23:09:12 --> Total execution time: 0.1220
DEBUG - 2016-12-26 23:09:12 --> Config Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:09:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:09:12 --> URI Class Initialized
DEBUG - 2016-12-26 23:09:12 --> Router Class Initialized
ERROR - 2016-12-26 23:09:12 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:11:02 --> Config Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:11:02 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:11:02 --> URI Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Router Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Output Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Security Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Input Class Initialized
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> XSS Filtering completed
DEBUG - 2016-12-26 23:11:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:11:02 --> Language Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Loader Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:11:02 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:11:02 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:11:02 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:11:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:11:02 --> Session Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:11:02 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Session routines successfully run
ERROR - 2016-12-26 23:11:02 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:11:02 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:11:02 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:11:02 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:11:02 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Table Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Model Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Model Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:11:02 --> Model Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Controller Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:11:02 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:11:02 --> Model Class Initialized
DEBUG - 2016-12-26 23:11:02 --> Upload Class Initialized
ERROR - 2016-12-26 23:11:03 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-26 23:11:03 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-26 23:11:03 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-26 23:11:03 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-26 23:11:03 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-26 23:11:03 --> Final output sent to browser
DEBUG - 2016-12-26 23:11:03 --> Total execution time: 0.5760
DEBUG - 2016-12-26 23:11:03 --> Config Class Initialized
DEBUG - 2016-12-26 23:11:03 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:11:03 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:11:03 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:11:03 --> URI Class Initialized
DEBUG - 2016-12-26 23:11:03 --> Router Class Initialized
ERROR - 2016-12-26 23:11:03 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:25:01 --> Config Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:25:01 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:25:01 --> URI Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Router Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Output Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Security Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Input Class Initialized
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:25:01 --> Language Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Loader Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:25:01 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:25:01 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:25:01 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:25:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:25:01 --> Session Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:25:01 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Session routines successfully run
ERROR - 2016-12-26 23:25:01 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:25:01 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:25:01 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:25:01 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:25:01 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Table Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Model Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Model Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:25:01 --> Model Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Controller Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:25:01 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:25:01 --> Model Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Upload Class Initialized
ERROR - 2016-12-26 23:25:01 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-26 23:25:01 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-26 23:25:01 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-26 23:25:01 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-26 23:25:01 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-26 23:25:01 --> Final output sent to browser
DEBUG - 2016-12-26 23:25:01 --> Total execution time: 0.5990
DEBUG - 2016-12-26 23:25:01 --> Config Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:25:01 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:25:01 --> URI Class Initialized
DEBUG - 2016-12-26 23:25:01 --> Router Class Initialized
ERROR - 2016-12-26 23:25:01 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:25:46 --> Config Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:25:46 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:25:46 --> URI Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Router Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Output Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Security Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Input Class Initialized
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> XSS Filtering completed
DEBUG - 2016-12-26 23:25:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:25:46 --> Language Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Loader Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:25:46 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:25:46 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:25:46 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:25:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:25:46 --> Session Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:25:46 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Session routines successfully run
ERROR - 2016-12-26 23:25:46 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:25:46 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:25:46 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:25:46 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:25:46 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Table Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Model Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Model Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:25:46 --> Model Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Controller Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:25:46 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:25:46 --> Model Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Upload Class Initialized
ERROR - 2016-12-26 23:25:46 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-26 23:25:46 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-26 23:25:46 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-26 23:25:46 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-26 23:25:46 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-26 23:25:46 --> Final output sent to browser
DEBUG - 2016-12-26 23:25:46 --> Total execution time: 0.5250
DEBUG - 2016-12-26 23:25:46 --> Config Class Initialized
DEBUG - 2016-12-26 23:25:46 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:25:47 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:25:47 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:25:47 --> URI Class Initialized
DEBUG - 2016-12-26 23:25:47 --> Router Class Initialized
ERROR - 2016-12-26 23:25:47 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:27:52 --> Config Class Initialized
DEBUG - 2016-12-26 23:27:52 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:27:52 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:27:52 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:27:52 --> URI Class Initialized
DEBUG - 2016-12-26 23:27:52 --> Router Class Initialized
DEBUG - 2016-12-26 23:27:52 --> Output Class Initialized
DEBUG - 2016-12-26 23:27:52 --> Security Class Initialized
DEBUG - 2016-12-26 23:27:52 --> Input Class Initialized
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:27:52 --> Language Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Config Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:28:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:28:21 --> URI Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Router Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Output Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Security Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Input Class Initialized
DEBUG - 2016-12-26 23:28:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:28:21 --> Language Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Loader Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:28:21 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:28:21 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:28:21 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:28:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:28:21 --> Session Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:28:21 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Session routines successfully run
ERROR - 2016-12-26 23:28:21 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:28:21 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:28:21 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:28:21 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:28:21 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Table Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Model Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Model Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:28:21 --> Model Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Controller Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:28:21 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:28:21 --> Model Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Upload Class Initialized
DEBUG - 2016-12-26 23:28:21 --> Language file loaded: language/arabic/upload_lang.php
ERROR - 2016-12-26 23:28:21 --> لم تختر ملف لرفعه.
ERROR - 2016-12-26 23:28:21 --> Severity: Warning  --> file_get_contents(application/uploads/): failed to open stream: No such file or directory C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Shared\OLERead.php 85
ERROR - 2016-12-26 23:28:21 --> Severity: Warning  --> fopen(application/uploads/): failed to open stream: No such file or directory C:\xampp\htdocs\www\alumni\application\third_party\PHPExcel\Reader\Abstract.php 200
DEBUG - 2016-12-26 23:28:51 --> Config Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:28:51 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:28:51 --> URI Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Router Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Output Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Security Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Input Class Initialized
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:28:51 --> Language Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Loader Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:28:51 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:28:51 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:28:51 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:28:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:28:51 --> Session Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:28:51 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Session routines successfully run
ERROR - 2016-12-26 23:28:51 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:28:51 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:28:51 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:28:51 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:28:51 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Table Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Model Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Model Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:28:51 --> Model Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Controller Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:28:51 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:28:51 --> Model Class Initialized
DEBUG - 2016-12-26 23:28:51 --> Upload Class Initialized
ERROR - 2016-12-26 23:28:52 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-26 23:28:52 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-26 23:28:52 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-26 23:28:52 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-26 23:28:52 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-26 23:28:52 --> Final output sent to browser
DEBUG - 2016-12-26 23:28:52 --> Total execution time: 0.6270
DEBUG - 2016-12-26 23:28:52 --> Config Class Initialized
DEBUG - 2016-12-26 23:28:52 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:28:52 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:28:52 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:28:52 --> URI Class Initialized
DEBUG - 2016-12-26 23:28:52 --> Router Class Initialized
ERROR - 2016-12-26 23:28:52 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:28:52 --> Config Class Initialized
DEBUG - 2016-12-26 23:28:52 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:28:52 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:28:52 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:28:52 --> URI Class Initialized
DEBUG - 2016-12-26 23:28:52 --> Router Class Initialized
ERROR - 2016-12-26 23:28:52 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:29:51 --> Config Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:29:51 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:29:51 --> URI Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Router Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Output Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Security Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Input Class Initialized
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:29:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:29:51 --> Language Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Loader Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:29:51 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:29:51 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:29:51 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:29:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:29:51 --> Session Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:29:51 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Session routines successfully run
ERROR - 2016-12-26 23:29:51 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:29:51 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:29:51 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:29:51 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:29:51 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Table Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Model Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Model Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:29:51 --> Model Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Controller Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:29:51 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:29:51 --> Model Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Upload Class Initialized
ERROR - 2016-12-26 23:29:51 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-26 23:29:51 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-26 23:29:51 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-26 23:29:51 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-26 23:29:51 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-26 23:29:51 --> Final output sent to browser
DEBUG - 2016-12-26 23:29:51 --> Total execution time: 0.6080
DEBUG - 2016-12-26 23:29:51 --> Config Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:29:51 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:29:51 --> URI Class Initialized
DEBUG - 2016-12-26 23:29:51 --> Router Class Initialized
ERROR - 2016-12-26 23:29:51 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:32:47 --> Config Class Initialized
DEBUG - 2016-12-26 23:32:47 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:32:47 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:32:47 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:32:47 --> URI Class Initialized
DEBUG - 2016-12-26 23:32:47 --> Router Class Initialized
DEBUG - 2016-12-26 23:32:47 --> No URI present. Default controller set.
DEBUG - 2016-12-26 23:32:47 --> Output Class Initialized
DEBUG - 2016-12-26 23:32:47 --> Security Class Initialized
DEBUG - 2016-12-26 23:32:47 --> Input Class Initialized
DEBUG - 2016-12-26 23:32:47 --> XSS Filtering completed
DEBUG - 2016-12-26 23:32:47 --> XSS Filtering completed
DEBUG - 2016-12-26 23:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:32:47 --> Language Class Initialized
DEBUG - 2016-12-26 23:32:47 --> Loader Class Initialized
DEBUG - 2016-12-26 23:32:47 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:32:47 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:32:47 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:32:47 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:32:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:32:47 --> Session Class Initialized
DEBUG - 2016-12-26 23:32:47 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:32:47 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:32:47 --> Session routines successfully run
ERROR - 2016-12-26 23:32:47 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:32:47 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:32:47 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:32:47 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:32:47 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:32:47 --> Table Class Initialized
DEBUG - 2016-12-26 23:32:47 --> Model Class Initialized
DEBUG - 2016-12-26 23:32:47 --> Model Class Initialized
DEBUG - 2016-12-26 23:32:47 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:32:47 --> Model Class Initialized
DEBUG - 2016-12-26 23:32:47 --> Controller Class Initialized
DEBUG - 2016-12-26 23:32:50 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:32:50 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:32:53 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-12-26 23:32:56 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:32:56 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 23:32:56 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-26 23:32:56 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-12-26 23:32:56 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-26 23:32:56 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:32:56 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:32:56 --> Final output sent to browser
DEBUG - 2016-12-26 23:32:56 --> Total execution time: 9.0715
DEBUG - 2016-12-26 23:32:57 --> Config Class Initialized
DEBUG - 2016-12-26 23:32:57 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:32:57 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:32:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:32:57 --> URI Class Initialized
DEBUG - 2016-12-26 23:32:57 --> Router Class Initialized
ERROR - 2016-12-26 23:32:57 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:33:06 --> Config Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:33:06 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:33:06 --> URI Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Router Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Output Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Security Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Input Class Initialized
DEBUG - 2016-12-26 23:33:06 --> XSS Filtering completed
DEBUG - 2016-12-26 23:33:06 --> XSS Filtering completed
DEBUG - 2016-12-26 23:33:06 --> XSS Filtering completed
DEBUG - 2016-12-26 23:33:06 --> XSS Filtering completed
DEBUG - 2016-12-26 23:33:06 --> XSS Filtering completed
DEBUG - 2016-12-26 23:33:06 --> XSS Filtering completed
DEBUG - 2016-12-26 23:33:06 --> XSS Filtering completed
DEBUG - 2016-12-26 23:33:06 --> XSS Filtering completed
DEBUG - 2016-12-26 23:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:33:06 --> Language Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Loader Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:33:06 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:33:06 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:33:06 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:33:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:33:06 --> Session Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:33:06 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Session routines successfully run
ERROR - 2016-12-26 23:33:06 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:33:06 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:33:06 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:33:06 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:33:06 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Table Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Model Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Model Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:33:06 --> Model Class Initialized
DEBUG - 2016-12-26 23:33:06 --> Controller Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:33:09 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:33:09 --> Config Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:33:09 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:33:09 --> URI Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Router Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Output Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Security Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Input Class Initialized
DEBUG - 2016-12-26 23:33:09 --> XSS Filtering completed
DEBUG - 2016-12-26 23:33:09 --> XSS Filtering completed
DEBUG - 2016-12-26 23:33:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:33:09 --> Language Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Loader Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:33:09 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:33:09 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:33:09 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:33:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:33:09 --> Session Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:33:09 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Session routines successfully run
ERROR - 2016-12-26 23:33:09 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:33:09 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:33:09 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:33:09 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:33:09 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Table Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Model Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Model Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:33:09 --> Model Class Initialized
DEBUG - 2016-12-26 23:33:09 --> Controller Class Initialized
DEBUG - 2016-12-26 23:33:12 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:33:12 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-26 23:33:12 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-26 23:33:12 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:33:12 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 23:33:12 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-26 23:33:12 --> File loaded: application/views/alumni_view_files/single.php
DEBUG - 2016-12-26 23:33:12 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-26 23:33:12 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:33:12 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:33:12 --> Final output sent to browser
DEBUG - 2016-12-26 23:33:12 --> Total execution time: 2.9472
DEBUG - 2016-12-26 23:33:12 --> Config Class Initialized
DEBUG - 2016-12-26 23:33:12 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:33:12 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:33:12 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:33:12 --> URI Class Initialized
DEBUG - 2016-12-26 23:33:12 --> Router Class Initialized
ERROR - 2016-12-26 23:33:12 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:33:18 --> Config Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:33:18 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:33:18 --> URI Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Router Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Output Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Security Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Input Class Initialized
DEBUG - 2016-12-26 23:33:18 --> XSS Filtering completed
DEBUG - 2016-12-26 23:33:18 --> XSS Filtering completed
DEBUG - 2016-12-26 23:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:33:18 --> Language Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Loader Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:33:18 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:33:18 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:33:18 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:33:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:33:18 --> Session Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:33:18 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Session routines successfully run
ERROR - 2016-12-26 23:33:18 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:33:18 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:33:18 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:33:18 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:33:18 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Table Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Model Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Model Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:33:18 --> Model Class Initialized
DEBUG - 2016-12-26 23:33:18 --> Controller Class Initialized
DEBUG - 2016-12-26 23:33:21 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:33:21 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:33:21 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:33:21 --> File loaded: application/views/includes/header.php
ERROR - 2016-12-26 23:33:21 --> Could not find the language line "id"
DEBUG - 2016-12-26 23:33:21 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 23:33:21 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:33:21 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:33:21 --> Final output sent to browser
DEBUG - 2016-12-26 23:33:21 --> Total execution time: 3.0352
DEBUG - 2016-12-26 23:33:21 --> Config Class Initialized
DEBUG - 2016-12-26 23:33:21 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:33:21 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:33:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:33:21 --> URI Class Initialized
DEBUG - 2016-12-26 23:33:21 --> Router Class Initialized
ERROR - 2016-12-26 23:33:21 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:34:52 --> Config Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:34:52 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:34:52 --> URI Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Router Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Output Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Security Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Input Class Initialized
DEBUG - 2016-12-26 23:34:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:34:52 --> XSS Filtering completed
DEBUG - 2016-12-26 23:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:34:52 --> Language Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Loader Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:34:52 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:34:52 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:34:52 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:34:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:34:52 --> Session Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:34:52 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Session routines successfully run
ERROR - 2016-12-26 23:34:52 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:34:52 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:34:52 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:34:52 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:34:52 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Table Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Model Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Model Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:34:52 --> Model Class Initialized
DEBUG - 2016-12-26 23:34:52 --> Controller Class Initialized
DEBUG - 2016-12-26 23:34:54 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:34:54 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:34:54 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:34:54 --> File loaded: application/views/includes/header.php
ERROR - 2016-12-26 23:34:54 --> Could not find the language line "id"
DEBUG - 2016-12-26 23:34:54 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 23:34:54 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:34:54 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:34:54 --> Final output sent to browser
DEBUG - 2016-12-26 23:34:54 --> Total execution time: 2.7392
DEBUG - 2016-12-26 23:34:54 --> Config Class Initialized
DEBUG - 2016-12-26 23:34:54 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:34:54 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:34:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:34:54 --> URI Class Initialized
DEBUG - 2016-12-26 23:34:54 --> Router Class Initialized
ERROR - 2016-12-26 23:34:54 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:35:05 --> Config Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:35:05 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:35:05 --> URI Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Router Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Output Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Security Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Input Class Initialized
DEBUG - 2016-12-26 23:35:05 --> XSS Filtering completed
DEBUG - 2016-12-26 23:35:05 --> XSS Filtering completed
DEBUG - 2016-12-26 23:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:35:05 --> Language Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Loader Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:35:05 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:35:05 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:35:05 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:35:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:35:05 --> Session Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:35:05 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Session routines successfully run
ERROR - 2016-12-26 23:35:05 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:35:05 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:35:05 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:35:05 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:35:05 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Table Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Model Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Model Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:35:05 --> Model Class Initialized
DEBUG - 2016-12-26 23:35:05 --> Controller Class Initialized
DEBUG - 2016-12-26 23:35:07 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:35:07 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:35:07 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:35:07 --> File loaded: application/views/includes/header.php
ERROR - 2016-12-26 23:35:07 --> Could not find the language line "id"
DEBUG - 2016-12-26 23:35:07 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 23:35:07 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:35:07 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:35:07 --> Final output sent to browser
DEBUG - 2016-12-26 23:35:07 --> Total execution time: 2.2991
DEBUG - 2016-12-26 23:35:07 --> Config Class Initialized
DEBUG - 2016-12-26 23:35:07 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:35:07 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:35:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:35:07 --> URI Class Initialized
DEBUG - 2016-12-26 23:35:07 --> Router Class Initialized
ERROR - 2016-12-26 23:35:07 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:35:48 --> Config Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:35:48 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:35:48 --> URI Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Router Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Output Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Security Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Input Class Initialized
DEBUG - 2016-12-26 23:35:48 --> XSS Filtering completed
DEBUG - 2016-12-26 23:35:48 --> XSS Filtering completed
DEBUG - 2016-12-26 23:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:35:48 --> Language Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Loader Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:35:48 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:35:48 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:35:48 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:35:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:35:48 --> Session Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:35:48 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Session routines successfully run
ERROR - 2016-12-26 23:35:48 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:35:48 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:35:48 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:35:48 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:35:48 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Table Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Model Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Model Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:35:48 --> Model Class Initialized
DEBUG - 2016-12-26 23:35:48 --> Controller Class Initialized
DEBUG - 2016-12-26 23:35:51 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:35:51 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:35:51 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:35:51 --> File loaded: application/views/includes/header.php
ERROR - 2016-12-26 23:35:51 --> Could not find the language line "id"
DEBUG - 2016-12-26 23:35:51 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 23:35:51 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:35:51 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:35:51 --> Final output sent to browser
DEBUG - 2016-12-26 23:35:51 --> Total execution time: 2.4981
DEBUG - 2016-12-26 23:35:51 --> Config Class Initialized
DEBUG - 2016-12-26 23:35:51 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:35:51 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:35:51 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:35:51 --> URI Class Initialized
DEBUG - 2016-12-26 23:35:51 --> Router Class Initialized
ERROR - 2016-12-26 23:35:51 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:38:15 --> Config Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:38:15 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:38:15 --> URI Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Router Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Output Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Security Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Input Class Initialized
DEBUG - 2016-12-26 23:38:15 --> XSS Filtering completed
DEBUG - 2016-12-26 23:38:15 --> XSS Filtering completed
DEBUG - 2016-12-26 23:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:38:15 --> Language Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Loader Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:38:15 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:38:15 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:38:15 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:38:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:38:15 --> Session Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:38:15 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Session routines successfully run
ERROR - 2016-12-26 23:38:15 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:38:15 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:38:15 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:38:15 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:38:15 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Table Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Model Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Model Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:38:15 --> Model Class Initialized
DEBUG - 2016-12-26 23:38:15 --> Controller Class Initialized
DEBUG - 2016-12-26 23:38:17 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:38:17 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:38:17 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:38:17 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 23:38:17 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 23:38:17 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:38:17 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:38:17 --> Final output sent to browser
DEBUG - 2016-12-26 23:38:17 --> Total execution time: 2.3261
DEBUG - 2016-12-26 23:38:17 --> Config Class Initialized
DEBUG - 2016-12-26 23:38:17 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:38:17 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:38:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:38:17 --> URI Class Initialized
DEBUG - 2016-12-26 23:38:17 --> Router Class Initialized
ERROR - 2016-12-26 23:38:17 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:38:17 --> Config Class Initialized
DEBUG - 2016-12-26 23:38:17 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:38:17 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:38:17 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:38:17 --> URI Class Initialized
DEBUG - 2016-12-26 23:38:17 --> Router Class Initialized
ERROR - 2016-12-26 23:38:17 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:38:38 --> Config Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:38:38 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:38:38 --> URI Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Router Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Output Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Security Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Input Class Initialized
DEBUG - 2016-12-26 23:38:38 --> XSS Filtering completed
DEBUG - 2016-12-26 23:38:38 --> XSS Filtering completed
DEBUG - 2016-12-26 23:38:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:38:38 --> Language Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Loader Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:38:38 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:38:38 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:38:38 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:38:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:38:38 --> Session Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:38:38 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Session routines successfully run
ERROR - 2016-12-26 23:38:38 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:38:38 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:38:38 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:38:38 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:38:38 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Table Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Model Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Model Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:38:38 --> Model Class Initialized
DEBUG - 2016-12-26 23:38:38 --> Controller Class Initialized
DEBUG - 2016-12-26 23:38:40 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:38:40 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:38:40 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:38:40 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 23:38:40 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 23:38:40 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:38:40 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:38:40 --> Final output sent to browser
DEBUG - 2016-12-26 23:38:40 --> Total execution time: 2.4781
DEBUG - 2016-12-26 23:38:40 --> Config Class Initialized
DEBUG - 2016-12-26 23:38:40 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:38:40 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:38:40 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:38:40 --> URI Class Initialized
DEBUG - 2016-12-26 23:38:40 --> Router Class Initialized
ERROR - 2016-12-26 23:38:40 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:38:42 --> Config Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:38:42 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:38:42 --> URI Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Router Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Output Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Security Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Input Class Initialized
DEBUG - 2016-12-26 23:38:42 --> XSS Filtering completed
DEBUG - 2016-12-26 23:38:42 --> XSS Filtering completed
DEBUG - 2016-12-26 23:38:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:38:42 --> Language Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Loader Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:38:42 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:38:42 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:38:42 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:38:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:38:42 --> Session Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:38:42 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Session routines successfully run
ERROR - 2016-12-26 23:38:42 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:38:42 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:38:42 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:38:42 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:38:42 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Table Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Model Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Model Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:38:42 --> Model Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Controller Class Initialized
DEBUG - 2016-12-26 23:38:42 --> Config Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:38:43 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:38:43 --> URI Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Router Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Output Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Security Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Input Class Initialized
DEBUG - 2016-12-26 23:38:43 --> XSS Filtering completed
DEBUG - 2016-12-26 23:38:43 --> XSS Filtering completed
DEBUG - 2016-12-26 23:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:38:43 --> Language Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Loader Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:38:43 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:38:43 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:38:43 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:38:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:38:43 --> Session Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:38:43 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Session routines successfully run
ERROR - 2016-12-26 23:38:43 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:38:43 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:38:43 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:38:43 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:38:43 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Table Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Model Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Model Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:38:43 --> Model Class Initialized
DEBUG - 2016-12-26 23:38:43 --> Controller Class Initialized
DEBUG - 2016-12-26 23:38:45 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:38:45 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:38:45 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:38:45 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:38:45 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:38:45 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:38:45 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 23:38:45 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 23:38:45 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 23:38:45 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 23:38:45 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:38:45 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:38:45 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:38:45 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:38:45 --> Final output sent to browser
DEBUG - 2016-12-26 23:38:45 --> Final output sent to browser
DEBUG - 2016-12-26 23:38:45 --> Total execution time: 2.2021
DEBUG - 2016-12-26 23:38:45 --> Total execution time: 2.4921
DEBUG - 2016-12-26 23:38:45 --> Config Class Initialized
DEBUG - 2016-12-26 23:38:45 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:38:45 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:38:45 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:38:45 --> URI Class Initialized
DEBUG - 2016-12-26 23:38:45 --> Router Class Initialized
ERROR - 2016-12-26 23:38:45 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:38:45 --> Config Class Initialized
DEBUG - 2016-12-26 23:38:45 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:38:45 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:38:45 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:38:45 --> URI Class Initialized
DEBUG - 2016-12-26 23:38:45 --> Router Class Initialized
ERROR - 2016-12-26 23:38:45 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:42:49 --> Config Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:42:49 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:42:49 --> URI Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Router Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Output Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Security Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Input Class Initialized
DEBUG - 2016-12-26 23:42:49 --> XSS Filtering completed
DEBUG - 2016-12-26 23:42:49 --> XSS Filtering completed
DEBUG - 2016-12-26 23:42:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:42:49 --> Language Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Loader Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:42:49 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:42:49 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:42:49 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:42:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:42:49 --> Session Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:42:49 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Session routines successfully run
ERROR - 2016-12-26 23:42:49 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:42:49 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:42:49 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:42:49 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:42:49 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Table Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Model Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Model Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:42:49 --> Model Class Initialized
DEBUG - 2016-12-26 23:42:49 --> Controller Class Initialized
DEBUG - 2016-12-26 23:42:51 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:42:51 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:42:52 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:42:52 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 23:42:52 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 23:42:52 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:42:52 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:42:52 --> Final output sent to browser
DEBUG - 2016-12-26 23:42:52 --> Total execution time: 2.7532
DEBUG - 2016-12-26 23:42:52 --> Config Class Initialized
DEBUG - 2016-12-26 23:42:52 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:42:52 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:42:52 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:42:52 --> URI Class Initialized
DEBUG - 2016-12-26 23:42:52 --> Router Class Initialized
ERROR - 2016-12-26 23:42:52 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:45:10 --> Config Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:45:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:45:10 --> URI Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Router Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Output Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Security Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Input Class Initialized
DEBUG - 2016-12-26 23:45:10 --> XSS Filtering completed
DEBUG - 2016-12-26 23:45:10 --> XSS Filtering completed
DEBUG - 2016-12-26 23:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:45:10 --> Language Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Loader Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:45:10 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:45:10 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:45:10 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:45:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:45:10 --> Session Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:45:10 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Session routines successfully run
ERROR - 2016-12-26 23:45:10 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:45:10 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:45:10 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:45:10 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:45:10 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Table Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Model Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Model Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:45:10 --> Model Class Initialized
DEBUG - 2016-12-26 23:45:10 --> Controller Class Initialized
DEBUG - 2016-12-26 23:45:13 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:45:13 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:45:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:45:13 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 23:45:13 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 23:45:13 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:45:13 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:45:13 --> Final output sent to browser
DEBUG - 2016-12-26 23:45:13 --> Total execution time: 2.3641
DEBUG - 2016-12-26 23:45:13 --> Config Class Initialized
DEBUG - 2016-12-26 23:45:13 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:45:13 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:45:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:45:13 --> URI Class Initialized
DEBUG - 2016-12-26 23:45:13 --> Router Class Initialized
ERROR - 2016-12-26 23:45:13 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:45:41 --> Config Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:45:41 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:45:41 --> URI Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Router Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Output Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Security Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Input Class Initialized
DEBUG - 2016-12-26 23:45:41 --> XSS Filtering completed
DEBUG - 2016-12-26 23:45:41 --> XSS Filtering completed
DEBUG - 2016-12-26 23:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:45:41 --> Language Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Loader Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:45:41 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:45:41 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:45:41 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:45:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:45:41 --> Session Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:45:41 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Session routines successfully run
ERROR - 2016-12-26 23:45:41 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:45:41 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:45:41 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:45:41 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:45:41 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Table Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Model Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Model Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:45:41 --> Model Class Initialized
DEBUG - 2016-12-26 23:45:41 --> Controller Class Initialized
DEBUG - 2016-12-26 23:45:43 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:45:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:45:43 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:45:43 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 23:45:43 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 23:45:43 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:45:43 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:45:43 --> Final output sent to browser
DEBUG - 2016-12-26 23:45:43 --> Total execution time: 2.3491
DEBUG - 2016-12-26 23:45:43 --> Config Class Initialized
DEBUG - 2016-12-26 23:45:43 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:45:43 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:45:43 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:45:43 --> URI Class Initialized
DEBUG - 2016-12-26 23:45:43 --> Router Class Initialized
ERROR - 2016-12-26 23:45:43 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:45:43 --> Config Class Initialized
DEBUG - 2016-12-26 23:45:43 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:45:43 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:45:43 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:45:43 --> URI Class Initialized
DEBUG - 2016-12-26 23:45:43 --> Router Class Initialized
ERROR - 2016-12-26 23:45:43 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:48:09 --> Config Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:48:09 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:48:09 --> URI Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Router Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Output Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Security Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Input Class Initialized
DEBUG - 2016-12-26 23:48:09 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:09 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:48:09 --> Language Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Loader Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:48:09 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:48:09 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:48:09 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:48:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:48:09 --> Session Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:48:09 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Session routines successfully run
ERROR - 2016-12-26 23:48:09 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:48:09 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:48:09 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:48:09 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:48:09 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Table Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Model Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Model Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:48:09 --> Model Class Initialized
DEBUG - 2016-12-26 23:48:09 --> Controller Class Initialized
DEBUG - 2016-12-26 23:48:12 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:48:12 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:48:12 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:48:12 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 23:48:12 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 23:48:12 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:48:12 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:48:12 --> Final output sent to browser
DEBUG - 2016-12-26 23:48:12 --> Total execution time: 3.1382
DEBUG - 2016-12-26 23:48:13 --> Config Class Initialized
DEBUG - 2016-12-26 23:48:13 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:48:13 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:48:13 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:48:13 --> URI Class Initialized
DEBUG - 2016-12-26 23:48:13 --> Router Class Initialized
ERROR - 2016-12-26 23:48:13 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:48:21 --> Config Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:48:21 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:48:21 --> URI Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Router Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Output Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Security Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Input Class Initialized
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:48:21 --> Language Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Loader Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:48:21 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:48:21 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:48:21 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:48:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:48:21 --> Session Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:48:21 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Session routines successfully run
ERROR - 2016-12-26 23:48:21 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:48:21 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:48:21 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:48:21 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:48:21 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Table Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Model Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Model Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:48:21 --> Model Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Controller Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:48:21 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:48:21 --> Model Class Initialized
DEBUG - 2016-12-26 23:48:21 --> Upload Class Initialized
ERROR - 2016-12-26 23:48:22 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\me\includes\header.php 6
DEBUG - 2016-12-26 23:48:22 --> File loaded: application/views/me/includes/header.php
DEBUG - 2016-12-26 23:48:22 --> File loaded: application/views/me/index2.php
DEBUG - 2016-12-26 23:48:22 --> File loaded: application/views/me/includes/footer.php
DEBUG - 2016-12-26 23:48:22 --> File loaded: application/views/me/includes/template.php
DEBUG - 2016-12-26 23:48:22 --> Final output sent to browser
DEBUG - 2016-12-26 23:48:22 --> Total execution time: 0.5620
DEBUG - 2016-12-26 23:48:22 --> Config Class Initialized
DEBUG - 2016-12-26 23:48:22 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:48:22 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:48:22 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:48:22 --> URI Class Initialized
DEBUG - 2016-12-26 23:48:22 --> Router Class Initialized
ERROR - 2016-12-26 23:48:22 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:48:51 --> Config Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:48:51 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:48:51 --> URI Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Router Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Output Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Security Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Input Class Initialized
DEBUG - 2016-12-26 23:48:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:51 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:48:51 --> Language Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Loader Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:48:51 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:48:51 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:48:51 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:48:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:48:51 --> Session Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:48:51 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Session routines successfully run
ERROR - 2016-12-26 23:48:51 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:48:51 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:48:51 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:48:51 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:48:51 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Table Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Model Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Model Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:48:51 --> Model Class Initialized
DEBUG - 2016-12-26 23:48:51 --> Controller Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:48:54 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:48:54 --> Config Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:48:54 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:48:54 --> URI Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Router Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Output Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Security Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Input Class Initialized
DEBUG - 2016-12-26 23:48:54 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:54 --> XSS Filtering completed
DEBUG - 2016-12-26 23:48:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:48:54 --> Language Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Loader Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:48:54 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:48:54 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:48:54 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:48:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:48:54 --> Session Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:48:54 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Session routines successfully run
ERROR - 2016-12-26 23:48:54 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:48:54 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:48:54 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:48:54 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:48:54 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Table Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Model Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Model Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:48:54 --> Model Class Initialized
DEBUG - 2016-12-26 23:48:54 --> Controller Class Initialized
DEBUG - 2016-12-26 23:48:57 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:48:57 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-12-26 23:48:57 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-12-26 23:48:57 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:48:57 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 23:48:57 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-12-26 23:48:57 --> File loaded: application/views/alumni_view_files/single.php
DEBUG - 2016-12-26 23:48:57 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-12-26 23:48:57 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:48:57 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:48:57 --> Final output sent to browser
DEBUG - 2016-12-26 23:48:57 --> Total execution time: 3.0332
DEBUG - 2016-12-26 23:48:57 --> Config Class Initialized
DEBUG - 2016-12-26 23:48:57 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:48:57 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:48:57 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:48:57 --> URI Class Initialized
DEBUG - 2016-12-26 23:48:57 --> Router Class Initialized
ERROR - 2016-12-26 23:48:57 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:49:07 --> Config Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:49:07 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:49:07 --> URI Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Router Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Output Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Security Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Input Class Initialized
DEBUG - 2016-12-26 23:49:07 --> XSS Filtering completed
DEBUG - 2016-12-26 23:49:07 --> XSS Filtering completed
DEBUG - 2016-12-26 23:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:49:07 --> Language Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Loader Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:49:07 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:49:07 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:49:07 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:49:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:49:07 --> Session Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:49:07 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Session routines successfully run
ERROR - 2016-12-26 23:49:07 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:49:07 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:49:07 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:49:07 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:49:07 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Table Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Model Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Model Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:49:07 --> Model Class Initialized
DEBUG - 2016-12-26 23:49:07 --> Controller Class Initialized
DEBUG - 2016-12-26 23:49:10 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:49:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:49:10 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:49:10 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 23:49:10 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 23:49:10 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:49:10 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:49:10 --> Final output sent to browser
DEBUG - 2016-12-26 23:49:10 --> Total execution time: 2.8632
DEBUG - 2016-12-26 23:49:10 --> Config Class Initialized
DEBUG - 2016-12-26 23:49:10 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:49:10 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:49:10 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:49:10 --> URI Class Initialized
DEBUG - 2016-12-26 23:49:10 --> Router Class Initialized
ERROR - 2016-12-26 23:49:10 --> 404 Page Not Found --> js
DEBUG - 2016-12-26 23:49:16 --> Config Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:49:16 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:49:16 --> URI Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Router Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Output Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Security Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Input Class Initialized
DEBUG - 2016-12-26 23:49:16 --> XSS Filtering completed
DEBUG - 2016-12-26 23:49:16 --> XSS Filtering completed
DEBUG - 2016-12-26 23:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-12-26 23:49:16 --> Language Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Loader Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Helper loaded: url_helper
DEBUG - 2016-12-26 23:49:16 --> Helper loaded: form_helper
DEBUG - 2016-12-26 23:49:16 --> Helper loaded: func_helper
DEBUG - 2016-12-26 23:49:16 --> Database Driver Class Initialized
ERROR - 2016-12-26 23:49:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-12-26 23:49:16 --> Session Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Helper loaded: string_helper
DEBUG - 2016-12-26 23:49:16 --> Encrypt Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Session routines successfully run
ERROR - 2016-12-26 23:49:16 --> Could not find the language line "first_link"
ERROR - 2016-12-26 23:49:16 --> Could not find the language line "last_link"
ERROR - 2016-12-26 23:49:16 --> Could not find the language line "next_link"
ERROR - 2016-12-26 23:49:16 --> Could not find the language line "prev_link"
DEBUG - 2016-12-26 23:49:16 --> Pagination Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Table Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Model Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Model Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Helper loaded: file_helper
DEBUG - 2016-12-26 23:49:16 --> Model Class Initialized
DEBUG - 2016-12-26 23:49:16 --> Controller Class Initialized
DEBUG - 2016-12-26 23:49:18 --> Helper loaded: language_helper
DEBUG - 2016-12-26 23:49:18 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-12-26 23:49:19 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-12-26 23:49:19 --> File loaded: application/views/includes/header.php
DEBUG - 2016-12-26 23:49:19 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-12-26 23:49:19 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-12-26 23:49:19 --> File loaded: application/views/includes/template.php
DEBUG - 2016-12-26 23:49:19 --> Final output sent to browser
DEBUG - 2016-12-26 23:49:19 --> Total execution time: 2.6041
DEBUG - 2016-12-26 23:49:19 --> Config Class Initialized
DEBUG - 2016-12-26 23:49:19 --> Hooks Class Initialized
DEBUG - 2016-12-26 23:49:19 --> Utf8 Class Initialized
DEBUG - 2016-12-26 23:49:19 --> UTF-8 Support Enabled
DEBUG - 2016-12-26 23:49:19 --> URI Class Initialized
DEBUG - 2016-12-26 23:49:19 --> Router Class Initialized
ERROR - 2016-12-26 23:49:19 --> 404 Page Not Found --> js
