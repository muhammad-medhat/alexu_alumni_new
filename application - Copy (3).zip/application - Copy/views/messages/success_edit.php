<?php

?>
<div class='success'>
<h1><?=$this->lang->line('done_editing');?></h1>
<p> <?=$this->lang->line('alumni_name') .$alumni->name ?></p>
</div>
