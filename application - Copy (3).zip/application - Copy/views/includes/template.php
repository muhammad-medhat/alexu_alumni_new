<?php $this->load->view('includes/header'); ?>

<div id="main_content">
<?php $this->load->view($main_content); ?>
</div>


<?php $this->load->view('includes/footer'); ?>
