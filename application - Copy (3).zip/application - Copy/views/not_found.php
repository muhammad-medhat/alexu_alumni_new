<div>
  <h1><?=$this->lang->line('not_found')?></h1>
<!--  <p><?=$this->lang->line('not_found_message')?></p>-->
</div>
