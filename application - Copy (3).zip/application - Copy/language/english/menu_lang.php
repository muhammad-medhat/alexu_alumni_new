<?php
#########################
##   English 
#########################

$lang['alumni_list']		= "Alumni";
$lang['registration']		= "Register";
$lang['login']		= "Login";



/* End of file form_validation_lang.php */
/* Location: ./system/language/english/form_validation_lang.php */
