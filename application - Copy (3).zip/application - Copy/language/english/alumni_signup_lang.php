<?php
#############################
// English Translation
#############################
$lang['academic_info']		= "Academic Information";


$lang['error_discussion_request']		= "كلمات الطلب";

$lang['error_insert_year']		= "السنة";
$lang['error_insert_title']		= "عنوان البحث";
$lang['error_insert_metakey']		= "الكلمات المفتاحية";
$lang['error_insert_authors']		= "المؤالفين";



/* End of file form_validation_lang.php */
/* Location: ./system/language/english/form_validation_lang.php */
