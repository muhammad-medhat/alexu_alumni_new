<?php
#############################
// English Translation
#############################
$lang['graduation_year']		= "Graduation Year";
$lang['graduation_faculty']		= "Faculty";
$lang['after_year']		= "After Year";
$lang['at_year']      = "At Year" ;
$lang['before_year']  = "Before Year";
$lang['show_results']  = "Show Results";

$lang['alumni']  = "Alumni";







$lang['error_discussion_request']		= "كلمات الطلب";

$lang['error_insert_year']		= "السنة";
$lang['error_insert_title']		= "عنوان البحث";
$lang['error_insert_metakey']		= "الكلمات المفتاحية";
$lang['error_insert_authors']		= "المؤالفين";
#####################
#####################
#####            ####
#####  HOME PAGE ####
#####            ####
#####################
#####################
$lang['name'] = 'Name';
$lang['faculty'] = 'Faculty';
$lang['scientific_degree'] = 'Scientific Degree';
$lang['graduation_year'] = 'Graduation Year';



/* End of file form_validation_lang.php */
/* Location: ./system/language/english/site_lang.php */

