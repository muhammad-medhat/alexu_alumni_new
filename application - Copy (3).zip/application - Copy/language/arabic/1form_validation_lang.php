<?php 
  $lang['specs'] = "شسيب";
  $lang['error_search_specid'] = "لم يتم اختيار مجال البحث";
  $lang['error_search_title'] = "لم يتم اختيار مجال البحث";
?>
