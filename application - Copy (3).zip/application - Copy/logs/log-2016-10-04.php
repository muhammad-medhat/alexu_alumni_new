<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-10-04 15:40:03 --> Config Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Hooks Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Utf8 Class Initialized
DEBUG - 2016-10-04 15:40:03 --> UTF-8 Support Enabled
DEBUG - 2016-10-04 15:40:03 --> URI Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Router Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Output Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Security Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Input Class Initialized
DEBUG - 2016-10-04 15:40:03 --> XSS Filtering completed
DEBUG - 2016-10-04 15:40:03 --> XSS Filtering completed
DEBUG - 2016-10-04 15:40:03 --> XSS Filtering completed
DEBUG - 2016-10-04 15:40:03 --> XSS Filtering completed
DEBUG - 2016-10-04 15:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-04 15:40:03 --> Language Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Loader Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Helper loaded: url_helper
DEBUG - 2016-10-04 15:40:03 --> Helper loaded: form_helper
DEBUG - 2016-10-04 15:40:03 --> Helper loaded: func_helper
DEBUG - 2016-10-04 15:40:03 --> Database Driver Class Initialized
ERROR - 2016-10-04 15:40:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-10-04 15:40:03 --> Session Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Helper loaded: string_helper
DEBUG - 2016-10-04 15:40:03 --> Encrypt Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Session routines successfully run
ERROR - 2016-10-04 15:40:03 --> Could not find the language line "first_link"
ERROR - 2016-10-04 15:40:03 --> Could not find the language line "last_link"
ERROR - 2016-10-04 15:40:03 --> Could not find the language line "next_link"
ERROR - 2016-10-04 15:40:03 --> Could not find the language line "prev_link"
DEBUG - 2016-10-04 15:40:03 --> Pagination Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Table Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Model Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Model Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Helper loaded: file_helper
DEBUG - 2016-10-04 15:40:03 --> Model Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Controller Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Form Validation Class Initialized
DEBUG - 2016-10-04 15:40:03 --> Helper loaded: language_helper
DEBUG - 2016-10-04 15:40:03 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-10-04 15:40:06 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-10-04 15:40:06 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-10-04 15:40:06 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-10-04 15:40:06 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-10-04 15:40:06 --> File loaded: application/views/admin_view.php
DEBUG - 2016-10-04 15:40:06 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-10-04 15:40:06 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-10-04 15:40:06 --> Final output sent to browser
DEBUG - 2016-10-04 15:40:06 --> Total execution time: 2.8652
DEBUG - 2016-10-04 15:40:06 --> Config Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Hooks Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Config Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Utf8 Class Initialized
DEBUG - 2016-10-04 15:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-10-04 15:40:06 --> URI Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Config Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Hooks Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Router Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Config Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Utf8 Class Initialized
DEBUG - 2016-10-04 15:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-10-04 15:40:06 --> Hooks Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Hooks Class Initialized
ERROR - 2016-10-04 15:40:06 --> 404 Page Not Found --> application
DEBUG - 2016-10-04 15:40:06 --> URI Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Utf8 Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Router Class Initialized
DEBUG - 2016-10-04 15:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-10-04 15:40:06 --> Utf8 Class Initialized
DEBUG - 2016-10-04 15:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-10-04 15:40:06 --> URI Class Initialized
ERROR - 2016-10-04 15:40:06 --> 404 Page Not Found --> application
DEBUG - 2016-10-04 15:40:06 --> URI Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Router Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Router Class Initialized
ERROR - 2016-10-04 15:40:06 --> 404 Page Not Found --> application
ERROR - 2016-10-04 15:40:06 --> 404 Page Not Found --> application
DEBUG - 2016-10-04 15:40:06 --> Config Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Config Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Hooks Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Hooks Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Config Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Utf8 Class Initialized
DEBUG - 2016-10-04 15:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-10-04 15:40:06 --> Hooks Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Config Class Initialized
DEBUG - 2016-10-04 15:40:06 --> URI Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Hooks Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Utf8 Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Utf8 Class Initialized
DEBUG - 2016-10-04 15:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-10-04 15:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-10-04 15:40:06 --> Router Class Initialized
DEBUG - 2016-10-04 15:40:06 --> URI Class Initialized
DEBUG - 2016-10-04 15:40:06 --> URI Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Utf8 Class Initialized
DEBUG - 2016-10-04 15:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-10-04 15:40:06 --> URI Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Router Class Initialized
DEBUG - 2016-10-04 15:40:06 --> Router Class Initialized
ERROR - 2016-10-04 15:40:06 --> 404 Page Not Found --> application
DEBUG - 2016-10-04 15:40:06 --> Router Class Initialized
ERROR - 2016-10-04 15:40:06 --> 404 Page Not Found --> application
ERROR - 2016-10-04 15:40:06 --> 404 Page Not Found --> application
ERROR - 2016-10-04 15:40:06 --> 404 Page Not Found --> application
DEBUG - 2016-10-04 18:55:40 --> Config Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Hooks Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Utf8 Class Initialized
DEBUG - 2016-10-04 18:55:40 --> UTF-8 Support Enabled
DEBUG - 2016-10-04 18:55:40 --> URI Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Router Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Output Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Security Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Input Class Initialized
DEBUG - 2016-10-04 18:55:40 --> XSS Filtering completed
DEBUG - 2016-10-04 18:55:40 --> XSS Filtering completed
DEBUG - 2016-10-04 18:55:40 --> XSS Filtering completed
DEBUG - 2016-10-04 18:55:40 --> XSS Filtering completed
DEBUG - 2016-10-04 18:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-04 18:55:40 --> Language Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Loader Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Helper loaded: url_helper
DEBUG - 2016-10-04 18:55:40 --> Helper loaded: form_helper
DEBUG - 2016-10-04 18:55:40 --> Helper loaded: func_helper
DEBUG - 2016-10-04 18:55:40 --> Database Driver Class Initialized
ERROR - 2016-10-04 18:55:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-10-04 18:55:40 --> Session Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Helper loaded: string_helper
DEBUG - 2016-10-04 18:55:40 --> Encrypt Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Session routines successfully run
ERROR - 2016-10-04 18:55:40 --> Could not find the language line "first_link"
ERROR - 2016-10-04 18:55:40 --> Could not find the language line "last_link"
ERROR - 2016-10-04 18:55:40 --> Could not find the language line "next_link"
ERROR - 2016-10-04 18:55:40 --> Could not find the language line "prev_link"
DEBUG - 2016-10-04 18:55:40 --> Pagination Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Table Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Model Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Model Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Helper loaded: file_helper
DEBUG - 2016-10-04 18:55:40 --> Model Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Controller Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Form Validation Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Config Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Hooks Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Utf8 Class Initialized
DEBUG - 2016-10-04 18:55:40 --> UTF-8 Support Enabled
DEBUG - 2016-10-04 18:55:40 --> URI Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Router Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Output Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Security Class Initialized
DEBUG - 2016-10-04 18:55:40 --> Input Class Initialized
DEBUG - 2016-10-04 18:55:40 --> XSS Filtering completed
DEBUG - 2016-10-04 18:55:40 --> XSS Filtering completed
DEBUG - 2016-10-04 18:55:40 --> XSS Filtering completed
DEBUG - 2016-10-04 18:55:40 --> XSS Filtering completed
DEBUG - 2016-10-04 18:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-10-04 18:55:40 --> Language Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Loader Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Helper loaded: url_helper
DEBUG - 2016-10-04 18:55:41 --> Helper loaded: form_helper
DEBUG - 2016-10-04 18:55:41 --> Helper loaded: func_helper
DEBUG - 2016-10-04 18:55:41 --> Database Driver Class Initialized
ERROR - 2016-10-04 18:55:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-10-04 18:55:41 --> Session Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Helper loaded: string_helper
DEBUG - 2016-10-04 18:55:41 --> Encrypt Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Session routines successfully run
ERROR - 2016-10-04 18:55:41 --> Could not find the language line "first_link"
ERROR - 2016-10-04 18:55:41 --> Could not find the language line "last_link"
ERROR - 2016-10-04 18:55:41 --> Could not find the language line "next_link"
ERROR - 2016-10-04 18:55:41 --> Could not find the language line "prev_link"
DEBUG - 2016-10-04 18:55:41 --> Pagination Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Table Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Model Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Model Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Helper loaded: file_helper
DEBUG - 2016-10-04 18:55:41 --> Model Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Controller Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Helper loaded: language_helper
DEBUG - 2016-10-04 18:55:41 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-10-04 18:55:41 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-10-04 18:55:41 --> File loaded: application/views/includes/header.php
DEBUG - 2016-10-04 18:55:41 --> File loaded: application/views/login_form.php
DEBUG - 2016-10-04 18:55:41 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-10-04 18:55:41 --> File loaded: application/views/includes/template.php
DEBUG - 2016-10-04 18:55:41 --> Final output sent to browser
DEBUG - 2016-10-04 18:55:41 --> Total execution time: 0.2190
DEBUG - 2016-10-04 18:55:41 --> Config Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Hooks Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Utf8 Class Initialized
DEBUG - 2016-10-04 18:55:41 --> UTF-8 Support Enabled
DEBUG - 2016-10-04 18:55:41 --> URI Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Router Class Initialized
ERROR - 2016-10-04 18:55:41 --> 404 Page Not Found --> js
DEBUG - 2016-10-04 18:55:41 --> Config Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Hooks Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Utf8 Class Initialized
DEBUG - 2016-10-04 18:55:41 --> UTF-8 Support Enabled
DEBUG - 2016-10-04 18:55:41 --> URI Class Initialized
DEBUG - 2016-10-04 18:55:41 --> Router Class Initialized
ERROR - 2016-10-04 18:55:41 --> 404 Page Not Found --> js
