<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-26 15:38:06 --> Config Class Initialized
DEBUG - 2016-09-26 15:38:06 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:38:06 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:38:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:38:06 --> URI Class Initialized
DEBUG - 2016-09-26 15:38:06 --> Router Class Initialized
DEBUG - 2016-09-26 15:38:06 --> No URI present. Default controller set.
DEBUG - 2016-09-26 15:38:06 --> Output Class Initialized
DEBUG - 2016-09-26 15:38:06 --> Security Class Initialized
DEBUG - 2016-09-26 15:38:06 --> Input Class Initialized
DEBUG - 2016-09-26 15:38:06 --> XSS Filtering completed
DEBUG - 2016-09-26 15:38:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 15:38:06 --> Language Class Initialized
DEBUG - 2016-09-26 15:38:06 --> Loader Class Initialized
DEBUG - 2016-09-26 15:38:06 --> Helper loaded: url_helper
DEBUG - 2016-09-26 15:38:06 --> Helper loaded: form_helper
DEBUG - 2016-09-26 15:38:06 --> Helper loaded: func_helper
DEBUG - 2016-09-26 15:38:06 --> Database Driver Class Initialized
ERROR - 2016-09-26 15:38:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 15:38:06 --> Session Class Initialized
DEBUG - 2016-09-26 15:38:06 --> Helper loaded: string_helper
DEBUG - 2016-09-26 15:38:06 --> Encrypt Class Initialized
DEBUG - 2016-09-26 15:38:06 --> A session cookie was not found.
DEBUG - 2016-09-26 15:38:06 --> Session routines successfully run
ERROR - 2016-09-26 15:38:06 --> Could not find the language line "first_link"
ERROR - 2016-09-26 15:38:06 --> Could not find the language line "last_link"
ERROR - 2016-09-26 15:38:06 --> Could not find the language line "next_link"
ERROR - 2016-09-26 15:38:06 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 15:38:06 --> Pagination Class Initialized
DEBUG - 2016-09-26 15:38:06 --> Table Class Initialized
DEBUG - 2016-09-26 15:38:06 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:06 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:06 --> Helper loaded: file_helper
DEBUG - 2016-09-26 15:38:06 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:06 --> Controller Class Initialized
DEBUG - 2016-09-26 15:38:09 --> Helper loaded: language_helper
DEBUG - 2016-09-26 15:38:09 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 15:38:11 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-26 15:38:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-26 15:38:13 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-26 15:38:13 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-26 15:38:13 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-26 15:38:13 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-26 15:38:13 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-26 15:38:13 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-26 15:38:13 --> Final output sent to browser
DEBUG - 2016-09-26 15:38:13 --> Total execution time: 6.9504
DEBUG - 2016-09-26 15:38:13 --> Config Class Initialized
DEBUG - 2016-09-26 15:38:13 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:38:13 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:38:13 --> URI Class Initialized
DEBUG - 2016-09-26 15:38:13 --> Router Class Initialized
ERROR - 2016-09-26 15:38:13 --> 404 Page Not Found --> js
DEBUG - 2016-09-26 15:38:13 --> Config Class Initialized
DEBUG - 2016-09-26 15:38:13 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:38:13 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:38:13 --> URI Class Initialized
DEBUG - 2016-09-26 15:38:13 --> Router Class Initialized
ERROR - 2016-09-26 15:38:13 --> 404 Page Not Found --> js
DEBUG - 2016-09-26 15:38:16 --> Config Class Initialized
DEBUG - 2016-09-26 15:38:16 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:38:16 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:38:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:38:16 --> URI Class Initialized
DEBUG - 2016-09-26 15:38:16 --> Router Class Initialized
DEBUG - 2016-09-26 15:38:16 --> Output Class Initialized
DEBUG - 2016-09-26 15:38:16 --> Security Class Initialized
DEBUG - 2016-09-26 15:38:16 --> Input Class Initialized
DEBUG - 2016-09-26 15:38:16 --> XSS Filtering completed
DEBUG - 2016-09-26 15:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 15:38:16 --> Language Class Initialized
DEBUG - 2016-09-26 15:38:16 --> Loader Class Initialized
DEBUG - 2016-09-26 15:38:17 --> Helper loaded: url_helper
DEBUG - 2016-09-26 15:38:17 --> Helper loaded: form_helper
DEBUG - 2016-09-26 15:38:17 --> Helper loaded: func_helper
DEBUG - 2016-09-26 15:38:17 --> Database Driver Class Initialized
ERROR - 2016-09-26 15:38:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 15:38:17 --> Session Class Initialized
DEBUG - 2016-09-26 15:38:17 --> Helper loaded: string_helper
DEBUG - 2016-09-26 15:38:17 --> Encrypt Class Initialized
DEBUG - 2016-09-26 15:38:17 --> Session routines successfully run
ERROR - 2016-09-26 15:38:17 --> Could not find the language line "first_link"
ERROR - 2016-09-26 15:38:17 --> Could not find the language line "last_link"
ERROR - 2016-09-26 15:38:17 --> Could not find the language line "next_link"
ERROR - 2016-09-26 15:38:17 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 15:38:17 --> Pagination Class Initialized
DEBUG - 2016-09-26 15:38:17 --> Table Class Initialized
DEBUG - 2016-09-26 15:38:17 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:17 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:17 --> Helper loaded: file_helper
DEBUG - 2016-09-26 15:38:17 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:17 --> Controller Class Initialized
DEBUG - 2016-09-26 15:38:17 --> Helper loaded: language_helper
DEBUG - 2016-09-26 15:38:17 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 15:38:17 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-26 15:38:17 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-26 15:38:17 --> File loaded: application/views/login_form.php
DEBUG - 2016-09-26 15:38:17 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-26 15:38:17 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-26 15:38:17 --> Final output sent to browser
DEBUG - 2016-09-26 15:38:17 --> Total execution time: 0.1240
DEBUG - 2016-09-26 15:38:17 --> Config Class Initialized
DEBUG - 2016-09-26 15:38:17 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:38:17 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:38:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:38:17 --> URI Class Initialized
DEBUG - 2016-09-26 15:38:17 --> Router Class Initialized
ERROR - 2016-09-26 15:38:17 --> 404 Page Not Found --> js
DEBUG - 2016-09-26 15:38:20 --> Config Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:38:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:38:20 --> URI Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Router Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Output Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Security Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Input Class Initialized
DEBUG - 2016-09-26 15:38:20 --> XSS Filtering completed
DEBUG - 2016-09-26 15:38:20 --> XSS Filtering completed
DEBUG - 2016-09-26 15:38:20 --> XSS Filtering completed
DEBUG - 2016-09-26 15:38:20 --> XSS Filtering completed
DEBUG - 2016-09-26 15:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 15:38:20 --> Language Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Loader Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Helper loaded: url_helper
DEBUG - 2016-09-26 15:38:20 --> Helper loaded: form_helper
DEBUG - 2016-09-26 15:38:20 --> Helper loaded: func_helper
DEBUG - 2016-09-26 15:38:20 --> Database Driver Class Initialized
ERROR - 2016-09-26 15:38:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 15:38:20 --> Session Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Helper loaded: string_helper
DEBUG - 2016-09-26 15:38:20 --> Encrypt Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Session routines successfully run
ERROR - 2016-09-26 15:38:20 --> Could not find the language line "first_link"
ERROR - 2016-09-26 15:38:20 --> Could not find the language line "last_link"
ERROR - 2016-09-26 15:38:20 --> Could not find the language line "next_link"
ERROR - 2016-09-26 15:38:20 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 15:38:20 --> Pagination Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Table Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Helper loaded: file_helper
DEBUG - 2016-09-26 15:38:20 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Controller Class Initialized
DEBUG - 2016-09-26 15:38:20 --> Helper loaded: language_helper
DEBUG - 2016-09-26 15:38:20 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 15:38:20 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Config Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:38:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:38:23 --> URI Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Router Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Output Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Security Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Input Class Initialized
DEBUG - 2016-09-26 15:38:23 --> XSS Filtering completed
DEBUG - 2016-09-26 15:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 15:38:23 --> Language Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Loader Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Helper loaded: url_helper
DEBUG - 2016-09-26 15:38:23 --> Helper loaded: form_helper
DEBUG - 2016-09-26 15:38:23 --> Helper loaded: func_helper
DEBUG - 2016-09-26 15:38:23 --> Database Driver Class Initialized
ERROR - 2016-09-26 15:38:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 15:38:23 --> Session Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Helper loaded: string_helper
DEBUG - 2016-09-26 15:38:23 --> Encrypt Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Session routines successfully run
ERROR - 2016-09-26 15:38:23 --> Could not find the language line "first_link"
ERROR - 2016-09-26 15:38:23 --> Could not find the language line "last_link"
ERROR - 2016-09-26 15:38:23 --> Could not find the language line "next_link"
ERROR - 2016-09-26 15:38:23 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 15:38:23 --> Pagination Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Table Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Helper loaded: file_helper
DEBUG - 2016-09-26 15:38:23 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Controller Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Form Validation Class Initialized
DEBUG - 2016-09-26 15:38:23 --> Helper loaded: language_helper
DEBUG - 2016-09-26 15:38:23 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 15:38:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-26 15:38:26 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-26 15:38:26 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-26 15:38:26 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-26 15:38:26 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-26 15:38:26 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-26 15:38:26 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-26 15:38:26 --> Final output sent to browser
DEBUG - 2016-09-26 15:38:26 --> Total execution time: 2.8022
DEBUG - 2016-09-26 15:38:26 --> Config Class Initialized
DEBUG - 2016-09-26 15:38:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:38:26 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:38:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:38:26 --> URI Class Initialized
DEBUG - 2016-09-26 15:38:26 --> Router Class Initialized
ERROR - 2016-09-26 15:38:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 15:38:26 --> Config Class Initialized
DEBUG - 2016-09-26 15:38:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:38:26 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:38:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:38:26 --> URI Class Initialized
DEBUG - 2016-09-26 15:38:26 --> Router Class Initialized
ERROR - 2016-09-26 15:38:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 15:38:26 --> Config Class Initialized
DEBUG - 2016-09-26 15:38:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:38:26 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:38:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:38:26 --> Config Class Initialized
DEBUG - 2016-09-26 15:38:26 --> URI Class Initialized
DEBUG - 2016-09-26 15:38:26 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:38:26 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:38:26 --> Router Class Initialized
DEBUG - 2016-09-26 15:38:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:38:26 --> URI Class Initialized
ERROR - 2016-09-26 15:38:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 15:38:26 --> Router Class Initialized
ERROR - 2016-09-26 15:38:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 15:38:41 --> Config Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:38:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:38:41 --> URI Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Router Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Output Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Security Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Input Class Initialized
DEBUG - 2016-09-26 15:38:41 --> XSS Filtering completed
DEBUG - 2016-09-26 15:38:41 --> XSS Filtering completed
DEBUG - 2016-09-26 15:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 15:38:41 --> Language Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Loader Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Helper loaded: url_helper
DEBUG - 2016-09-26 15:38:41 --> Helper loaded: form_helper
DEBUG - 2016-09-26 15:38:41 --> Helper loaded: func_helper
DEBUG - 2016-09-26 15:38:41 --> Database Driver Class Initialized
ERROR - 2016-09-26 15:38:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 15:38:41 --> Session Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Helper loaded: string_helper
DEBUG - 2016-09-26 15:38:41 --> Encrypt Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Session routines successfully run
ERROR - 2016-09-26 15:38:41 --> Could not find the language line "first_link"
ERROR - 2016-09-26 15:38:41 --> Could not find the language line "last_link"
ERROR - 2016-09-26 15:38:41 --> Could not find the language line "next_link"
ERROR - 2016-09-26 15:38:41 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 15:38:41 --> Pagination Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Table Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Helper loaded: file_helper
DEBUG - 2016-09-26 15:38:41 --> Model Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Controller Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Form Validation Class Initialized
DEBUG - 2016-09-26 15:38:41 --> Helper loaded: language_helper
DEBUG - 2016-09-26 15:38:41 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 15:38:41 --> Final output sent to browser
DEBUG - 2016-09-26 15:38:41 --> Total execution time: 0.1240
DEBUG - 2016-09-26 15:43:59 --> Config Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:43:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:43:59 --> URI Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Router Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Output Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Security Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Input Class Initialized
DEBUG - 2016-09-26 15:43:59 --> XSS Filtering completed
DEBUG - 2016-09-26 15:43:59 --> XSS Filtering completed
DEBUG - 2016-09-26 15:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 15:43:59 --> Language Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Loader Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Helper loaded: url_helper
DEBUG - 2016-09-26 15:43:59 --> Helper loaded: form_helper
DEBUG - 2016-09-26 15:43:59 --> Helper loaded: func_helper
DEBUG - 2016-09-26 15:43:59 --> Database Driver Class Initialized
ERROR - 2016-09-26 15:43:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 15:43:59 --> Session Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Helper loaded: string_helper
DEBUG - 2016-09-26 15:43:59 --> Encrypt Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Session routines successfully run
ERROR - 2016-09-26 15:43:59 --> Could not find the language line "first_link"
ERROR - 2016-09-26 15:43:59 --> Could not find the language line "last_link"
ERROR - 2016-09-26 15:43:59 --> Could not find the language line "next_link"
ERROR - 2016-09-26 15:43:59 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 15:43:59 --> Pagination Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Table Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Model Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Model Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Helper loaded: file_helper
DEBUG - 2016-09-26 15:43:59 --> Model Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Controller Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Form Validation Class Initialized
DEBUG - 2016-09-26 15:43:59 --> Helper loaded: language_helper
DEBUG - 2016-09-26 15:43:59 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 15:43:59 --> Final output sent to browser
DEBUG - 2016-09-26 15:43:59 --> Total execution time: 0.0990
DEBUG - 2016-09-26 15:44:47 --> Config Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:44:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:44:47 --> URI Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Router Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Output Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Security Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Input Class Initialized
DEBUG - 2016-09-26 15:44:47 --> XSS Filtering completed
DEBUG - 2016-09-26 15:44:47 --> XSS Filtering completed
DEBUG - 2016-09-26 15:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 15:44:47 --> Language Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Loader Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Helper loaded: url_helper
DEBUG - 2016-09-26 15:44:47 --> Helper loaded: form_helper
DEBUG - 2016-09-26 15:44:47 --> Helper loaded: func_helper
DEBUG - 2016-09-26 15:44:47 --> Database Driver Class Initialized
ERROR - 2016-09-26 15:44:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 15:44:47 --> Session Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Helper loaded: string_helper
DEBUG - 2016-09-26 15:44:47 --> Encrypt Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Session routines successfully run
ERROR - 2016-09-26 15:44:47 --> Could not find the language line "first_link"
ERROR - 2016-09-26 15:44:47 --> Could not find the language line "last_link"
ERROR - 2016-09-26 15:44:47 --> Could not find the language line "next_link"
ERROR - 2016-09-26 15:44:47 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 15:44:47 --> Pagination Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Table Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Model Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Model Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Helper loaded: file_helper
DEBUG - 2016-09-26 15:44:47 --> Model Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Controller Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Form Validation Class Initialized
DEBUG - 2016-09-26 15:44:47 --> Helper loaded: language_helper
DEBUG - 2016-09-26 15:44:47 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 15:44:47 --> Final output sent to browser
DEBUG - 2016-09-26 15:44:47 --> Total execution time: 0.0812
DEBUG - 2016-09-26 15:45:24 --> Config Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:45:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:45:24 --> URI Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Router Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Output Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Security Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Input Class Initialized
DEBUG - 2016-09-26 15:45:24 --> XSS Filtering completed
DEBUG - 2016-09-26 15:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 15:45:24 --> Language Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Loader Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Helper loaded: url_helper
DEBUG - 2016-09-26 15:45:24 --> Helper loaded: form_helper
DEBUG - 2016-09-26 15:45:24 --> Helper loaded: func_helper
DEBUG - 2016-09-26 15:45:24 --> Database Driver Class Initialized
ERROR - 2016-09-26 15:45:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 15:45:24 --> Session Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Helper loaded: string_helper
DEBUG - 2016-09-26 15:45:24 --> Encrypt Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Session routines successfully run
ERROR - 2016-09-26 15:45:24 --> Could not find the language line "first_link"
ERROR - 2016-09-26 15:45:24 --> Could not find the language line "last_link"
ERROR - 2016-09-26 15:45:24 --> Could not find the language line "next_link"
ERROR - 2016-09-26 15:45:24 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 15:45:24 --> Pagination Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Table Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Model Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Model Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Helper loaded: file_helper
DEBUG - 2016-09-26 15:45:24 --> Model Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Controller Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Form Validation Class Initialized
DEBUG - 2016-09-26 15:45:24 --> Helper loaded: language_helper
DEBUG - 2016-09-26 15:45:24 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 15:45:24 --> Final output sent to browser
DEBUG - 2016-09-26 15:45:24 --> Total execution time: 0.0840
DEBUG - 2016-09-26 15:46:13 --> Config Class Initialized
DEBUG - 2016-09-26 15:46:13 --> Hooks Class Initialized
DEBUG - 2016-09-26 15:46:13 --> Utf8 Class Initialized
DEBUG - 2016-09-26 15:46:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 15:46:13 --> URI Class Initialized
DEBUG - 2016-09-26 15:46:13 --> Router Class Initialized
DEBUG - 2016-09-26 15:46:13 --> Output Class Initialized
DEBUG - 2016-09-26 15:46:13 --> Security Class Initialized
DEBUG - 2016-09-26 15:46:13 --> Input Class Initialized
DEBUG - 2016-09-26 15:46:13 --> XSS Filtering completed
DEBUG - 2016-09-26 15:46:13 --> XSS Filtering completed
DEBUG - 2016-09-26 15:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 15:46:13 --> Language Class Initialized
DEBUG - 2016-09-26 15:46:13 --> Loader Class Initialized
DEBUG - 2016-09-26 15:46:13 --> Helper loaded: url_helper
DEBUG - 2016-09-26 15:46:13 --> Helper loaded: form_helper
DEBUG - 2016-09-26 15:46:13 --> Helper loaded: func_helper
DEBUG - 2016-09-26 15:46:13 --> Database Driver Class Initialized
ERROR - 2016-09-26 15:46:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 15:46:13 --> Session Class Initialized
DEBUG - 2016-09-26 15:46:13 --> Helper loaded: string_helper
DEBUG - 2016-09-26 15:46:13 --> Encrypt Class Initialized
DEBUG - 2016-09-26 15:46:13 --> Session routines successfully run
ERROR - 2016-09-26 15:46:14 --> Could not find the language line "first_link"
ERROR - 2016-09-26 15:46:14 --> Could not find the language line "last_link"
ERROR - 2016-09-26 15:46:14 --> Could not find the language line "next_link"
ERROR - 2016-09-26 15:46:14 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 15:46:14 --> Pagination Class Initialized
DEBUG - 2016-09-26 15:46:14 --> Table Class Initialized
DEBUG - 2016-09-26 15:46:14 --> Model Class Initialized
DEBUG - 2016-09-26 15:46:14 --> Model Class Initialized
DEBUG - 2016-09-26 15:46:14 --> Helper loaded: file_helper
DEBUG - 2016-09-26 15:46:14 --> Model Class Initialized
DEBUG - 2016-09-26 15:46:14 --> Controller Class Initialized
DEBUG - 2016-09-26 15:46:14 --> Form Validation Class Initialized
DEBUG - 2016-09-26 15:46:14 --> Helper loaded: language_helper
DEBUG - 2016-09-26 15:46:14 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 15:46:14 --> Final output sent to browser
DEBUG - 2016-09-26 15:46:14 --> Total execution time: 0.0818
DEBUG - 2016-09-26 16:12:22 --> Config Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:12:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:12:22 --> URI Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Router Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Output Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Security Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Input Class Initialized
DEBUG - 2016-09-26 16:12:22 --> XSS Filtering completed
DEBUG - 2016-09-26 16:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 16:12:22 --> Language Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Loader Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Helper loaded: url_helper
DEBUG - 2016-09-26 16:12:22 --> Helper loaded: form_helper
DEBUG - 2016-09-26 16:12:22 --> Helper loaded: func_helper
DEBUG - 2016-09-26 16:12:22 --> Database Driver Class Initialized
ERROR - 2016-09-26 16:12:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 16:12:22 --> Session Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Helper loaded: string_helper
DEBUG - 2016-09-26 16:12:22 --> Encrypt Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Session routines successfully run
ERROR - 2016-09-26 16:12:22 --> Could not find the language line "first_link"
ERROR - 2016-09-26 16:12:22 --> Could not find the language line "last_link"
ERROR - 2016-09-26 16:12:22 --> Could not find the language line "next_link"
ERROR - 2016-09-26 16:12:22 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 16:12:22 --> Pagination Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Table Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Model Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Model Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Helper loaded: file_helper
DEBUG - 2016-09-26 16:12:22 --> Model Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Controller Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Form Validation Class Initialized
DEBUG - 2016-09-26 16:12:22 --> Helper loaded: language_helper
DEBUG - 2016-09-26 16:12:22 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 16:12:25 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-26 16:12:25 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-26 16:12:25 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-26 16:12:25 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-26 16:12:25 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-26 16:12:25 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-26 16:12:25 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-26 16:12:25 --> Final output sent to browser
DEBUG - 2016-09-26 16:12:25 --> Total execution time: 2.4271
DEBUG - 2016-09-26 16:12:25 --> Config Class Initialized
DEBUG - 2016-09-26 16:12:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:12:25 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:12:25 --> URI Class Initialized
DEBUG - 2016-09-26 16:12:25 --> Router Class Initialized
ERROR - 2016-09-26 16:12:25 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 16:12:25 --> Config Class Initialized
DEBUG - 2016-09-26 16:12:25 --> Config Class Initialized
DEBUG - 2016-09-26 16:12:25 --> Config Class Initialized
DEBUG - 2016-09-26 16:12:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:12:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:12:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:12:25 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:12:25 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:12:25 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:12:25 --> URI Class Initialized
DEBUG - 2016-09-26 16:12:25 --> URI Class Initialized
DEBUG - 2016-09-26 16:12:25 --> URI Class Initialized
DEBUG - 2016-09-26 16:12:25 --> Router Class Initialized
DEBUG - 2016-09-26 16:12:25 --> Router Class Initialized
DEBUG - 2016-09-26 16:12:25 --> Router Class Initialized
ERROR - 2016-09-26 16:12:25 --> 404 Page Not Found --> application
ERROR - 2016-09-26 16:12:25 --> 404 Page Not Found --> application
ERROR - 2016-09-26 16:12:25 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 16:12:33 --> Config Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:12:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:12:33 --> URI Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Router Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Output Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Security Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Input Class Initialized
DEBUG - 2016-09-26 16:12:33 --> XSS Filtering completed
DEBUG - 2016-09-26 16:12:33 --> XSS Filtering completed
DEBUG - 2016-09-26 16:12:33 --> XSS Filtering completed
DEBUG - 2016-09-26 16:12:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 16:12:33 --> Language Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Loader Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Helper loaded: url_helper
DEBUG - 2016-09-26 16:12:33 --> Helper loaded: form_helper
DEBUG - 2016-09-26 16:12:33 --> Helper loaded: func_helper
DEBUG - 2016-09-26 16:12:33 --> Database Driver Class Initialized
ERROR - 2016-09-26 16:12:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 16:12:33 --> Session Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Helper loaded: string_helper
DEBUG - 2016-09-26 16:12:33 --> Encrypt Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Session routines successfully run
ERROR - 2016-09-26 16:12:33 --> Could not find the language line "first_link"
ERROR - 2016-09-26 16:12:33 --> Could not find the language line "last_link"
ERROR - 2016-09-26 16:12:33 --> Could not find the language line "next_link"
ERROR - 2016-09-26 16:12:33 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 16:12:33 --> Pagination Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Table Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Model Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Model Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Helper loaded: file_helper
DEBUG - 2016-09-26 16:12:33 --> Model Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Controller Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Form Validation Class Initialized
DEBUG - 2016-09-26 16:12:33 --> Helper loaded: language_helper
DEBUG - 2016-09-26 16:12:33 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 16:12:33 --> Final output sent to browser
DEBUG - 2016-09-26 16:12:33 --> Total execution time: 0.0936
DEBUG - 2016-09-26 16:13:18 --> Config Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:13:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:13:18 --> URI Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Router Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Output Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Security Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Input Class Initialized
DEBUG - 2016-09-26 16:13:18 --> XSS Filtering completed
DEBUG - 2016-09-26 16:13:18 --> XSS Filtering completed
DEBUG - 2016-09-26 16:13:18 --> XSS Filtering completed
DEBUG - 2016-09-26 16:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 16:13:18 --> Language Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Loader Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Helper loaded: url_helper
DEBUG - 2016-09-26 16:13:18 --> Helper loaded: form_helper
DEBUG - 2016-09-26 16:13:18 --> Helper loaded: func_helper
DEBUG - 2016-09-26 16:13:18 --> Database Driver Class Initialized
ERROR - 2016-09-26 16:13:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 16:13:18 --> Session Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Helper loaded: string_helper
DEBUG - 2016-09-26 16:13:18 --> Encrypt Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Session routines successfully run
ERROR - 2016-09-26 16:13:18 --> Could not find the language line "first_link"
ERROR - 2016-09-26 16:13:18 --> Could not find the language line "last_link"
ERROR - 2016-09-26 16:13:18 --> Could not find the language line "next_link"
ERROR - 2016-09-26 16:13:18 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 16:13:18 --> Pagination Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Table Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Model Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Model Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Helper loaded: file_helper
DEBUG - 2016-09-26 16:13:18 --> Model Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Controller Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Form Validation Class Initialized
DEBUG - 2016-09-26 16:13:18 --> Helper loaded: language_helper
DEBUG - 2016-09-26 16:13:18 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 16:13:18 --> Final output sent to browser
DEBUG - 2016-09-26 16:13:18 --> Total execution time: 0.0868
DEBUG - 2016-09-26 16:18:25 --> Config Class Initialized
DEBUG - 2016-09-26 16:18:25 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:18:25 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:18:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:18:25 --> URI Class Initialized
DEBUG - 2016-09-26 16:18:25 --> Router Class Initialized
DEBUG - 2016-09-26 16:18:25 --> Output Class Initialized
DEBUG - 2016-09-26 16:18:25 --> Security Class Initialized
DEBUG - 2016-09-26 16:18:25 --> Input Class Initialized
DEBUG - 2016-09-26 16:18:25 --> XSS Filtering completed
DEBUG - 2016-09-26 16:18:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 16:18:25 --> Language Class Initialized
DEBUG - 2016-09-26 16:18:25 --> Loader Class Initialized
DEBUG - 2016-09-26 16:18:25 --> Helper loaded: url_helper
DEBUG - 2016-09-26 16:18:25 --> Helper loaded: form_helper
DEBUG - 2016-09-26 16:18:25 --> Helper loaded: func_helper
DEBUG - 2016-09-26 16:18:26 --> Database Driver Class Initialized
ERROR - 2016-09-26 16:18:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 16:18:26 --> Session Class Initialized
DEBUG - 2016-09-26 16:18:26 --> Helper loaded: string_helper
DEBUG - 2016-09-26 16:18:26 --> Encrypt Class Initialized
DEBUG - 2016-09-26 16:18:26 --> Session routines successfully run
ERROR - 2016-09-26 16:18:26 --> Could not find the language line "first_link"
ERROR - 2016-09-26 16:18:26 --> Could not find the language line "last_link"
ERROR - 2016-09-26 16:18:26 --> Could not find the language line "next_link"
ERROR - 2016-09-26 16:18:26 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 16:18:26 --> Pagination Class Initialized
DEBUG - 2016-09-26 16:18:26 --> Table Class Initialized
DEBUG - 2016-09-26 16:18:26 --> Model Class Initialized
DEBUG - 2016-09-26 16:18:26 --> Model Class Initialized
DEBUG - 2016-09-26 16:18:26 --> Helper loaded: file_helper
DEBUG - 2016-09-26 16:18:26 --> Model Class Initialized
DEBUG - 2016-09-26 16:18:26 --> Controller Class Initialized
DEBUG - 2016-09-26 16:18:26 --> Form Validation Class Initialized
DEBUG - 2016-09-26 16:18:26 --> Helper loaded: language_helper
DEBUG - 2016-09-26 16:18:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 16:18:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-26 16:18:28 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-26 16:18:28 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-26 16:18:28 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-26 16:18:28 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-26 16:18:28 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-26 16:18:28 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-26 16:18:28 --> Final output sent to browser
DEBUG - 2016-09-26 16:18:28 --> Total execution time: 2.2171
DEBUG - 2016-09-26 16:18:28 --> Config Class Initialized
DEBUG - 2016-09-26 16:18:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:18:28 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:18:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:18:28 --> URI Class Initialized
DEBUG - 2016-09-26 16:18:28 --> Router Class Initialized
ERROR - 2016-09-26 16:18:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 16:18:28 --> Config Class Initialized
DEBUG - 2016-09-26 16:18:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:18:28 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:18:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:18:28 --> Config Class Initialized
DEBUG - 2016-09-26 16:18:28 --> URI Class Initialized
DEBUG - 2016-09-26 16:18:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:18:28 --> Router Class Initialized
DEBUG - 2016-09-26 16:18:28 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:18:28 --> UTF-8 Support Enabled
ERROR - 2016-09-26 16:18:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 16:18:28 --> URI Class Initialized
DEBUG - 2016-09-26 16:18:28 --> Router Class Initialized
DEBUG - 2016-09-26 16:18:28 --> Config Class Initialized
ERROR - 2016-09-26 16:18:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 16:18:28 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:18:28 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:18:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:18:28 --> URI Class Initialized
DEBUG - 2016-09-26 16:18:28 --> Router Class Initialized
ERROR - 2016-09-26 16:18:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 16:18:36 --> Config Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:18:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:18:36 --> URI Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Router Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Output Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Security Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Input Class Initialized
DEBUG - 2016-09-26 16:18:36 --> XSS Filtering completed
DEBUG - 2016-09-26 16:18:36 --> XSS Filtering completed
DEBUG - 2016-09-26 16:18:36 --> XSS Filtering completed
DEBUG - 2016-09-26 16:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 16:18:36 --> Language Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Loader Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Helper loaded: url_helper
DEBUG - 2016-09-26 16:18:36 --> Helper loaded: form_helper
DEBUG - 2016-09-26 16:18:36 --> Helper loaded: func_helper
DEBUG - 2016-09-26 16:18:36 --> Database Driver Class Initialized
ERROR - 2016-09-26 16:18:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 16:18:36 --> Session Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Helper loaded: string_helper
DEBUG - 2016-09-26 16:18:36 --> Encrypt Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Session routines successfully run
ERROR - 2016-09-26 16:18:36 --> Could not find the language line "first_link"
ERROR - 2016-09-26 16:18:36 --> Could not find the language line "last_link"
ERROR - 2016-09-26 16:18:36 --> Could not find the language line "next_link"
ERROR - 2016-09-26 16:18:36 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 16:18:36 --> Pagination Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Table Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Model Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Model Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Helper loaded: file_helper
DEBUG - 2016-09-26 16:18:36 --> Model Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Controller Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Form Validation Class Initialized
DEBUG - 2016-09-26 16:18:36 --> Helper loaded: language_helper
DEBUG - 2016-09-26 16:18:36 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 16:18:36 --> Final output sent to browser
DEBUG - 2016-09-26 16:18:36 --> Total execution time: 0.0878
DEBUG - 2016-09-26 16:32:59 --> Config Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:32:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:32:59 --> URI Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Router Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Output Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Security Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Input Class Initialized
DEBUG - 2016-09-26 16:32:59 --> XSS Filtering completed
DEBUG - 2016-09-26 16:32:59 --> XSS Filtering completed
DEBUG - 2016-09-26 16:32:59 --> XSS Filtering completed
DEBUG - 2016-09-26 16:32:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 16:32:59 --> Language Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Loader Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Helper loaded: url_helper
DEBUG - 2016-09-26 16:32:59 --> Helper loaded: form_helper
DEBUG - 2016-09-26 16:32:59 --> Helper loaded: func_helper
DEBUG - 2016-09-26 16:32:59 --> Database Driver Class Initialized
ERROR - 2016-09-26 16:32:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 16:32:59 --> Session Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Helper loaded: string_helper
DEBUG - 2016-09-26 16:32:59 --> Encrypt Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Session routines successfully run
ERROR - 2016-09-26 16:32:59 --> Could not find the language line "first_link"
ERROR - 2016-09-26 16:32:59 --> Could not find the language line "last_link"
ERROR - 2016-09-26 16:32:59 --> Could not find the language line "next_link"
ERROR - 2016-09-26 16:32:59 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 16:32:59 --> Pagination Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Table Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Model Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Model Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Helper loaded: file_helper
DEBUG - 2016-09-26 16:32:59 --> Model Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Controller Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Form Validation Class Initialized
DEBUG - 2016-09-26 16:32:59 --> Helper loaded: language_helper
DEBUG - 2016-09-26 16:32:59 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-26 16:32:59 --> Severity: Notice  --> Undefined variable: ids C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 235
ERROR - 2016-09-26 16:32:59 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 235
DEBUG - 2016-09-26 16:32:59 --> Final output sent to browser
DEBUG - 2016-09-26 16:32:59 --> Total execution time: 0.1050
DEBUG - 2016-09-26 16:33:35 --> Config Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:33:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:33:35 --> URI Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Router Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Output Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Security Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Input Class Initialized
DEBUG - 2016-09-26 16:33:35 --> XSS Filtering completed
DEBUG - 2016-09-26 16:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 16:33:35 --> Language Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Loader Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Helper loaded: url_helper
DEBUG - 2016-09-26 16:33:35 --> Helper loaded: form_helper
DEBUG - 2016-09-26 16:33:35 --> Helper loaded: func_helper
DEBUG - 2016-09-26 16:33:35 --> Database Driver Class Initialized
ERROR - 2016-09-26 16:33:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 16:33:35 --> Session Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Helper loaded: string_helper
DEBUG - 2016-09-26 16:33:35 --> Encrypt Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Session routines successfully run
ERROR - 2016-09-26 16:33:35 --> Could not find the language line "first_link"
ERROR - 2016-09-26 16:33:35 --> Could not find the language line "last_link"
ERROR - 2016-09-26 16:33:35 --> Could not find the language line "next_link"
ERROR - 2016-09-26 16:33:35 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 16:33:35 --> Pagination Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Table Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Model Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Model Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Helper loaded: file_helper
DEBUG - 2016-09-26 16:33:35 --> Model Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Controller Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Form Validation Class Initialized
DEBUG - 2016-09-26 16:33:35 --> Helper loaded: language_helper
DEBUG - 2016-09-26 16:33:35 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 16:33:37 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-26 16:33:37 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-26 16:33:37 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-26 16:33:37 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-26 16:33:37 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-26 16:33:37 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-26 16:33:37 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-26 16:33:37 --> Final output sent to browser
DEBUG - 2016-09-26 16:33:37 --> Total execution time: 2.3051
DEBUG - 2016-09-26 16:33:38 --> Config Class Initialized
DEBUG - 2016-09-26 16:33:38 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:33:38 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:33:38 --> URI Class Initialized
DEBUG - 2016-09-26 16:33:38 --> Router Class Initialized
ERROR - 2016-09-26 16:33:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 16:33:38 --> Config Class Initialized
DEBUG - 2016-09-26 16:33:38 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:33:38 --> Config Class Initialized
DEBUG - 2016-09-26 16:33:38 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:33:38 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:33:38 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:33:38 --> URI Class Initialized
DEBUG - 2016-09-26 16:33:38 --> URI Class Initialized
DEBUG - 2016-09-26 16:33:38 --> Router Class Initialized
DEBUG - 2016-09-26 16:33:38 --> Config Class Initialized
DEBUG - 2016-09-26 16:33:38 --> Router Class Initialized
ERROR - 2016-09-26 16:33:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 16:33:38 --> Hooks Class Initialized
ERROR - 2016-09-26 16:33:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 16:33:38 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:33:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:33:38 --> URI Class Initialized
DEBUG - 2016-09-26 16:33:38 --> Router Class Initialized
ERROR - 2016-09-26 16:33:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 16:34:09 --> Config Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:34:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:34:09 --> URI Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Router Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Output Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Security Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Input Class Initialized
DEBUG - 2016-09-26 16:34:09 --> XSS Filtering completed
DEBUG - 2016-09-26 16:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 16:34:09 --> Language Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Loader Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Helper loaded: url_helper
DEBUG - 2016-09-26 16:34:09 --> Helper loaded: form_helper
DEBUG - 2016-09-26 16:34:09 --> Helper loaded: func_helper
DEBUG - 2016-09-26 16:34:09 --> Database Driver Class Initialized
ERROR - 2016-09-26 16:34:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 16:34:09 --> Session Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Helper loaded: string_helper
DEBUG - 2016-09-26 16:34:09 --> Encrypt Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Session routines successfully run
ERROR - 2016-09-26 16:34:09 --> Could not find the language line "first_link"
ERROR - 2016-09-26 16:34:09 --> Could not find the language line "last_link"
ERROR - 2016-09-26 16:34:09 --> Could not find the language line "next_link"
ERROR - 2016-09-26 16:34:09 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 16:34:09 --> Pagination Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Table Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Model Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Model Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Helper loaded: file_helper
DEBUG - 2016-09-26 16:34:09 --> Model Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Controller Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Form Validation Class Initialized
DEBUG - 2016-09-26 16:34:09 --> Helper loaded: language_helper
DEBUG - 2016-09-26 16:34:09 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-26 16:34:09 --> Severity: Notice  --> Undefined variable: ids C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 235
ERROR - 2016-09-26 16:34:09 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 235
DEBUG - 2016-09-26 16:34:09 --> Final output sent to browser
DEBUG - 2016-09-26 16:34:09 --> Total execution time: 0.1248
DEBUG - 2016-09-26 16:36:49 --> Config Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:36:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:36:49 --> URI Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Router Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Output Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Security Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Input Class Initialized
DEBUG - 2016-09-26 16:36:49 --> XSS Filtering completed
DEBUG - 2016-09-26 16:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 16:36:49 --> Language Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Loader Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Helper loaded: url_helper
DEBUG - 2016-09-26 16:36:49 --> Helper loaded: form_helper
DEBUG - 2016-09-26 16:36:49 --> Helper loaded: func_helper
DEBUG - 2016-09-26 16:36:49 --> Database Driver Class Initialized
ERROR - 2016-09-26 16:36:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 16:36:49 --> Session Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Helper loaded: string_helper
DEBUG - 2016-09-26 16:36:49 --> Encrypt Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Session routines successfully run
ERROR - 2016-09-26 16:36:49 --> Could not find the language line "first_link"
ERROR - 2016-09-26 16:36:49 --> Could not find the language line "last_link"
ERROR - 2016-09-26 16:36:49 --> Could not find the language line "next_link"
ERROR - 2016-09-26 16:36:49 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 16:36:49 --> Pagination Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Table Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Model Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Model Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Helper loaded: file_helper
DEBUG - 2016-09-26 16:36:49 --> Model Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Controller Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Form Validation Class Initialized
DEBUG - 2016-09-26 16:36:49 --> Helper loaded: language_helper
DEBUG - 2016-09-26 16:36:49 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 16:36:51 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-26 16:36:51 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-26 16:36:51 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-26 16:36:51 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-26 16:36:51 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-26 16:36:51 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-26 16:36:51 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-26 16:36:51 --> Final output sent to browser
DEBUG - 2016-09-26 16:36:51 --> Total execution time: 2.5521
DEBUG - 2016-09-26 16:36:51 --> Config Class Initialized
DEBUG - 2016-09-26 16:36:51 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:36:51 --> Config Class Initialized
DEBUG - 2016-09-26 16:36:51 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:36:51 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:36:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:36:51 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:36:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:36:51 --> URI Class Initialized
DEBUG - 2016-09-26 16:36:51 --> URI Class Initialized
DEBUG - 2016-09-26 16:36:51 --> Router Class Initialized
DEBUG - 2016-09-26 16:36:51 --> Router Class Initialized
ERROR - 2016-09-26 16:36:51 --> 404 Page Not Found --> application
ERROR - 2016-09-26 16:36:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 16:36:51 --> Config Class Initialized
DEBUG - 2016-09-26 16:36:51 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:36:51 --> Config Class Initialized
DEBUG - 2016-09-26 16:36:51 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:36:51 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:36:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:36:51 --> URI Class Initialized
DEBUG - 2016-09-26 16:36:51 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:36:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:36:51 --> Router Class Initialized
DEBUG - 2016-09-26 16:36:51 --> URI Class Initialized
ERROR - 2016-09-26 16:36:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 16:36:51 --> Router Class Initialized
ERROR - 2016-09-26 16:36:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 16:39:02 --> Config Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Hooks Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Utf8 Class Initialized
DEBUG - 2016-09-26 16:39:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 16:39:02 --> URI Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Router Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Output Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Security Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Input Class Initialized
DEBUG - 2016-09-26 16:39:02 --> XSS Filtering completed
DEBUG - 2016-09-26 16:39:02 --> XSS Filtering completed
DEBUG - 2016-09-26 16:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 16:39:02 --> Language Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Loader Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Helper loaded: url_helper
DEBUG - 2016-09-26 16:39:02 --> Helper loaded: form_helper
DEBUG - 2016-09-26 16:39:02 --> Helper loaded: func_helper
DEBUG - 2016-09-26 16:39:02 --> Database Driver Class Initialized
ERROR - 2016-09-26 16:39:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 16:39:02 --> Session Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Helper loaded: string_helper
DEBUG - 2016-09-26 16:39:02 --> Encrypt Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Session routines successfully run
ERROR - 2016-09-26 16:39:02 --> Could not find the language line "first_link"
ERROR - 2016-09-26 16:39:02 --> Could not find the language line "last_link"
ERROR - 2016-09-26 16:39:02 --> Could not find the language line "next_link"
ERROR - 2016-09-26 16:39:02 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 16:39:02 --> Pagination Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Table Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Model Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Model Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Helper loaded: file_helper
DEBUG - 2016-09-26 16:39:02 --> Model Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Controller Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Form Validation Class Initialized
DEBUG - 2016-09-26 16:39:02 --> Helper loaded: language_helper
DEBUG - 2016-09-26 16:39:02 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-26 16:39:02 --> Severity: Notice  --> Undefined variable: ids C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 235
ERROR - 2016-09-26 16:39:02 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 235
DEBUG - 2016-09-26 16:39:02 --> Final output sent to browser
DEBUG - 2016-09-26 16:39:02 --> Total execution time: 0.1256
DEBUG - 2016-09-26 23:49:16 --> Config Class Initialized
DEBUG - 2016-09-26 23:49:16 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:49:16 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:49:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:49:16 --> URI Class Initialized
DEBUG - 2016-09-26 23:49:16 --> Router Class Initialized
DEBUG - 2016-09-26 23:49:16 --> Output Class Initialized
DEBUG - 2016-09-26 23:49:16 --> Security Class Initialized
DEBUG - 2016-09-26 23:49:16 --> Input Class Initialized
DEBUG - 2016-09-26 23:49:16 --> XSS Filtering completed
DEBUG - 2016-09-26 23:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 23:49:16 --> Language Class Initialized
DEBUG - 2016-09-26 23:49:16 --> Loader Class Initialized
DEBUG - 2016-09-26 23:49:16 --> Helper loaded: url_helper
DEBUG - 2016-09-26 23:49:17 --> Helper loaded: form_helper
DEBUG - 2016-09-26 23:49:17 --> Helper loaded: func_helper
DEBUG - 2016-09-26 23:49:17 --> Database Driver Class Initialized
ERROR - 2016-09-26 23:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 23:49:17 --> Session Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Helper loaded: string_helper
DEBUG - 2016-09-26 23:49:17 --> Encrypt Class Initialized
DEBUG - 2016-09-26 23:49:17 --> A session cookie was not found.
DEBUG - 2016-09-26 23:49:17 --> Session routines successfully run
ERROR - 2016-09-26 23:49:17 --> Could not find the language line "first_link"
ERROR - 2016-09-26 23:49:17 --> Could not find the language line "last_link"
ERROR - 2016-09-26 23:49:17 --> Could not find the language line "next_link"
ERROR - 2016-09-26 23:49:17 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 23:49:17 --> Pagination Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Table Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Model Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Model Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Helper loaded: file_helper
DEBUG - 2016-09-26 23:49:17 --> Model Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Controller Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Form Validation Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Config Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:49:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:49:17 --> URI Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Router Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Output Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Security Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Input Class Initialized
DEBUG - 2016-09-26 23:49:17 --> XSS Filtering completed
DEBUG - 2016-09-26 23:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 23:49:17 --> Language Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Loader Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Helper loaded: url_helper
DEBUG - 2016-09-26 23:49:17 --> Helper loaded: form_helper
DEBUG - 2016-09-26 23:49:17 --> Helper loaded: func_helper
DEBUG - 2016-09-26 23:49:17 --> Database Driver Class Initialized
ERROR - 2016-09-26 23:49:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 23:49:17 --> Session Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Helper loaded: string_helper
DEBUG - 2016-09-26 23:49:17 --> Encrypt Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Session routines successfully run
ERROR - 2016-09-26 23:49:17 --> Could not find the language line "first_link"
ERROR - 2016-09-26 23:49:17 --> Could not find the language line "last_link"
ERROR - 2016-09-26 23:49:17 --> Could not find the language line "next_link"
ERROR - 2016-09-26 23:49:17 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 23:49:17 --> Pagination Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Table Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Model Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Model Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Helper loaded: file_helper
DEBUG - 2016-09-26 23:49:17 --> Model Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Controller Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Helper loaded: language_helper
DEBUG - 2016-09-26 23:49:17 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 23:49:17 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-26 23:49:17 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-26 23:49:17 --> File loaded: application/views/login_form.php
DEBUG - 2016-09-26 23:49:17 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-26 23:49:17 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-26 23:49:17 --> Final output sent to browser
DEBUG - 2016-09-26 23:49:17 --> Total execution time: 0.1940
DEBUG - 2016-09-26 23:49:17 --> Config Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:49:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:49:17 --> URI Class Initialized
DEBUG - 2016-09-26 23:49:17 --> Router Class Initialized
ERROR - 2016-09-26 23:49:17 --> 404 Page Not Found --> js
DEBUG - 2016-09-26 23:49:21 --> Config Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:49:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:49:21 --> URI Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Router Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Output Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Security Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Input Class Initialized
DEBUG - 2016-09-26 23:49:21 --> XSS Filtering completed
DEBUG - 2016-09-26 23:49:21 --> XSS Filtering completed
DEBUG - 2016-09-26 23:49:21 --> XSS Filtering completed
DEBUG - 2016-09-26 23:49:21 --> XSS Filtering completed
DEBUG - 2016-09-26 23:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 23:49:21 --> Language Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Loader Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Helper loaded: url_helper
DEBUG - 2016-09-26 23:49:21 --> Helper loaded: form_helper
DEBUG - 2016-09-26 23:49:21 --> Helper loaded: func_helper
DEBUG - 2016-09-26 23:49:21 --> Database Driver Class Initialized
ERROR - 2016-09-26 23:49:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 23:49:21 --> Session Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Helper loaded: string_helper
DEBUG - 2016-09-26 23:49:21 --> Encrypt Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Session routines successfully run
ERROR - 2016-09-26 23:49:21 --> Could not find the language line "first_link"
ERROR - 2016-09-26 23:49:21 --> Could not find the language line "last_link"
ERROR - 2016-09-26 23:49:21 --> Could not find the language line "next_link"
ERROR - 2016-09-26 23:49:21 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 23:49:21 --> Pagination Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Table Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Model Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Model Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Helper loaded: file_helper
DEBUG - 2016-09-26 23:49:21 --> Model Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Controller Class Initialized
DEBUG - 2016-09-26 23:49:21 --> Helper loaded: language_helper
DEBUG - 2016-09-26 23:49:21 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 23:49:21 --> Model Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Config Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:49:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:49:30 --> URI Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Router Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Output Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Security Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Input Class Initialized
DEBUG - 2016-09-26 23:49:30 --> XSS Filtering completed
DEBUG - 2016-09-26 23:49:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 23:49:30 --> Language Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Loader Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Helper loaded: url_helper
DEBUG - 2016-09-26 23:49:30 --> Helper loaded: form_helper
DEBUG - 2016-09-26 23:49:30 --> Helper loaded: func_helper
DEBUG - 2016-09-26 23:49:30 --> Database Driver Class Initialized
ERROR - 2016-09-26 23:49:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 23:49:30 --> Session Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Helper loaded: string_helper
DEBUG - 2016-09-26 23:49:30 --> Encrypt Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Session routines successfully run
ERROR - 2016-09-26 23:49:30 --> Could not find the language line "first_link"
ERROR - 2016-09-26 23:49:30 --> Could not find the language line "last_link"
ERROR - 2016-09-26 23:49:30 --> Could not find the language line "next_link"
ERROR - 2016-09-26 23:49:30 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 23:49:30 --> Pagination Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Table Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Model Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Model Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Helper loaded: file_helper
DEBUG - 2016-09-26 23:49:30 --> Model Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Controller Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Form Validation Class Initialized
DEBUG - 2016-09-26 23:49:30 --> Helper loaded: language_helper
DEBUG - 2016-09-26 23:49:30 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 23:49:34 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-26 23:49:34 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-26 23:49:34 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-26 23:49:34 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-26 23:49:34 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-26 23:49:34 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-26 23:49:34 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-26 23:49:34 --> Final output sent to browser
DEBUG - 2016-09-26 23:49:34 --> Total execution time: 4.1162
DEBUG - 2016-09-26 23:49:34 --> Config Class Initialized
DEBUG - 2016-09-26 23:49:34 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:49:34 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:49:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:49:34 --> URI Class Initialized
DEBUG - 2016-09-26 23:49:34 --> Router Class Initialized
ERROR - 2016-09-26 23:49:34 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 23:49:34 --> Config Class Initialized
DEBUG - 2016-09-26 23:49:34 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:49:34 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:49:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:49:34 --> URI Class Initialized
DEBUG - 2016-09-26 23:49:34 --> Config Class Initialized
DEBUG - 2016-09-26 23:49:34 --> Router Class Initialized
DEBUG - 2016-09-26 23:49:34 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:49:34 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:49:34 --> Config Class Initialized
DEBUG - 2016-09-26 23:49:34 --> UTF-8 Support Enabled
ERROR - 2016-09-26 23:49:34 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 23:49:34 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:49:34 --> URI Class Initialized
DEBUG - 2016-09-26 23:49:34 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:49:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:49:34 --> Router Class Initialized
DEBUG - 2016-09-26 23:49:35 --> URI Class Initialized
ERROR - 2016-09-26 23:49:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 23:49:35 --> Router Class Initialized
ERROR - 2016-09-26 23:49:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 23:56:49 --> Config Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:56:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:56:49 --> URI Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Router Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Output Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Security Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Input Class Initialized
DEBUG - 2016-09-26 23:56:49 --> XSS Filtering completed
DEBUG - 2016-09-26 23:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 23:56:49 --> Language Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Loader Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Helper loaded: url_helper
DEBUG - 2016-09-26 23:56:49 --> Helper loaded: form_helper
DEBUG - 2016-09-26 23:56:49 --> Helper loaded: func_helper
DEBUG - 2016-09-26 23:56:49 --> Database Driver Class Initialized
ERROR - 2016-09-26 23:56:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 23:56:49 --> Session Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Helper loaded: string_helper
DEBUG - 2016-09-26 23:56:49 --> Encrypt Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Session routines successfully run
ERROR - 2016-09-26 23:56:49 --> Could not find the language line "first_link"
ERROR - 2016-09-26 23:56:49 --> Could not find the language line "last_link"
ERROR - 2016-09-26 23:56:49 --> Could not find the language line "next_link"
ERROR - 2016-09-26 23:56:49 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 23:56:49 --> Pagination Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Table Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Model Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Model Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Helper loaded: file_helper
DEBUG - 2016-09-26 23:56:49 --> Model Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Controller Class Initialized
DEBUG - 2016-09-26 23:56:49 --> Form Validation Class Initialized
DEBUG - 2016-09-26 23:56:50 --> Helper loaded: language_helper
DEBUG - 2016-09-26 23:56:50 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 23:56:52 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-26 23:56:52 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-26 23:56:52 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-26 23:56:52 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-26 23:56:52 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-26 23:56:52 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-26 23:56:52 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-26 23:56:52 --> Final output sent to browser
DEBUG - 2016-09-26 23:56:52 --> Total execution time: 2.3961
DEBUG - 2016-09-26 23:56:52 --> Config Class Initialized
DEBUG - 2016-09-26 23:56:52 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:56:52 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:56:52 --> URI Class Initialized
DEBUG - 2016-09-26 23:56:52 --> Router Class Initialized
ERROR - 2016-09-26 23:56:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 23:56:52 --> Config Class Initialized
DEBUG - 2016-09-26 23:56:52 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:56:52 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:56:52 --> URI Class Initialized
DEBUG - 2016-09-26 23:56:52 --> Router Class Initialized
ERROR - 2016-09-26 23:56:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 23:56:52 --> Config Class Initialized
DEBUG - 2016-09-26 23:56:52 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:56:52 --> Config Class Initialized
DEBUG - 2016-09-26 23:56:52 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:56:52 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:56:52 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:56:52 --> URI Class Initialized
DEBUG - 2016-09-26 23:56:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:56:52 --> Router Class Initialized
DEBUG - 2016-09-26 23:56:52 --> URI Class Initialized
DEBUG - 2016-09-26 23:56:52 --> Router Class Initialized
ERROR - 2016-09-26 23:56:52 --> 404 Page Not Found --> application
ERROR - 2016-09-26 23:56:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 23:56:59 --> Config Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:56:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:56:59 --> URI Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Router Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Output Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Security Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Input Class Initialized
DEBUG - 2016-09-26 23:56:59 --> XSS Filtering completed
DEBUG - 2016-09-26 23:56:59 --> XSS Filtering completed
DEBUG - 2016-09-26 23:56:59 --> XSS Filtering completed
DEBUG - 2016-09-26 23:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 23:56:59 --> Language Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Loader Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Helper loaded: url_helper
DEBUG - 2016-09-26 23:56:59 --> Helper loaded: form_helper
DEBUG - 2016-09-26 23:56:59 --> Helper loaded: func_helper
DEBUG - 2016-09-26 23:56:59 --> Database Driver Class Initialized
ERROR - 2016-09-26 23:56:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 23:56:59 --> Session Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Helper loaded: string_helper
DEBUG - 2016-09-26 23:56:59 --> Encrypt Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Session routines successfully run
ERROR - 2016-09-26 23:56:59 --> Could not find the language line "first_link"
ERROR - 2016-09-26 23:56:59 --> Could not find the language line "last_link"
ERROR - 2016-09-26 23:56:59 --> Could not find the language line "next_link"
ERROR - 2016-09-26 23:56:59 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 23:56:59 --> Pagination Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Table Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Model Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Model Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Helper loaded: file_helper
DEBUG - 2016-09-26 23:56:59 --> Model Class Initialized
DEBUG - 2016-09-26 23:56:59 --> Controller Class Initialized
DEBUG - 2016-09-26 23:57:00 --> Form Validation Class Initialized
DEBUG - 2016-09-26 23:57:00 --> Helper loaded: language_helper
DEBUG - 2016-09-26 23:57:00 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-26 23:57:00 --> Severity: Notice  --> Undefined variable: ids C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 235
ERROR - 2016-09-26 23:57:00 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 235
DEBUG - 2016-09-26 23:57:00 --> Final output sent to browser
DEBUG - 2016-09-26 23:57:00 --> Total execution time: 0.1120
DEBUG - 2016-09-26 23:59:31 --> Config Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:59:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:59:31 --> URI Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Router Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Output Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Security Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Input Class Initialized
DEBUG - 2016-09-26 23:59:31 --> XSS Filtering completed
DEBUG - 2016-09-26 23:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 23:59:31 --> Language Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Loader Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Helper loaded: url_helper
DEBUG - 2016-09-26 23:59:31 --> Helper loaded: form_helper
DEBUG - 2016-09-26 23:59:31 --> Helper loaded: func_helper
DEBUG - 2016-09-26 23:59:31 --> Database Driver Class Initialized
ERROR - 2016-09-26 23:59:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 23:59:31 --> Session Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Helper loaded: string_helper
DEBUG - 2016-09-26 23:59:31 --> Encrypt Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Session routines successfully run
ERROR - 2016-09-26 23:59:31 --> Could not find the language line "first_link"
ERROR - 2016-09-26 23:59:31 --> Could not find the language line "last_link"
ERROR - 2016-09-26 23:59:31 --> Could not find the language line "next_link"
ERROR - 2016-09-26 23:59:31 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 23:59:31 --> Pagination Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Table Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Model Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Model Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Helper loaded: file_helper
DEBUG - 2016-09-26 23:59:31 --> Model Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Controller Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Form Validation Class Initialized
DEBUG - 2016-09-26 23:59:31 --> Helper loaded: language_helper
DEBUG - 2016-09-26 23:59:31 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-26 23:59:34 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-26 23:59:34 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-26 23:59:34 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-26 23:59:34 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-26 23:59:34 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-26 23:59:34 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-26 23:59:34 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-26 23:59:34 --> Final output sent to browser
DEBUG - 2016-09-26 23:59:34 --> Total execution time: 2.6131
DEBUG - 2016-09-26 23:59:34 --> Config Class Initialized
DEBUG - 2016-09-26 23:59:34 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:59:34 --> Config Class Initialized
DEBUG - 2016-09-26 23:59:34 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:59:34 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:59:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:59:34 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:59:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:59:34 --> URI Class Initialized
DEBUG - 2016-09-26 23:59:34 --> Router Class Initialized
DEBUG - 2016-09-26 23:59:34 --> URI Class Initialized
DEBUG - 2016-09-26 23:59:34 --> Config Class Initialized
DEBUG - 2016-09-26 23:59:34 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:59:34 --> Router Class Initialized
DEBUG - 2016-09-26 23:59:34 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:59:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:59:34 --> URI Class Initialized
DEBUG - 2016-09-26 23:59:34 --> Router Class Initialized
ERROR - 2016-09-26 23:59:34 --> 404 Page Not Found --> application
ERROR - 2016-09-26 23:59:34 --> 404 Page Not Found --> application
ERROR - 2016-09-26 23:59:34 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 23:59:34 --> Config Class Initialized
DEBUG - 2016-09-26 23:59:34 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:59:34 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:59:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:59:34 --> URI Class Initialized
DEBUG - 2016-09-26 23:59:34 --> Router Class Initialized
ERROR - 2016-09-26 23:59:34 --> 404 Page Not Found --> application
DEBUG - 2016-09-26 23:59:41 --> Config Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Hooks Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Utf8 Class Initialized
DEBUG - 2016-09-26 23:59:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-26 23:59:41 --> URI Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Router Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Output Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Security Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Input Class Initialized
DEBUG - 2016-09-26 23:59:41 --> XSS Filtering completed
DEBUG - 2016-09-26 23:59:41 --> XSS Filtering completed
DEBUG - 2016-09-26 23:59:41 --> XSS Filtering completed
DEBUG - 2016-09-26 23:59:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-26 23:59:41 --> Language Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Loader Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Helper loaded: url_helper
DEBUG - 2016-09-26 23:59:41 --> Helper loaded: form_helper
DEBUG - 2016-09-26 23:59:41 --> Helper loaded: func_helper
DEBUG - 2016-09-26 23:59:41 --> Database Driver Class Initialized
ERROR - 2016-09-26 23:59:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-26 23:59:41 --> Session Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Helper loaded: string_helper
DEBUG - 2016-09-26 23:59:41 --> Encrypt Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Session routines successfully run
ERROR - 2016-09-26 23:59:41 --> Could not find the language line "first_link"
ERROR - 2016-09-26 23:59:41 --> Could not find the language line "last_link"
ERROR - 2016-09-26 23:59:41 --> Could not find the language line "next_link"
ERROR - 2016-09-26 23:59:41 --> Could not find the language line "prev_link"
DEBUG - 2016-09-26 23:59:41 --> Pagination Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Table Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Model Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Model Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Helper loaded: file_helper
DEBUG - 2016-09-26 23:59:41 --> Model Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Controller Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Form Validation Class Initialized
DEBUG - 2016-09-26 23:59:41 --> Helper loaded: language_helper
DEBUG - 2016-09-26 23:59:41 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-26 23:59:41 --> Severity: Notice  --> Undefined variable: ids C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 235
ERROR - 2016-09-26 23:59:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 235
DEBUG - 2016-09-26 23:59:41 --> Final output sent to browser
DEBUG - 2016-09-26 23:59:41 --> Total execution time: 0.1080
