<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-09-28 02:01:54 --> Config Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:01:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:01:54 --> URI Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Router Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Output Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Security Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Input Class Initialized
DEBUG - 2016-09-28 02:01:54 --> XSS Filtering completed
DEBUG - 2016-09-28 02:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:01:54 --> Language Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Loader Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:01:54 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:01:54 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:01:54 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:01:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:01:54 --> Session Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:01:54 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:01:54 --> A session cookie was not found.
DEBUG - 2016-09-28 02:01:54 --> Session routines successfully run
ERROR - 2016-09-28 02:01:54 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:01:54 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:01:54 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:01:54 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:01:54 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Table Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Model Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Model Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:01:54 --> Model Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Controller Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Form Validation Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Config Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:01:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:01:54 --> URI Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Router Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Output Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Security Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Input Class Initialized
DEBUG - 2016-09-28 02:01:54 --> XSS Filtering completed
DEBUG - 2016-09-28 02:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:01:54 --> Language Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Loader Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:01:54 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:01:54 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:01:54 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:01:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:01:54 --> Session Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:01:54 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Session routines successfully run
ERROR - 2016-09-28 02:01:54 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:01:54 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:01:54 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:01:54 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:01:54 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Table Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Model Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Model Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:01:54 --> Model Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Controller Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:01:54 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:01:54 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:01:54 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:01:54 --> File loaded: application/views/login_form.php
DEBUG - 2016-09-28 02:01:54 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:01:54 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:01:54 --> Final output sent to browser
DEBUG - 2016-09-28 02:01:54 --> Total execution time: 0.0540
DEBUG - 2016-09-28 02:01:54 --> Config Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:01:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:01:54 --> URI Class Initialized
DEBUG - 2016-09-28 02:01:54 --> Router Class Initialized
ERROR - 2016-09-28 02:01:54 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:01:56 --> Config Class Initialized
DEBUG - 2016-09-28 02:01:56 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:01:56 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:01:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:01:56 --> URI Class Initialized
DEBUG - 2016-09-28 02:01:56 --> Router Class Initialized
DEBUG - 2016-09-28 02:01:56 --> No URI present. Default controller set.
DEBUG - 2016-09-28 02:01:56 --> Output Class Initialized
DEBUG - 2016-09-28 02:01:56 --> Security Class Initialized
DEBUG - 2016-09-28 02:01:56 --> Input Class Initialized
DEBUG - 2016-09-28 02:01:56 --> XSS Filtering completed
DEBUG - 2016-09-28 02:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:01:56 --> Language Class Initialized
DEBUG - 2016-09-28 02:01:56 --> Loader Class Initialized
DEBUG - 2016-09-28 02:01:56 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:01:56 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:01:56 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:01:56 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:01:56 --> Session Class Initialized
DEBUG - 2016-09-28 02:01:56 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:01:56 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:01:56 --> Session routines successfully run
ERROR - 2016-09-28 02:01:56 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:01:56 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:01:56 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:01:56 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:01:56 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:01:56 --> Table Class Initialized
DEBUG - 2016-09-28 02:01:56 --> Model Class Initialized
DEBUG - 2016-09-28 02:01:56 --> Model Class Initialized
DEBUG - 2016-09-28 02:01:56 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:01:56 --> Model Class Initialized
DEBUG - 2016-09-28 02:01:56 --> Controller Class Initialized
DEBUG - 2016-09-28 02:01:58 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:01:58 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:02:00 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-28 02:02:03 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:02:03 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:02:03 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-28 02:02:03 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-28 02:02:03 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-28 02:02:03 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:02:03 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:02:03 --> Final output sent to browser
DEBUG - 2016-09-28 02:02:03 --> Total execution time: 7.3261
DEBUG - 2016-09-28 02:02:03 --> Config Class Initialized
DEBUG - 2016-09-28 02:02:03 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:02:03 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:02:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:02:03 --> URI Class Initialized
DEBUG - 2016-09-28 02:02:03 --> Router Class Initialized
ERROR - 2016-09-28 02:02:03 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:02:44 --> Config Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:02:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:02:44 --> URI Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Router Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Output Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Security Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Input Class Initialized
DEBUG - 2016-09-28 02:02:44 --> XSS Filtering completed
DEBUG - 2016-09-28 02:02:44 --> XSS Filtering completed
DEBUG - 2016-09-28 02:02:44 --> XSS Filtering completed
DEBUG - 2016-09-28 02:02:44 --> XSS Filtering completed
DEBUG - 2016-09-28 02:02:44 --> XSS Filtering completed
DEBUG - 2016-09-28 02:02:44 --> XSS Filtering completed
DEBUG - 2016-09-28 02:02:44 --> XSS Filtering completed
DEBUG - 2016-09-28 02:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:02:44 --> Language Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Loader Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:02:44 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:02:44 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:02:44 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:02:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:02:44 --> Session Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:02:44 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Session routines successfully run
ERROR - 2016-09-28 02:02:44 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:02:44 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:02:44 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:02:44 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:02:44 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Table Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Model Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Model Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:02:44 --> Model Class Initialized
DEBUG - 2016-09-28 02:02:44 --> Controller Class Initialized
DEBUG - 2016-09-28 02:02:46 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:02:46 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:02:48 --> Config Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:02:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:02:48 --> URI Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Router Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Output Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Security Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Input Class Initialized
DEBUG - 2016-09-28 02:02:48 --> XSS Filtering completed
DEBUG - 2016-09-28 02:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:02:48 --> Language Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Loader Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:02:48 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:02:48 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:02:48 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:02:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:02:48 --> Session Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:02:48 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Session routines successfully run
ERROR - 2016-09-28 02:02:48 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:02:48 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:02:48 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:02:48 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:02:48 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Table Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Model Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Model Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:02:48 --> Model Class Initialized
DEBUG - 2016-09-28 02:02:48 --> Controller Class Initialized
DEBUG - 2016-09-28 02:02:51 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:02:51 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:02:51 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-09-28 02:02:53 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-09-28 02:02:53 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:02:53 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:02:53 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-28 02:02:53 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-28 02:02:53 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-28 02:02:53 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:02:53 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:02:53 --> Final output sent to browser
DEBUG - 2016-09-28 02:02:53 --> Total execution time: 4.8612
DEBUG - 2016-09-28 02:02:53 --> Config Class Initialized
DEBUG - 2016-09-28 02:02:53 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:02:53 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:02:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:02:53 --> URI Class Initialized
DEBUG - 2016-09-28 02:02:53 --> Router Class Initialized
ERROR - 2016-09-28 02:02:53 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:03:07 --> Config Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:03:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:03:07 --> URI Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Router Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Output Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Security Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Input Class Initialized
DEBUG - 2016-09-28 02:03:07 --> XSS Filtering completed
DEBUG - 2016-09-28 02:03:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:03:07 --> Language Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Loader Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:03:07 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:03:07 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:03:07 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:03:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:03:07 --> Session Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:03:07 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Session routines successfully run
ERROR - 2016-09-28 02:03:07 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:03:07 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:03:07 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:03:07 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:03:07 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Table Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Model Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Model Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:03:07 --> Model Class Initialized
DEBUG - 2016-09-28 02:03:07 --> Controller Class Initialized
DEBUG - 2016-09-28 02:03:09 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:03:09 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:03:09 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-09-28 02:03:11 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-09-28 02:03:11 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:03:11 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:03:11 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-28 02:03:11 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-28 02:03:11 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-28 02:03:11 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:03:11 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:03:11 --> Final output sent to browser
DEBUG - 2016-09-28 02:03:11 --> Total execution time: 4.0350
DEBUG - 2016-09-28 02:03:11 --> Config Class Initialized
DEBUG - 2016-09-28 02:03:11 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:03:11 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:03:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:03:11 --> URI Class Initialized
DEBUG - 2016-09-28 02:03:11 --> Router Class Initialized
ERROR - 2016-09-28 02:03:11 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:03:19 --> Config Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:03:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:03:19 --> URI Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Router Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Output Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Security Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Input Class Initialized
DEBUG - 2016-09-28 02:03:19 --> XSS Filtering completed
DEBUG - 2016-09-28 02:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:03:19 --> Language Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Loader Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:03:19 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:03:19 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:03:19 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:03:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:03:19 --> Session Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:03:19 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Session routines successfully run
ERROR - 2016-09-28 02:03:19 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:03:19 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:03:19 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:03:19 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:03:19 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Table Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Model Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Model Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:03:19 --> Model Class Initialized
DEBUG - 2016-09-28 02:03:19 --> Controller Class Initialized
DEBUG - 2016-09-28 02:03:21 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:03:21 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:03:21 --> Pagination class already loaded. Second attempt ignored.
ERROR - 2016-09-28 02:03:23 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-09-28 02:03:23 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:03:23 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:03:23 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-28 02:03:23 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-28 02:03:23 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-28 02:03:23 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:03:23 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:03:23 --> Final output sent to browser
DEBUG - 2016-09-28 02:03:23 --> Total execution time: 4.0742
DEBUG - 2016-09-28 02:03:23 --> Config Class Initialized
DEBUG - 2016-09-28 02:03:23 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:03:23 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:03:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:03:23 --> URI Class Initialized
DEBUG - 2016-09-28 02:03:23 --> Router Class Initialized
ERROR - 2016-09-28 02:03:23 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:03:23 --> Config Class Initialized
DEBUG - 2016-09-28 02:03:23 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:03:23 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:03:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:03:23 --> URI Class Initialized
DEBUG - 2016-09-28 02:03:23 --> Router Class Initialized
ERROR - 2016-09-28 02:03:23 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:04:44 --> Config Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:04:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:04:44 --> URI Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Router Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Output Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Security Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Input Class Initialized
DEBUG - 2016-09-28 02:04:44 --> XSS Filtering completed
DEBUG - 2016-09-28 02:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:04:44 --> Language Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Loader Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:04:44 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:04:44 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:04:44 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:04:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:04:44 --> Session Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:04:44 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Session routines successfully run
ERROR - 2016-09-28 02:04:44 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:04:44 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:04:44 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:04:44 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:04:44 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Table Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Model Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Model Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:04:44 --> Model Class Initialized
DEBUG - 2016-09-28 02:04:44 --> Controller Class Initialized
DEBUG - 2016-09-28 02:04:46 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:04:46 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:04:46 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:04:46 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:04:46 --> File loaded: application/views/signup/main.php
DEBUG - 2016-09-28 02:04:46 --> File loaded: application/views/signup/login.php
DEBUG - 2016-09-28 02:04:46 --> File loaded: application/views/signup/personal.php
ERROR - 2016-09-28 02:04:46 --> Could not find the language line "register"
DEBUG - 2016-09-28 02:04:46 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-09-28 02:04:46 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:04:46 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:04:46 --> Final output sent to browser
DEBUG - 2016-09-28 02:04:46 --> Total execution time: 2.2151
DEBUG - 2016-09-28 02:04:46 --> Config Class Initialized
DEBUG - 2016-09-28 02:04:46 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:04:46 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:04:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:04:46 --> URI Class Initialized
DEBUG - 2016-09-28 02:04:46 --> Router Class Initialized
ERROR - 2016-09-28 02:04:46 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:04:48 --> Config Class Initialized
DEBUG - 2016-09-28 02:04:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:04:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:04:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:04:48 --> URI Class Initialized
DEBUG - 2016-09-28 02:04:48 --> Router Class Initialized
DEBUG - 2016-09-28 02:04:48 --> No URI present. Default controller set.
DEBUG - 2016-09-28 02:04:48 --> Output Class Initialized
DEBUG - 2016-09-28 02:04:48 --> Security Class Initialized
DEBUG - 2016-09-28 02:04:48 --> Input Class Initialized
DEBUG - 2016-09-28 02:04:48 --> XSS Filtering completed
DEBUG - 2016-09-28 02:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:04:48 --> Language Class Initialized
DEBUG - 2016-09-28 02:04:48 --> Loader Class Initialized
DEBUG - 2016-09-28 02:04:48 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:04:48 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:04:48 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:04:48 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:04:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:04:48 --> Session Class Initialized
DEBUG - 2016-09-28 02:04:48 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:04:48 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:04:48 --> Session routines successfully run
ERROR - 2016-09-28 02:04:48 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:04:48 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:04:48 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:04:48 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:04:48 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:04:49 --> Table Class Initialized
DEBUG - 2016-09-28 02:04:49 --> Model Class Initialized
DEBUG - 2016-09-28 02:04:49 --> Model Class Initialized
DEBUG - 2016-09-28 02:04:49 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:04:49 --> Model Class Initialized
DEBUG - 2016-09-28 02:04:49 --> Controller Class Initialized
DEBUG - 2016-09-28 02:04:50 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:04:50 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:04:52 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-28 02:04:55 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:04:55 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:04:55 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-28 02:04:55 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-28 02:04:55 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-28 02:04:55 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:04:55 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:04:55 --> Final output sent to browser
DEBUG - 2016-09-28 02:04:55 --> Total execution time: 6.6590
DEBUG - 2016-09-28 02:04:55 --> Config Class Initialized
DEBUG - 2016-09-28 02:04:55 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:04:55 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:04:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:04:55 --> URI Class Initialized
DEBUG - 2016-09-28 02:04:55 --> Router Class Initialized
ERROR - 2016-09-28 02:04:55 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:05:04 --> Config Class Initialized
DEBUG - 2016-09-28 02:05:04 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:05:04 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:05:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:05:04 --> URI Class Initialized
DEBUG - 2016-09-28 02:05:04 --> Router Class Initialized
DEBUG - 2016-09-28 02:05:04 --> No URI present. Default controller set.
DEBUG - 2016-09-28 02:05:04 --> Output Class Initialized
DEBUG - 2016-09-28 02:05:04 --> Security Class Initialized
DEBUG - 2016-09-28 02:05:04 --> Input Class Initialized
DEBUG - 2016-09-28 02:05:04 --> XSS Filtering completed
DEBUG - 2016-09-28 02:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:05:04 --> Language Class Initialized
DEBUG - 2016-09-28 02:05:04 --> Loader Class Initialized
DEBUG - 2016-09-28 02:05:04 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:05:04 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:05:04 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:05:04 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:05:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:05:04 --> Session Class Initialized
DEBUG - 2016-09-28 02:05:04 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:05:04 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:05:04 --> Session routines successfully run
ERROR - 2016-09-28 02:05:04 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:05:04 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:05:04 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:05:04 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:05:04 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:05:04 --> Table Class Initialized
DEBUG - 2016-09-28 02:05:04 --> Model Class Initialized
DEBUG - 2016-09-28 02:05:04 --> Model Class Initialized
DEBUG - 2016-09-28 02:05:04 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:05:04 --> Model Class Initialized
DEBUG - 2016-09-28 02:05:04 --> Controller Class Initialized
DEBUG - 2016-09-28 02:05:06 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:05:06 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:05:09 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-28 02:05:11 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:05:11 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:05:11 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-28 02:05:11 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-28 02:05:11 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-28 02:05:11 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:05:11 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:05:11 --> Final output sent to browser
DEBUG - 2016-09-28 02:05:11 --> Total execution time: 7.0990
DEBUG - 2016-09-28 02:05:11 --> Config Class Initialized
DEBUG - 2016-09-28 02:05:11 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:05:11 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:05:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:05:11 --> URI Class Initialized
DEBUG - 2016-09-28 02:05:11 --> Router Class Initialized
ERROR - 2016-09-28 02:05:11 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:05:11 --> Config Class Initialized
DEBUG - 2016-09-28 02:05:11 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:05:11 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:05:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:05:11 --> URI Class Initialized
DEBUG - 2016-09-28 02:05:11 --> Router Class Initialized
ERROR - 2016-09-28 02:05:11 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:05:14 --> Config Class Initialized
DEBUG - 2016-09-28 02:05:14 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:05:14 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:05:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:05:14 --> URI Class Initialized
DEBUG - 2016-09-28 02:05:14 --> Router Class Initialized
DEBUG - 2016-09-28 02:05:14 --> No URI present. Default controller set.
DEBUG - 2016-09-28 02:05:14 --> Output Class Initialized
DEBUG - 2016-09-28 02:05:14 --> Security Class Initialized
DEBUG - 2016-09-28 02:05:14 --> Input Class Initialized
DEBUG - 2016-09-28 02:05:14 --> XSS Filtering completed
DEBUG - 2016-09-28 02:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:05:14 --> Language Class Initialized
DEBUG - 2016-09-28 02:05:14 --> Loader Class Initialized
DEBUG - 2016-09-28 02:05:14 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:05:14 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:05:14 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:05:14 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:05:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:05:14 --> Session Class Initialized
DEBUG - 2016-09-28 02:05:14 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:05:14 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:05:14 --> Session routines successfully run
ERROR - 2016-09-28 02:05:14 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:05:14 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:05:14 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:05:14 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:05:14 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:05:14 --> Table Class Initialized
DEBUG - 2016-09-28 02:05:14 --> Model Class Initialized
DEBUG - 2016-09-28 02:05:14 --> Model Class Initialized
DEBUG - 2016-09-28 02:05:14 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:05:14 --> Model Class Initialized
DEBUG - 2016-09-28 02:05:14 --> Controller Class Initialized
DEBUG - 2016-09-28 02:05:16 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:05:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:05:18 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-28 02:05:21 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:05:21 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:05:21 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-28 02:05:21 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-28 02:05:21 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-28 02:05:21 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:05:21 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:05:21 --> Final output sent to browser
DEBUG - 2016-09-28 02:05:21 --> Total execution time: 7.4721
DEBUG - 2016-09-28 02:05:21 --> Config Class Initialized
DEBUG - 2016-09-28 02:05:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:05:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:05:21 --> URI Class Initialized
DEBUG - 2016-09-28 02:05:21 --> Router Class Initialized
ERROR - 2016-09-28 02:05:21 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:05:21 --> Config Class Initialized
DEBUG - 2016-09-28 02:05:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:05:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:05:21 --> URI Class Initialized
DEBUG - 2016-09-28 02:05:21 --> Router Class Initialized
ERROR - 2016-09-28 02:05:21 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:07:03 --> Config Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:07:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:07:03 --> URI Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Router Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Output Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Security Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Input Class Initialized
DEBUG - 2016-09-28 02:07:03 --> XSS Filtering completed
DEBUG - 2016-09-28 02:07:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:07:03 --> Language Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Loader Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:07:03 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:07:03 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:07:03 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:07:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:07:03 --> Session Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:07:03 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Session routines successfully run
ERROR - 2016-09-28 02:07:03 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:07:03 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:07:03 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:07:03 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:07:03 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Table Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:07:03 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:03 --> Controller Class Initialized
DEBUG - 2016-09-28 02:07:05 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:07:05 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:07:07 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-28 02:07:09 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:07:09 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:07:09 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-28 02:07:09 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-28 02:07:09 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-28 02:07:09 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:07:09 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:07:09 --> Final output sent to browser
DEBUG - 2016-09-28 02:07:09 --> Total execution time: 6.6770
DEBUG - 2016-09-28 02:07:09 --> Config Class Initialized
DEBUG - 2016-09-28 02:07:09 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:07:09 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:07:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:07:09 --> URI Class Initialized
DEBUG - 2016-09-28 02:07:09 --> Router Class Initialized
ERROR - 2016-09-28 02:07:09 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:07:16 --> Config Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:07:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:07:16 --> URI Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Router Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Output Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Security Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Input Class Initialized
DEBUG - 2016-09-28 02:07:16 --> XSS Filtering completed
DEBUG - 2016-09-28 02:07:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:07:16 --> Language Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Loader Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:07:16 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:07:16 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:07:16 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:07:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:07:16 --> Session Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:07:16 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Session routines successfully run
ERROR - 2016-09-28 02:07:16 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:07:16 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:07:16 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:07:16 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:07:16 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Table Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:07:16 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:16 --> Controller Class Initialized
DEBUG - 2016-09-28 02:07:18 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:07:18 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:07:18 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:07:18 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:07:18 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-09-28 02:07:18 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:07:18 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:07:18 --> Final output sent to browser
DEBUG - 2016-09-28 02:07:18 --> Total execution time: 2.2890
DEBUG - 2016-09-28 02:07:18 --> Config Class Initialized
DEBUG - 2016-09-28 02:07:18 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:07:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:07:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:07:18 --> URI Class Initialized
DEBUG - 2016-09-28 02:07:18 --> Router Class Initialized
ERROR - 2016-09-28 02:07:18 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:07:18 --> Config Class Initialized
DEBUG - 2016-09-28 02:07:18 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:07:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:07:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:07:18 --> URI Class Initialized
DEBUG - 2016-09-28 02:07:18 --> Router Class Initialized
ERROR - 2016-09-28 02:07:18 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:07:37 --> Config Class Initialized
DEBUG - 2016-09-28 02:07:37 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:07:37 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:07:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:07:37 --> URI Class Initialized
DEBUG - 2016-09-28 02:07:37 --> Router Class Initialized
DEBUG - 2016-09-28 02:07:37 --> No URI present. Default controller set.
DEBUG - 2016-09-28 02:07:37 --> Output Class Initialized
DEBUG - 2016-09-28 02:07:37 --> Security Class Initialized
DEBUG - 2016-09-28 02:07:37 --> Input Class Initialized
DEBUG - 2016-09-28 02:07:37 --> XSS Filtering completed
DEBUG - 2016-09-28 02:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:07:37 --> Language Class Initialized
DEBUG - 2016-09-28 02:07:37 --> Loader Class Initialized
DEBUG - 2016-09-28 02:07:37 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:07:37 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:07:37 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:07:37 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:07:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:07:37 --> Session Class Initialized
DEBUG - 2016-09-28 02:07:37 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:07:37 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:07:37 --> Session routines successfully run
ERROR - 2016-09-28 02:07:37 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:07:37 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:07:37 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:07:37 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:07:37 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:07:37 --> Table Class Initialized
DEBUG - 2016-09-28 02:07:37 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:37 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:37 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:07:37 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:37 --> Controller Class Initialized
DEBUG - 2016-09-28 02:07:40 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:07:40 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:07:42 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-28 02:07:45 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:07:45 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:07:45 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-28 02:07:45 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-28 02:07:45 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-28 02:07:45 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:07:45 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:07:45 --> Final output sent to browser
DEBUG - 2016-09-28 02:07:45 --> Total execution time: 7.5730
DEBUG - 2016-09-28 02:07:45 --> Config Class Initialized
DEBUG - 2016-09-28 02:07:45 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:07:45 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:07:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:07:45 --> URI Class Initialized
DEBUG - 2016-09-28 02:07:45 --> Router Class Initialized
ERROR - 2016-09-28 02:07:45 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:07:45 --> Config Class Initialized
DEBUG - 2016-09-28 02:07:45 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:07:45 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:07:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:07:45 --> URI Class Initialized
DEBUG - 2016-09-28 02:07:45 --> Router Class Initialized
ERROR - 2016-09-28 02:07:45 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:07:51 --> Config Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:07:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:07:51 --> URI Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Router Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Output Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Security Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Input Class Initialized
DEBUG - 2016-09-28 02:07:51 --> XSS Filtering completed
DEBUG - 2016-09-28 02:07:51 --> XSS Filtering completed
DEBUG - 2016-09-28 02:07:51 --> XSS Filtering completed
DEBUG - 2016-09-28 02:07:51 --> XSS Filtering completed
DEBUG - 2016-09-28 02:07:51 --> XSS Filtering completed
DEBUG - 2016-09-28 02:07:51 --> XSS Filtering completed
DEBUG - 2016-09-28 02:07:51 --> XSS Filtering completed
DEBUG - 2016-09-28 02:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:07:51 --> Language Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Loader Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:07:51 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:07:51 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:07:51 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:07:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:07:51 --> Session Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:07:51 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Session routines successfully run
ERROR - 2016-09-28 02:07:51 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:07:51 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:07:51 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:07:51 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:07:51 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Table Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:07:51 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:51 --> Controller Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:07:54 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:07:54 --> Config Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:07:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:07:54 --> URI Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Router Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Output Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Security Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Input Class Initialized
DEBUG - 2016-09-28 02:07:54 --> XSS Filtering completed
DEBUG - 2016-09-28 02:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:07:54 --> Language Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Loader Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:07:54 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:07:54 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:07:54 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:07:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:07:54 --> Session Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:07:54 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Session routines successfully run
ERROR - 2016-09-28 02:07:54 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:07:54 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:07:54 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:07:54 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:07:54 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Table Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:07:54 --> Model Class Initialized
DEBUG - 2016-09-28 02:07:54 --> Controller Class Initialized
DEBUG - 2016-09-28 02:07:56 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:07:56 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-28 02:07:56 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-09-28 02:07:56 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:07:56 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:07:56 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-28 02:07:56 --> File loaded: application/views/alumni_view_files/single.php
DEBUG - 2016-09-28 02:07:56 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-28 02:07:56 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:07:56 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:07:56 --> Final output sent to browser
DEBUG - 2016-09-28 02:07:56 --> Total execution time: 2.3470
DEBUG - 2016-09-28 02:07:56 --> Config Class Initialized
DEBUG - 2016-09-28 02:07:56 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:07:56 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:07:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:07:56 --> URI Class Initialized
DEBUG - 2016-09-28 02:07:56 --> Router Class Initialized
ERROR - 2016-09-28 02:07:56 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:08:04 --> Config Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:08:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:08:04 --> URI Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Router Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Output Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Security Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Input Class Initialized
DEBUG - 2016-09-28 02:08:04 --> XSS Filtering completed
DEBUG - 2016-09-28 02:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:08:04 --> Language Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Loader Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:08:04 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:08:04 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:08:04 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:08:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:08:04 --> Session Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:08:04 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Session routines successfully run
ERROR - 2016-09-28 02:08:04 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:08:04 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:08:04 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:08:04 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:08:04 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Table Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Model Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Model Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:08:04 --> Model Class Initialized
DEBUG - 2016-09-28 02:08:04 --> Controller Class Initialized
DEBUG - 2016-09-28 02:08:06 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:08:06 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:08:06 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:08:06 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:08:06 --> File loaded: application/views/single_alumni_view.php
DEBUG - 2016-09-28 02:08:06 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:08:06 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:08:06 --> Final output sent to browser
DEBUG - 2016-09-28 02:08:06 --> Total execution time: 2.3000
DEBUG - 2016-09-28 02:08:06 --> Config Class Initialized
DEBUG - 2016-09-28 02:08:06 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:08:06 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:08:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:08:06 --> URI Class Initialized
DEBUG - 2016-09-28 02:08:06 --> Router Class Initialized
ERROR - 2016-09-28 02:08:06 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:08:06 --> Config Class Initialized
DEBUG - 2016-09-28 02:08:06 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:08:06 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:08:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:08:06 --> URI Class Initialized
DEBUG - 2016-09-28 02:08:06 --> Router Class Initialized
ERROR - 2016-09-28 02:08:06 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:09:10 --> Config Class Initialized
DEBUG - 2016-09-28 02:09:10 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:09:10 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:09:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:09:10 --> URI Class Initialized
DEBUG - 2016-09-28 02:09:10 --> Router Class Initialized
DEBUG - 2016-09-28 02:09:10 --> Output Class Initialized
DEBUG - 2016-09-28 02:09:10 --> Security Class Initialized
DEBUG - 2016-09-28 02:09:10 --> Input Class Initialized
DEBUG - 2016-09-28 02:09:10 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:09:10 --> Language Class Initialized
DEBUG - 2016-09-28 02:09:10 --> Loader Class Initialized
DEBUG - 2016-09-28 02:09:10 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:09:10 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:09:10 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:09:11 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:09:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:09:11 --> Session Class Initialized
DEBUG - 2016-09-28 02:09:11 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:09:11 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:09:11 --> Session routines successfully run
ERROR - 2016-09-28 02:09:11 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:09:11 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:09:11 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:09:11 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:09:11 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:09:11 --> Table Class Initialized
DEBUG - 2016-09-28 02:09:11 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:11 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:11 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:09:11 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:11 --> Controller Class Initialized
DEBUG - 2016-09-28 02:09:13 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:09:13 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:09:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:09:13 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:09:13 --> File loaded: application/views/signup/main.php
DEBUG - 2016-09-28 02:09:13 --> File loaded: application/views/signup/login.php
DEBUG - 2016-09-28 02:09:13 --> File loaded: application/views/signup/personal.php
ERROR - 2016-09-28 02:09:13 --> Could not find the language line "register"
DEBUG - 2016-09-28 02:09:13 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-09-28 02:09:13 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:09:13 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:09:13 --> Final output sent to browser
DEBUG - 2016-09-28 02:09:13 --> Total execution time: 2.1371
DEBUG - 2016-09-28 02:09:13 --> Config Class Initialized
DEBUG - 2016-09-28 02:09:13 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:09:13 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:09:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:09:13 --> URI Class Initialized
DEBUG - 2016-09-28 02:09:13 --> Router Class Initialized
ERROR - 2016-09-28 02:09:13 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:09:24 --> Config Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:09:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:09:24 --> URI Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Router Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Output Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Security Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Input Class Initialized
DEBUG - 2016-09-28 02:09:24 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:09:24 --> Language Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Loader Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:09:24 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:09:24 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:09:24 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:09:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:09:24 --> Session Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:09:24 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Session routines successfully run
ERROR - 2016-09-28 02:09:24 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:09:24 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:09:24 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:09:24 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:09:24 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Table Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:09:24 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Controller Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:09:24 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 02:09:24 --> Config Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:09:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:09:24 --> URI Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Router Class Initialized
DEBUG - 2016-09-28 02:09:24 --> No URI present. Default controller set.
DEBUG - 2016-09-28 02:09:24 --> Output Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Security Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Input Class Initialized
DEBUG - 2016-09-28 02:09:24 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:09:24 --> Language Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Loader Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:09:24 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:09:24 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:09:24 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:09:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:09:24 --> Session Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:09:24 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Session routines successfully run
ERROR - 2016-09-28 02:09:24 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:09:24 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:09:24 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:09:24 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:09:24 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Table Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:09:24 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:24 --> Controller Class Initialized
DEBUG - 2016-09-28 02:09:27 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:09:27 --> Language file loaded: language/english/site_lang.php
DEBUG - 2016-09-28 02:09:29 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-28 02:09:31 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:09:31 --> File loaded: application/views/includes/header.php
ERROR - 2016-09-28 02:09:31 --> Could not find the language line "first_letters_from_name"
DEBUG - 2016-09-28 02:09:31 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-28 02:09:31 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-28 02:09:31 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-28 02:09:31 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:09:31 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:09:31 --> Final output sent to browser
DEBUG - 2016-09-28 02:09:31 --> Total execution time: 7.1034
DEBUG - 2016-09-28 02:09:31 --> Config Class Initialized
DEBUG - 2016-09-28 02:09:31 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:09:31 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:09:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:09:31 --> URI Class Initialized
DEBUG - 2016-09-28 02:09:31 --> Router Class Initialized
ERROR - 2016-09-28 02:09:31 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:09:44 --> Config Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:09:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:09:44 --> URI Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Router Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Output Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Security Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Input Class Initialized
DEBUG - 2016-09-28 02:09:44 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:09:44 --> Language Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Loader Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:09:44 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:09:44 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:09:44 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:09:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:09:44 --> Session Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:09:44 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Session routines successfully run
ERROR - 2016-09-28 02:09:44 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:09:44 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:09:44 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:09:44 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:09:44 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Table Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:09:44 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:44 --> Controller Class Initialized
DEBUG - 2016-09-28 02:09:46 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:09:46 --> Language file loaded: language/english/site_lang.php
DEBUG - 2016-09-28 02:09:46 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:09:46 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:09:46 --> File loaded: application/views/signup/main.php
DEBUG - 2016-09-28 02:09:46 --> File loaded: application/views/signup/login.php
DEBUG - 2016-09-28 02:09:46 --> File loaded: application/views/signup/personal.php
ERROR - 2016-09-28 02:09:46 --> Could not find the language line "register"
DEBUG - 2016-09-28 02:09:46 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-09-28 02:09:46 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:09:46 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:09:46 --> Final output sent to browser
DEBUG - 2016-09-28 02:09:46 --> Total execution time: 2.1611
DEBUG - 2016-09-28 02:09:46 --> Config Class Initialized
DEBUG - 2016-09-28 02:09:46 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:09:46 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:09:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:09:46 --> URI Class Initialized
DEBUG - 2016-09-28 02:09:46 --> Router Class Initialized
ERROR - 2016-09-28 02:09:46 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:09:46 --> Config Class Initialized
DEBUG - 2016-09-28 02:09:46 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:09:46 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:09:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:09:46 --> URI Class Initialized
DEBUG - 2016-09-28 02:09:46 --> Router Class Initialized
ERROR - 2016-09-28 02:09:46 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:09:57 --> Config Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:09:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:09:57 --> URI Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Router Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Output Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Security Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Input Class Initialized
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> XSS Filtering completed
DEBUG - 2016-09-28 02:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:09:57 --> Language Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Loader Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:09:57 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:09:57 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:09:57 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:09:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:09:57 --> Session Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:09:57 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Session routines successfully run
ERROR - 2016-09-28 02:09:57 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:09:57 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:09:57 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:09:57 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:09:57 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Table Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:09:57 --> Model Class Initialized
DEBUG - 2016-09-28 02:09:57 --> Controller Class Initialized
DEBUG - 2016-09-28 02:09:59 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:09:59 --> Language file loaded: language/english/site_lang.php
DEBUG - 2016-09-28 02:09:59 --> Form Validation Class Initialized
ERROR - 2016-09-28 02:09:59 --> Could not find the language line "year"
ERROR - 2016-09-28 02:09:59 --> Could not find the language line "retype"
DEBUG - 2016-09-28 02:09:59 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-28 02:09:59 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:09:59 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:09:59 --> File loaded: application/views/signup/main.php
DEBUG - 2016-09-28 02:09:59 --> File loaded: application/views/signup/login.php
DEBUG - 2016-09-28 02:09:59 --> File loaded: application/views/signup/personal.php
ERROR - 2016-09-28 02:09:59 --> Could not find the language line "register"
DEBUG - 2016-09-28 02:09:59 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-09-28 02:09:59 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:09:59 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:09:59 --> Final output sent to browser
DEBUG - 2016-09-28 02:09:59 --> Total execution time: 2.2841
DEBUG - 2016-09-28 02:09:59 --> Config Class Initialized
DEBUG - 2016-09-28 02:09:59 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:09:59 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:09:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:09:59 --> URI Class Initialized
DEBUG - 2016-09-28 02:09:59 --> Router Class Initialized
ERROR - 2016-09-28 02:09:59 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:10:56 --> Config Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:10:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:10:56 --> URI Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Router Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Output Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Security Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Input Class Initialized
DEBUG - 2016-09-28 02:10:56 --> XSS Filtering completed
DEBUG - 2016-09-28 02:10:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:10:56 --> Language Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Loader Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:10:56 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:10:56 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:10:56 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:10:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:10:56 --> Session Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:10:56 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Session routines successfully run
ERROR - 2016-09-28 02:10:56 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:10:56 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:10:56 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:10:56 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:10:56 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Table Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Model Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Model Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:10:56 --> Model Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Controller Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:10:56 --> Language file loaded: language/english/site_lang.php
DEBUG - 2016-09-28 02:10:56 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:10:56 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 02:10:56 --> File loaded: application/views/login_form.php
DEBUG - 2016-09-28 02:10:56 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 02:10:56 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 02:10:56 --> Final output sent to browser
DEBUG - 2016-09-28 02:10:56 --> Total execution time: 0.0600
DEBUG - 2016-09-28 02:10:56 --> Config Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:10:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:10:56 --> URI Class Initialized
DEBUG - 2016-09-28 02:10:56 --> Router Class Initialized
ERROR - 2016-09-28 02:10:56 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 02:11:03 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:03 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Router Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Output Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Security Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Input Class Initialized
DEBUG - 2016-09-28 02:11:03 --> XSS Filtering completed
DEBUG - 2016-09-28 02:11:03 --> XSS Filtering completed
DEBUG - 2016-09-28 02:11:03 --> XSS Filtering completed
DEBUG - 2016-09-28 02:11:03 --> XSS Filtering completed
DEBUG - 2016-09-28 02:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:11:03 --> Language Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Loader Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:11:03 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:11:03 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:11:03 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:11:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:11:03 --> Session Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:11:03 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Session routines successfully run
ERROR - 2016-09-28 02:11:03 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:11:03 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:11:03 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:11:03 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:11:03 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Table Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:11:03 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Controller Class Initialized
DEBUG - 2016-09-28 02:11:03 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:11:03 --> Language file loaded: language/english/site_lang.php
DEBUG - 2016-09-28 02:11:03 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:06 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Router Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Output Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Security Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Input Class Initialized
DEBUG - 2016-09-28 02:11:06 --> XSS Filtering completed
DEBUG - 2016-09-28 02:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:11:06 --> Language Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Loader Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:11:06 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:11:06 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:11:06 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:11:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:11:06 --> Session Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:11:06 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Session routines successfully run
ERROR - 2016-09-28 02:11:06 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:11:06 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:11:06 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:11:06 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:11:06 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Table Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:11:06 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Controller Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Form Validation Class Initialized
DEBUG - 2016-09-28 02:11:06 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:11:06 --> Language file loaded: language/english/site_lang.php
DEBUG - 2016-09-28 02:11:08 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:11:08 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 02:11:08 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 02:11:08 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 02:11:08 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 02:11:08 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 02:11:08 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 02:11:08 --> Final output sent to browser
DEBUG - 2016-09-28 02:11:08 --> Total execution time: 2.5700
DEBUG - 2016-09-28 02:11:08 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:08 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Router Class Initialized
ERROR - 2016-09-28 02:11:08 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 02:11:08 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:08 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:08 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:08 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Router Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Router Class Initialized
ERROR - 2016-09-28 02:11:08 --> 404 Page Not Found --> application
ERROR - 2016-09-28 02:11:08 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 02:11:08 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:08 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Router Class Initialized
ERROR - 2016-09-28 02:11:08 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 02:11:08 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:08 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:08 --> Router Class Initialized
ERROR - 2016-09-28 02:11:08 --> 404 Page Not Found --> css
DEBUG - 2016-09-28 02:11:29 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:29 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Router Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Output Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Security Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Input Class Initialized
DEBUG - 2016-09-28 02:11:29 --> XSS Filtering completed
DEBUG - 2016-09-28 02:11:29 --> XSS Filtering completed
DEBUG - 2016-09-28 02:11:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:11:29 --> Language Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Loader Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:11:29 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:11:29 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:11:29 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:11:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:11:29 --> Session Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:11:29 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Session routines successfully run
ERROR - 2016-09-28 02:11:29 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:11:29 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:11:29 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:11:29 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:11:29 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Table Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:11:29 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Controller Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Form Validation Class Initialized
DEBUG - 2016-09-28 02:11:29 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:11:29 --> Language file loaded: language/english/site_lang.php
DEBUG - 2016-09-28 02:11:29 --> Final output sent to browser
DEBUG - 2016-09-28 02:11:29 --> Total execution time: 0.1500
DEBUG - 2016-09-28 02:11:30 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:30 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Router Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Output Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Security Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Input Class Initialized
DEBUG - 2016-09-28 02:11:30 --> XSS Filtering completed
DEBUG - 2016-09-28 02:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:11:30 --> Language Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Loader Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:11:30 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:11:30 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:11:30 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:11:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:11:30 --> Session Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:11:30 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Session routines successfully run
ERROR - 2016-09-28 02:11:30 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:11:30 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:11:30 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:11:30 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:11:30 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Table Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:11:30 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Controller Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Form Validation Class Initialized
DEBUG - 2016-09-28 02:11:30 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:11:30 --> Language file loaded: language/english/site_lang.php
DEBUG - 2016-09-28 02:11:32 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:11:32 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 02:11:32 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 02:11:32 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 02:11:32 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 02:11:32 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 02:11:32 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 02:11:32 --> Final output sent to browser
DEBUG - 2016-09-28 02:11:32 --> Total execution time: 2.3560
DEBUG - 2016-09-28 02:11:32 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:32 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:32 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:32 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Router Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Router Class Initialized
ERROR - 2016-09-28 02:11:32 --> 404 Page Not Found --> application
ERROR - 2016-09-28 02:11:32 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 02:11:32 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:32 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Router Class Initialized
ERROR - 2016-09-28 02:11:32 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 02:11:32 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:32 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Router Class Initialized
ERROR - 2016-09-28 02:11:32 --> 404 Page Not Found --> css
DEBUG - 2016-09-28 02:11:32 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:32 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:32 --> Router Class Initialized
ERROR - 2016-09-28 02:11:32 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 02:11:42 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:42 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Router Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Output Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Security Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Input Class Initialized
DEBUG - 2016-09-28 02:11:42 --> XSS Filtering completed
DEBUG - 2016-09-28 02:11:42 --> XSS Filtering completed
DEBUG - 2016-09-28 02:11:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:11:42 --> Language Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Loader Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:11:42 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:11:42 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:11:42 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:11:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-28 02:11:42 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:11:42 --> Session Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:11:42 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Session routines successfully run
ERROR - 2016-09-28 02:11:42 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:11:42 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:11:42 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:11:42 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:11:42 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Table Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:11:42 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Controller Class Initialized
DEBUG - 2016-09-28 02:11:42 --> Form Validation Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:11:43 --> Language file loaded: language/english/site_lang.php
DEBUG - 2016-09-28 02:11:43 --> Final output sent to browser
DEBUG - 2016-09-28 02:11:43 --> Total execution time: 0.3200
DEBUG - 2016-09-28 02:11:43 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:43 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Router Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Output Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Security Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Input Class Initialized
DEBUG - 2016-09-28 02:11:43 --> XSS Filtering completed
DEBUG - 2016-09-28 02:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:11:43 --> Language Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Loader Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:11:43 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:11:43 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:11:43 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:11:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:11:43 --> Session Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:11:43 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Session routines successfully run
ERROR - 2016-09-28 02:11:43 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:11:43 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:11:43 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:11:43 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:11:43 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Table Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:11:43 --> Model Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Controller Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Form Validation Class Initialized
DEBUG - 2016-09-28 02:11:43 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:11:43 --> Language file loaded: language/english/site_lang.php
DEBUG - 2016-09-28 02:11:46 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:11:46 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 02:11:46 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 02:11:46 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 02:11:46 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 02:11:46 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 02:11:46 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 02:11:46 --> Final output sent to browser
DEBUG - 2016-09-28 02:11:46 --> Total execution time: 2.7620
DEBUG - 2016-09-28 02:11:46 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:46 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Router Class Initialized
ERROR - 2016-09-28 02:11:46 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 02:11:46 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:46 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Router Class Initialized
ERROR - 2016-09-28 02:11:46 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 02:11:46 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:46 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:46 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Router Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Router Class Initialized
ERROR - 2016-09-28 02:11:46 --> 404 Page Not Found --> application
ERROR - 2016-09-28 02:11:46 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 02:11:46 --> Config Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:11:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:11:46 --> URI Class Initialized
DEBUG - 2016-09-28 02:11:46 --> Router Class Initialized
ERROR - 2016-09-28 02:11:46 --> 404 Page Not Found --> css
DEBUG - 2016-09-28 02:15:20 --> Config Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:15:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:15:20 --> URI Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Router Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Output Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Security Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Input Class Initialized
DEBUG - 2016-09-28 02:15:20 --> XSS Filtering completed
DEBUG - 2016-09-28 02:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:15:20 --> Language Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Loader Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:15:20 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:15:20 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:15:20 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:15:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:15:20 --> Session Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:15:20 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Session routines successfully run
ERROR - 2016-09-28 02:15:20 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:15:20 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:15:20 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:15:20 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:15:20 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Table Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Model Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Model Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:15:20 --> Model Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Controller Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Form Validation Class Initialized
DEBUG - 2016-09-28 02:15:20 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:15:20 --> Language file loaded: language/english/site_lang.php
DEBUG - 2016-09-28 02:15:23 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:15:23 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 02:15:23 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 02:15:23 --> Config Class Initialized
DEBUG - 2016-09-28 02:15:23 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:15:23 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:15:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:15:23 --> URI Class Initialized
DEBUG - 2016-09-28 02:15:23 --> Router Class Initialized
ERROR - 2016-09-28 02:15:23 --> 404 Page Not Found --> css
DEBUG - 2016-09-28 02:17:25 --> Config Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:17:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:17:25 --> URI Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Router Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Output Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Security Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Input Class Initialized
DEBUG - 2016-09-28 02:17:25 --> XSS Filtering completed
DEBUG - 2016-09-28 02:17:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:17:25 --> Language Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Loader Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:17:25 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:17:25 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:17:25 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:17:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:17:25 --> Session Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:17:25 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Session routines successfully run
ERROR - 2016-09-28 02:17:25 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:17:25 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:17:25 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:17:25 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:17:25 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Table Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Model Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Model Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:17:25 --> Model Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Controller Class Initialized
DEBUG - 2016-09-28 02:17:25 --> Form Validation Class Initialized
DEBUG - 2016-09-28 02:17:26 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:17:26 --> Language file loaded: language/english/site_lang.php
DEBUG - 2016-09-28 02:17:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:17:28 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 02:17:28 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 02:17:28 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 02:17:28 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 02:17:28 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 02:17:28 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 02:17:28 --> Final output sent to browser
DEBUG - 2016-09-28 02:17:28 --> Total execution time: 2.5100
DEBUG - 2016-09-28 02:17:28 --> Config Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:17:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:17:28 --> URI Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Router Class Initialized
ERROR - 2016-09-28 02:17:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 02:17:28 --> Config Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Config Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:17:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:17:28 --> URI Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:17:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:17:28 --> Router Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Config Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:17:28 --> URI Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Utf8 Class Initialized
ERROR - 2016-09-28 02:17:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 02:17:28 --> Router Class Initialized
DEBUG - 2016-09-28 02:17:28 --> UTF-8 Support Enabled
ERROR - 2016-09-28 02:17:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 02:17:28 --> URI Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Router Class Initialized
ERROR - 2016-09-28 02:17:28 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 02:17:28 --> Config Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:17:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:17:28 --> URI Class Initialized
DEBUG - 2016-09-28 02:17:28 --> Router Class Initialized
ERROR - 2016-09-28 02:17:28 --> 404 Page Not Found --> css
DEBUG - 2016-09-28 02:17:53 --> Config Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:17:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:17:53 --> URI Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Router Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Output Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Security Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Input Class Initialized
DEBUG - 2016-09-28 02:17:53 --> XSS Filtering completed
DEBUG - 2016-09-28 02:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 02:17:53 --> Language Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Loader Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Helper loaded: url_helper
DEBUG - 2016-09-28 02:17:53 --> Helper loaded: form_helper
DEBUG - 2016-09-28 02:17:53 --> Helper loaded: func_helper
DEBUG - 2016-09-28 02:17:53 --> Database Driver Class Initialized
ERROR - 2016-09-28 02:17:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 02:17:53 --> Session Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Helper loaded: string_helper
DEBUG - 2016-09-28 02:17:53 --> Encrypt Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Session routines successfully run
ERROR - 2016-09-28 02:17:53 --> Could not find the language line "first_link"
ERROR - 2016-09-28 02:17:53 --> Could not find the language line "last_link"
ERROR - 2016-09-28 02:17:53 --> Could not find the language line "next_link"
ERROR - 2016-09-28 02:17:53 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 02:17:53 --> Pagination Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Table Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Model Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Model Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Helper loaded: file_helper
DEBUG - 2016-09-28 02:17:53 --> Model Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Controller Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Form Validation Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Helper loaded: language_helper
DEBUG - 2016-09-28 02:17:53 --> Language file loaded: language/english/site_lang.php
DEBUG - 2016-09-28 02:17:53 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 02:17:53 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 02:17:53 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 02:17:53 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-09-28 02:17:53 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-09-28 02:17:53 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 02:17:53 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-09-28 02:17:53 --> Final output sent to browser
DEBUG - 2016-09-28 02:17:53 --> Total execution time: 0.2280
DEBUG - 2016-09-28 02:17:53 --> Config Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Hooks Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Utf8 Class Initialized
DEBUG - 2016-09-28 02:17:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 02:17:53 --> URI Class Initialized
DEBUG - 2016-09-28 02:17:53 --> Router Class Initialized
ERROR - 2016-09-28 02:17:53 --> 404 Page Not Found --> css
DEBUG - 2016-09-28 13:15:53 --> Config Class Initialized
DEBUG - 2016-09-28 13:15:53 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:15:53 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:15:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:15:53 --> URI Class Initialized
DEBUG - 2016-09-28 13:15:53 --> Router Class Initialized
ERROR - 2016-09-28 13:15:53 --> 404 Page Not Found --> css
DEBUG - 2016-09-28 13:15:58 --> Config Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:15:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:15:58 --> URI Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Router Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Output Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Security Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Input Class Initialized
DEBUG - 2016-09-28 13:15:58 --> XSS Filtering completed
DEBUG - 2016-09-28 13:15:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 13:15:58 --> Language Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Loader Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Helper loaded: url_helper
DEBUG - 2016-09-28 13:15:58 --> Helper loaded: form_helper
DEBUG - 2016-09-28 13:15:58 --> Helper loaded: func_helper
DEBUG - 2016-09-28 13:15:58 --> Database Driver Class Initialized
ERROR - 2016-09-28 13:15:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 13:15:58 --> Session Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Helper loaded: string_helper
DEBUG - 2016-09-28 13:15:58 --> Encrypt Class Initialized
DEBUG - 2016-09-28 13:15:58 --> A session cookie was not found.
DEBUG - 2016-09-28 13:15:58 --> Session routines successfully run
ERROR - 2016-09-28 13:15:58 --> Could not find the language line "first_link"
ERROR - 2016-09-28 13:15:58 --> Could not find the language line "last_link"
ERROR - 2016-09-28 13:15:58 --> Could not find the language line "next_link"
ERROR - 2016-09-28 13:15:58 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 13:15:58 --> Pagination Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Table Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Model Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Model Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Helper loaded: file_helper
DEBUG - 2016-09-28 13:15:58 --> Model Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Controller Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Helper loaded: language_helper
DEBUG - 2016-09-28 13:15:58 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 13:15:58 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 13:15:58 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 13:15:58 --> File loaded: application/views/login_form.php
DEBUG - 2016-09-28 13:15:58 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 13:15:58 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 13:15:58 --> Final output sent to browser
DEBUG - 2016-09-28 13:15:58 --> Total execution time: 0.1960
DEBUG - 2016-09-28 13:15:58 --> Config Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:15:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:15:58 --> URI Class Initialized
DEBUG - 2016-09-28 13:15:58 --> Router Class Initialized
ERROR - 2016-09-28 13:15:58 --> 404 Page Not Found --> js
DEBUG - 2016-09-28 13:16:06 --> Config Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:06 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Router Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Output Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Security Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Input Class Initialized
DEBUG - 2016-09-28 13:16:06 --> XSS Filtering completed
DEBUG - 2016-09-28 13:16:06 --> XSS Filtering completed
DEBUG - 2016-09-28 13:16:06 --> XSS Filtering completed
DEBUG - 2016-09-28 13:16:06 --> XSS Filtering completed
DEBUG - 2016-09-28 13:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 13:16:06 --> Language Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Loader Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Helper loaded: url_helper
DEBUG - 2016-09-28 13:16:06 --> Helper loaded: form_helper
DEBUG - 2016-09-28 13:16:06 --> Helper loaded: func_helper
DEBUG - 2016-09-28 13:16:06 --> Database Driver Class Initialized
ERROR - 2016-09-28 13:16:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 13:16:06 --> Session Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Helper loaded: string_helper
DEBUG - 2016-09-28 13:16:06 --> Encrypt Class Initialized
DEBUG - 2016-09-28 13:16:06 --> A session cookie was not found.
DEBUG - 2016-09-28 13:16:06 --> Session routines successfully run
ERROR - 2016-09-28 13:16:06 --> Could not find the language line "first_link"
ERROR - 2016-09-28 13:16:06 --> Could not find the language line "last_link"
ERROR - 2016-09-28 13:16:06 --> Could not find the language line "next_link"
ERROR - 2016-09-28 13:16:06 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 13:16:06 --> Pagination Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Table Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Model Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Model Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Helper loaded: file_helper
DEBUG - 2016-09-28 13:16:06 --> Model Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Controller Class Initialized
DEBUG - 2016-09-28 13:16:06 --> Helper loaded: language_helper
DEBUG - 2016-09-28 13:16:06 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 13:16:06 --> Model Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Config Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:10 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Router Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Output Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Security Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Input Class Initialized
DEBUG - 2016-09-28 13:16:10 --> XSS Filtering completed
DEBUG - 2016-09-28 13:16:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 13:16:10 --> Language Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Loader Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Helper loaded: url_helper
DEBUG - 2016-09-28 13:16:10 --> Helper loaded: form_helper
DEBUG - 2016-09-28 13:16:10 --> Helper loaded: func_helper
DEBUG - 2016-09-28 13:16:10 --> Database Driver Class Initialized
ERROR - 2016-09-28 13:16:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 13:16:10 --> Session Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Helper loaded: string_helper
DEBUG - 2016-09-28 13:16:10 --> Encrypt Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Session routines successfully run
ERROR - 2016-09-28 13:16:10 --> Could not find the language line "first_link"
ERROR - 2016-09-28 13:16:10 --> Could not find the language line "last_link"
ERROR - 2016-09-28 13:16:10 --> Could not find the language line "next_link"
ERROR - 2016-09-28 13:16:10 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 13:16:10 --> Pagination Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Table Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Model Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Model Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Helper loaded: file_helper
DEBUG - 2016-09-28 13:16:10 --> Model Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Controller Class Initialized
DEBUG - 2016-09-28 13:16:10 --> Form Validation Class Initialized
DEBUG - 2016-09-28 13:16:11 --> Helper loaded: language_helper
DEBUG - 2016-09-28 13:16:11 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 13:16:14 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 13:16:14 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 13:16:14 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 13:16:14 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 13:16:14 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 13:16:14 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 13:16:14 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 13:16:14 --> Final output sent to browser
DEBUG - 2016-09-28 13:16:14 --> Total execution time: 3.5512
DEBUG - 2016-09-28 13:16:14 --> Config Class Initialized
DEBUG - 2016-09-28 13:16:14 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:16:14 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:14 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:14 --> Router Class Initialized
DEBUG - 2016-09-28 13:16:14 --> Config Class Initialized
DEBUG - 2016-09-28 13:16:14 --> Hooks Class Initialized
ERROR - 2016-09-28 13:16:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 13:16:14 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:14 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:14 --> Router Class Initialized
ERROR - 2016-09-28 13:16:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 13:16:14 --> Config Class Initialized
DEBUG - 2016-09-28 13:16:14 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:16:14 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:14 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:14 --> Router Class Initialized
ERROR - 2016-09-28 13:16:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 13:16:14 --> Config Class Initialized
DEBUG - 2016-09-28 13:16:14 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:16:14 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:14 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:14 --> Router Class Initialized
ERROR - 2016-09-28 13:16:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 13:16:23 --> Config Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:23 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Router Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Output Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Security Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Input Class Initialized
DEBUG - 2016-09-28 13:16:23 --> XSS Filtering completed
DEBUG - 2016-09-28 13:16:23 --> XSS Filtering completed
DEBUG - 2016-09-28 13:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 13:16:23 --> Language Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Loader Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Helper loaded: url_helper
DEBUG - 2016-09-28 13:16:23 --> Helper loaded: form_helper
DEBUG - 2016-09-28 13:16:23 --> Helper loaded: func_helper
DEBUG - 2016-09-28 13:16:23 --> Database Driver Class Initialized
ERROR - 2016-09-28 13:16:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 13:16:23 --> Session Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Helper loaded: string_helper
DEBUG - 2016-09-28 13:16:23 --> Encrypt Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Session routines successfully run
ERROR - 2016-09-28 13:16:23 --> Could not find the language line "first_link"
ERROR - 2016-09-28 13:16:23 --> Could not find the language line "last_link"
ERROR - 2016-09-28 13:16:23 --> Could not find the language line "next_link"
ERROR - 2016-09-28 13:16:23 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 13:16:23 --> Pagination Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Table Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Model Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Model Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Helper loaded: file_helper
DEBUG - 2016-09-28 13:16:23 --> Model Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Controller Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Form Validation Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Helper loaded: language_helper
DEBUG - 2016-09-28 13:16:23 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 13:16:23 --> Final output sent to browser
DEBUG - 2016-09-28 13:16:23 --> Total execution time: 0.1780
DEBUG - 2016-09-28 13:16:23 --> Config Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:23 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Router Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Output Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Security Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Input Class Initialized
DEBUG - 2016-09-28 13:16:23 --> XSS Filtering completed
DEBUG - 2016-09-28 13:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 13:16:23 --> Language Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Loader Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Helper loaded: url_helper
DEBUG - 2016-09-28 13:16:23 --> Helper loaded: form_helper
DEBUG - 2016-09-28 13:16:23 --> Helper loaded: func_helper
DEBUG - 2016-09-28 13:16:23 --> Database Driver Class Initialized
ERROR - 2016-09-28 13:16:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 13:16:23 --> Session Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Helper loaded: string_helper
DEBUG - 2016-09-28 13:16:23 --> Encrypt Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Session routines successfully run
ERROR - 2016-09-28 13:16:23 --> Could not find the language line "first_link"
ERROR - 2016-09-28 13:16:23 --> Could not find the language line "last_link"
ERROR - 2016-09-28 13:16:23 --> Could not find the language line "next_link"
ERROR - 2016-09-28 13:16:23 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 13:16:23 --> Pagination Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Table Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Model Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Model Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Helper loaded: file_helper
DEBUG - 2016-09-28 13:16:23 --> Model Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Controller Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Form Validation Class Initialized
DEBUG - 2016-09-28 13:16:23 --> Helper loaded: language_helper
DEBUG - 2016-09-28 13:16:23 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 13:16:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 13:16:26 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 13:16:26 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 13:16:26 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 13:16:26 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 13:16:26 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 13:16:26 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 13:16:26 --> Final output sent to browser
DEBUG - 2016-09-28 13:16:26 --> Total execution time: 3.3052
DEBUG - 2016-09-28 13:16:26 --> Config Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:26 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Router Class Initialized
ERROR - 2016-09-28 13:16:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 13:16:26 --> Config Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:26 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Router Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Config Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Hooks Class Initialized
ERROR - 2016-09-28 13:16:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 13:16:26 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:26 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Router Class Initialized
ERROR - 2016-09-28 13:16:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 13:16:26 --> Config Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:26 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Router Class Initialized
ERROR - 2016-09-28 13:16:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 13:16:26 --> Config Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:26 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Router Class Initialized
ERROR - 2016-09-28 13:16:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 13:16:26 --> Config Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:26 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Router Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Config Class Initialized
ERROR - 2016-09-28 13:16:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 13:16:26 --> Hooks Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Utf8 Class Initialized
DEBUG - 2016-09-28 13:16:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 13:16:26 --> URI Class Initialized
DEBUG - 2016-09-28 13:16:26 --> Router Class Initialized
ERROR - 2016-09-28 13:16:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:14:26 --> Config Class Initialized
DEBUG - 2016-09-28 14:14:26 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:14:26 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:14:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:14:26 --> URI Class Initialized
DEBUG - 2016-09-28 14:14:26 --> Router Class Initialized
DEBUG - 2016-09-28 14:14:26 --> Output Class Initialized
DEBUG - 2016-09-28 14:14:26 --> Security Class Initialized
DEBUG - 2016-09-28 14:14:26 --> Input Class Initialized
DEBUG - 2016-09-28 14:14:26 --> XSS Filtering completed
DEBUG - 2016-09-28 14:14:26 --> XSS Filtering completed
DEBUG - 2016-09-28 14:14:26 --> XSS Filtering completed
DEBUG - 2016-09-28 14:14:26 --> XSS Filtering completed
DEBUG - 2016-09-28 14:14:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:14:26 --> Language Class Initialized
DEBUG - 2016-09-28 14:14:26 --> Loader Class Initialized
DEBUG - 2016-09-28 14:14:26 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:14:26 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:14:26 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:14:26 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:14:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:14:26 --> Session Class Initialized
DEBUG - 2016-09-28 14:14:26 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:14:26 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:14:26 --> Session routines successfully run
ERROR - 2016-09-28 14:14:26 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:14:26 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:14:26 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:14:26 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:14:26 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:14:27 --> Table Class Initialized
DEBUG - 2016-09-28 14:14:27 --> Model Class Initialized
DEBUG - 2016-09-28 14:14:27 --> Model Class Initialized
DEBUG - 2016-09-28 14:14:27 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:14:27 --> Model Class Initialized
DEBUG - 2016-09-28 14:14:27 --> Controller Class Initialized
DEBUG - 2016-09-28 14:14:27 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:14:27 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:14:27 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:14:27 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:14:27 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:14:27 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:14:27 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-09-28 14:14:27 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-09-28 14:14:27 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:14:27 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-09-28 14:14:27 --> Final output sent to browser
DEBUG - 2016-09-28 14:14:27 --> Total execution time: 0.2860
DEBUG - 2016-09-28 14:26:03 --> Config Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:26:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:26:03 --> URI Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Router Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Output Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Security Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Input Class Initialized
DEBUG - 2016-09-28 14:26:03 --> XSS Filtering completed
DEBUG - 2016-09-28 14:26:03 --> XSS Filtering completed
DEBUG - 2016-09-28 14:26:03 --> XSS Filtering completed
DEBUG - 2016-09-28 14:26:03 --> XSS Filtering completed
DEBUG - 2016-09-28 14:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:26:03 --> Language Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Loader Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:26:03 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:26:03 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:26:03 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:26:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:26:03 --> Session Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:26:03 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Session routines successfully run
ERROR - 2016-09-28 14:26:03 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:26:03 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:26:03 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:26:03 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:26:03 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Table Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Model Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Model Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:26:03 --> Model Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Controller Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:26:03 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:26:03 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:26:03 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:26:03 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:26:03 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:26:03 --> File loaded: application/views/includes/admin/admin_bar.php
DEBUG - 2016-09-28 14:26:03 --> File loaded: application/views/admin/single_alumni_view.php
DEBUG - 2016-09-28 14:26:03 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:26:03 --> File loaded: application/views/includes/admin/edit_temp.php
DEBUG - 2016-09-28 14:26:03 --> Final output sent to browser
DEBUG - 2016-09-28 14:26:03 --> Total execution time: 0.1390
DEBUG - 2016-09-28 14:26:25 --> Config Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:26:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:26:25 --> URI Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Router Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Output Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Security Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Input Class Initialized
DEBUG - 2016-09-28 14:26:25 --> XSS Filtering completed
DEBUG - 2016-09-28 14:26:25 --> XSS Filtering completed
DEBUG - 2016-09-28 14:26:25 --> XSS Filtering completed
DEBUG - 2016-09-28 14:26:25 --> XSS Filtering completed
DEBUG - 2016-09-28 14:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:26:25 --> Language Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Loader Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:26:25 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:26:25 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:26:25 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:26:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:26:25 --> Session Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:26:25 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Session routines successfully run
ERROR - 2016-09-28 14:26:25 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:26:25 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:26:25 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:26:25 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:26:25 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Table Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Model Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Model Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:26:25 --> Model Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Controller Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:26:25 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:26:25 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:26:29 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:26:29 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:26:29 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:26:29 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:26:29 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:26:29 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:26:29 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:26:29 --> Final output sent to browser
DEBUG - 2016-09-28 14:26:29 --> Total execution time: 3.2800
DEBUG - 2016-09-28 14:26:29 --> Config Class Initialized
DEBUG - 2016-09-28 14:26:29 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:26:29 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:26:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:26:29 --> URI Class Initialized
DEBUG - 2016-09-28 14:26:29 --> Router Class Initialized
ERROR - 2016-09-28 14:26:29 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:26:29 --> Config Class Initialized
DEBUG - 2016-09-28 14:26:29 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:26:29 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:26:29 --> Config Class Initialized
DEBUG - 2016-09-28 14:26:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:26:29 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:26:29 --> URI Class Initialized
DEBUG - 2016-09-28 14:26:29 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:26:29 --> Config Class Initialized
DEBUG - 2016-09-28 14:26:29 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:26:29 --> Router Class Initialized
DEBUG - 2016-09-28 14:26:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:26:29 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:26:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:26:29 --> URI Class Initialized
ERROR - 2016-09-28 14:26:29 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:26:29 --> URI Class Initialized
DEBUG - 2016-09-28 14:26:29 --> Router Class Initialized
DEBUG - 2016-09-28 14:26:29 --> Router Class Initialized
ERROR - 2016-09-28 14:26:29 --> 404 Page Not Found --> application
ERROR - 2016-09-28 14:26:29 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:27:09 --> Config Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:27:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:27:09 --> URI Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Router Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Output Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Security Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Input Class Initialized
DEBUG - 2016-09-28 14:27:09 --> XSS Filtering completed
DEBUG - 2016-09-28 14:27:09 --> XSS Filtering completed
DEBUG - 2016-09-28 14:27:09 --> XSS Filtering completed
DEBUG - 2016-09-28 14:27:09 --> XSS Filtering completed
DEBUG - 2016-09-28 14:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:27:09 --> Language Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Loader Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:27:09 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:27:09 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:27:09 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:27:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:27:09 --> Session Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:27:09 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Session routines successfully run
ERROR - 2016-09-28 14:27:09 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:27:09 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:27:09 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:27:09 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:27:09 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Table Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Model Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Model Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:27:09 --> Model Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Controller Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:27:09 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:27:09 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:27:12 --> Config Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:27:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:27:12 --> URI Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Router Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Output Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Security Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Input Class Initialized
DEBUG - 2016-09-28 14:27:12 --> XSS Filtering completed
DEBUG - 2016-09-28 14:27:12 --> XSS Filtering completed
DEBUG - 2016-09-28 14:27:12 --> XSS Filtering completed
DEBUG - 2016-09-28 14:27:12 --> XSS Filtering completed
DEBUG - 2016-09-28 14:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:27:12 --> Language Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Loader Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:27:12 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:27:12 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:27:12 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:27:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:27:12 --> Session Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:27:12 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Session routines successfully run
ERROR - 2016-09-28 14:27:12 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:27:12 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:27:12 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:27:12 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:27:12 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Table Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Model Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Model Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:27:12 --> Model Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Controller Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:27:12 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:27:12 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:27:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:27:13 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:27:13 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:27:13 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:27:13 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:27:13 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:27:13 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:27:13 --> Final output sent to browser
DEBUG - 2016-09-28 14:27:13 --> Total execution time: 3.6000
DEBUG - 2016-09-28 14:27:15 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:27:15 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:27:15 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:27:15 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:27:15 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:27:15 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:27:15 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:27:15 --> Final output sent to browser
DEBUG - 2016-09-28 14:27:15 --> Total execution time: 3.4750
DEBUG - 2016-09-28 14:27:15 --> Config Class Initialized
DEBUG - 2016-09-28 14:27:15 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:27:15 --> Config Class Initialized
DEBUG - 2016-09-28 14:27:15 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:27:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:27:15 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:27:15 --> URI Class Initialized
DEBUG - 2016-09-28 14:27:15 --> Config Class Initialized
DEBUG - 2016-09-28 14:27:15 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:27:15 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:27:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:27:15 --> Router Class Initialized
DEBUG - 2016-09-28 14:27:15 --> URI Class Initialized
DEBUG - 2016-09-28 14:27:15 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:27:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:27:15 --> URI Class Initialized
DEBUG - 2016-09-28 14:27:15 --> Router Class Initialized
ERROR - 2016-09-28 14:27:15 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:27:15 --> Router Class Initialized
ERROR - 2016-09-28 14:27:15 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:27:15 --> Config Class Initialized
DEBUG - 2016-09-28 14:27:15 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:27:15 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:27:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:27:15 --> URI Class Initialized
DEBUG - 2016-09-28 14:27:15 --> Router Class Initialized
ERROR - 2016-09-28 14:27:15 --> 404 Page Not Found --> application
ERROR - 2016-09-28 14:27:15 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:32:02 --> Config Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:32:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:32:02 --> URI Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Router Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Output Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Security Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Input Class Initialized
DEBUG - 2016-09-28 14:32:02 --> XSS Filtering completed
DEBUG - 2016-09-28 14:32:02 --> XSS Filtering completed
DEBUG - 2016-09-28 14:32:02 --> XSS Filtering completed
DEBUG - 2016-09-28 14:32:02 --> XSS Filtering completed
DEBUG - 2016-09-28 14:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:32:02 --> Language Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Loader Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:32:02 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:32:02 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:32:02 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:32:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:32:02 --> Session Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:32:02 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Session routines successfully run
ERROR - 2016-09-28 14:32:02 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:32:02 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:32:02 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:32:02 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:32:02 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Table Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Model Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Model Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:32:02 --> Model Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Controller Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:32:02 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:32:02 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:32:05 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:32:05 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:32:05 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:32:05 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:32:05 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:32:05 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:32:05 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:32:05 --> Final output sent to browser
DEBUG - 2016-09-28 14:32:05 --> Total execution time: 3.4375
DEBUG - 2016-09-28 14:32:05 --> Config Class Initialized
DEBUG - 2016-09-28 14:32:05 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:32:05 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:32:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:32:05 --> URI Class Initialized
DEBUG - 2016-09-28 14:32:05 --> Router Class Initialized
ERROR - 2016-09-28 14:32:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:32:05 --> Config Class Initialized
DEBUG - 2016-09-28 14:32:05 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:32:05 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:32:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:32:05 --> URI Class Initialized
DEBUG - 2016-09-28 14:32:05 --> Config Class Initialized
DEBUG - 2016-09-28 14:32:05 --> Router Class Initialized
DEBUG - 2016-09-28 14:32:05 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:32:05 --> Utf8 Class Initialized
ERROR - 2016-09-28 14:32:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:32:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:32:05 --> URI Class Initialized
DEBUG - 2016-09-28 14:32:05 --> Router Class Initialized
ERROR - 2016-09-28 14:32:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:32:05 --> Config Class Initialized
DEBUG - 2016-09-28 14:32:05 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:32:05 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:32:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:32:05 --> URI Class Initialized
DEBUG - 2016-09-28 14:32:05 --> Router Class Initialized
ERROR - 2016-09-28 14:32:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:33:18 --> Config Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:33:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:33:18 --> URI Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Router Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Output Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Security Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Input Class Initialized
DEBUG - 2016-09-28 14:33:18 --> XSS Filtering completed
DEBUG - 2016-09-28 14:33:18 --> XSS Filtering completed
DEBUG - 2016-09-28 14:33:18 --> XSS Filtering completed
DEBUG - 2016-09-28 14:33:18 --> XSS Filtering completed
DEBUG - 2016-09-28 14:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:33:18 --> Language Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Loader Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:33:18 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:33:18 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:33:18 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:33:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:33:18 --> Session Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:33:18 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Session routines successfully run
ERROR - 2016-09-28 14:33:18 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:33:18 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:33:18 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:33:18 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:33:18 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Table Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Model Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Model Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:33:18 --> Model Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Controller Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:33:18 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:33:18 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:33:21 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:33:21 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:33:21 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:33:21 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:33:21 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:33:21 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:33:21 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:33:21 --> Final output sent to browser
DEBUG - 2016-09-28 14:33:21 --> Total execution time: 3.0625
DEBUG - 2016-09-28 14:33:21 --> Config Class Initialized
DEBUG - 2016-09-28 14:33:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:33:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:33:21 --> Config Class Initialized
DEBUG - 2016-09-28 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:33:21 --> URI Class Initialized
DEBUG - 2016-09-28 14:33:21 --> Config Class Initialized
DEBUG - 2016-09-28 14:33:21 --> Router Class Initialized
DEBUG - 2016-09-28 14:33:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:33:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:33:21 --> Hooks Class Initialized
ERROR - 2016-09-28 14:33:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:33:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:33:21 --> URI Class Initialized
DEBUG - 2016-09-28 14:33:21 --> Config Class Initialized
DEBUG - 2016-09-28 14:33:21 --> URI Class Initialized
DEBUG - 2016-09-28 14:33:21 --> Router Class Initialized
DEBUG - 2016-09-28 14:33:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:33:21 --> Router Class Initialized
ERROR - 2016-09-28 14:33:21 --> 404 Page Not Found --> application
ERROR - 2016-09-28 14:33:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:33:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:33:21 --> URI Class Initialized
DEBUG - 2016-09-28 14:33:21 --> Router Class Initialized
ERROR - 2016-09-28 14:33:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:39:17 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:17 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Router Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Output Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Security Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Input Class Initialized
DEBUG - 2016-09-28 14:39:17 --> XSS Filtering completed
DEBUG - 2016-09-28 14:39:17 --> XSS Filtering completed
DEBUG - 2016-09-28 14:39:17 --> XSS Filtering completed
DEBUG - 2016-09-28 14:39:17 --> XSS Filtering completed
DEBUG - 2016-09-28 14:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:39:17 --> Language Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Loader Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:39:17 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:39:17 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:39:17 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:39:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:39:17 --> Session Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:39:17 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Session routines successfully run
ERROR - 2016-09-28 14:39:17 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:39:17 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:39:17 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:39:17 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:39:17 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Table Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Model Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Model Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:39:17 --> Model Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Controller Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:39:17 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:39:17 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:39:20 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:39:20 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:39:20 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:39:20 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:39:20 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:39:20 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:39:20 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:39:20 --> Final output sent to browser
DEBUG - 2016-09-28 14:39:20 --> Total execution time: 3.1762
DEBUG - 2016-09-28 14:39:20 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:20 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:39:20 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:20 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:39:20 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:20 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:20 --> Router Class Initialized
ERROR - 2016-09-28 14:39:20 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:39:20 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:20 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:20 --> Router Class Initialized
ERROR - 2016-09-28 14:39:20 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:39:20 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:20 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:39:20 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:20 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:20 --> Router Class Initialized
ERROR - 2016-09-28 14:39:20 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:39:20 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:20 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:39:20 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:20 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:20 --> Router Class Initialized
ERROR - 2016-09-28 14:39:20 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:39:28 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:28 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Router Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Output Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Security Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Input Class Initialized
DEBUG - 2016-09-28 14:39:28 --> XSS Filtering completed
DEBUG - 2016-09-28 14:39:28 --> XSS Filtering completed
DEBUG - 2016-09-28 14:39:28 --> XSS Filtering completed
DEBUG - 2016-09-28 14:39:28 --> XSS Filtering completed
DEBUG - 2016-09-28 14:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:39:28 --> Language Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Loader Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:39:28 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:39:28 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:39:28 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:39:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:39:28 --> Session Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:39:28 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Session routines successfully run
ERROR - 2016-09-28 14:39:28 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:39:28 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:39:28 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:39:28 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:39:28 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Table Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Model Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Model Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:39:28 --> Model Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Controller Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:39:28 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:39:28 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:39:31 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:39:31 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:39:31 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:39:31 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:39:31 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:39:31 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:39:31 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:39:31 --> Final output sent to browser
DEBUG - 2016-09-28 14:39:31 --> Total execution time: 3.0922
DEBUG - 2016-09-28 14:39:31 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:31 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:39:31 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:31 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:39:31 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:31 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:31 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:31 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:39:31 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:31 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:31 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:31 --> Router Class Initialized
ERROR - 2016-09-28 14:39:31 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:39:31 --> Router Class Initialized
ERROR - 2016-09-28 14:39:31 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:39:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:31 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:31 --> Router Class Initialized
ERROR - 2016-09-28 14:39:31 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:39:31 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:31 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:39:31 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:31 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:31 --> Router Class Initialized
ERROR - 2016-09-28 14:39:31 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:39:39 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:39 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Router Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Output Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Security Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Input Class Initialized
DEBUG - 2016-09-28 14:39:39 --> XSS Filtering completed
DEBUG - 2016-09-28 14:39:39 --> XSS Filtering completed
DEBUG - 2016-09-28 14:39:39 --> XSS Filtering completed
DEBUG - 2016-09-28 14:39:39 --> XSS Filtering completed
DEBUG - 2016-09-28 14:39:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:39:39 --> Language Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Loader Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:39:39 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:39:39 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:39:39 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:39:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:39:39 --> Session Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:39:39 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Session routines successfully run
ERROR - 2016-09-28 14:39:39 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:39:39 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:39:39 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:39:39 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:39:39 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Table Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Model Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Model Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:39:39 --> Model Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Controller Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:39:39 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:39:39 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:39:43 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:39:43 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:39:43 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:39:43 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:39:43 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:39:43 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:39:43 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:39:43 --> Final output sent to browser
DEBUG - 2016-09-28 14:39:43 --> Total execution time: 3.3392
DEBUG - 2016-09-28 14:39:43 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:43 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:39:43 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:43 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:43 --> Router Class Initialized
ERROR - 2016-09-28 14:39:43 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:39:43 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:43 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:43 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:39:43 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:39:43 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:43 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:43 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:43 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:43 --> Router Class Initialized
ERROR - 2016-09-28 14:39:43 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:39:43 --> Router Class Initialized
DEBUG - 2016-09-28 14:39:43 --> Config Class Initialized
DEBUG - 2016-09-28 14:39:43 --> Hooks Class Initialized
ERROR - 2016-09-28 14:39:43 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:39:43 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:39:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:39:43 --> URI Class Initialized
DEBUG - 2016-09-28 14:39:43 --> Router Class Initialized
ERROR - 2016-09-28 14:39:43 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:40:04 --> Config Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:40:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:40:04 --> URI Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Router Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Output Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Security Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Input Class Initialized
DEBUG - 2016-09-28 14:40:04 --> XSS Filtering completed
DEBUG - 2016-09-28 14:40:04 --> XSS Filtering completed
DEBUG - 2016-09-28 14:40:04 --> XSS Filtering completed
DEBUG - 2016-09-28 14:40:04 --> XSS Filtering completed
DEBUG - 2016-09-28 14:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:40:04 --> Language Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Loader Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:40:04 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:40:04 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:40:04 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:40:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:40:04 --> Session Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:40:04 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Session routines successfully run
ERROR - 2016-09-28 14:40:04 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:40:04 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:40:04 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:40:04 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:40:04 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Table Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Model Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Model Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:40:04 --> Model Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Controller Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:40:04 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:40:04 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:40:06 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:40:06 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:40:06 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:40:06 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:40:06 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:40:06 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:40:06 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:40:06 --> Final output sent to browser
DEBUG - 2016-09-28 14:40:06 --> Total execution time: 2.7052
DEBUG - 2016-09-28 14:40:06 --> Config Class Initialized
DEBUG - 2016-09-28 14:40:06 --> Config Class Initialized
DEBUG - 2016-09-28 14:40:06 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:40:06 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:40:06 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:40:06 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:40:06 --> URI Class Initialized
DEBUG - 2016-09-28 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:40:06 --> Router Class Initialized
DEBUG - 2016-09-28 14:40:06 --> URI Class Initialized
ERROR - 2016-09-28 14:40:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:40:06 --> Router Class Initialized
ERROR - 2016-09-28 14:40:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:40:06 --> Config Class Initialized
DEBUG - 2016-09-28 14:40:06 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:40:06 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:40:06 --> URI Class Initialized
DEBUG - 2016-09-28 14:40:06 --> Config Class Initialized
DEBUG - 2016-09-28 14:40:06 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:40:06 --> Router Class Initialized
DEBUG - 2016-09-28 14:40:06 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:40:06 --> URI Class Initialized
DEBUG - 2016-09-28 14:40:06 --> Router Class Initialized
ERROR - 2016-09-28 14:40:06 --> 404 Page Not Found --> application
ERROR - 2016-09-28 14:40:06 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:40:17 --> Config Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:40:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:40:17 --> URI Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Router Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Output Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Security Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Input Class Initialized
DEBUG - 2016-09-28 14:40:17 --> XSS Filtering completed
DEBUG - 2016-09-28 14:40:17 --> XSS Filtering completed
DEBUG - 2016-09-28 14:40:17 --> XSS Filtering completed
DEBUG - 2016-09-28 14:40:17 --> XSS Filtering completed
DEBUG - 2016-09-28 14:40:17 --> XSS Filtering completed
DEBUG - 2016-09-28 14:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:40:17 --> Language Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Loader Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:40:17 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:40:17 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:40:17 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:40:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:40:17 --> Session Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:40:17 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Session routines successfully run
ERROR - 2016-09-28 14:40:17 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:40:17 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:40:17 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:40:17 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:40:17 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Table Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Model Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Model Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:40:17 --> Model Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Controller Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:40:17 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:40:17 --> Final output sent to browser
DEBUG - 2016-09-28 14:40:17 --> Total execution time: 0.2270
DEBUG - 2016-09-28 14:40:17 --> Config Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:40:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:40:17 --> URI Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Router Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Output Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Security Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Input Class Initialized
DEBUG - 2016-09-28 14:40:17 --> XSS Filtering completed
DEBUG - 2016-09-28 14:40:17 --> XSS Filtering completed
DEBUG - 2016-09-28 14:40:17 --> XSS Filtering completed
DEBUG - 2016-09-28 14:40:17 --> XSS Filtering completed
DEBUG - 2016-09-28 14:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:40:17 --> Language Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Loader Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:40:17 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:40:17 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:40:17 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:40:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:40:17 --> Session Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:40:17 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Session routines successfully run
ERROR - 2016-09-28 14:40:17 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:40:17 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:40:17 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:40:17 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:40:17 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Table Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Model Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Model Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:40:17 --> Model Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Controller Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:40:17 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:40:17 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:40:21 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:40:21 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:40:21 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:40:21 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:40:21 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:40:21 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:40:21 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:40:21 --> Final output sent to browser
DEBUG - 2016-09-28 14:40:21 --> Total execution time: 3.5390
DEBUG - 2016-09-28 14:40:21 --> Config Class Initialized
DEBUG - 2016-09-28 14:40:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:40:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:40:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:40:21 --> Config Class Initialized
DEBUG - 2016-09-28 14:40:21 --> Config Class Initialized
DEBUG - 2016-09-28 14:40:21 --> URI Class Initialized
DEBUG - 2016-09-28 14:40:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:40:21 --> Config Class Initialized
DEBUG - 2016-09-28 14:40:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:40:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:40:21 --> Router Class Initialized
DEBUG - 2016-09-28 14:40:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:40:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:40:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:40:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:40:21 --> Utf8 Class Initialized
ERROR - 2016-09-28 14:40:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:40:21 --> URI Class Initialized
DEBUG - 2016-09-28 14:40:21 --> URI Class Initialized
DEBUG - 2016-09-28 14:40:21 --> Router Class Initialized
DEBUG - 2016-09-28 14:40:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:40:21 --> Router Class Initialized
DEBUG - 2016-09-28 14:40:21 --> URI Class Initialized
ERROR - 2016-09-28 14:40:21 --> 404 Page Not Found --> application
ERROR - 2016-09-28 14:40:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:40:21 --> Router Class Initialized
ERROR - 2016-09-28 14:40:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:41:33 --> Config Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:41:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:41:33 --> URI Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Router Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Output Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Security Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Input Class Initialized
DEBUG - 2016-09-28 14:41:33 --> XSS Filtering completed
DEBUG - 2016-09-28 14:41:33 --> XSS Filtering completed
DEBUG - 2016-09-28 14:41:33 --> XSS Filtering completed
DEBUG - 2016-09-28 14:41:33 --> XSS Filtering completed
DEBUG - 2016-09-28 14:41:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:41:33 --> Language Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Loader Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:41:33 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:41:33 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:41:33 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:41:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:41:33 --> Session Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:41:33 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Session routines successfully run
ERROR - 2016-09-28 14:41:33 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:41:33 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:41:33 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:41:33 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:41:33 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Table Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Model Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Model Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:41:33 --> Model Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Controller Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:41:33 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:41:33 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-28 14:41:36 --> Severity: Notice  --> Undefined property: Admin::$paginaton C:\xampp\htdocs\www\alumni\application\controllers\Admin.php 142
DEBUG - 2016-09-28 14:41:36 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:41:36 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:41:36 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:41:36 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:41:36 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:41:36 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:41:36 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:41:36 --> Final output sent to browser
DEBUG - 2016-09-28 14:41:36 --> Total execution time: 3.1300
DEBUG - 2016-09-28 14:41:36 --> Config Class Initialized
DEBUG - 2016-09-28 14:41:36 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:41:36 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:41:36 --> URI Class Initialized
DEBUG - 2016-09-28 14:41:36 --> Router Class Initialized
ERROR - 2016-09-28 14:41:36 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:41:36 --> Config Class Initialized
DEBUG - 2016-09-28 14:41:36 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:41:36 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:41:36 --> Config Class Initialized
DEBUG - 2016-09-28 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:41:36 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:41:36 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:41:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:41:36 --> URI Class Initialized
DEBUG - 2016-09-28 14:41:36 --> Router Class Initialized
DEBUG - 2016-09-28 14:41:36 --> Config Class Initialized
DEBUG - 2016-09-28 14:41:36 --> URI Class Initialized
DEBUG - 2016-09-28 14:41:36 --> Router Class Initialized
ERROR - 2016-09-28 14:41:36 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:41:36 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:41:36 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:41:36 --> UTF-8 Support Enabled
ERROR - 2016-09-28 14:41:36 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:41:36 --> URI Class Initialized
DEBUG - 2016-09-28 14:41:36 --> Router Class Initialized
ERROR - 2016-09-28 14:41:36 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:41:37 --> Config Class Initialized
DEBUG - 2016-09-28 14:41:37 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:41:37 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:41:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:41:37 --> URI Class Initialized
DEBUG - 2016-09-28 14:41:37 --> Router Class Initialized
ERROR - 2016-09-28 14:41:37 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:41:57 --> Config Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:41:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:41:57 --> URI Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Router Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Output Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Security Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Input Class Initialized
DEBUG - 2016-09-28 14:41:57 --> XSS Filtering completed
DEBUG - 2016-09-28 14:41:57 --> XSS Filtering completed
DEBUG - 2016-09-28 14:41:57 --> XSS Filtering completed
DEBUG - 2016-09-28 14:41:57 --> XSS Filtering completed
DEBUG - 2016-09-28 14:41:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:41:57 --> Language Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Loader Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:41:57 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:41:57 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:41:57 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:41:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:41:57 --> Session Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:41:57 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Session routines successfully run
ERROR - 2016-09-28 14:41:57 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:41:57 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:41:57 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:41:57 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:41:57 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Table Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Model Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Model Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:41:57 --> Model Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Controller Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:41:57 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:41:57 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:42:00 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:42:00 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:42:00 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:42:00 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:42:00 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:42:00 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:42:00 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:42:00 --> Final output sent to browser
DEBUG - 2016-09-28 14:42:00 --> Total execution time: 3.2200
DEBUG - 2016-09-28 14:42:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:42:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:42:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:42:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:42:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:42:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:42:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:42:00 --> Router Class Initialized
ERROR - 2016-09-28 14:42:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:42:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:42:00 --> Router Class Initialized
DEBUG - 2016-09-28 14:42:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:42:00 --> Hooks Class Initialized
ERROR - 2016-09-28 14:42:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:42:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:42:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:42:00 --> Router Class Initialized
ERROR - 2016-09-28 14:42:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:42:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:42:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:42:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:42:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:42:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:42:00 --> Router Class Initialized
ERROR - 2016-09-28 14:42:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:42:23 --> Config Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:42:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:42:23 --> URI Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Router Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Output Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Security Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Input Class Initialized
DEBUG - 2016-09-28 14:42:23 --> XSS Filtering completed
DEBUG - 2016-09-28 14:42:23 --> XSS Filtering completed
DEBUG - 2016-09-28 14:42:23 --> XSS Filtering completed
DEBUG - 2016-09-28 14:42:23 --> XSS Filtering completed
DEBUG - 2016-09-28 14:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:42:23 --> Language Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Loader Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:42:23 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:42:23 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:42:23 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:42:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:42:23 --> Session Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:42:23 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Session routines successfully run
ERROR - 2016-09-28 14:42:23 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:42:23 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:42:23 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:42:23 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:42:23 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Table Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Model Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Model Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:42:23 --> Model Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Controller Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:42:23 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:42:23 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:42:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:42:26 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:42:26 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:42:26 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:42:26 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:42:26 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:42:26 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:42:26 --> Final output sent to browser
DEBUG - 2016-09-28 14:42:26 --> Total execution time: 3.3700
DEBUG - 2016-09-28 14:42:27 --> Config Class Initialized
DEBUG - 2016-09-28 14:42:27 --> Config Class Initialized
DEBUG - 2016-09-28 14:42:27 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:42:27 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:42:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:42:27 --> URI Class Initialized
DEBUG - 2016-09-28 14:42:27 --> Router Class Initialized
ERROR - 2016-09-28 14:42:27 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:42:27 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:42:27 --> Config Class Initialized
DEBUG - 2016-09-28 14:42:27 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:42:27 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:42:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:42:27 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:42:27 --> URI Class Initialized
DEBUG - 2016-09-28 14:42:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:42:27 --> Config Class Initialized
DEBUG - 2016-09-28 14:42:27 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:42:27 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:42:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:42:27 --> URI Class Initialized
DEBUG - 2016-09-28 14:42:27 --> Router Class Initialized
DEBUG - 2016-09-28 14:42:27 --> Router Class Initialized
ERROR - 2016-09-28 14:42:27 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:42:27 --> URI Class Initialized
ERROR - 2016-09-28 14:42:27 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:42:27 --> Router Class Initialized
ERROR - 2016-09-28 14:42:27 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:43:38 --> Config Class Initialized
DEBUG - 2016-09-28 14:43:38 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:43:38 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:43:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:43:38 --> URI Class Initialized
DEBUG - 2016-09-28 14:43:38 --> Router Class Initialized
DEBUG - 2016-09-28 14:43:38 --> Output Class Initialized
DEBUG - 2016-09-28 14:43:38 --> Security Class Initialized
DEBUG - 2016-09-28 14:43:38 --> Input Class Initialized
DEBUG - 2016-09-28 14:43:38 --> XSS Filtering completed
DEBUG - 2016-09-28 14:43:38 --> XSS Filtering completed
DEBUG - 2016-09-28 14:43:38 --> XSS Filtering completed
DEBUG - 2016-09-28 14:43:38 --> XSS Filtering completed
DEBUG - 2016-09-28 14:43:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:43:38 --> Language Class Initialized
DEBUG - 2016-09-28 14:43:38 --> Loader Class Initialized
DEBUG - 2016-09-28 14:43:38 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:43:38 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:43:38 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:43:38 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:43:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:43:38 --> Session Class Initialized
DEBUG - 2016-09-28 14:43:38 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:43:38 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:43:38 --> Session routines successfully run
ERROR - 2016-09-28 14:43:38 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:43:38 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:43:38 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:43:39 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:43:39 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:43:39 --> Table Class Initialized
DEBUG - 2016-09-28 14:43:39 --> Model Class Initialized
DEBUG - 2016-09-28 14:43:39 --> Model Class Initialized
DEBUG - 2016-09-28 14:43:39 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:43:39 --> Model Class Initialized
DEBUG - 2016-09-28 14:43:39 --> Controller Class Initialized
DEBUG - 2016-09-28 14:43:39 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:43:39 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:43:39 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:43:42 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:43:42 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:43:42 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:43:42 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:43:42 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:43:42 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:43:42 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:43:42 --> Final output sent to browser
DEBUG - 2016-09-28 14:43:42 --> Total execution time: 3.2200
DEBUG - 2016-09-28 14:43:42 --> Config Class Initialized
DEBUG - 2016-09-28 14:43:42 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:43:42 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:43:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:43:42 --> URI Class Initialized
DEBUG - 2016-09-28 14:43:42 --> Router Class Initialized
ERROR - 2016-09-28 14:43:42 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:43:42 --> Config Class Initialized
DEBUG - 2016-09-28 14:43:42 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:43:42 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:43:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:43:42 --> URI Class Initialized
DEBUG - 2016-09-28 14:43:42 --> Router Class Initialized
ERROR - 2016-09-28 14:43:42 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:43:42 --> Config Class Initialized
DEBUG - 2016-09-28 14:43:42 --> Config Class Initialized
DEBUG - 2016-09-28 14:43:42 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:43:42 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:43:42 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:43:42 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:43:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:43:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:43:42 --> URI Class Initialized
DEBUG - 2016-09-28 14:43:42 --> Router Class Initialized
ERROR - 2016-09-28 14:43:42 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:43:42 --> URI Class Initialized
DEBUG - 2016-09-28 14:43:42 --> Router Class Initialized
ERROR - 2016-09-28 14:43:42 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:44:10 --> Config Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:44:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:44:10 --> URI Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Router Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Output Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Security Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Input Class Initialized
DEBUG - 2016-09-28 14:44:10 --> XSS Filtering completed
DEBUG - 2016-09-28 14:44:10 --> XSS Filtering completed
DEBUG - 2016-09-28 14:44:10 --> XSS Filtering completed
DEBUG - 2016-09-28 14:44:10 --> XSS Filtering completed
DEBUG - 2016-09-28 14:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:44:10 --> Language Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Loader Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:44:10 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:44:10 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:44:10 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:44:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:44:10 --> Session Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:44:10 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Session routines successfully run
ERROR - 2016-09-28 14:44:10 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:44:10 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:44:10 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:44:10 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:44:10 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Table Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Model Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Model Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:44:10 --> Model Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Controller Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:44:10 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:44:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:44:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:44:13 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:44:13 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:44:13 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:44:13 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:44:13 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:44:13 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:44:13 --> Final output sent to browser
DEBUG - 2016-09-28 14:44:13 --> Total execution time: 3.1800
DEBUG - 2016-09-28 14:44:13 --> Config Class Initialized
DEBUG - 2016-09-28 14:44:13 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:44:13 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:44:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:44:13 --> URI Class Initialized
DEBUG - 2016-09-28 14:44:13 --> Router Class Initialized
ERROR - 2016-09-28 14:44:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:44:13 --> Config Class Initialized
DEBUG - 2016-09-28 14:44:13 --> Config Class Initialized
DEBUG - 2016-09-28 14:44:13 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:44:13 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:44:13 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:44:13 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:44:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:44:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:44:13 --> URI Class Initialized
DEBUG - 2016-09-28 14:44:13 --> Router Class Initialized
DEBUG - 2016-09-28 14:44:13 --> URI Class Initialized
DEBUG - 2016-09-28 14:44:13 --> Router Class Initialized
ERROR - 2016-09-28 14:44:13 --> 404 Page Not Found --> application
ERROR - 2016-09-28 14:44:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:44:13 --> Config Class Initialized
DEBUG - 2016-09-28 14:44:13 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:44:13 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:44:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:44:13 --> URI Class Initialized
DEBUG - 2016-09-28 14:44:13 --> Router Class Initialized
ERROR - 2016-09-28 14:44:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:46:57 --> Config Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:46:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:46:57 --> URI Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Router Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Output Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Security Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Input Class Initialized
DEBUG - 2016-09-28 14:46:57 --> XSS Filtering completed
DEBUG - 2016-09-28 14:46:57 --> XSS Filtering completed
DEBUG - 2016-09-28 14:46:57 --> XSS Filtering completed
DEBUG - 2016-09-28 14:46:57 --> XSS Filtering completed
DEBUG - 2016-09-28 14:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:46:57 --> Language Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Loader Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:46:57 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:46:57 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:46:57 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:46:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:46:57 --> Session Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:46:57 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Session routines successfully run
ERROR - 2016-09-28 14:46:57 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:46:57 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:46:57 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:46:57 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:46:57 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Table Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Model Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Model Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:46:57 --> Model Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Controller Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:46:57 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:46:57 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:47:00 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:47:00 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:47:00 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:47:00 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:47:00 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:47:00 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:47:00 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:47:00 --> Final output sent to browser
DEBUG - 2016-09-28 14:47:00 --> Total execution time: 3.2300
DEBUG - 2016-09-28 14:47:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:47:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:47:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Router Class Initialized
ERROR - 2016-09-28 14:47:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:47:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:47:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:47:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Router Class Initialized
ERROR - 2016-09-28 14:47:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:47:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:47:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:47:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Router Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:47:00 --> UTF-8 Support Enabled
ERROR - 2016-09-28 14:47:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:47:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Router Class Initialized
ERROR - 2016-09-28 14:47:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:47:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:47:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:47:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:47:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:47:00 --> Router Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:47:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:47:00 --> URI Class Initialized
ERROR - 2016-09-28 14:47:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:47:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Router Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Router Class Initialized
ERROR - 2016-09-28 14:47:00 --> 404 Page Not Found --> application
ERROR - 2016-09-28 14:47:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:47:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:47:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:47:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:47:00 --> Router Class Initialized
ERROR - 2016-09-28 14:47:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:49:31 --> Config Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:49:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:49:31 --> URI Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Router Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Output Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Security Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Input Class Initialized
DEBUG - 2016-09-28 14:49:31 --> XSS Filtering completed
DEBUG - 2016-09-28 14:49:31 --> XSS Filtering completed
DEBUG - 2016-09-28 14:49:31 --> XSS Filtering completed
DEBUG - 2016-09-28 14:49:31 --> XSS Filtering completed
DEBUG - 2016-09-28 14:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:49:31 --> Language Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Loader Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:49:31 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:49:31 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:49:31 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:49:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:49:31 --> Session Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:49:31 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Session routines successfully run
ERROR - 2016-09-28 14:49:31 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:49:31 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:49:31 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:49:31 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:49:31 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Table Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Model Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Model Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:49:31 --> Model Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Controller Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:49:31 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:49:31 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:49:35 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:49:35 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:49:35 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:49:35 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:49:35 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:49:35 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:49:35 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:49:35 --> Final output sent to browser
DEBUG - 2016-09-28 14:49:35 --> Total execution time: 3.4100
DEBUG - 2016-09-28 14:49:35 --> Config Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:49:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:49:35 --> URI Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Router Class Initialized
ERROR - 2016-09-28 14:49:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:49:35 --> Config Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:49:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:49:35 --> URI Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Router Class Initialized
ERROR - 2016-09-28 14:49:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:49:35 --> Config Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:49:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:49:35 --> URI Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Router Class Initialized
ERROR - 2016-09-28 14:49:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:49:35 --> Config Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:49:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:49:35 --> URI Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Router Class Initialized
ERROR - 2016-09-28 14:49:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:49:35 --> Config Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:49:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:49:35 --> URI Class Initialized
DEBUG - 2016-09-28 14:49:35 --> Router Class Initialized
ERROR - 2016-09-28 14:49:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:49:49 --> Config Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:49:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:49:49 --> URI Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Router Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Output Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Security Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Input Class Initialized
DEBUG - 2016-09-28 14:49:49 --> XSS Filtering completed
DEBUG - 2016-09-28 14:49:49 --> XSS Filtering completed
DEBUG - 2016-09-28 14:49:49 --> XSS Filtering completed
DEBUG - 2016-09-28 14:49:49 --> XSS Filtering completed
DEBUG - 2016-09-28 14:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:49:49 --> Language Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Loader Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:49:49 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:49:49 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:49:49 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:49:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:49:49 --> Session Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:49:49 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Session routines successfully run
ERROR - 2016-09-28 14:49:49 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:49:49 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:49:49 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:49:49 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:49:49 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Table Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Model Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Model Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:49:49 --> Model Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Controller Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:49:49 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:49:49 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:49:52 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:49:52 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:49:52 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:49:52 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:49:52 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:49:52 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:49:52 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:49:52 --> Final output sent to browser
DEBUG - 2016-09-28 14:49:52 --> Total execution time: 3.0200
DEBUG - 2016-09-28 14:49:52 --> Config Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:49:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:49:52 --> URI Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Router Class Initialized
ERROR - 2016-09-28 14:49:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:49:52 --> Config Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:49:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:49:52 --> URI Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Router Class Initialized
ERROR - 2016-09-28 14:49:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:49:52 --> Config Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:49:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:49:52 --> URI Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Router Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Config Class Initialized
ERROR - 2016-09-28 14:49:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:49:52 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:49:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:49:52 --> URI Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Router Class Initialized
ERROR - 2016-09-28 14:49:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:49:52 --> Config Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:49:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:49:52 --> URI Class Initialized
DEBUG - 2016-09-28 14:49:52 --> Router Class Initialized
ERROR - 2016-09-28 14:49:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:50:28 --> Config Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:50:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:50:28 --> URI Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Router Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Output Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Security Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Input Class Initialized
DEBUG - 2016-09-28 14:50:28 --> XSS Filtering completed
DEBUG - 2016-09-28 14:50:28 --> XSS Filtering completed
DEBUG - 2016-09-28 14:50:28 --> XSS Filtering completed
DEBUG - 2016-09-28 14:50:28 --> XSS Filtering completed
DEBUG - 2016-09-28 14:50:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:50:28 --> Language Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Loader Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:50:28 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:50:28 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:50:28 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:50:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:50:28 --> Session Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:50:28 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Session routines successfully run
ERROR - 2016-09-28 14:50:28 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:50:28 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:50:28 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:50:28 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:50:28 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Table Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Model Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Model Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:50:28 --> Model Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Controller Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:50:28 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:50:28 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:50:31 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:50:31 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:50:31 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:50:31 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:50:31 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:50:31 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:50:31 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:50:31 --> Final output sent to browser
DEBUG - 2016-09-28 14:50:31 --> Total execution time: 3.1675
DEBUG - 2016-09-28 14:50:31 --> Config Class Initialized
DEBUG - 2016-09-28 14:50:31 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:50:31 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:50:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:50:31 --> URI Class Initialized
DEBUG - 2016-09-28 14:50:31 --> Router Class Initialized
ERROR - 2016-09-28 14:50:31 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:50:31 --> Config Class Initialized
DEBUG - 2016-09-28 14:50:31 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:50:31 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:50:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:50:31 --> URI Class Initialized
DEBUG - 2016-09-28 14:50:31 --> Router Class Initialized
DEBUG - 2016-09-28 14:50:31 --> Config Class Initialized
ERROR - 2016-09-28 14:50:31 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:50:31 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:50:31 --> Config Class Initialized
DEBUG - 2016-09-28 14:50:31 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:50:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:50:31 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:50:31 --> URI Class Initialized
DEBUG - 2016-09-28 14:50:31 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:50:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:50:31 --> Router Class Initialized
DEBUG - 2016-09-28 14:50:31 --> URI Class Initialized
DEBUG - 2016-09-28 14:50:31 --> Router Class Initialized
ERROR - 2016-09-28 14:50:31 --> 404 Page Not Found --> application
ERROR - 2016-09-28 14:50:31 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:51:14 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:14 --> URI Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Router Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Output Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Security Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Input Class Initialized
DEBUG - 2016-09-28 14:51:14 --> XSS Filtering completed
DEBUG - 2016-09-28 14:51:14 --> XSS Filtering completed
DEBUG - 2016-09-28 14:51:14 --> XSS Filtering completed
DEBUG - 2016-09-28 14:51:14 --> XSS Filtering completed
DEBUG - 2016-09-28 14:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:51:14 --> Language Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Loader Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:51:14 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:51:14 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:51:14 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:51:14 --> Session Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:51:14 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Session routines successfully run
ERROR - 2016-09-28 14:51:14 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:51:14 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:51:14 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:51:14 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:51:14 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Table Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Model Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Model Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:51:14 --> Model Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Controller Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:51:14 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:51:14 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:51:17 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:51:17 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:51:17 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:51:17 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:51:17 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:51:17 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:51:17 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:51:17 --> Final output sent to browser
DEBUG - 2016-09-28 14:51:17 --> Total execution time: 3.2625
DEBUG - 2016-09-28 14:51:17 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:17 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:17 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:17 --> URI Class Initialized
DEBUG - 2016-09-28 14:51:17 --> Router Class Initialized
ERROR - 2016-09-28 14:51:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:51:17 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:17 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:17 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:17 --> URI Class Initialized
DEBUG - 2016-09-28 14:51:17 --> Router Class Initialized
ERROR - 2016-09-28 14:51:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:51:17 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:17 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:17 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:17 --> URI Class Initialized
DEBUG - 2016-09-28 14:51:18 --> Router Class Initialized
DEBUG - 2016-09-28 14:51:18 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:18 --> Hooks Class Initialized
ERROR - 2016-09-28 14:51:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:51:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:18 --> URI Class Initialized
DEBUG - 2016-09-28 14:51:18 --> Router Class Initialized
ERROR - 2016-09-28 14:51:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:51:35 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:35 --> URI Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Router Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Output Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Security Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Input Class Initialized
DEBUG - 2016-09-28 14:51:35 --> XSS Filtering completed
DEBUG - 2016-09-28 14:51:35 --> XSS Filtering completed
DEBUG - 2016-09-28 14:51:35 --> XSS Filtering completed
DEBUG - 2016-09-28 14:51:35 --> XSS Filtering completed
DEBUG - 2016-09-28 14:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:51:35 --> Language Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Loader Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:51:35 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:51:35 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:51:35 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:51:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:51:35 --> Session Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:51:35 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Session routines successfully run
ERROR - 2016-09-28 14:51:35 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:51:35 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:51:35 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:51:35 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:51:35 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Table Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Model Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Model Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:51:35 --> Model Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Controller Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:51:35 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:51:35 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:51:38 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:51:38 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:51:38 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:51:38 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:51:38 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:51:38 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:51:38 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:51:38 --> Final output sent to browser
DEBUG - 2016-09-28 14:51:38 --> Total execution time: 3.2350
DEBUG - 2016-09-28 14:51:38 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:38 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:38 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:38 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:38 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:38 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:38 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:38 --> URI Class Initialized
DEBUG - 2016-09-28 14:51:38 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:38 --> Router Class Initialized
ERROR - 2016-09-28 14:51:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:51:38 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:38 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:38 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:38 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:38 --> URI Class Initialized
DEBUG - 2016-09-28 14:51:38 --> URI Class Initialized
DEBUG - 2016-09-28 14:51:38 --> Router Class Initialized
DEBUG - 2016-09-28 14:51:38 --> Router Class Initialized
ERROR - 2016-09-28 14:51:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:51:38 --> URI Class Initialized
ERROR - 2016-09-28 14:51:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:51:38 --> Router Class Initialized
ERROR - 2016-09-28 14:51:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:51:55 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:55 --> URI Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Router Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Output Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Security Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Input Class Initialized
DEBUG - 2016-09-28 14:51:55 --> XSS Filtering completed
DEBUG - 2016-09-28 14:51:55 --> XSS Filtering completed
DEBUG - 2016-09-28 14:51:55 --> XSS Filtering completed
DEBUG - 2016-09-28 14:51:55 --> XSS Filtering completed
DEBUG - 2016-09-28 14:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:51:55 --> Language Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Loader Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:51:55 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:51:55 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:51:55 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:51:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:51:55 --> Session Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:51:55 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Session routines successfully run
ERROR - 2016-09-28 14:51:55 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:51:55 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:51:55 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:51:55 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:51:55 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Table Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Model Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Model Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:51:55 --> Model Class Initialized
DEBUG - 2016-09-28 14:51:55 --> Controller Class Initialized
DEBUG - 2016-09-28 14:51:56 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:51:56 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:51:56 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:51:59 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:51:59 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:51:59 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:51:59 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:51:59 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:51:59 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:51:59 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:51:59 --> Final output sent to browser
DEBUG - 2016-09-28 14:51:59 --> Total execution time: 3.5925
DEBUG - 2016-09-28 14:51:59 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:59 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:59 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:59 --> URI Class Initialized
DEBUG - 2016-09-28 14:51:59 --> Router Class Initialized
ERROR - 2016-09-28 14:51:59 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:51:59 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:59 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:59 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:59 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:59 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:59 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:59 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:59 --> URI Class Initialized
DEBUG - 2016-09-28 14:51:59 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:59 --> Router Class Initialized
DEBUG - 2016-09-28 14:51:59 --> URI Class Initialized
DEBUG - 2016-09-28 14:51:59 --> Router Class Initialized
ERROR - 2016-09-28 14:51:59 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:51:59 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:59 --> URI Class Initialized
ERROR - 2016-09-28 14:51:59 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:51:59 --> Router Class Initialized
ERROR - 2016-09-28 14:51:59 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:51:59 --> Config Class Initialized
DEBUG - 2016-09-28 14:51:59 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:51:59 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:51:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:51:59 --> URI Class Initialized
DEBUG - 2016-09-28 14:51:59 --> Router Class Initialized
ERROR - 2016-09-28 14:51:59 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:52:07 --> Config Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:52:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:52:07 --> URI Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Router Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Output Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Security Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Input Class Initialized
DEBUG - 2016-09-28 14:52:07 --> XSS Filtering completed
DEBUG - 2016-09-28 14:52:07 --> XSS Filtering completed
DEBUG - 2016-09-28 14:52:07 --> XSS Filtering completed
DEBUG - 2016-09-28 14:52:07 --> XSS Filtering completed
DEBUG - 2016-09-28 14:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:52:07 --> Language Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Loader Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:52:07 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:52:07 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:52:07 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:52:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:52:07 --> Session Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:52:07 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Session routines successfully run
ERROR - 2016-09-28 14:52:07 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:52:07 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:52:07 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:52:07 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:52:07 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Table Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Model Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Model Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:52:07 --> Model Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Controller Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:52:07 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:52:07 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:52:10 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:52:10 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:52:10 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:52:10 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:52:10 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:52:10 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:52:10 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:52:10 --> Final output sent to browser
DEBUG - 2016-09-28 14:52:10 --> Total execution time: 3.2100
DEBUG - 2016-09-28 14:52:10 --> Config Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:52:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:52:10 --> URI Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Router Class Initialized
ERROR - 2016-09-28 14:52:10 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:52:10 --> Config Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Config Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:52:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:52:10 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:52:10 --> URI Class Initialized
DEBUG - 2016-09-28 14:52:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:52:10 --> URI Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Router Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Router Class Initialized
ERROR - 2016-09-28 14:52:10 --> 404 Page Not Found --> application
ERROR - 2016-09-28 14:52:10 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:52:10 --> Config Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:52:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:52:10 --> URI Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Router Class Initialized
ERROR - 2016-09-28 14:52:10 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:52:10 --> Config Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:52:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:52:10 --> URI Class Initialized
DEBUG - 2016-09-28 14:52:10 --> Router Class Initialized
ERROR - 2016-09-28 14:52:10 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:52:29 --> Config Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:52:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:52:29 --> URI Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Router Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Output Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Security Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Input Class Initialized
DEBUG - 2016-09-28 14:52:29 --> XSS Filtering completed
DEBUG - 2016-09-28 14:52:29 --> XSS Filtering completed
DEBUG - 2016-09-28 14:52:29 --> XSS Filtering completed
DEBUG - 2016-09-28 14:52:29 --> XSS Filtering completed
DEBUG - 2016-09-28 14:52:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:52:29 --> Language Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Loader Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:52:29 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:52:29 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:52:29 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:52:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:52:29 --> Session Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:52:29 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Session routines successfully run
ERROR - 2016-09-28 14:52:29 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:52:29 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:52:29 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:52:29 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:52:29 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Table Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Model Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Model Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:52:29 --> Model Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Controller Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:52:29 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:52:29 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:52:32 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:52:32 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:52:32 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:52:32 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:52:32 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:52:32 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:52:32 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:52:32 --> Final output sent to browser
DEBUG - 2016-09-28 14:52:32 --> Total execution time: 3.2050
DEBUG - 2016-09-28 14:52:32 --> Config Class Initialized
DEBUG - 2016-09-28 14:52:32 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:52:32 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:52:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:52:32 --> URI Class Initialized
DEBUG - 2016-09-28 14:52:32 --> Router Class Initialized
ERROR - 2016-09-28 14:52:32 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:52:32 --> Config Class Initialized
DEBUG - 2016-09-28 14:52:32 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:52:32 --> Config Class Initialized
DEBUG - 2016-09-28 14:52:32 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:52:32 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:52:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:52:32 --> URI Class Initialized
DEBUG - 2016-09-28 14:52:32 --> Router Class Initialized
ERROR - 2016-09-28 14:52:32 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:52:32 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:52:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:52:32 --> URI Class Initialized
DEBUG - 2016-09-28 14:52:32 --> Router Class Initialized
ERROR - 2016-09-28 14:52:32 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:52:32 --> Config Class Initialized
DEBUG - 2016-09-28 14:52:32 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:52:32 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:52:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:52:32 --> URI Class Initialized
DEBUG - 2016-09-28 14:52:32 --> Router Class Initialized
ERROR - 2016-09-28 14:52:32 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:53:15 --> Config Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:53:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:53:15 --> URI Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Router Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Output Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Security Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Input Class Initialized
DEBUG - 2016-09-28 14:53:15 --> XSS Filtering completed
DEBUG - 2016-09-28 14:53:15 --> XSS Filtering completed
DEBUG - 2016-09-28 14:53:15 --> XSS Filtering completed
DEBUG - 2016-09-28 14:53:15 --> XSS Filtering completed
DEBUG - 2016-09-28 14:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:53:15 --> Language Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Loader Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:53:15 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:53:15 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:53:15 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:53:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:53:15 --> Session Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:53:15 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Session routines successfully run
ERROR - 2016-09-28 14:53:15 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:53:15 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:53:15 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:53:15 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:53:15 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Table Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Model Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Model Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:53:15 --> Model Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Controller Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:53:15 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:53:15 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:53:18 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:53:18 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:53:18 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:53:18 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:53:18 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:53:18 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:53:18 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:53:18 --> Final output sent to browser
DEBUG - 2016-09-28 14:53:18 --> Total execution time: 3.1050
DEBUG - 2016-09-28 14:53:18 --> Config Class Initialized
DEBUG - 2016-09-28 14:53:18 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:53:18 --> Config Class Initialized
DEBUG - 2016-09-28 14:53:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:53:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:53:18 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:53:18 --> URI Class Initialized
DEBUG - 2016-09-28 14:53:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:53:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:53:18 --> Router Class Initialized
DEBUG - 2016-09-28 14:53:18 --> Config Class Initialized
DEBUG - 2016-09-28 14:53:18 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:53:18 --> URI Class Initialized
ERROR - 2016-09-28 14:53:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:53:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:53:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:53:18 --> Router Class Initialized
DEBUG - 2016-09-28 14:53:18 --> URI Class Initialized
ERROR - 2016-09-28 14:53:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:53:18 --> Router Class Initialized
ERROR - 2016-09-28 14:53:19 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:53:19 --> Config Class Initialized
DEBUG - 2016-09-28 14:53:19 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:53:19 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:53:19 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:53:19 --> URI Class Initialized
DEBUG - 2016-09-28 14:53:19 --> Router Class Initialized
ERROR - 2016-09-28 14:53:19 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:53:41 --> Config Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:53:41 --> URI Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Router Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Output Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Security Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Input Class Initialized
DEBUG - 2016-09-28 14:53:41 --> XSS Filtering completed
DEBUG - 2016-09-28 14:53:41 --> XSS Filtering completed
DEBUG - 2016-09-28 14:53:41 --> XSS Filtering completed
DEBUG - 2016-09-28 14:53:41 --> XSS Filtering completed
DEBUG - 2016-09-28 14:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:53:41 --> Language Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Loader Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:53:41 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:53:41 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:53:41 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:53:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:53:41 --> Session Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:53:41 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Session routines successfully run
ERROR - 2016-09-28 14:53:41 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:53:41 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:53:41 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:53:41 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:53:41 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Table Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Model Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Model Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:53:41 --> Model Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Controller Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:53:41 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:53:41 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:53:44 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:53:44 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:53:44 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:53:44 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:53:44 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:53:44 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:53:44 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:53:44 --> Final output sent to browser
DEBUG - 2016-09-28 14:53:44 --> Total execution time: 3.3475
DEBUG - 2016-09-28 14:53:45 --> Config Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:53:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:53:45 --> Config Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:53:45 --> URI Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:53:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:53:45 --> URI Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Router Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Router Class Initialized
ERROR - 2016-09-28 14:53:45 --> 404 Page Not Found --> application
ERROR - 2016-09-28 14:53:45 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:53:45 --> Config Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:53:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:53:45 --> URI Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Router Class Initialized
ERROR - 2016-09-28 14:53:45 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:53:45 --> Config Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:53:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:53:45 --> URI Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Router Class Initialized
ERROR - 2016-09-28 14:53:45 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:53:45 --> Config Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:53:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:53:45 --> URI Class Initialized
DEBUG - 2016-09-28 14:53:45 --> Router Class Initialized
ERROR - 2016-09-28 14:53:45 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:53:57 --> Config Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:53:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:53:57 --> URI Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Router Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Output Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Security Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Input Class Initialized
DEBUG - 2016-09-28 14:53:57 --> XSS Filtering completed
DEBUG - 2016-09-28 14:53:57 --> XSS Filtering completed
DEBUG - 2016-09-28 14:53:57 --> XSS Filtering completed
DEBUG - 2016-09-28 14:53:57 --> XSS Filtering completed
DEBUG - 2016-09-28 14:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:53:57 --> Language Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Loader Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:53:57 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:53:57 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:53:57 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:53:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:53:57 --> Session Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:53:57 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Session routines successfully run
ERROR - 2016-09-28 14:53:57 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:53:57 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:53:57 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:53:57 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:53:57 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Table Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Model Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Model Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:53:57 --> Model Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Controller Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:53:57 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:53:57 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:54:00 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:54:00 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:54:00 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:54:00 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:54:00 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:54:00 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:54:00 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:54:00 --> Final output sent to browser
DEBUG - 2016-09-28 14:54:00 --> Total execution time: 3.2950
DEBUG - 2016-09-28 14:54:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:54:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:54:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:54:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:54:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:54:00 --> Router Class Initialized
ERROR - 2016-09-28 14:54:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:54:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:54:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:54:00 --> Config Class Initialized
DEBUG - 2016-09-28 14:54:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:54:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:54:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:54:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:54:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:54:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:54:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:54:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:54:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:54:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:54:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:54:00 --> Router Class Initialized
DEBUG - 2016-09-28 14:54:00 --> Router Class Initialized
ERROR - 2016-09-28 14:54:00 --> 404 Page Not Found --> application
ERROR - 2016-09-28 14:54:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:54:00 --> URI Class Initialized
DEBUG - 2016-09-28 14:54:01 --> Router Class Initialized
ERROR - 2016-09-28 14:54:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:54:38 --> Config Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:54:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:54:38 --> URI Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Router Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Output Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Security Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Input Class Initialized
DEBUG - 2016-09-28 14:54:38 --> XSS Filtering completed
DEBUG - 2016-09-28 14:54:38 --> XSS Filtering completed
DEBUG - 2016-09-28 14:54:38 --> XSS Filtering completed
DEBUG - 2016-09-28 14:54:38 --> XSS Filtering completed
DEBUG - 2016-09-28 14:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:54:38 --> Language Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Loader Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:54:38 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:54:38 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:54:38 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:54:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:54:38 --> Session Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:54:38 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Session routines successfully run
ERROR - 2016-09-28 14:54:38 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:54:38 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:54:38 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:54:38 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:54:38 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Table Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Model Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Model Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:54:38 --> Model Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Controller Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:54:38 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:54:38 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:54:41 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:54:41 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:54:41 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:54:41 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:54:41 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:54:41 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:54:41 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:54:41 --> Final output sent to browser
DEBUG - 2016-09-28 14:54:41 --> Total execution time: 3.2500
DEBUG - 2016-09-28 14:54:41 --> Config Class Initialized
DEBUG - 2016-09-28 14:54:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:54:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:54:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:54:41 --> URI Class Initialized
DEBUG - 2016-09-28 14:54:41 --> Router Class Initialized
DEBUG - 2016-09-28 14:54:41 --> Config Class Initialized
DEBUG - 2016-09-28 14:54:41 --> Hooks Class Initialized
ERROR - 2016-09-28 14:54:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:54:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:54:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:54:41 --> URI Class Initialized
DEBUG - 2016-09-28 14:54:41 --> Router Class Initialized
ERROR - 2016-09-28 14:54:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:54:41 --> Config Class Initialized
DEBUG - 2016-09-28 14:54:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:54:41 --> Config Class Initialized
DEBUG - 2016-09-28 14:54:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:54:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:54:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:54:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:54:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:54:41 --> URI Class Initialized
DEBUG - 2016-09-28 14:54:41 --> URI Class Initialized
DEBUG - 2016-09-28 14:54:41 --> Router Class Initialized
DEBUG - 2016-09-28 14:54:41 --> Router Class Initialized
ERROR - 2016-09-28 14:54:41 --> 404 Page Not Found --> application
ERROR - 2016-09-28 14:54:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:54:53 --> Config Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:54:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:54:53 --> URI Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Router Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Output Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Security Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Input Class Initialized
DEBUG - 2016-09-28 14:54:53 --> XSS Filtering completed
DEBUG - 2016-09-28 14:54:53 --> XSS Filtering completed
DEBUG - 2016-09-28 14:54:53 --> XSS Filtering completed
DEBUG - 2016-09-28 14:54:53 --> XSS Filtering completed
DEBUG - 2016-09-28 14:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:54:53 --> Language Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Loader Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:54:53 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:54:53 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:54:53 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:54:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:54:53 --> Session Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:54:53 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Session routines successfully run
ERROR - 2016-09-28 14:54:53 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:54:53 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:54:53 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:54:53 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:54:53 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Table Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Model Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Model Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:54:53 --> Model Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Controller Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:54:53 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:54:53 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-28 14:54:53 --> 404 Page Not Found --> admin/10
DEBUG - 2016-09-28 14:56:10 --> Config Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:56:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:56:10 --> URI Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Router Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Output Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Security Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Input Class Initialized
DEBUG - 2016-09-28 14:56:10 --> XSS Filtering completed
DEBUG - 2016-09-28 14:56:10 --> XSS Filtering completed
DEBUG - 2016-09-28 14:56:10 --> XSS Filtering completed
DEBUG - 2016-09-28 14:56:10 --> XSS Filtering completed
DEBUG - 2016-09-28 14:56:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:56:10 --> Language Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Loader Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:56:10 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:56:10 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:56:10 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:56:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:56:10 --> Session Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:56:10 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Session routines successfully run
ERROR - 2016-09-28 14:56:10 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:56:10 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:56:10 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:56:10 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:56:10 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Table Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Model Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Model Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:56:10 --> Model Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Controller Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:56:10 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:56:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 14:56:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 14:56:13 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 14:56:13 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 14:56:13 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 14:56:13 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 14:56:13 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 14:56:13 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 14:56:13 --> Final output sent to browser
DEBUG - 2016-09-28 14:56:13 --> Total execution time: 3.4325
DEBUG - 2016-09-28 14:56:13 --> Config Class Initialized
DEBUG - 2016-09-28 14:56:13 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:56:13 --> Config Class Initialized
DEBUG - 2016-09-28 14:56:13 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:56:13 --> Config Class Initialized
DEBUG - 2016-09-28 14:56:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:56:13 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:56:13 --> URI Class Initialized
DEBUG - 2016-09-28 14:56:13 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:56:13 --> Router Class Initialized
DEBUG - 2016-09-28 14:56:13 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:56:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:56:13 --> Config Class Initialized
DEBUG - 2016-09-28 14:56:13 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:56:13 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:56:13 --> URI Class Initialized
DEBUG - 2016-09-28 14:56:13 --> UTF-8 Support Enabled
ERROR - 2016-09-28 14:56:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:56:13 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:56:13 --> Router Class Initialized
DEBUG - 2016-09-28 14:56:13 --> URI Class Initialized
ERROR - 2016-09-28 14:56:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:56:13 --> Router Class Initialized
DEBUG - 2016-09-28 14:56:13 --> UTF-8 Support Enabled
ERROR - 2016-09-28 14:56:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:56:13 --> URI Class Initialized
DEBUG - 2016-09-28 14:56:13 --> Router Class Initialized
ERROR - 2016-09-28 14:56:13 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 14:56:24 --> Config Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Hooks Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Utf8 Class Initialized
DEBUG - 2016-09-28 14:56:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 14:56:24 --> URI Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Router Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Output Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Security Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Input Class Initialized
DEBUG - 2016-09-28 14:56:24 --> XSS Filtering completed
DEBUG - 2016-09-28 14:56:24 --> XSS Filtering completed
DEBUG - 2016-09-28 14:56:24 --> XSS Filtering completed
DEBUG - 2016-09-28 14:56:24 --> XSS Filtering completed
DEBUG - 2016-09-28 14:56:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 14:56:24 --> Language Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Loader Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Helper loaded: url_helper
DEBUG - 2016-09-28 14:56:24 --> Helper loaded: form_helper
DEBUG - 2016-09-28 14:56:24 --> Helper loaded: func_helper
DEBUG - 2016-09-28 14:56:24 --> Database Driver Class Initialized
ERROR - 2016-09-28 14:56:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 14:56:24 --> Session Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Helper loaded: string_helper
DEBUG - 2016-09-28 14:56:24 --> Encrypt Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Session routines successfully run
ERROR - 2016-09-28 14:56:24 --> Could not find the language line "first_link"
ERROR - 2016-09-28 14:56:24 --> Could not find the language line "last_link"
ERROR - 2016-09-28 14:56:24 --> Could not find the language line "next_link"
ERROR - 2016-09-28 14:56:24 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 14:56:24 --> Pagination Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Table Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Model Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Model Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Helper loaded: file_helper
DEBUG - 2016-09-28 14:56:24 --> Model Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Controller Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Form Validation Class Initialized
DEBUG - 2016-09-28 14:56:24 --> Helper loaded: language_helper
DEBUG - 2016-09-28 14:56:24 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-28 14:56:24 --> 404 Page Not Found --> admin/10
DEBUG - 2016-09-28 15:25:22 --> Config Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:25:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:25:22 --> URI Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Router Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Output Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Security Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Input Class Initialized
DEBUG - 2016-09-28 15:25:22 --> XSS Filtering completed
DEBUG - 2016-09-28 15:25:22 --> XSS Filtering completed
DEBUG - 2016-09-28 15:25:22 --> XSS Filtering completed
DEBUG - 2016-09-28 15:25:22 --> XSS Filtering completed
DEBUG - 2016-09-28 15:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:25:22 --> Language Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Loader Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:25:22 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:25:22 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:25:22 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:25:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:25:22 --> Session Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:25:22 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Session routines successfully run
ERROR - 2016-09-28 15:25:22 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:25:22 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:25:22 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:25:22 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:25:22 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Table Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Model Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Model Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:25:22 --> Model Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Controller Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:25:22 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:25:22 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:25:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:25:26 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:25:26 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:25:26 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:25:26 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:25:26 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:25:26 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:25:26 --> Final output sent to browser
DEBUG - 2016-09-28 15:25:26 --> Total execution time: 3.4352
DEBUG - 2016-09-28 15:25:26 --> Config Class Initialized
DEBUG - 2016-09-28 15:25:26 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:25:26 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:25:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:25:26 --> URI Class Initialized
DEBUG - 2016-09-28 15:25:26 --> Router Class Initialized
DEBUG - 2016-09-28 15:25:26 --> Config Class Initialized
DEBUG - 2016-09-28 15:25:26 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:25:26 --> Config Class Initialized
DEBUG - 2016-09-28 15:25:26 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:25:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:25:26 --> URI Class Initialized
ERROR - 2016-09-28 15:25:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:25:26 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:25:26 --> Router Class Initialized
DEBUG - 2016-09-28 15:25:26 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:25:26 --> Config Class Initialized
DEBUG - 2016-09-28 15:25:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:25:26 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:25:26 --> URI Class Initialized
ERROR - 2016-09-28 15:25:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:25:26 --> Router Class Initialized
DEBUG - 2016-09-28 15:25:26 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:25:26 --> UTF-8 Support Enabled
ERROR - 2016-09-28 15:25:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:25:26 --> URI Class Initialized
DEBUG - 2016-09-28 15:25:26 --> Router Class Initialized
ERROR - 2016-09-28 15:25:26 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:25:33 --> Config Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:25:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:25:33 --> URI Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Router Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Output Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Security Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Input Class Initialized
DEBUG - 2016-09-28 15:25:33 --> XSS Filtering completed
DEBUG - 2016-09-28 15:25:33 --> XSS Filtering completed
DEBUG - 2016-09-28 15:25:33 --> XSS Filtering completed
DEBUG - 2016-09-28 15:25:33 --> XSS Filtering completed
DEBUG - 2016-09-28 15:25:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:25:33 --> Language Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Loader Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:25:33 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:25:33 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:25:33 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:25:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:25:33 --> Session Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:25:33 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Session routines successfully run
ERROR - 2016-09-28 15:25:33 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:25:33 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:25:33 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:25:33 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:25:33 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Table Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Model Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Model Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:25:33 --> Model Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Controller Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:25:33 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:25:33 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-28 15:25:33 --> 404 Page Not Found --> admin/10
DEBUG - 2016-09-28 15:27:46 --> Config Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:27:46 --> URI Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Router Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Output Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Security Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Input Class Initialized
DEBUG - 2016-09-28 15:27:46 --> XSS Filtering completed
DEBUG - 2016-09-28 15:27:46 --> XSS Filtering completed
DEBUG - 2016-09-28 15:27:46 --> XSS Filtering completed
DEBUG - 2016-09-28 15:27:46 --> XSS Filtering completed
DEBUG - 2016-09-28 15:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:27:46 --> Language Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Loader Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:27:46 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:27:46 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:27:46 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:27:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:27:46 --> Session Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:27:46 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Session routines successfully run
ERROR - 2016-09-28 15:27:46 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:27:46 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:27:46 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:27:46 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:27:46 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Table Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Model Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Model Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:27:46 --> Model Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Controller Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:27:46 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:27:46 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:27:50 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:27:50 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:27:50 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:27:50 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:27:50 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:27:50 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:27:50 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:27:50 --> Final output sent to browser
DEBUG - 2016-09-28 15:27:50 --> Total execution time: 3.5922
DEBUG - 2016-09-28 15:27:50 --> Config Class Initialized
DEBUG - 2016-09-28 15:27:50 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:27:50 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:27:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:27:50 --> Config Class Initialized
DEBUG - 2016-09-28 15:27:50 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:27:50 --> URI Class Initialized
DEBUG - 2016-09-28 15:27:50 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:27:50 --> Router Class Initialized
DEBUG - 2016-09-28 15:27:50 --> UTF-8 Support Enabled
ERROR - 2016-09-28 15:27:50 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:27:50 --> URI Class Initialized
DEBUG - 2016-09-28 15:27:50 --> Router Class Initialized
DEBUG - 2016-09-28 15:27:50 --> Config Class Initialized
DEBUG - 2016-09-28 15:27:50 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:27:50 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:27:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:27:50 --> URI Class Initialized
DEBUG - 2016-09-28 15:27:50 --> Router Class Initialized
ERROR - 2016-09-28 15:27:50 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:27:50 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:27:50 --> Config Class Initialized
DEBUG - 2016-09-28 15:27:50 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:27:50 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:27:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:27:50 --> URI Class Initialized
DEBUG - 2016-09-28 15:27:50 --> Router Class Initialized
ERROR - 2016-09-28 15:27:50 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:15 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:15 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Output Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Security Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Input Class Initialized
DEBUG - 2016-09-28 15:34:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:34:15 --> Language Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Loader Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:34:15 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:34:15 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:34:15 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:34:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:34:15 --> Session Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:34:15 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Session routines successfully run
ERROR - 2016-09-28 15:34:15 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:34:15 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:34:15 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:34:15 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:34:15 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Table Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Model Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Model Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:34:15 --> Model Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Controller Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:34:15 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:34:15 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:34:18 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:34:18 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:34:18 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:34:18 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:34:18 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:34:18 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:34:18 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:34:18 --> Final output sent to browser
DEBUG - 2016-09-28 15:34:18 --> Total execution time: 3.3175
DEBUG - 2016-09-28 15:34:18 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:18 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:18 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:18 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:18 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:18 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:18 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:18 --> Router Class Initialized
ERROR - 2016-09-28 15:34:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:18 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:18 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:18 --> URI Class Initialized
ERROR - 2016-09-28 15:34:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:18 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:18 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:18 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:18 --> Router Class Initialized
ERROR - 2016-09-28 15:34:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:18 --> Router Class Initialized
ERROR - 2016-09-28 15:34:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:27 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:27 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Output Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Security Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Input Class Initialized
DEBUG - 2016-09-28 15:34:27 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:27 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:27 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:27 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:34:27 --> Language Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Loader Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:34:27 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:34:27 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:34:27 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:34:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:34:27 --> Session Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:34:27 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Session routines successfully run
ERROR - 2016-09-28 15:34:27 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:34:27 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:34:27 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:34:27 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:34:27 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Table Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Model Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Model Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:34:27 --> Model Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Controller Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:34:27 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:34:27 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:34:30 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:34:30 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:34:30 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:34:30 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:34:30 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:34:30 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:34:30 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:34:30 --> Final output sent to browser
DEBUG - 2016-09-28 15:34:30 --> Total execution time: 3.0550
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:30 --> UTF-8 Support Enabled
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:30 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:30 --> Router Class Initialized
ERROR - 2016-09-28 15:34:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Output Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Security Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Input Class Initialized
DEBUG - 2016-09-28 15:34:41 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:41 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:41 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:41 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:34:41 --> Language Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Loader Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:34:41 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:34:41 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:34:41 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:34:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:34:41 --> Session Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:34:41 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Session routines successfully run
ERROR - 2016-09-28 15:34:41 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:34:41 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:34:41 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:34:41 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:34:41 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Table Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Model Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Model Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:34:41 --> Model Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Controller Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:34:41 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:34:41 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:34:44 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:34:44 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:34:44 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:34:44 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:34:44 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:34:44 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:34:44 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:34:44 --> Final output sent to browser
DEBUG - 2016-09-28 15:34:44 --> Total execution time: 3.2550
DEBUG - 2016-09-28 15:34:44 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:44 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:44 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:44 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Router Class Initialized
ERROR - 2016-09-28 15:34:44 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:34:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:44 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Hooks Class Initialized
ERROR - 2016-09-28 15:34:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:44 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:44 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:44 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Hooks Class Initialized
ERROR - 2016-09-28 15:34:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:44 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:44 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Router Class Initialized
ERROR - 2016-09-28 15:34:44 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:34:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:44 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Hooks Class Initialized
ERROR - 2016-09-28 15:34:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:44 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Router Class Initialized
ERROR - 2016-09-28 15:34:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Config Class Initialized
ERROR - 2016-09-28 15:34:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:44 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:44 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:44 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:44 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:44 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:44 --> URI Class Initialized
ERROR - 2016-09-28 15:34:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:44 --> Router Class Initialized
ERROR - 2016-09-28 15:34:44 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:34:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:34:58 --> Config Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:34:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:34:58 --> URI Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Router Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Output Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Security Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Input Class Initialized
DEBUG - 2016-09-28 15:34:58 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:58 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:58 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:58 --> XSS Filtering completed
DEBUG - 2016-09-28 15:34:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:34:58 --> Language Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Loader Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:34:58 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:34:58 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:34:58 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:34:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:34:58 --> Session Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:34:58 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Session routines successfully run
ERROR - 2016-09-28 15:34:58 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:34:58 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:34:58 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:34:58 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:34:58 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Table Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Model Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Model Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:34:58 --> Model Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Controller Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:34:58 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:34:58 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:35:04 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:35:04 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:35:04 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:35:04 --> File loaded: application/views/admin_noalumnies.php
DEBUG - 2016-09-28 15:35:04 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:35:04 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:35:04 --> Final output sent to browser
DEBUG - 2016-09-28 15:35:04 --> Total execution time: 6.0825
DEBUG - 2016-09-28 15:35:18 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:18 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Router Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Output Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Security Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Input Class Initialized
DEBUG - 2016-09-28 15:35:18 --> XSS Filtering completed
DEBUG - 2016-09-28 15:35:18 --> XSS Filtering completed
DEBUG - 2016-09-28 15:35:18 --> XSS Filtering completed
DEBUG - 2016-09-28 15:35:18 --> XSS Filtering completed
DEBUG - 2016-09-28 15:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:35:18 --> Language Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Loader Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:35:18 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:35:18 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:35:18 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:35:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:35:18 --> Session Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:35:18 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Session routines successfully run
ERROR - 2016-09-28 15:35:18 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:35:18 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:35:18 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:35:18 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:35:18 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Table Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Model Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Model Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:35:18 --> Model Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Controller Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:35:18 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:35:18 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:35:20 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:35:20 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:35:20 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:35:20 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:35:20 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:35:20 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:35:20 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:35:20 --> Final output sent to browser
DEBUG - 2016-09-28 15:35:20 --> Total execution time: 2.7025
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
DEBUG - 2016-09-28 15:35:21 --> Router Class Initialized
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:35:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:35:29 --> Config Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:35:29 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:35:29 --> URI Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Router Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Output Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Security Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Input Class Initialized
DEBUG - 2016-09-28 15:35:29 --> XSS Filtering completed
DEBUG - 2016-09-28 15:35:29 --> XSS Filtering completed
DEBUG - 2016-09-28 15:35:29 --> XSS Filtering completed
DEBUG - 2016-09-28 15:35:29 --> XSS Filtering completed
DEBUG - 2016-09-28 15:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:35:29 --> Language Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Loader Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:35:29 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:35:29 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:35:29 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:35:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:35:29 --> Session Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:35:29 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Session routines successfully run
ERROR - 2016-09-28 15:35:29 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:35:29 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:35:29 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:35:29 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:35:29 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Table Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Model Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Model Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:35:29 --> Model Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Controller Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:35:29 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:35:29 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:35:34 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:35:34 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:35:34 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:35:34 --> File loaded: application/views/admin_noalumnies.php
DEBUG - 2016-09-28 15:35:34 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:35:34 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:35:34 --> Final output sent to browser
DEBUG - 2016-09-28 15:35:34 --> Total execution time: 5.5350
DEBUG - 2016-09-28 15:40:38 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:38 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Router Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Output Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Security Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Input Class Initialized
DEBUG - 2016-09-28 15:40:38 --> XSS Filtering completed
DEBUG - 2016-09-28 15:40:38 --> XSS Filtering completed
DEBUG - 2016-09-28 15:40:38 --> XSS Filtering completed
DEBUG - 2016-09-28 15:40:38 --> XSS Filtering completed
DEBUG - 2016-09-28 15:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:40:38 --> Language Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Loader Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:40:38 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:40:38 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:40:38 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:40:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:40:38 --> Session Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:40:38 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Session routines successfully run
ERROR - 2016-09-28 15:40:38 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:40:38 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:40:38 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:40:38 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:40:38 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Table Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Model Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Model Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:40:38 --> Model Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Controller Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:40:38 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:40:38 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:40:41 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:40:41 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:40:41 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:40:41 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:40:41 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:40:41 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:40:41 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:40:41 --> Final output sent to browser
DEBUG - 2016-09-28 15:40:41 --> Total execution time: 2.9125
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:40:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:40:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:40:41 --> Router Class Initialized
ERROR - 2016-09-28 15:40:41 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:41:10 --> Config Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:41:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:41:10 --> URI Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Router Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Output Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Security Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Input Class Initialized
DEBUG - 2016-09-28 15:41:10 --> XSS Filtering completed
DEBUG - 2016-09-28 15:41:10 --> XSS Filtering completed
DEBUG - 2016-09-28 15:41:10 --> XSS Filtering completed
DEBUG - 2016-09-28 15:41:10 --> XSS Filtering completed
DEBUG - 2016-09-28 15:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:41:10 --> Language Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Loader Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:41:10 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:41:10 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:41:10 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:41:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:41:10 --> Session Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:41:10 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Session routines successfully run
ERROR - 2016-09-28 15:41:10 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:41:10 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:41:10 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:41:10 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:41:10 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Table Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Model Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Model Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:41:10 --> Model Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Controller Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:41:10 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:41:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:41:15 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:41:15 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:41:15 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:41:15 --> File loaded: application/views/admin_noalumnies.php
DEBUG - 2016-09-28 15:41:15 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:41:15 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:41:15 --> Final output sent to browser
DEBUG - 2016-09-28 15:41:15 --> Total execution time: 5.2650
DEBUG - 2016-09-28 15:41:56 --> Config Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:41:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:41:56 --> URI Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Router Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Output Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Security Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Input Class Initialized
DEBUG - 2016-09-28 15:41:56 --> XSS Filtering completed
DEBUG - 2016-09-28 15:41:56 --> XSS Filtering completed
DEBUG - 2016-09-28 15:41:56 --> XSS Filtering completed
DEBUG - 2016-09-28 15:41:56 --> XSS Filtering completed
DEBUG - 2016-09-28 15:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:41:56 --> Language Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Loader Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:41:56 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:41:56 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:41:56 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:41:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:41:56 --> Session Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:41:56 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Session routines successfully run
ERROR - 2016-09-28 15:41:56 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:41:56 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:41:56 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:41:56 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:41:56 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Table Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Model Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Model Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:41:56 --> Model Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Controller Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:41:56 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:41:56 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:42:01 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:42:01 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:42:01 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:42:01 --> File loaded: application/views/admin_noalumnies.php
DEBUG - 2016-09-28 15:42:01 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:42:01 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:42:01 --> Final output sent to browser
DEBUG - 2016-09-28 15:42:01 --> Total execution time: 5.3550
DEBUG - 2016-09-28 15:42:12 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:12 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Output Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Security Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Input Class Initialized
DEBUG - 2016-09-28 15:42:12 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:12 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:12 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:12 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:42:12 --> Language Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Loader Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:42:12 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:42:12 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:42:12 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:42:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:42:12 --> Session Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:42:12 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Session routines successfully run
ERROR - 2016-09-28 15:42:12 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:42:12 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:42:12 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:42:12 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:42:12 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Table Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:42:12 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Controller Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:42:12 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:42:12 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:42:17 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:42:17 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:42:17 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:42:17 --> File loaded: application/views/admin_noalumnies.php
DEBUG - 2016-09-28 15:42:17 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:42:17 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:42:17 --> Final output sent to browser
DEBUG - 2016-09-28 15:42:17 --> Total execution time: 4.7950
DEBUG - 2016-09-28 15:42:25 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:25 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Output Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Security Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Input Class Initialized
DEBUG - 2016-09-28 15:42:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:42:25 --> Language Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Loader Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:42:25 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:42:25 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:42:25 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:42:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:42:25 --> Session Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:42:25 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Session routines successfully run
ERROR - 2016-09-28 15:42:25 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:42:25 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:42:25 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:42:25 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:42:25 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Table Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:42:25 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Controller Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:42:25 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:42:25 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:42:30 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:42:30 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:42:30 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:42:30 --> File loaded: application/views/admin_noalumnies.php
DEBUG - 2016-09-28 15:42:30 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:42:30 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:42:30 --> Final output sent to browser
DEBUG - 2016-09-28 15:42:30 --> Total execution time: 4.8125
DEBUG - 2016-09-28 15:42:35 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:35 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Output Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Security Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Input Class Initialized
DEBUG - 2016-09-28 15:42:35 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:35 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:35 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:35 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:42:35 --> Language Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Loader Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:42:35 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:42:35 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:42:35 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:42:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:42:35 --> Session Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:42:35 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Session routines successfully run
ERROR - 2016-09-28 15:42:35 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:42:35 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:42:35 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:42:35 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:42:35 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Table Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:42:35 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Controller Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:42:35 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:42:35 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:42:37 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:42:37 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:42:37 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:42:37 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:42:37 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:42:37 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:42:37 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:42:37 --> Final output sent to browser
DEBUG - 2016-09-28 15:42:37 --> Total execution time: 2.9025
DEBUG - 2016-09-28 15:42:38 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:38 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:38 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:38 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:38 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:38 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:38 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:38 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:38 --> UTF-8 Support Enabled
ERROR - 2016-09-28 15:42:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:42:38 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:38 --> Router Class Initialized
ERROR - 2016-09-28 15:42:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:42:38 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:38 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:38 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:38 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:38 --> Router Class Initialized
ERROR - 2016-09-28 15:42:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:42:38 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:38 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:38 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:38 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:38 --> Router Class Initialized
ERROR - 2016-09-28 15:42:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:42:45 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:45 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Output Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Security Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Input Class Initialized
DEBUG - 2016-09-28 15:42:45 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:45 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:45 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:45 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:42:45 --> Language Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Loader Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:42:45 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:42:45 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:42:45 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:42:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:42:45 --> Session Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:42:45 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Session routines successfully run
ERROR - 2016-09-28 15:42:45 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:42:45 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:42:45 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:42:45 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:42:45 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Table Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:42:45 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Controller Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:42:45 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:42:45 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:42:48 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:42:48 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:42:48 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:42:48 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:42:48 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:42:48 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:42:48 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:42:48 --> Final output sent to browser
DEBUG - 2016-09-28 15:42:48 --> Total execution time: 3.3675
DEBUG - 2016-09-28 15:42:48 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:48 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Router Class Initialized
ERROR - 2016-09-28 15:42:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:42:48 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:48 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Router Class Initialized
ERROR - 2016-09-28 15:42:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:48 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Hooks Class Initialized
ERROR - 2016-09-28 15:42:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:42:48 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:48 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:48 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:48 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:48 --> URI Class Initialized
ERROR - 2016-09-28 15:42:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:48 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Router Class Initialized
ERROR - 2016-09-28 15:42:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:42:48 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:48 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:48 --> UTF-8 Support Enabled
ERROR - 2016-09-28 15:42:48 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:42:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:42:48 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:48 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Hooks Class Initialized
ERROR - 2016-09-28 15:42:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:48 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:48 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Config Class Initialized
ERROR - 2016-09-28 15:42:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:42:48 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:48 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:48 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Router Class Initialized
ERROR - 2016-09-28 15:42:48 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:42:48 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:42:48 --> 404 Page Not Found --> application
ERROR - 2016-09-28 15:42:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:42:48 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:48 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:48 --> Router Class Initialized
ERROR - 2016-09-28 15:42:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 15:42:56 --> Config Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:42:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:42:56 --> URI Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Router Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Output Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Security Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Input Class Initialized
DEBUG - 2016-09-28 15:42:56 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:56 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:56 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:56 --> XSS Filtering completed
DEBUG - 2016-09-28 15:42:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:42:56 --> Language Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Loader Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:42:56 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:42:56 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:42:56 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:42:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:42:56 --> Session Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:42:56 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Session routines successfully run
ERROR - 2016-09-28 15:42:56 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:42:56 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:42:56 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:42:56 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:42:56 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Table Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:42:56 --> Model Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Controller Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:42:56 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:42:56 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:43:02 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:43:02 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:43:02 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:43:02 --> File loaded: application/views/admin_noalumnies.php
DEBUG - 2016-09-28 15:43:02 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:43:02 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:43:02 --> Final output sent to browser
DEBUG - 2016-09-28 15:43:02 --> Total execution time: 5.7100
DEBUG - 2016-09-28 15:43:25 --> Config Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:43:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:43:25 --> URI Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Router Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Output Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Security Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Input Class Initialized
DEBUG - 2016-09-28 15:43:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:43:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:43:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:43:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:43:25 --> Language Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Loader Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:43:25 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:43:25 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:43:25 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:43:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:43:25 --> Session Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:43:25 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Session routines successfully run
ERROR - 2016-09-28 15:43:25 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:43:25 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:43:25 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:43:25 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:43:25 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Table Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Model Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Model Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:43:25 --> Model Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Controller Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:43:25 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:43:25 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:43:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:43:28 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:43:28 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:43:28 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:43:28 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:43:28 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:43:28 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:43:28 --> Final output sent to browser
DEBUG - 2016-09-28 15:43:28 --> Total execution time: 2.9575
DEBUG - 2016-09-28 15:43:35 --> Config Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:43:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:43:35 --> URI Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Router Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Output Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Security Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Input Class Initialized
DEBUG - 2016-09-28 15:43:35 --> XSS Filtering completed
DEBUG - 2016-09-28 15:43:35 --> XSS Filtering completed
DEBUG - 2016-09-28 15:43:35 --> XSS Filtering completed
DEBUG - 2016-09-28 15:43:35 --> XSS Filtering completed
DEBUG - 2016-09-28 15:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:43:35 --> Language Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Loader Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:43:35 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:43:35 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:43:35 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:43:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:43:35 --> Session Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:43:35 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Session routines successfully run
ERROR - 2016-09-28 15:43:35 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:43:35 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:43:35 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:43:35 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:43:35 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Table Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Model Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Model Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:43:35 --> Model Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Controller Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:43:35 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:43:35 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:43:38 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:43:38 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:43:38 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:43:38 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:43:38 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:43:38 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:43:38 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:43:38 --> Final output sent to browser
DEBUG - 2016-09-28 15:43:38 --> Total execution time: 3.3675
DEBUG - 2016-09-28 15:43:44 --> Config Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:43:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:43:44 --> URI Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Router Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Output Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Security Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Input Class Initialized
DEBUG - 2016-09-28 15:43:44 --> XSS Filtering completed
DEBUG - 2016-09-28 15:43:44 --> XSS Filtering completed
DEBUG - 2016-09-28 15:43:44 --> XSS Filtering completed
DEBUG - 2016-09-28 15:43:44 --> XSS Filtering completed
DEBUG - 2016-09-28 15:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:43:44 --> Language Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Loader Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:43:44 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:43:44 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:43:44 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:43:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:43:44 --> Session Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:43:44 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Session routines successfully run
ERROR - 2016-09-28 15:43:44 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:43:44 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:43:44 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:43:44 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:43:44 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Table Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Model Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Model Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:43:44 --> Model Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Controller Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:43:44 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:43:44 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:43:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:43:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:43:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:43:47 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:43:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:43:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:43:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:43:47 --> Final output sent to browser
DEBUG - 2016-09-28 15:43:47 --> Total execution time: 3.2075
DEBUG - 2016-09-28 15:44:02 --> Config Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:44:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:44:02 --> URI Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Router Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Output Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Security Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Input Class Initialized
DEBUG - 2016-09-28 15:44:02 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:02 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:02 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:02 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:44:02 --> Language Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Loader Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:44:02 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:44:02 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:44:02 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:44:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:44:02 --> Session Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:44:02 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Session routines successfully run
ERROR - 2016-09-28 15:44:02 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:44:02 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:44:02 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:44:02 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:44:02 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Table Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Model Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Model Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:44:02 --> Model Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Controller Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:44:02 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:44:02 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:44:05 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:44:05 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:44:05 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:44:05 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:44:05 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:44:05 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:44:05 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:44:05 --> Final output sent to browser
DEBUG - 2016-09-28 15:44:05 --> Total execution time: 3.0775
DEBUG - 2016-09-28 15:44:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:44:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:44:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Router Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Output Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Security Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Input Class Initialized
DEBUG - 2016-09-28 15:44:21 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:21 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:21 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:21 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:44:21 --> Language Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Loader Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:44:21 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:44:21 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:44:21 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:44:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:44:21 --> Session Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:44:21 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Session routines successfully run
ERROR - 2016-09-28 15:44:21 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:44:21 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:44:21 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:44:21 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:44:21 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Table Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Model Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Model Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:44:21 --> Model Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Controller Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:44:21 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:44:21 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:44:24 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:44:24 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:44:24 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:44:24 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:44:24 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:44:24 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:44:24 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:44:24 --> Final output sent to browser
DEBUG - 2016-09-28 15:44:24 --> Total execution time: 3.3075
DEBUG - 2016-09-28 15:44:44 --> Config Class Initialized
DEBUG - 2016-09-28 15:44:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:44:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:44:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:44:44 --> URI Class Initialized
DEBUG - 2016-09-28 15:44:44 --> Router Class Initialized
DEBUG - 2016-09-28 15:44:44 --> Output Class Initialized
DEBUG - 2016-09-28 15:44:44 --> Security Class Initialized
DEBUG - 2016-09-28 15:44:44 --> Input Class Initialized
DEBUG - 2016-09-28 15:44:44 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:44 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:44 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:44 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:44:44 --> Language Class Initialized
DEBUG - 2016-09-28 15:44:44 --> Loader Class Initialized
DEBUG - 2016-09-28 15:44:45 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:44:45 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:44:45 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:44:45 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:44:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:44:45 --> Session Class Initialized
DEBUG - 2016-09-28 15:44:45 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:44:45 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:44:45 --> Session routines successfully run
ERROR - 2016-09-28 15:44:45 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:44:45 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:44:45 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:44:45 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:44:45 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:44:45 --> Table Class Initialized
DEBUG - 2016-09-28 15:44:45 --> Model Class Initialized
DEBUG - 2016-09-28 15:44:45 --> Model Class Initialized
DEBUG - 2016-09-28 15:44:45 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:44:45 --> Model Class Initialized
DEBUG - 2016-09-28 15:44:45 --> Controller Class Initialized
DEBUG - 2016-09-28 15:44:45 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:44:45 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:44:45 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:44:48 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:44:48 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:44:48 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:44:48 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:44:48 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:44:48 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:44:48 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:44:48 --> Final output sent to browser
DEBUG - 2016-09-28 15:44:48 --> Total execution time: 3.8525
DEBUG - 2016-09-28 15:44:57 --> Config Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:44:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:44:57 --> URI Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Router Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Output Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Security Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Input Class Initialized
DEBUG - 2016-09-28 15:44:57 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:57 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:57 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:57 --> XSS Filtering completed
DEBUG - 2016-09-28 15:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:44:57 --> Language Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Loader Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:44:57 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:44:57 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:44:57 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:44:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:44:57 --> Session Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:44:57 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Session routines successfully run
ERROR - 2016-09-28 15:44:57 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:44:57 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:44:57 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:44:57 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:44:57 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Table Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Model Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Model Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:44:57 --> Model Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Controller Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:44:57 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:44:57 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:45:00 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:45:00 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:45:00 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:45:00 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:45:00 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:45:00 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:45:00 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:45:00 --> Final output sent to browser
DEBUG - 2016-09-28 15:45:00 --> Total execution time: 3.1025
DEBUG - 2016-09-28 15:45:09 --> Config Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:45:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:45:09 --> URI Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Router Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Output Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Security Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Input Class Initialized
DEBUG - 2016-09-28 15:45:09 --> XSS Filtering completed
DEBUG - 2016-09-28 15:45:09 --> XSS Filtering completed
DEBUG - 2016-09-28 15:45:09 --> XSS Filtering completed
DEBUG - 2016-09-28 15:45:09 --> XSS Filtering completed
DEBUG - 2016-09-28 15:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:45:09 --> Language Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Loader Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:45:09 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:45:09 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:45:09 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:45:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:45:09 --> Session Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:45:09 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Session routines successfully run
ERROR - 2016-09-28 15:45:09 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:45:09 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:45:09 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:45:09 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:45:09 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Table Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Model Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Model Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:45:09 --> Model Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Controller Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:45:09 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:45:09 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:45:12 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:45:12 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:45:12 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:45:12 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:45:12 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:45:12 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:45:12 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:45:12 --> Final output sent to browser
DEBUG - 2016-09-28 15:45:12 --> Total execution time: 3.5175
DEBUG - 2016-09-28 15:45:21 --> Config Class Initialized
DEBUG - 2016-09-28 15:45:21 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:45:21 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:45:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:45:21 --> URI Class Initialized
DEBUG - 2016-09-28 15:45:21 --> Router Class Initialized
DEBUG - 2016-09-28 15:45:21 --> Output Class Initialized
DEBUG - 2016-09-28 15:45:21 --> Security Class Initialized
DEBUG - 2016-09-28 15:45:21 --> Input Class Initialized
DEBUG - 2016-09-28 15:45:21 --> XSS Filtering completed
DEBUG - 2016-09-28 15:45:21 --> XSS Filtering completed
DEBUG - 2016-09-28 15:45:21 --> XSS Filtering completed
DEBUG - 2016-09-28 15:45:21 --> XSS Filtering completed
DEBUG - 2016-09-28 15:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:45:21 --> Language Class Initialized
DEBUG - 2016-09-28 15:45:21 --> Loader Class Initialized
DEBUG - 2016-09-28 15:45:21 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:45:21 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:45:21 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:45:21 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:45:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:45:21 --> Session Class Initialized
DEBUG - 2016-09-28 15:45:21 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:45:21 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:45:22 --> Session routines successfully run
ERROR - 2016-09-28 15:45:22 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:45:22 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:45:22 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:45:22 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:45:22 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:45:22 --> Table Class Initialized
DEBUG - 2016-09-28 15:45:22 --> Model Class Initialized
DEBUG - 2016-09-28 15:45:22 --> Model Class Initialized
DEBUG - 2016-09-28 15:45:22 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:45:22 --> Model Class Initialized
DEBUG - 2016-09-28 15:45:22 --> Controller Class Initialized
DEBUG - 2016-09-28 15:45:22 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:45:22 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:45:22 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:45:25 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:45:25 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:45:25 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:45:25 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:45:25 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:45:25 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:45:25 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:45:25 --> Final output sent to browser
DEBUG - 2016-09-28 15:45:25 --> Total execution time: 3.2900
DEBUG - 2016-09-28 15:48:26 --> Config Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:48:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:48:26 --> URI Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Router Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Output Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Security Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Input Class Initialized
DEBUG - 2016-09-28 15:48:26 --> XSS Filtering completed
DEBUG - 2016-09-28 15:48:26 --> XSS Filtering completed
DEBUG - 2016-09-28 15:48:26 --> XSS Filtering completed
DEBUG - 2016-09-28 15:48:26 --> XSS Filtering completed
DEBUG - 2016-09-28 15:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:48:26 --> Language Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Loader Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:48:26 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:48:26 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:48:26 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:48:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:48:26 --> Session Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:48:26 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Session routines successfully run
ERROR - 2016-09-28 15:48:26 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:48:26 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:48:26 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:48:26 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:48:26 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Table Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Model Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Model Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:48:26 --> Model Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Controller Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:48:26 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:48:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:48:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:48:28 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:48:28 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:48:28 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:48:28 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:48:28 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:48:28 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:48:28 --> Final output sent to browser
DEBUG - 2016-09-28 15:48:28 --> Total execution time: 2.5500
DEBUG - 2016-09-28 15:48:44 --> Config Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:48:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:48:44 --> URI Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Router Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Output Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Security Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Input Class Initialized
DEBUG - 2016-09-28 15:48:44 --> XSS Filtering completed
DEBUG - 2016-09-28 15:48:44 --> XSS Filtering completed
DEBUG - 2016-09-28 15:48:44 --> XSS Filtering completed
DEBUG - 2016-09-28 15:48:44 --> XSS Filtering completed
DEBUG - 2016-09-28 15:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:48:44 --> Language Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Loader Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:48:44 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:48:44 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:48:44 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:48:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:48:44 --> Session Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:48:44 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Session routines successfully run
ERROR - 2016-09-28 15:48:44 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:48:44 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:48:44 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:48:44 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:48:44 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Table Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Model Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Model Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:48:44 --> Model Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Controller Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:48:44 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:48:44 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:48:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:48:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:48:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:48:47 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:48:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:48:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:48:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:48:47 --> Final output sent to browser
DEBUG - 2016-09-28 15:48:47 --> Total execution time: 3.5625
DEBUG - 2016-09-28 15:48:53 --> Config Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:48:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:48:53 --> URI Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Router Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Output Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Security Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Input Class Initialized
DEBUG - 2016-09-28 15:48:53 --> XSS Filtering completed
DEBUG - 2016-09-28 15:48:53 --> XSS Filtering completed
DEBUG - 2016-09-28 15:48:53 --> XSS Filtering completed
DEBUG - 2016-09-28 15:48:53 --> XSS Filtering completed
DEBUG - 2016-09-28 15:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:48:53 --> Language Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Loader Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:48:53 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:48:53 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:48:53 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:48:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:48:53 --> Session Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:48:53 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Session routines successfully run
ERROR - 2016-09-28 15:48:53 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:48:53 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:48:53 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:48:53 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:48:53 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Table Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Model Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Model Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:48:53 --> Model Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Controller Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:48:53 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:48:53 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:48:57 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:48:57 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:48:57 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:48:57 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:48:57 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:48:57 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:48:57 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:48:57 --> Final output sent to browser
DEBUG - 2016-09-28 15:48:57 --> Total execution time: 3.4575
DEBUG - 2016-09-28 15:49:03 --> Config Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:49:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:49:03 --> URI Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Router Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Output Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Security Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Input Class Initialized
DEBUG - 2016-09-28 15:49:03 --> XSS Filtering completed
DEBUG - 2016-09-28 15:49:03 --> XSS Filtering completed
DEBUG - 2016-09-28 15:49:03 --> XSS Filtering completed
DEBUG - 2016-09-28 15:49:03 --> XSS Filtering completed
DEBUG - 2016-09-28 15:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:49:03 --> Language Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Loader Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:49:03 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:49:03 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:49:03 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:49:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:49:03 --> Session Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:49:03 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Session routines successfully run
ERROR - 2016-09-28 15:49:03 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:49:03 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:49:03 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:49:03 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:49:03 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Table Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Model Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Model Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:49:03 --> Model Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Controller Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:49:03 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:49:03 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:49:07 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:49:07 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:49:07 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:49:07 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:49:07 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:49:07 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:49:07 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:49:07 --> Final output sent to browser
DEBUG - 2016-09-28 15:49:07 --> Total execution time: 3.4000
DEBUG - 2016-09-28 15:49:15 --> Config Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:49:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:49:15 --> URI Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Router Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Output Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Security Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Input Class Initialized
DEBUG - 2016-09-28 15:49:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:49:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:49:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:49:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:49:15 --> Language Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Loader Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:49:15 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:49:15 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:49:15 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:49:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:49:15 --> Session Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:49:15 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Session routines successfully run
ERROR - 2016-09-28 15:49:15 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:49:15 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:49:15 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:49:15 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:49:15 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Table Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Model Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Model Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:49:15 --> Model Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Controller Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:49:15 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:49:15 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:49:19 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:49:19 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:49:19 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:49:19 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:49:19 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:49:19 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:49:19 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:49:19 --> Final output sent to browser
DEBUG - 2016-09-28 15:49:19 --> Total execution time: 3.4250
DEBUG - 2016-09-28 15:49:24 --> Config Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:49:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:49:24 --> URI Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Router Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Output Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Security Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Input Class Initialized
DEBUG - 2016-09-28 15:49:24 --> XSS Filtering completed
DEBUG - 2016-09-28 15:49:24 --> XSS Filtering completed
DEBUG - 2016-09-28 15:49:24 --> XSS Filtering completed
DEBUG - 2016-09-28 15:49:24 --> XSS Filtering completed
DEBUG - 2016-09-28 15:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:49:24 --> Language Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Loader Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:49:24 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:49:24 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:49:24 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:49:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:49:24 --> Session Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:49:24 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Session routines successfully run
ERROR - 2016-09-28 15:49:24 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:49:24 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:49:24 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:49:24 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:49:24 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Table Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Model Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Model Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:49:24 --> Model Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Controller Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:49:24 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:49:24 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:49:27 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:49:27 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:49:27 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:49:27 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:49:27 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:49:27 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:49:27 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:49:27 --> Final output sent to browser
DEBUG - 2016-09-28 15:49:27 --> Total execution time: 3.8300
DEBUG - 2016-09-28 15:53:08 --> Config Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:53:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:53:08 --> URI Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Router Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Output Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Security Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Input Class Initialized
DEBUG - 2016-09-28 15:53:08 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:08 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:08 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:08 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:53:08 --> Language Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Loader Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:53:08 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:53:08 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:53:08 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:53:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:53:08 --> Session Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:53:08 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Session routines successfully run
ERROR - 2016-09-28 15:53:08 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:53:08 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:53:08 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:53:08 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:53:08 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Table Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Model Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Model Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:53:08 --> Model Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Controller Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:53:08 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:53:08 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:53:11 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:53:11 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:53:11 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:53:11 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:53:11 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:53:11 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:53:11 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:53:11 --> Final output sent to browser
DEBUG - 2016-09-28 15:53:11 --> Total execution time: 3.1175
DEBUG - 2016-09-28 15:53:15 --> Config Class Initialized
DEBUG - 2016-09-28 15:53:15 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:53:15 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:53:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:53:15 --> URI Class Initialized
DEBUG - 2016-09-28 15:53:15 --> Router Class Initialized
DEBUG - 2016-09-28 15:53:15 --> Output Class Initialized
DEBUG - 2016-09-28 15:53:15 --> Security Class Initialized
DEBUG - 2016-09-28 15:53:15 --> Input Class Initialized
DEBUG - 2016-09-28 15:53:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:53:15 --> Language Class Initialized
DEBUG - 2016-09-28 15:53:15 --> Loader Class Initialized
DEBUG - 2016-09-28 15:53:15 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:53:15 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:53:15 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:53:15 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:53:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:53:15 --> Session Class Initialized
DEBUG - 2016-09-28 15:53:15 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:53:15 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:53:16 --> Session routines successfully run
ERROR - 2016-09-28 15:53:16 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:53:16 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:53:16 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:53:16 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:53:16 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:53:16 --> Table Class Initialized
DEBUG - 2016-09-28 15:53:16 --> Model Class Initialized
DEBUG - 2016-09-28 15:53:16 --> Model Class Initialized
DEBUG - 2016-09-28 15:53:16 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:53:16 --> Model Class Initialized
DEBUG - 2016-09-28 15:53:16 --> Controller Class Initialized
DEBUG - 2016-09-28 15:53:16 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:53:16 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:53:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:53:19 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:53:19 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:53:19 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:53:19 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:53:19 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:53:19 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:53:19 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:53:19 --> Final output sent to browser
DEBUG - 2016-09-28 15:53:19 --> Total execution time: 3.2675
DEBUG - 2016-09-28 15:53:25 --> Config Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:53:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:53:25 --> URI Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Router Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Output Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Security Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Input Class Initialized
DEBUG - 2016-09-28 15:53:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:53:25 --> Language Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Loader Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:53:25 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:53:25 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:53:25 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:53:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:53:25 --> Session Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:53:25 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Session routines successfully run
ERROR - 2016-09-28 15:53:25 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:53:25 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:53:25 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:53:25 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:53:25 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Table Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Model Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Model Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:53:25 --> Model Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Controller Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:53:25 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:53:25 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:53:30 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:53:30 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:53:30 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:53:30 --> File loaded: application/views/admin_noalumnies.php
DEBUG - 2016-09-28 15:53:30 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:53:30 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:53:30 --> Final output sent to browser
DEBUG - 2016-09-28 15:53:30 --> Total execution time: 5.8675
DEBUG - 2016-09-28 15:53:57 --> Config Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:53:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:53:57 --> URI Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Router Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Output Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Security Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Input Class Initialized
DEBUG - 2016-09-28 15:53:57 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:57 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:57 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:57 --> XSS Filtering completed
DEBUG - 2016-09-28 15:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:53:57 --> Language Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Loader Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:53:57 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:53:57 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:53:57 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:53:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:53:57 --> Session Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:53:57 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Session routines successfully run
ERROR - 2016-09-28 15:53:57 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:53:57 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:53:57 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:53:57 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:53:57 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Table Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Model Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Model Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:53:57 --> Model Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Controller Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:53:57 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:53:57 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:54:00 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:54:00 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:54:00 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:54:00 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:54:00 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:54:00 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:54:00 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:54:00 --> Final output sent to browser
DEBUG - 2016-09-28 15:54:00 --> Total execution time: 2.6475
DEBUG - 2016-09-28 15:54:10 --> Config Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:54:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:54:10 --> URI Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Router Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Output Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Security Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Input Class Initialized
DEBUG - 2016-09-28 15:54:10 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:10 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:10 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:10 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:54:10 --> Language Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Loader Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:54:10 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:54:10 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:54:10 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:54:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:54:10 --> Session Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:54:10 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Session routines successfully run
ERROR - 2016-09-28 15:54:10 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:54:10 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:54:10 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:54:10 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:54:10 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Table Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:54:10 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:10 --> Controller Class Initialized
DEBUG - 2016-09-28 15:54:11 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:54:11 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:54:11 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:54:14 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:54:14 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:54:14 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:54:14 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:54:14 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:54:14 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:54:14 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:54:14 --> Final output sent to browser
DEBUG - 2016-09-28 15:54:14 --> Total execution time: 3.1650
DEBUG - 2016-09-28 15:54:15 --> Config Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:54:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:54:15 --> URI Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Router Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Output Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Security Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Input Class Initialized
DEBUG - 2016-09-28 15:54:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:15 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:54:15 --> Language Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Loader Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:54:15 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:54:15 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:54:15 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:54:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:54:15 --> Session Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:54:15 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Session routines successfully run
ERROR - 2016-09-28 15:54:15 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:54:15 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:54:15 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:54:15 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:54:15 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Table Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:54:15 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Controller Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:54:15 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:54:15 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:54:18 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:54:18 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:54:18 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:54:18 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:54:18 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:54:18 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:54:18 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:54:18 --> Final output sent to browser
DEBUG - 2016-09-28 15:54:18 --> Total execution time: 3.4675
DEBUG - 2016-09-28 15:54:25 --> Config Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:54:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:54:25 --> URI Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Router Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Output Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Security Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Input Class Initialized
DEBUG - 2016-09-28 15:54:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:25 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:54:25 --> Language Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Loader Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:54:25 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:54:25 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:54:25 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:54:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:54:25 --> Session Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:54:25 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Session routines successfully run
ERROR - 2016-09-28 15:54:25 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:54:25 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:54:25 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:54:25 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:54:25 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Table Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:54:25 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Controller Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:54:25 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:54:25 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:54:29 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:54:29 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:54:29 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:54:29 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:54:29 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:54:29 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:54:29 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:54:29 --> Final output sent to browser
DEBUG - 2016-09-28 15:54:29 --> Total execution time: 3.7175
DEBUG - 2016-09-28 15:54:38 --> Config Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:54:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:54:38 --> URI Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Router Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Output Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Security Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Input Class Initialized
DEBUG - 2016-09-28 15:54:38 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:38 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:38 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:38 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:54:38 --> Language Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Loader Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:54:38 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:54:38 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:54:38 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:54:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:54:38 --> Session Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:54:38 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Session routines successfully run
ERROR - 2016-09-28 15:54:38 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:54:38 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:54:38 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:54:38 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:54:38 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Table Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:54:38 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Controller Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:54:38 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:54:38 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:54:44 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:54:44 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:54:44 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:54:44 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:54:44 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:54:44 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:54:44 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:54:44 --> Final output sent to browser
DEBUG - 2016-09-28 15:54:44 --> Total execution time: 5.8975
DEBUG - 2016-09-28 15:54:51 --> Config Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:54:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:54:51 --> URI Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Router Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Output Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Security Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Input Class Initialized
DEBUG - 2016-09-28 15:54:51 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:51 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:51 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:51 --> XSS Filtering completed
DEBUG - 2016-09-28 15:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:54:51 --> Language Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Loader Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:54:51 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:54:51 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:54:51 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:54:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:54:51 --> Session Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:54:51 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Session routines successfully run
ERROR - 2016-09-28 15:54:51 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:54:51 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:54:51 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:54:51 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:54:51 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Table Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:54:51 --> Model Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Controller Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:54:51 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:54:51 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:54:57 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:54:57 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:54:57 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:54:57 --> File loaded: application/views/admin_noalumnies.php
DEBUG - 2016-09-28 15:54:57 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:54:57 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:54:57 --> Final output sent to browser
DEBUG - 2016-09-28 15:54:57 --> Total execution time: 5.3425
DEBUG - 2016-09-28 15:55:14 --> Config Class Initialized
DEBUG - 2016-09-28 15:55:14 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:55:14 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:55:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:55:14 --> URI Class Initialized
DEBUG - 2016-09-28 15:55:14 --> Router Class Initialized
DEBUG - 2016-09-28 15:55:14 --> Output Class Initialized
DEBUG - 2016-09-28 15:55:14 --> Security Class Initialized
DEBUG - 2016-09-28 15:55:14 --> Input Class Initialized
DEBUG - 2016-09-28 15:55:14 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:14 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:14 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:14 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:55:14 --> Language Class Initialized
DEBUG - 2016-09-28 15:55:14 --> Loader Class Initialized
DEBUG - 2016-09-28 15:55:14 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:55:14 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:55:14 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:55:14 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:55:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:55:14 --> Session Class Initialized
DEBUG - 2016-09-28 15:55:14 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:55:14 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:55:15 --> Session routines successfully run
ERROR - 2016-09-28 15:55:15 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:55:15 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:55:15 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:55:15 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:55:15 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:55:15 --> Table Class Initialized
DEBUG - 2016-09-28 15:55:15 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:15 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:15 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:55:15 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:15 --> Controller Class Initialized
DEBUG - 2016-09-28 15:55:15 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:55:15 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:55:15 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:55:20 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:55:20 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:55:20 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:55:20 --> File loaded: application/views/admin_noalumnies.php
DEBUG - 2016-09-28 15:55:20 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:55:20 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:55:20 --> Final output sent to browser
DEBUG - 2016-09-28 15:55:20 --> Total execution time: 5.5100
DEBUG - 2016-09-28 15:55:28 --> Config Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:55:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:55:28 --> URI Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Router Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Output Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Security Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Input Class Initialized
DEBUG - 2016-09-28 15:55:28 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:28 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:28 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:28 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:55:28 --> Language Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Loader Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:55:28 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:55:28 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:55:28 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:55:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:55:28 --> Session Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:55:28 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Session routines successfully run
ERROR - 2016-09-28 15:55:28 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:55:28 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:55:28 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:55:28 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:55:28 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Table Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:55:28 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Controller Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:55:28 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:55:28 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:55:33 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:55:33 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:55:33 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:55:33 --> File loaded: application/views/admin_noalumnies.php
DEBUG - 2016-09-28 15:55:33 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:55:33 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:55:33 --> Final output sent to browser
DEBUG - 2016-09-28 15:55:33 --> Total execution time: 4.8200
DEBUG - 2016-09-28 15:55:43 --> Config Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:55:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:55:43 --> URI Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Router Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Output Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Security Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Input Class Initialized
DEBUG - 2016-09-28 15:55:43 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:43 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:43 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:43 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:55:43 --> Language Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Loader Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:55:43 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:55:43 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:55:43 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:55:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:55:43 --> Session Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:55:43 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Session routines successfully run
ERROR - 2016-09-28 15:55:43 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:55:43 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:55:43 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:55:43 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:55:43 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Table Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:55:43 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Controller Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:55:43 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:55:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:55:48 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:55:48 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:55:48 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:55:48 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:55:48 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:55:48 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:55:48 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:55:48 --> Final output sent to browser
DEBUG - 2016-09-28 15:55:48 --> Total execution time: 5.3375
DEBUG - 2016-09-28 15:55:57 --> Config Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:55:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:55:57 --> URI Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Router Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Output Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Security Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Input Class Initialized
DEBUG - 2016-09-28 15:55:57 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:57 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:57 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:57 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:55:57 --> Language Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Loader Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:55:57 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:55:57 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:55:57 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:55:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:55:57 --> Session Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:55:57 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Session routines successfully run
ERROR - 2016-09-28 15:55:57 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:55:57 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:55:57 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:55:57 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:55:57 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Table Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:55:57 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Controller Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:55:57 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:55:57 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:55:59 --> Config Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:55:59 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:55:59 --> URI Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Router Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Output Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Security Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Input Class Initialized
DEBUG - 2016-09-28 15:55:59 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:59 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:59 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:59 --> XSS Filtering completed
DEBUG - 2016-09-28 15:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:55:59 --> Language Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Loader Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:55:59 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:55:59 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:55:59 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:55:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:55:59 --> Session Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:55:59 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Session routines successfully run
ERROR - 2016-09-28 15:55:59 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:55:59 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:55:59 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:55:59 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:55:59 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Table Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:55:59 --> Model Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Controller Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:55:59 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:55:59 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:56:04 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:56:04 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:56:04 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:56:04 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:56:04 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:56:04 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:56:04 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:56:04 --> Final output sent to browser
DEBUG - 2016-09-28 15:56:04 --> Total execution time: 6.5300
DEBUG - 2016-09-28 15:56:06 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:56:06 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:56:06 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:56:06 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:56:06 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:56:06 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:56:06 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:56:06 --> Final output sent to browser
DEBUG - 2016-09-28 15:56:06 --> Total execution time: 6.9375
DEBUG - 2016-09-28 15:56:17 --> Config Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:56:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:56:17 --> URI Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Router Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Output Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Security Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Input Class Initialized
DEBUG - 2016-09-28 15:56:17 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:17 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:17 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:17 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:56:17 --> Language Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Loader Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:56:17 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:56:17 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:56:17 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:56:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:56:17 --> Session Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:56:17 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Session routines successfully run
ERROR - 2016-09-28 15:56:17 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:56:17 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:56:17 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:56:17 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:56:17 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Table Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Model Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Model Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:56:17 --> Model Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Controller Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:56:17 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:56:17 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:56:23 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:56:23 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:56:23 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:56:23 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:56:23 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:56:23 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:56:23 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:56:23 --> Final output sent to browser
DEBUG - 2016-09-28 15:56:23 --> Total execution time: 5.7600
DEBUG - 2016-09-28 15:56:31 --> Config Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:56:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:56:31 --> URI Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Router Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Output Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Security Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Input Class Initialized
DEBUG - 2016-09-28 15:56:31 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:31 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:31 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:31 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:56:31 --> Language Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Loader Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:56:31 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:56:31 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:56:31 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:56:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:56:31 --> Session Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:56:31 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Session routines successfully run
ERROR - 2016-09-28 15:56:31 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:56:31 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:56:31 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:56:31 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:56:31 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Table Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Model Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Model Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:56:31 --> Model Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Controller Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:56:31 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:56:31 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:56:36 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:56:36 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:56:36 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:56:36 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:56:36 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:56:36 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:56:36 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:56:36 --> Final output sent to browser
DEBUG - 2016-09-28 15:56:36 --> Total execution time: 5.2575
DEBUG - 2016-09-28 15:56:41 --> Config Class Initialized
DEBUG - 2016-09-28 15:56:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:56:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:56:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:56:41 --> URI Class Initialized
DEBUG - 2016-09-28 15:56:41 --> Router Class Initialized
DEBUG - 2016-09-28 15:56:41 --> Output Class Initialized
DEBUG - 2016-09-28 15:56:41 --> Security Class Initialized
DEBUG - 2016-09-28 15:56:41 --> Input Class Initialized
DEBUG - 2016-09-28 15:56:41 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:41 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:42 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:42 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:56:42 --> Language Class Initialized
DEBUG - 2016-09-28 15:56:42 --> Loader Class Initialized
DEBUG - 2016-09-28 15:56:42 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:56:42 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:56:42 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:56:42 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:56:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:56:42 --> Session Class Initialized
DEBUG - 2016-09-28 15:56:42 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:56:42 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:56:42 --> Session routines successfully run
ERROR - 2016-09-28 15:56:42 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:56:42 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:56:42 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:56:42 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:56:42 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:56:42 --> Table Class Initialized
DEBUG - 2016-09-28 15:56:42 --> Model Class Initialized
DEBUG - 2016-09-28 15:56:42 --> Model Class Initialized
DEBUG - 2016-09-28 15:56:42 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:56:42 --> Model Class Initialized
DEBUG - 2016-09-28 15:56:42 --> Controller Class Initialized
DEBUG - 2016-09-28 15:56:42 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:56:42 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:56:42 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:56:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:56:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:56:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:56:47 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:56:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:56:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:56:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:56:47 --> Final output sent to browser
DEBUG - 2016-09-28 15:56:47 --> Total execution time: 5.5800
DEBUG - 2016-09-28 15:56:51 --> Config Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:56:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:56:51 --> URI Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Router Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Output Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Security Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Input Class Initialized
DEBUG - 2016-09-28 15:56:51 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:51 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:51 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:51 --> XSS Filtering completed
DEBUG - 2016-09-28 15:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:56:51 --> Language Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Loader Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:56:51 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:56:51 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:56:51 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:56:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:56:51 --> Session Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:56:51 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Session routines successfully run
ERROR - 2016-09-28 15:56:51 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:56:51 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:56:51 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:56:51 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:56:51 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Table Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Model Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Model Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:56:51 --> Model Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Controller Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:56:51 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:56:51 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:56:56 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:56:56 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:56:56 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:56:56 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:56:56 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:56:56 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:56:56 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:56:56 --> Final output sent to browser
DEBUG - 2016-09-28 15:56:56 --> Total execution time: 5.3200
DEBUG - 2016-09-28 15:57:02 --> Config Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Hooks Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Utf8 Class Initialized
DEBUG - 2016-09-28 15:57:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 15:57:02 --> URI Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Router Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Output Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Security Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Input Class Initialized
DEBUG - 2016-09-28 15:57:02 --> XSS Filtering completed
DEBUG - 2016-09-28 15:57:02 --> XSS Filtering completed
DEBUG - 2016-09-28 15:57:02 --> XSS Filtering completed
DEBUG - 2016-09-28 15:57:02 --> XSS Filtering completed
DEBUG - 2016-09-28 15:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 15:57:02 --> Language Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Loader Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Helper loaded: url_helper
DEBUG - 2016-09-28 15:57:02 --> Helper loaded: form_helper
DEBUG - 2016-09-28 15:57:02 --> Helper loaded: func_helper
DEBUG - 2016-09-28 15:57:02 --> Database Driver Class Initialized
ERROR - 2016-09-28 15:57:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 15:57:02 --> Session Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Helper loaded: string_helper
DEBUG - 2016-09-28 15:57:02 --> Encrypt Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Session routines successfully run
ERROR - 2016-09-28 15:57:02 --> Could not find the language line "first_link"
ERROR - 2016-09-28 15:57:02 --> Could not find the language line "last_link"
ERROR - 2016-09-28 15:57:02 --> Could not find the language line "next_link"
ERROR - 2016-09-28 15:57:02 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 15:57:02 --> Pagination Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Table Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Model Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Model Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Helper loaded: file_helper
DEBUG - 2016-09-28 15:57:02 --> Model Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Controller Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Form Validation Class Initialized
DEBUG - 2016-09-28 15:57:02 --> Helper loaded: language_helper
DEBUG - 2016-09-28 15:57:02 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 15:57:08 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 15:57:08 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 15:57:08 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 15:57:08 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 15:57:08 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 15:57:08 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 15:57:08 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 15:57:08 --> Final output sent to browser
DEBUG - 2016-09-28 15:57:08 --> Total execution time: 5.5050
DEBUG - 2016-09-28 16:07:31 --> Config Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:07:31 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:07:31 --> URI Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Router Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Output Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Security Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Input Class Initialized
DEBUG - 2016-09-28 16:07:31 --> XSS Filtering completed
DEBUG - 2016-09-28 16:07:31 --> XSS Filtering completed
DEBUG - 2016-09-28 16:07:31 --> XSS Filtering completed
DEBUG - 2016-09-28 16:07:31 --> XSS Filtering completed
DEBUG - 2016-09-28 16:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 16:07:31 --> Language Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Loader Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Helper loaded: url_helper
DEBUG - 2016-09-28 16:07:31 --> Helper loaded: form_helper
DEBUG - 2016-09-28 16:07:31 --> Helper loaded: func_helper
DEBUG - 2016-09-28 16:07:31 --> Database Driver Class Initialized
ERROR - 2016-09-28 16:07:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 16:07:31 --> Session Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Helper loaded: string_helper
DEBUG - 2016-09-28 16:07:31 --> Encrypt Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Session routines successfully run
ERROR - 2016-09-28 16:07:31 --> Could not find the language line "first_link"
ERROR - 2016-09-28 16:07:31 --> Could not find the language line "last_link"
ERROR - 2016-09-28 16:07:31 --> Could not find the language line "next_link"
ERROR - 2016-09-28 16:07:31 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 16:07:31 --> Pagination Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Table Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Model Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Model Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Helper loaded: file_helper
DEBUG - 2016-09-28 16:07:31 --> Model Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Controller Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Form Validation Class Initialized
DEBUG - 2016-09-28 16:07:31 --> Helper loaded: language_helper
DEBUG - 2016-09-28 16:07:31 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 16:07:35 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 16:07:35 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 16:07:35 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 16:07:35 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 16:07:35 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 16:07:35 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 16:07:35 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 16:07:35 --> Final output sent to browser
DEBUG - 2016-09-28 16:07:35 --> Total execution time: 4.5325
DEBUG - 2016-09-28 16:07:54 --> Config Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:07:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:07:54 --> URI Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Router Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Output Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Security Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Input Class Initialized
DEBUG - 2016-09-28 16:07:54 --> XSS Filtering completed
DEBUG - 2016-09-28 16:07:54 --> XSS Filtering completed
DEBUG - 2016-09-28 16:07:54 --> XSS Filtering completed
DEBUG - 2016-09-28 16:07:54 --> XSS Filtering completed
DEBUG - 2016-09-28 16:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 16:07:54 --> Language Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Loader Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Helper loaded: url_helper
DEBUG - 2016-09-28 16:07:54 --> Helper loaded: form_helper
DEBUG - 2016-09-28 16:07:54 --> Helper loaded: func_helper
DEBUG - 2016-09-28 16:07:54 --> Database Driver Class Initialized
ERROR - 2016-09-28 16:07:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 16:07:54 --> Session Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Helper loaded: string_helper
DEBUG - 2016-09-28 16:07:54 --> Encrypt Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Session routines successfully run
ERROR - 2016-09-28 16:07:54 --> Could not find the language line "first_link"
ERROR - 2016-09-28 16:07:54 --> Could not find the language line "last_link"
ERROR - 2016-09-28 16:07:54 --> Could not find the language line "next_link"
ERROR - 2016-09-28 16:07:54 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 16:07:54 --> Pagination Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Table Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Model Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Model Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Helper loaded: file_helper
DEBUG - 2016-09-28 16:07:54 --> Model Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Controller Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Form Validation Class Initialized
DEBUG - 2016-09-28 16:07:54 --> Helper loaded: language_helper
DEBUG - 2016-09-28 16:07:54 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 16:07:59 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 16:07:59 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 16:07:59 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 16:07:59 --> File loaded: application/views/admin_noalumnies.php
DEBUG - 2016-09-28 16:07:59 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 16:07:59 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 16:07:59 --> Final output sent to browser
DEBUG - 2016-09-28 16:07:59 --> Total execution time: 4.9075
DEBUG - 2016-09-28 16:08:06 --> Config Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:08:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:08:06 --> URI Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Router Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Output Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Security Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Input Class Initialized
DEBUG - 2016-09-28 16:08:06 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:06 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:06 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:06 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 16:08:06 --> Language Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Loader Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Helper loaded: url_helper
DEBUG - 2016-09-28 16:08:06 --> Helper loaded: form_helper
DEBUG - 2016-09-28 16:08:06 --> Helper loaded: func_helper
DEBUG - 2016-09-28 16:08:06 --> Database Driver Class Initialized
ERROR - 2016-09-28 16:08:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 16:08:06 --> Session Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Helper loaded: string_helper
DEBUG - 2016-09-28 16:08:06 --> Encrypt Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Session routines successfully run
ERROR - 2016-09-28 16:08:06 --> Could not find the language line "first_link"
ERROR - 2016-09-28 16:08:06 --> Could not find the language line "last_link"
ERROR - 2016-09-28 16:08:06 --> Could not find the language line "next_link"
ERROR - 2016-09-28 16:08:06 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 16:08:06 --> Pagination Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Table Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Helper loaded: file_helper
DEBUG - 2016-09-28 16:08:06 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Controller Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Form Validation Class Initialized
DEBUG - 2016-09-28 16:08:06 --> Helper loaded: language_helper
DEBUG - 2016-09-28 16:08:06 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 16:08:11 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 16:08:11 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 16:08:11 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 16:08:11 --> File loaded: application/views/admin_noalumnies.php
DEBUG - 2016-09-28 16:08:11 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 16:08:11 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 16:08:11 --> Final output sent to browser
DEBUG - 2016-09-28 16:08:11 --> Total execution time: 5.2825
DEBUG - 2016-09-28 16:08:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:08:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:08:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Router Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Output Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Security Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Input Class Initialized
DEBUG - 2016-09-28 16:08:16 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:16 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:16 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:16 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 16:08:16 --> Language Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Loader Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Helper loaded: url_helper
DEBUG - 2016-09-28 16:08:16 --> Helper loaded: form_helper
DEBUG - 2016-09-28 16:08:16 --> Helper loaded: func_helper
DEBUG - 2016-09-28 16:08:16 --> Database Driver Class Initialized
ERROR - 2016-09-28 16:08:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 16:08:16 --> Session Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Helper loaded: string_helper
DEBUG - 2016-09-28 16:08:16 --> Encrypt Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Session routines successfully run
ERROR - 2016-09-28 16:08:16 --> Could not find the language line "first_link"
ERROR - 2016-09-28 16:08:16 --> Could not find the language line "last_link"
ERROR - 2016-09-28 16:08:16 --> Could not find the language line "next_link"
ERROR - 2016-09-28 16:08:16 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 16:08:16 --> Pagination Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Table Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Helper loaded: file_helper
DEBUG - 2016-09-28 16:08:16 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Controller Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Form Validation Class Initialized
DEBUG - 2016-09-28 16:08:16 --> Helper loaded: language_helper
DEBUG - 2016-09-28 16:08:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 16:08:20 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 16:08:20 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 16:08:20 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 16:08:20 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 16:08:20 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 16:08:20 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 16:08:20 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 16:08:20 --> Final output sent to browser
DEBUG - 2016-09-28 16:08:20 --> Total execution time: 4.7675
DEBUG - 2016-09-28 16:08:28 --> Config Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:08:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:08:28 --> URI Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Router Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Output Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Security Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Input Class Initialized
DEBUG - 2016-09-28 16:08:28 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:28 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:28 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:28 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 16:08:28 --> Language Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Loader Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Helper loaded: url_helper
DEBUG - 2016-09-28 16:08:28 --> Helper loaded: form_helper
DEBUG - 2016-09-28 16:08:28 --> Helper loaded: func_helper
DEBUG - 2016-09-28 16:08:28 --> Database Driver Class Initialized
ERROR - 2016-09-28 16:08:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 16:08:28 --> Session Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Helper loaded: string_helper
DEBUG - 2016-09-28 16:08:28 --> Encrypt Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Session routines successfully run
ERROR - 2016-09-28 16:08:28 --> Could not find the language line "first_link"
ERROR - 2016-09-28 16:08:28 --> Could not find the language line "last_link"
ERROR - 2016-09-28 16:08:28 --> Could not find the language line "next_link"
ERROR - 2016-09-28 16:08:28 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 16:08:28 --> Pagination Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Table Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Helper loaded: file_helper
DEBUG - 2016-09-28 16:08:28 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Controller Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Form Validation Class Initialized
DEBUG - 2016-09-28 16:08:28 --> Helper loaded: language_helper
DEBUG - 2016-09-28 16:08:28 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 16:08:33 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 16:08:33 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 16:08:33 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 16:08:33 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 16:08:33 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 16:08:33 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 16:08:33 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 16:08:33 --> Final output sent to browser
DEBUG - 2016-09-28 16:08:33 --> Total execution time: 5.2800
DEBUG - 2016-09-28 16:08:41 --> Config Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:08:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:08:41 --> URI Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Router Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Output Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Security Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Input Class Initialized
DEBUG - 2016-09-28 16:08:41 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:41 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:41 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:41 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 16:08:41 --> Language Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Loader Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Helper loaded: url_helper
DEBUG - 2016-09-28 16:08:41 --> Helper loaded: form_helper
DEBUG - 2016-09-28 16:08:41 --> Helper loaded: func_helper
DEBUG - 2016-09-28 16:08:41 --> Database Driver Class Initialized
ERROR - 2016-09-28 16:08:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 16:08:41 --> Session Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Helper loaded: string_helper
DEBUG - 2016-09-28 16:08:41 --> Encrypt Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Session routines successfully run
ERROR - 2016-09-28 16:08:41 --> Could not find the language line "first_link"
ERROR - 2016-09-28 16:08:41 --> Could not find the language line "last_link"
ERROR - 2016-09-28 16:08:41 --> Could not find the language line "next_link"
ERROR - 2016-09-28 16:08:41 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 16:08:41 --> Pagination Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Table Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Helper loaded: file_helper
DEBUG - 2016-09-28 16:08:41 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Controller Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Form Validation Class Initialized
DEBUG - 2016-09-28 16:08:41 --> Helper loaded: language_helper
DEBUG - 2016-09-28 16:08:41 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 16:08:46 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 16:08:46 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 16:08:46 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 16:08:46 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 16:08:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 16:08:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 16:08:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 16:08:47 --> Final output sent to browser
DEBUG - 2016-09-28 16:08:47 --> Total execution time: 5.3450
DEBUG - 2016-09-28 16:08:54 --> Config Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:08:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:08:54 --> URI Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Router Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Output Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Security Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Input Class Initialized
DEBUG - 2016-09-28 16:08:54 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:54 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:54 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:54 --> XSS Filtering completed
DEBUG - 2016-09-28 16:08:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 16:08:54 --> Language Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Loader Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Helper loaded: url_helper
DEBUG - 2016-09-28 16:08:54 --> Helper loaded: form_helper
DEBUG - 2016-09-28 16:08:54 --> Helper loaded: func_helper
DEBUG - 2016-09-28 16:08:54 --> Database Driver Class Initialized
ERROR - 2016-09-28 16:08:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 16:08:54 --> Session Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Helper loaded: string_helper
DEBUG - 2016-09-28 16:08:54 --> Encrypt Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Session routines successfully run
ERROR - 2016-09-28 16:08:54 --> Could not find the language line "first_link"
ERROR - 2016-09-28 16:08:54 --> Could not find the language line "last_link"
ERROR - 2016-09-28 16:08:54 --> Could not find the language line "next_link"
ERROR - 2016-09-28 16:08:54 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 16:08:54 --> Pagination Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Table Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Helper loaded: file_helper
DEBUG - 2016-09-28 16:08:54 --> Model Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Controller Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Form Validation Class Initialized
DEBUG - 2016-09-28 16:08:54 --> Helper loaded: language_helper
DEBUG - 2016-09-28 16:08:54 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 16:08:59 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 16:08:59 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 16:08:59 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 16:08:59 --> File loaded: application/views/admin_noalumnies.php
DEBUG - 2016-09-28 16:08:59 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 16:08:59 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 16:08:59 --> Final output sent to browser
DEBUG - 2016-09-28 16:08:59 --> Total execution time: 5.1625
DEBUG - 2016-09-28 16:16:27 --> Config Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:16:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:16:27 --> URI Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Router Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Output Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Security Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Input Class Initialized
DEBUG - 2016-09-28 16:16:27 --> XSS Filtering completed
DEBUG - 2016-09-28 16:16:27 --> XSS Filtering completed
DEBUG - 2016-09-28 16:16:27 --> XSS Filtering completed
DEBUG - 2016-09-28 16:16:27 --> XSS Filtering completed
DEBUG - 2016-09-28 16:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 16:16:27 --> Language Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Loader Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Helper loaded: url_helper
DEBUG - 2016-09-28 16:16:27 --> Helper loaded: form_helper
DEBUG - 2016-09-28 16:16:27 --> Helper loaded: func_helper
DEBUG - 2016-09-28 16:16:27 --> Database Driver Class Initialized
ERROR - 2016-09-28 16:16:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 16:16:27 --> Session Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Helper loaded: string_helper
DEBUG - 2016-09-28 16:16:27 --> Encrypt Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Session routines successfully run
ERROR - 2016-09-28 16:16:27 --> Could not find the language line "first_link"
ERROR - 2016-09-28 16:16:27 --> Could not find the language line "last_link"
ERROR - 2016-09-28 16:16:27 --> Could not find the language line "next_link"
ERROR - 2016-09-28 16:16:27 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 16:16:27 --> Pagination Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Table Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Model Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Model Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Helper loaded: file_helper
DEBUG - 2016-09-28 16:16:27 --> Model Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Controller Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Form Validation Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Helper loaded: language_helper
DEBUG - 2016-09-28 16:16:27 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-28 16:16:27 --> Severity: Notice  --> Undefined variable: _limit C:\xampp\htdocs\www\alumni\application\models\Admin_model.php 68
ERROR - 2016-09-28 16:16:27 --> Severity: Notice  --> Undefined variable: _offset C:\xampp\htdocs\www\alumni\application\models\Admin_model.php 68
DEBUG - 2016-09-28 16:16:27 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 16:16:27 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 16:16:27 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 16:16:27 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 16:16:27 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 16:16:27 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 16:16:27 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 16:16:27 --> Final output sent to browser
DEBUG - 2016-09-28 16:16:27 --> Total execution time: 0.2900
DEBUG - 2016-09-28 16:16:27 --> Config Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Config Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:16:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:16:27 --> URI Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Router Class Initialized
ERROR - 2016-09-28 16:16:27 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:16:27 --> Config Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Config Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:16:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:16:27 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:16:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:16:27 --> URI Class Initialized
DEBUG - 2016-09-28 16:16:27 --> URI Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Router Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Router Class Initialized
ERROR - 2016-09-28 16:16:27 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:16:27 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:16:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:16:27 --> URI Class Initialized
DEBUG - 2016-09-28 16:16:27 --> Router Class Initialized
ERROR - 2016-09-28 16:16:27 --> 404 Page Not Found --> application
ERROR - 2016-09-28 16:16:27 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:00 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:00 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Output Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Security Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Input Class Initialized
DEBUG - 2016-09-28 16:17:00 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:00 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:00 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:00 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 16:17:00 --> Language Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Loader Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Helper loaded: url_helper
DEBUG - 2016-09-28 16:17:00 --> Helper loaded: form_helper
DEBUG - 2016-09-28 16:17:00 --> Helper loaded: func_helper
DEBUG - 2016-09-28 16:17:00 --> Database Driver Class Initialized
ERROR - 2016-09-28 16:17:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 16:17:00 --> Session Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Helper loaded: string_helper
DEBUG - 2016-09-28 16:17:00 --> Encrypt Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Session routines successfully run
ERROR - 2016-09-28 16:17:00 --> Could not find the language line "first_link"
ERROR - 2016-09-28 16:17:00 --> Could not find the language line "last_link"
ERROR - 2016-09-28 16:17:00 --> Could not find the language line "next_link"
ERROR - 2016-09-28 16:17:00 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 16:17:00 --> Pagination Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Table Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Helper loaded: file_helper
DEBUG - 2016-09-28 16:17:00 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Controller Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Form Validation Class Initialized
DEBUG - 2016-09-28 16:17:00 --> Helper loaded: language_helper
DEBUG - 2016-09-28 16:17:00 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 16:17:03 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 16:17:03 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 16:17:03 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 16:17:03 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 16:17:03 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 16:17:03 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 16:17:03 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 16:17:03 --> Final output sent to browser
DEBUG - 2016-09-28 16:17:03 --> Total execution time: 3.1600
DEBUG - 2016-09-28 16:17:03 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:03 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Config Class Initialized
ERROR - 2016-09-28 16:17:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:03 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:03 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Router Class Initialized
ERROR - 2016-09-28 16:17:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:03 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:03 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:03 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:03 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Router Class Initialized
ERROR - 2016-09-28 16:17:03 --> 404 Page Not Found --> application
ERROR - 2016-09-28 16:17:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:03 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:03 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:03 --> UTF-8 Support Enabled
ERROR - 2016-09-28 16:17:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:03 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:03 --> Router Class Initialized
ERROR - 2016-09-28 16:17:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:13 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:13 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Output Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Security Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Input Class Initialized
DEBUG - 2016-09-28 16:17:13 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:13 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:13 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:13 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 16:17:13 --> Language Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Loader Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Helper loaded: url_helper
DEBUG - 2016-09-28 16:17:13 --> Helper loaded: form_helper
DEBUG - 2016-09-28 16:17:13 --> Helper loaded: func_helper
DEBUG - 2016-09-28 16:17:13 --> Database Driver Class Initialized
ERROR - 2016-09-28 16:17:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 16:17:13 --> Session Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Helper loaded: string_helper
DEBUG - 2016-09-28 16:17:13 --> Encrypt Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Session routines successfully run
ERROR - 2016-09-28 16:17:13 --> Could not find the language line "first_link"
ERROR - 2016-09-28 16:17:13 --> Could not find the language line "last_link"
ERROR - 2016-09-28 16:17:13 --> Could not find the language line "next_link"
ERROR - 2016-09-28 16:17:13 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 16:17:13 --> Pagination Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Table Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Helper loaded: file_helper
DEBUG - 2016-09-28 16:17:13 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Controller Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Form Validation Class Initialized
DEBUG - 2016-09-28 16:17:13 --> Helper loaded: language_helper
DEBUG - 2016-09-28 16:17:13 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 16:17:16 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 16:17:16 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 16:17:16 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 16:17:16 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 16:17:16 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 16:17:16 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 16:17:16 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 16:17:16 --> Final output sent to browser
DEBUG - 2016-09-28 16:17:16 --> Total execution time: 3.3650
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:16 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:16 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:16 --> Router Class Initialized
ERROR - 2016-09-28 16:17:16 --> 404 Page Not Found --> application
DEBUG - 2016-09-28 16:17:22 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:22 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Output Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Security Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Input Class Initialized
DEBUG - 2016-09-28 16:17:22 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:22 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:22 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:22 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 16:17:22 --> Language Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Loader Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Helper loaded: url_helper
DEBUG - 2016-09-28 16:17:22 --> Helper loaded: form_helper
DEBUG - 2016-09-28 16:17:22 --> Helper loaded: func_helper
DEBUG - 2016-09-28 16:17:22 --> Database Driver Class Initialized
ERROR - 2016-09-28 16:17:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 16:17:22 --> Session Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Helper loaded: string_helper
DEBUG - 2016-09-28 16:17:22 --> Encrypt Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Session routines successfully run
ERROR - 2016-09-28 16:17:22 --> Could not find the language line "first_link"
ERROR - 2016-09-28 16:17:22 --> Could not find the language line "last_link"
ERROR - 2016-09-28 16:17:22 --> Could not find the language line "next_link"
ERROR - 2016-09-28 16:17:22 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 16:17:22 --> Pagination Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Table Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Helper loaded: file_helper
DEBUG - 2016-09-28 16:17:22 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Controller Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Form Validation Class Initialized
DEBUG - 2016-09-28 16:17:22 --> Helper loaded: language_helper
DEBUG - 2016-09-28 16:17:22 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 16:17:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 16:17:28 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 16:17:28 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 16:17:28 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 16:17:28 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 16:17:28 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 16:17:28 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 16:17:28 --> Final output sent to browser
DEBUG - 2016-09-28 16:17:28 --> Total execution time: 6.1050
DEBUG - 2016-09-28 16:17:55 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:55 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Output Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Security Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Input Class Initialized
DEBUG - 2016-09-28 16:17:55 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:55 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:55 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:55 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:55 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 16:17:55 --> Language Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Loader Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Helper loaded: url_helper
DEBUG - 2016-09-28 16:17:55 --> Helper loaded: form_helper
DEBUG - 2016-09-28 16:17:55 --> Helper loaded: func_helper
DEBUG - 2016-09-28 16:17:55 --> Database Driver Class Initialized
ERROR - 2016-09-28 16:17:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 16:17:55 --> Session Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Helper loaded: string_helper
DEBUG - 2016-09-28 16:17:55 --> Encrypt Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Session routines successfully run
ERROR - 2016-09-28 16:17:55 --> Could not find the language line "first_link"
ERROR - 2016-09-28 16:17:55 --> Could not find the language line "last_link"
ERROR - 2016-09-28 16:17:55 --> Could not find the language line "next_link"
ERROR - 2016-09-28 16:17:55 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 16:17:55 --> Pagination Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Table Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Helper loaded: file_helper
DEBUG - 2016-09-28 16:17:55 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Controller Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Form Validation Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Helper loaded: language_helper
DEBUG - 2016-09-28 16:17:55 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 16:17:55 --> Final output sent to browser
DEBUG - 2016-09-28 16:17:55 --> Total execution time: 0.2475
DEBUG - 2016-09-28 16:17:55 --> Config Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Hooks Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Utf8 Class Initialized
DEBUG - 2016-09-28 16:17:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 16:17:55 --> URI Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Router Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Output Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Security Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Input Class Initialized
DEBUG - 2016-09-28 16:17:55 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:55 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:55 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:55 --> XSS Filtering completed
DEBUG - 2016-09-28 16:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 16:17:55 --> Language Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Loader Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Helper loaded: url_helper
DEBUG - 2016-09-28 16:17:55 --> Helper loaded: form_helper
DEBUG - 2016-09-28 16:17:55 --> Helper loaded: func_helper
DEBUG - 2016-09-28 16:17:55 --> Database Driver Class Initialized
ERROR - 2016-09-28 16:17:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 16:17:55 --> Session Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Helper loaded: string_helper
DEBUG - 2016-09-28 16:17:55 --> Encrypt Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Session routines successfully run
ERROR - 2016-09-28 16:17:55 --> Could not find the language line "first_link"
ERROR - 2016-09-28 16:17:55 --> Could not find the language line "last_link"
ERROR - 2016-09-28 16:17:55 --> Could not find the language line "next_link"
ERROR - 2016-09-28 16:17:55 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 16:17:55 --> Pagination Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Table Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Helper loaded: file_helper
DEBUG - 2016-09-28 16:17:55 --> Model Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Controller Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Form Validation Class Initialized
DEBUG - 2016-09-28 16:17:55 --> Helper loaded: language_helper
DEBUG - 2016-09-28 16:17:55 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 16:18:00 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 16:18:00 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-28 16:18:00 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-28 16:18:00 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-28 16:18:00 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-28 16:18:00 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-28 16:18:00 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-28 16:18:00 --> Final output sent to browser
DEBUG - 2016-09-28 16:18:00 --> Total execution time: 5.1975
DEBUG - 2016-09-28 18:54:18 --> Config Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:54:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:54:18 --> URI Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Router Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Output Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Security Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Input Class Initialized
DEBUG - 2016-09-28 18:54:18 --> XSS Filtering completed
DEBUG - 2016-09-28 18:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:54:18 --> Language Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Loader Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:54:18 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:54:18 --> Helper loaded: func_helper
DEBUG - 2016-09-28 18:54:18 --> Database Driver Class Initialized
ERROR - 2016-09-28 18:54:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 18:54:18 --> Session Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:54:18 --> Encrypt Class Initialized
DEBUG - 2016-09-28 18:54:18 --> A session cookie was not found.
DEBUG - 2016-09-28 18:54:18 --> Session routines successfully run
ERROR - 2016-09-28 18:54:18 --> Could not find the language line "first_link"
ERROR - 2016-09-28 18:54:18 --> Could not find the language line "last_link"
ERROR - 2016-09-28 18:54:18 --> Could not find the language line "next_link"
ERROR - 2016-09-28 18:54:18 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 18:54:18 --> Pagination Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Table Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Model Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Model Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:54:18 --> Model Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Controller Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Form Validation Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Config Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:54:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:54:18 --> URI Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Router Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Output Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Security Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Input Class Initialized
DEBUG - 2016-09-28 18:54:18 --> XSS Filtering completed
DEBUG - 2016-09-28 18:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-28 18:54:18 --> Language Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Loader Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Helper loaded: url_helper
DEBUG - 2016-09-28 18:54:18 --> Helper loaded: form_helper
DEBUG - 2016-09-28 18:54:18 --> Helper loaded: func_helper
DEBUG - 2016-09-28 18:54:18 --> Database Driver Class Initialized
ERROR - 2016-09-28 18:54:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-28 18:54:18 --> Session Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Helper loaded: string_helper
DEBUG - 2016-09-28 18:54:18 --> Encrypt Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Session routines successfully run
ERROR - 2016-09-28 18:54:18 --> Could not find the language line "first_link"
ERROR - 2016-09-28 18:54:18 --> Could not find the language line "last_link"
ERROR - 2016-09-28 18:54:18 --> Could not find the language line "next_link"
ERROR - 2016-09-28 18:54:18 --> Could not find the language line "prev_link"
DEBUG - 2016-09-28 18:54:18 --> Pagination Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Table Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Model Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Model Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Helper loaded: file_helper
DEBUG - 2016-09-28 18:54:18 --> Model Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Controller Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Helper loaded: language_helper
DEBUG - 2016-09-28 18:54:18 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-28 18:54:18 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-28 18:54:18 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-28 18:54:18 --> File loaded: application/views/login_form.php
DEBUG - 2016-09-28 18:54:18 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-28 18:54:18 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-28 18:54:18 --> Final output sent to browser
DEBUG - 2016-09-28 18:54:18 --> Total execution time: 0.0980
DEBUG - 2016-09-28 18:54:18 --> Config Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Hooks Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Utf8 Class Initialized
DEBUG - 2016-09-28 18:54:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-28 18:54:18 --> URI Class Initialized
DEBUG - 2016-09-28 18:54:18 --> Router Class Initialized
ERROR - 2016-09-28 18:54:18 --> 404 Page Not Found --> js
