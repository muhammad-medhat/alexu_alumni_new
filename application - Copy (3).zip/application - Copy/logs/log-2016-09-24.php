DEBUG - 2016-09-24 18:32:54 --> Config Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:32:54 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:32:54 --> URI Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Router Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Output Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Security Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Input Class Initialized
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:32:54 --> Language Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Loader Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:32:54 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:32:54 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:32:54 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:32:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:32:54 --> Session Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:32:54 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Session routines successfully run
ERROR - 2016-09-24 18:32:54 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:32:54 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:32:54 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:32:54 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:32:54 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Table Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Model Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Model Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:32:54 --> Model Class Initialized
DEBUG - 2016-09-24 18:32:54 --> Controller Class Initialized
DEBUG - 2016-09-24 18:32:56 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:32:56 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 18:32:56 --> Form Validation Class Initialized
ERROR - 2016-09-24 18:32:56 --> Could not find the language line "year"
ERROR - 2016-09-24 18:32:56 --> Could not find the language line "retype"
DEBUG - 2016-09-24 18:32:56 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> XSS Filtering completed
DEBUG - 2016-09-24 18:32:58 --> DB Transaction Failure
ERROR - 2016-09-24 18:32:58 --> Query error: Duplicate entry '155357' for key 'PRIMARY'
DEBUG - 2016-09-24 18:32:58 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-09-24 18:32:58 --> Could not find the language line "db_error_heading"
DEBUG - 2016-09-24 18:36:28 --> Config Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:36:28 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:36:28 --> URI Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Router Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Output Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Security Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Input Class Initialized
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:36:28 --> Language Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Loader Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:36:28 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:36:28 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:36:28 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:36:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:36:28 --> Session Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:36:28 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Session routines successfully run
ERROR - 2016-09-24 18:36:28 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:36:28 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:36:28 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:36:28 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:36:28 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Table Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Model Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Model Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:36:28 --> Model Class Initialized
DEBUG - 2016-09-24 18:36:28 --> Controller Class Initialized
DEBUG - 2016-09-24 18:36:30 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:36:30 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 18:36:30 --> Form Validation Class Initialized
ERROR - 2016-09-24 18:36:30 --> Could not find the language line "year"
ERROR - 2016-09-24 18:36:30 --> Could not find the language line "retype"
DEBUG - 2016-09-24 18:36:30 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> XSS Filtering completed
DEBUG - 2016-09-24 18:36:32 --> DB Transaction Failure
ERROR - 2016-09-24 18:36:32 --> Query error: Duplicate entry '155358' for key 'PRIMARY'
DEBUG - 2016-09-24 18:36:32 --> Language file loaded: language/arabic/db_lang.php
ERROR - 2016-09-24 18:36:32 --> Could not find the language line "db_error_heading"
DEBUG - 2016-09-24 18:41:34 --> Config Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:41:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:41:34 --> URI Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Router Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Output Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Security Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Input Class Initialized
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:41:34 --> Language Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Loader Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:41:34 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:41:34 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:41:34 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:41:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:41:34 --> Session Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:41:34 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Session routines successfully run
ERROR - 2016-09-24 18:41:34 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:41:34 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:41:34 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:41:34 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:41:34 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Table Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Model Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Model Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:41:34 --> Model Class Initialized
DEBUG - 2016-09-24 18:41:34 --> Controller Class Initialized
DEBUG - 2016-09-24 18:41:36 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:41:36 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 18:41:36 --> Form Validation Class Initialized
ERROR - 2016-09-24 18:41:36 --> Could not find the language line "year"
ERROR - 2016-09-24 18:41:36 --> Could not find the language line "retype"
DEBUG - 2016-09-24 18:41:36 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> Config Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:41:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:41:37 --> URI Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Router Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Output Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Security Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Input Class Initialized
DEBUG - 2016-09-24 18:41:37 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:41:37 --> Language Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Loader Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:41:37 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:41:37 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:41:37 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:41:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:41:37 --> Session Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:41:37 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Session routines successfully run
ERROR - 2016-09-24 18:41:37 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:41:37 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:41:37 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:41:37 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:41:37 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Table Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Model Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Model Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:41:37 --> Model Class Initialized
DEBUG - 2016-09-24 18:41:37 --> Controller Class Initialized
DEBUG - 2016-09-24 18:41:39 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:41:39 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-24 18:41:39 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-09-24 18:41:39 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 18:41:39 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 18:41:39 --> File loaded: application/views/signup/complete.php
DEBUG - 2016-09-24 18:41:39 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 18:41:39 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 18:41:39 --> Final output sent to browser
DEBUG - 2016-09-24 18:41:39 --> Total execution time: 2.0631
DEBUG - 2016-09-24 18:41:39 --> Config Class Initialized
DEBUG - 2016-09-24 18:41:39 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:41:39 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:41:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:41:39 --> URI Class Initialized
DEBUG - 2016-09-24 18:41:39 --> Router Class Initialized
ERROR - 2016-09-24 18:41:39 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 18:41:56 --> Config Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:41:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:41:56 --> URI Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Router Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Output Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Security Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Input Class Initialized
DEBUG - 2016-09-24 18:41:56 --> XSS Filtering completed
DEBUG - 2016-09-24 18:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:41:56 --> Language Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Loader Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:41:56 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:41:56 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:41:56 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:41:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:41:56 --> Session Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:41:56 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Session routines successfully run
ERROR - 2016-09-24 18:41:56 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:41:56 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:41:56 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:41:56 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:41:56 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Table Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Model Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Model Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:41:56 --> Model Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Controller Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Form Validation Class Initialized
DEBUG - 2016-09-24 18:41:56 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:41:56 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 18:41:59 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 18:41:59 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 18:41:59 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 18:41:59 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 18:41:59 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 18:41:59 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 18:41:59 --> Final output sent to browser
DEBUG - 2016-09-24 18:41:59 --> Total execution time: 2.7272
DEBUG - 2016-09-24 18:43:11 --> Config Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:43:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:43:11 --> URI Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Router Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Output Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Security Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Input Class Initialized
DEBUG - 2016-09-24 18:43:11 --> XSS Filtering completed
DEBUG - 2016-09-24 18:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:43:11 --> Language Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Loader Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:43:11 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:43:11 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:43:11 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:43:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:43:11 --> Session Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:43:11 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Session routines successfully run
ERROR - 2016-09-24 18:43:11 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:43:11 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:43:11 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:43:11 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:43:11 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Table Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Model Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Model Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:43:11 --> Model Class Initialized
DEBUG - 2016-09-24 18:43:11 --> Controller Class Initialized
DEBUG - 2016-09-24 18:43:13 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:43:13 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 18:43:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 18:43:13 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 18:43:13 --> File loaded: application/views/signup/main.php
DEBUG - 2016-09-24 18:43:13 --> File loaded: application/views/signup/login.php
DEBUG - 2016-09-24 18:43:13 --> File loaded: application/views/signup/personal.php
ERROR - 2016-09-24 18:43:13 --> Could not find the language line "register"
DEBUG - 2016-09-24 18:43:13 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-09-24 18:43:13 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 18:43:13 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 18:43:13 --> Final output sent to browser
DEBUG - 2016-09-24 18:43:13 --> Total execution time: 1.9381
DEBUG - 2016-09-24 18:43:13 --> Config Class Initialized
DEBUG - 2016-09-24 18:43:13 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:43:13 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:43:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:43:13 --> URI Class Initialized
DEBUG - 2016-09-24 18:43:13 --> Router Class Initialized
ERROR - 2016-09-24 18:43:13 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 18:44:38 --> Config Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:44:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:44:38 --> URI Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Router Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Output Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Security Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Input Class Initialized
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:44:38 --> Language Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Loader Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:44:38 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:44:38 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:44:38 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:44:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:44:38 --> Session Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:44:38 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Session routines successfully run
ERROR - 2016-09-24 18:44:38 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:44:38 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:44:38 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:44:38 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:44:38 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Table Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Model Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Model Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:44:38 --> Model Class Initialized
DEBUG - 2016-09-24 18:44:38 --> Controller Class Initialized
DEBUG - 2016-09-24 18:44:40 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:44:40 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 18:44:40 --> Form Validation Class Initialized
ERROR - 2016-09-24 18:44:40 --> Could not find the language line "year"
ERROR - 2016-09-24 18:44:40 --> Could not find the language line "retype"
DEBUG - 2016-09-24 18:44:40 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:41 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:42 --> Config Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:44:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:44:42 --> URI Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Router Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Output Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Security Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Input Class Initialized
DEBUG - 2016-09-24 18:44:42 --> XSS Filtering completed
DEBUG - 2016-09-24 18:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:44:42 --> Language Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Loader Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:44:42 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:44:42 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:44:42 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:44:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:44:42 --> Session Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:44:42 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Session routines successfully run
ERROR - 2016-09-24 18:44:42 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:44:42 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:44:42 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:44:42 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:44:42 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Table Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Model Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Model Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:44:42 --> Model Class Initialized
DEBUG - 2016-09-24 18:44:42 --> Controller Class Initialized
DEBUG - 2016-09-24 18:44:44 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:44:44 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-24 18:44:44 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-09-24 18:44:44 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 18:44:44 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 18:44:44 --> File loaded: application/views/signup/complete.php
DEBUG - 2016-09-24 18:44:44 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 18:44:44 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 18:44:44 --> Final output sent to browser
DEBUG - 2016-09-24 18:44:44 --> Total execution time: 2.4881
DEBUG - 2016-09-24 18:44:44 --> Config Class Initialized
DEBUG - 2016-09-24 18:44:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:44:44 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:44:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:44:44 --> URI Class Initialized
DEBUG - 2016-09-24 18:44:44 --> Router Class Initialized
ERROR - 2016-09-24 18:44:44 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 18:45:04 --> Config Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:45:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:45:04 --> URI Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Router Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Output Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Security Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Input Class Initialized
DEBUG - 2016-09-24 18:45:04 --> XSS Filtering completed
DEBUG - 2016-09-24 18:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:45:04 --> Language Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Loader Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:45:04 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:45:04 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:45:04 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:45:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:45:04 --> Session Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:45:04 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Session routines successfully run
ERROR - 2016-09-24 18:45:04 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:45:04 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:45:04 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:45:04 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:45:04 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Table Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Model Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Model Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:45:04 --> Model Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Controller Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Form Validation Class Initialized
DEBUG - 2016-09-24 18:45:04 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:45:04 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 18:45:06 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 18:45:06 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 18:45:06 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 18:45:06 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 18:45:06 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 18:45:06 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 18:45:06 --> Final output sent to browser
DEBUG - 2016-09-24 18:45:06 --> Total execution time: 1.8341
DEBUG - 2016-09-24 18:45:45 --> Config Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:45:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:45:45 --> URI Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Router Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Output Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Security Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Input Class Initialized
DEBUG - 2016-09-24 18:45:45 --> XSS Filtering completed
DEBUG - 2016-09-24 18:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:45:45 --> Language Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Loader Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:45:45 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:45:45 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:45:45 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:45:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:45:45 --> Session Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:45:45 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Session routines successfully run
ERROR - 2016-09-24 18:45:45 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:45:45 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:45:45 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:45:45 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:45:45 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Table Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Model Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Model Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:45:45 --> Model Class Initialized
DEBUG - 2016-09-24 18:45:45 --> Controller Class Initialized
DEBUG - 2016-09-24 18:45:47 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:45:47 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 18:45:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 18:45:47 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 18:45:47 --> File loaded: application/views/signup/main.php
DEBUG - 2016-09-24 18:45:47 --> File loaded: application/views/signup/login.php
DEBUG - 2016-09-24 18:45:47 --> File loaded: application/views/signup/personal.php
ERROR - 2016-09-24 18:45:47 --> Could not find the language line "register"
DEBUG - 2016-09-24 18:45:47 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-09-24 18:45:47 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 18:45:47 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 18:45:47 --> Final output sent to browser
DEBUG - 2016-09-24 18:45:47 --> Total execution time: 1.8701
DEBUG - 2016-09-24 18:45:47 --> Config Class Initialized
DEBUG - 2016-09-24 18:45:47 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:45:47 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:45:47 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:45:47 --> URI Class Initialized
DEBUG - 2016-09-24 18:45:47 --> Router Class Initialized
ERROR - 2016-09-24 18:45:47 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 18:46:51 --> Config Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:46:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:46:51 --> URI Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Router Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Output Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Security Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Input Class Initialized
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:46:51 --> Language Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Loader Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:46:51 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:46:51 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:46:51 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:46:51 --> Session Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:46:51 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Session routines successfully run
ERROR - 2016-09-24 18:46:51 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:46:51 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:46:51 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:46:51 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:46:51 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Table Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Model Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Model Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:46:51 --> Model Class Initialized
DEBUG - 2016-09-24 18:46:51 --> Controller Class Initialized
DEBUG - 2016-09-24 18:46:53 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:46:53 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 18:46:53 --> Form Validation Class Initialized
ERROR - 2016-09-24 18:46:53 --> Could not find the language line "year"
ERROR - 2016-09-24 18:46:53 --> Could not find the language line "retype"
DEBUG - 2016-09-24 18:46:53 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:54 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:55 --> Config Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:46:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:46:55 --> URI Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Router Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Output Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Security Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Input Class Initialized
DEBUG - 2016-09-24 18:46:55 --> XSS Filtering completed
DEBUG - 2016-09-24 18:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:46:55 --> Language Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Loader Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:46:55 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:46:55 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:46:55 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:46:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:46:55 --> Session Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:46:55 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Session routines successfully run
ERROR - 2016-09-24 18:46:55 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:46:55 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:46:55 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:46:55 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:46:55 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Table Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Model Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Model Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:46:55 --> Model Class Initialized
DEBUG - 2016-09-24 18:46:55 --> Controller Class Initialized
DEBUG - 2016-09-24 18:46:57 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:46:57 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-24 18:46:57 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-09-24 18:46:57 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 18:46:57 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 18:46:57 --> File loaded: application/views/signup/complete.php
DEBUG - 2016-09-24 18:46:57 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 18:46:57 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 18:46:57 --> Final output sent to browser
DEBUG - 2016-09-24 18:46:57 --> Total execution time: 2.4031
DEBUG - 2016-09-24 18:46:57 --> Config Class Initialized
DEBUG - 2016-09-24 18:46:57 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:46:57 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:46:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:46:57 --> URI Class Initialized
DEBUG - 2016-09-24 18:46:57 --> Router Class Initialized
ERROR - 2016-09-24 18:46:57 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 18:47:11 --> Config Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:47:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:47:11 --> URI Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Router Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Output Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Security Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Input Class Initialized
DEBUG - 2016-09-24 18:47:11 --> XSS Filtering completed
DEBUG - 2016-09-24 18:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:47:11 --> Language Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Loader Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:47:11 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:47:11 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:47:11 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:47:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:47:11 --> Session Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:47:11 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Session routines successfully run
ERROR - 2016-09-24 18:47:11 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:47:11 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:47:11 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:47:11 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:47:11 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Table Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Model Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Model Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:47:11 --> Model Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Controller Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Form Validation Class Initialized
DEBUG - 2016-09-24 18:47:11 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:47:11 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 18:47:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 18:47:13 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 18:47:13 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 18:47:13 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 18:47:13 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 18:47:13 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 18:47:13 --> Final output sent to browser
DEBUG - 2016-09-24 18:47:13 --> Total execution time: 2.2301
DEBUG - 2016-09-24 18:52:39 --> Config Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:52:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:52:39 --> URI Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Router Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Output Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Security Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Input Class Initialized
DEBUG - 2016-09-24 18:52:39 --> XSS Filtering completed
DEBUG - 2016-09-24 18:52:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:52:39 --> Language Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Loader Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:52:39 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:52:39 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:52:39 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:52:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:52:39 --> Session Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:52:39 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Session routines successfully run
ERROR - 2016-09-24 18:52:39 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:52:39 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:52:39 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:52:39 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:52:39 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Table Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Model Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Model Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:52:39 --> Model Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Controller Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Form Validation Class Initialized
DEBUG - 2016-09-24 18:52:39 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:52:39 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 18:52:41 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 18:52:41 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 18:52:41 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 18:53:26 --> Config Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Hooks Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Utf8 Class Initialized
DEBUG - 2016-09-24 18:53:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 18:53:26 --> URI Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Router Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Output Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Security Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Input Class Initialized
DEBUG - 2016-09-24 18:53:26 --> XSS Filtering completed
DEBUG - 2016-09-24 18:53:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 18:53:26 --> Language Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Loader Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Helper loaded: url_helper
DEBUG - 2016-09-24 18:53:26 --> Helper loaded: form_helper
DEBUG - 2016-09-24 18:53:26 --> Helper loaded: func_helper
DEBUG - 2016-09-24 18:53:26 --> Database Driver Class Initialized
ERROR - 2016-09-24 18:53:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 18:53:26 --> Session Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Helper loaded: string_helper
DEBUG - 2016-09-24 18:53:26 --> Encrypt Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Session routines successfully run
ERROR - 2016-09-24 18:53:26 --> Could not find the language line "first_link"
ERROR - 2016-09-24 18:53:26 --> Could not find the language line "last_link"
ERROR - 2016-09-24 18:53:26 --> Could not find the language line "next_link"
ERROR - 2016-09-24 18:53:26 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 18:53:26 --> Pagination Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Table Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Model Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Model Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Helper loaded: file_helper
DEBUG - 2016-09-24 18:53:26 --> Model Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Controller Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Form Validation Class Initialized
DEBUG - 2016-09-24 18:53:26 --> Helper loaded: language_helper
DEBUG - 2016-09-24 18:53:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 18:53:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 18:53:28 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 18:53:28 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 18:53:28 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 18:53:28 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 18:53:28 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 18:53:28 --> Final output sent to browser
DEBUG - 2016-09-24 18:53:28 --> Total execution time: 1.7541
DEBUG - 2016-09-24 19:18:44 --> Config Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:18:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:18:44 --> URI Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Router Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Output Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Security Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Input Class Initialized
DEBUG - 2016-09-24 19:18:44 --> XSS Filtering completed
DEBUG - 2016-09-24 19:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:18:44 --> Language Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Loader Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:18:44 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:18:44 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:18:44 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:18:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:18:44 --> Session Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:18:44 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Session routines successfully run
ERROR - 2016-09-24 19:18:44 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:18:44 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:18:44 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:18:44 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:18:44 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Table Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Model Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Model Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:18:44 --> Model Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Controller Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:18:44 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:18:44 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:18:46 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:18:46 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:18:46 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-24 19:18:46 --> Severity: Notice  --> Undefined property: stdClass::$alumni C:\xampp\htdocs\www\alumni\application\views\admin_view.php 95
ERROR - 2016-09-24 19:18:46 --> Severity: Notice  --> Undefined property: stdClass::$alumni C:\xampp\htdocs\www\alumni\application\views\admin_view.php 95
ERROR - 2016-09-24 19:18:46 --> Severity: Notice  --> Undefined property: stdClass::$alumni C:\xampp\htdocs\www\alumni\application\views\admin_view.php 95
DEBUG - 2016-09-24 19:18:46 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:18:46 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:18:46 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:18:46 --> Final output sent to browser
DEBUG - 2016-09-24 19:18:46 --> Total execution time: 1.8421
DEBUG - 2016-09-24 19:19:37 --> Config Class Initialized
DEBUG - 2016-09-24 19:19:37 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:19:37 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:19:37 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:19:37 --> URI Class Initialized
DEBUG - 2016-09-24 19:19:37 --> Router Class Initialized
DEBUG - 2016-09-24 19:19:37 --> Output Class Initialized
DEBUG - 2016-09-24 19:19:37 --> Security Class Initialized
DEBUG - 2016-09-24 19:19:37 --> Input Class Initialized
DEBUG - 2016-09-24 19:19:37 --> XSS Filtering completed
DEBUG - 2016-09-24 19:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:19:37 --> Language Class Initialized
DEBUG - 2016-09-24 19:19:37 --> Loader Class Initialized
DEBUG - 2016-09-24 19:19:37 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:19:37 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:19:37 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:19:37 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:19:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:19:37 --> Session Class Initialized
DEBUG - 2016-09-24 19:19:37 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:19:37 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:19:37 --> Session routines successfully run
ERROR - 2016-09-24 19:19:37 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:19:37 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:19:37 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:19:37 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:19:37 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:19:37 --> Table Class Initialized
DEBUG - 2016-09-24 19:19:37 --> Model Class Initialized
DEBUG - 2016-09-24 19:19:37 --> Model Class Initialized
DEBUG - 2016-09-24 19:19:38 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:19:38 --> Model Class Initialized
DEBUG - 2016-09-24 19:19:38 --> Controller Class Initialized
DEBUG - 2016-09-24 19:19:38 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:19:38 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:19:38 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:19:39 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:19:39 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:19:39 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:19:39 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:19:39 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:19:39 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:19:39 --> Final output sent to browser
DEBUG - 2016-09-24 19:19:39 --> Total execution time: 1.7461
DEBUG - 2016-09-24 19:27:10 --> Config Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:27:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:27:10 --> URI Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Router Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Output Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Security Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Input Class Initialized
DEBUG - 2016-09-24 19:27:10 --> XSS Filtering completed
DEBUG - 2016-09-24 19:27:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:27:10 --> Language Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Loader Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:27:10 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:27:10 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:27:10 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:27:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:27:10 --> Session Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:27:10 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Session routines successfully run
ERROR - 2016-09-24 19:27:10 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:27:10 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:27:10 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:27:10 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:27:10 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Table Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Model Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Model Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:27:10 --> Model Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Controller Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:27:10 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:27:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:27:11 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:27:11 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:27:11 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:27:11 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:27:11 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:27:11 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:27:11 --> Final output sent to browser
DEBUG - 2016-09-24 19:27:11 --> Total execution time: 1.4051
DEBUG - 2016-09-24 19:29:35 --> Config Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:29:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:29:35 --> URI Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Router Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Output Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Security Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Input Class Initialized
DEBUG - 2016-09-24 19:29:35 --> XSS Filtering completed
DEBUG - 2016-09-24 19:29:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:29:35 --> Language Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Loader Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:29:35 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:29:35 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:29:35 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:29:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:29:35 --> Session Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:29:35 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Session routines successfully run
ERROR - 2016-09-24 19:29:35 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:29:35 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:29:35 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:29:35 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:29:35 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Table Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Model Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Model Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:29:35 --> Model Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Controller Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:29:35 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:29:35 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:29:37 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:29:37 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:29:37 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:29:37 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:29:37 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:29:37 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:29:37 --> Final output sent to browser
DEBUG - 2016-09-24 19:29:37 --> Total execution time: 2.4811
DEBUG - 2016-09-24 19:31:39 --> Config Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:31:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:31:39 --> URI Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Router Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Output Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Security Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Input Class Initialized
DEBUG - 2016-09-24 19:31:39 --> XSS Filtering completed
DEBUG - 2016-09-24 19:31:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:31:39 --> Language Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Loader Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:31:39 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:31:39 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:31:39 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:31:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:31:39 --> Session Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:31:39 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Session routines successfully run
ERROR - 2016-09-24 19:31:39 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:31:39 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:31:39 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:31:39 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:31:39 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Table Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:31:39 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Controller Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:31:39 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:31:39 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:31:41 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:31:41 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:31:41 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:31:41 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:31:41 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:31:41 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:31:41 --> Final output sent to browser
DEBUG - 2016-09-24 19:31:41 --> Total execution time: 2.0981
DEBUG - 2016-09-24 19:31:43 --> Config Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:31:43 --> URI Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Router Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Output Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Security Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Input Class Initialized
DEBUG - 2016-09-24 19:31:43 --> XSS Filtering completed
DEBUG - 2016-09-24 19:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:31:43 --> Language Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Loader Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:31:43 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:31:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:31:43 --> Session Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:31:43 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Session routines successfully run
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:31:43 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Table Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Controller Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:31:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:31:43 --> Config Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:31:43 --> URI Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Router Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Output Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Security Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Input Class Initialized
DEBUG - 2016-09-24 19:31:43 --> XSS Filtering completed
DEBUG - 2016-09-24 19:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:31:43 --> Language Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Loader Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:31:43 --> Config Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:31:43 --> URI Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Router Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Output Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:31:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:31:43 --> Security Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Session Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:31:43 --> Input Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:31:43 --> XSS Filtering completed
DEBUG - 2016-09-24 19:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:31:43 --> Language Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Loader Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:31:43 --> Config Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:31:43 --> Database Driver Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Session routines successfully run
DEBUG - 2016-09-24 19:31:43 --> URI Class Initialized
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "first_link"
DEBUG - 2016-09-24 19:31:43 --> Router Class Initialized
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:31:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:31:43 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Output Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Table Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Security Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Session Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Input Class Initialized
DEBUG - 2016-09-24 19:31:43 --> XSS Filtering completed
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:31:43 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Language Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Controller Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Loader Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Config Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:31:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:31:43 --> URI Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Router Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Database Driver Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Output Class Initialized
ERROR - 2016-09-24 19:31:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:31:43 --> Security Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Input Class Initialized
DEBUG - 2016-09-24 19:31:43 --> XSS Filtering completed
DEBUG - 2016-09-24 19:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:31:43 --> Language Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Session Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:31:43 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Loader Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:31:43 --> Session routines successfully run
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: func_helper
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "first_link"
DEBUG - 2016-09-24 19:31:43 --> Config Class Initialized
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "last_link"
DEBUG - 2016-09-24 19:31:43 --> Hooks Class Initialized
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:31:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:31:43 --> Database Driver Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Table Class Initialized
DEBUG - 2016-09-24 19:31:43 --> URI Class Initialized
ERROR - 2016-09-24 19:31:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Router Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Session Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:31:43 --> Output Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Security Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Controller Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Input Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Config Class Initialized
DEBUG - 2016-09-24 19:31:43 --> XSS Filtering completed
DEBUG - 2016-09-24 19:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:31:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Language Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:31:43 --> URI Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Router Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Loader Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:31:43 --> Output Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:31:43 --> Security Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:31:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:31:43 --> Input Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:31:43 --> Session routines successfully run
DEBUG - 2016-09-24 19:31:43 --> XSS Filtering completed
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "last_link"
DEBUG - 2016-09-24 19:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:31:43 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "next_link"
DEBUG - 2016-09-24 19:31:43 --> Language Class Initialized
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "prev_link"
ERROR - 2016-09-24 19:31:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:31:43 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Table Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Session Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Loader Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:31:43 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Controller Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:31:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:31:43 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Session Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Session routines successfully run
DEBUG - 2016-09-24 19:31:43 --> Config Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:31:43 --> Hooks Class Initialized
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "first_link"
DEBUG - 2016-09-24 19:31:43 --> Encrypt Class Initialized
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "last_link"
DEBUG - 2016-09-24 19:31:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:31:43 --> UTF-8 Support Enabled
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:31:43 --> URI Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Router Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:31:43 --> Table Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Config Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Output Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Security Class Initialized
DEBUG - 2016-09-24 19:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:31:43 --> Input Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> URI Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Controller Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Router Class Initialized
DEBUG - 2016-09-24 19:31:43 --> XSS Filtering completed
DEBUG - 2016-09-24 19:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:31:43 --> Language Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Output Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Security Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Input Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Loader Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:31:43 --> Config Class Initialized
DEBUG - 2016-09-24 19:31:43 --> XSS Filtering completed
DEBUG - 2016-09-24 19:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:31:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Language Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:31:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:31:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:31:43 --> URI Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Router Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Loader Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Output Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:31:43 --> Database Driver Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Security Class Initialized
ERROR - 2016-09-24 19:31:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-24 19:31:43 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:31:43 --> Input Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Database Driver Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Session routines successfully run
ERROR - 2016-09-24 19:31:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-24 19:31:43 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "first_link"
DEBUG - 2016-09-24 19:31:43 --> XSS Filtering completed
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "last_link"
DEBUG - 2016-09-24 19:31:43 --> Global POST and COOKIE data sanitized
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:31:43 --> Language Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Table Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Session routines successfully run
DEBUG - 2016-09-24 19:31:43 --> Loader Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: url_helper
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "first_link"
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: file_helper
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:31:43 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:31:43 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Controller Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:31:43 --> Table Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:31:43 --> Database Driver Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Model Class Initialized
ERROR - 2016-09-24 19:31:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-24 19:31:43 --> Severity: Notice  --> mysql_pconnect(): send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:31:43 --> Controller Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:31:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:31:43 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:31:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:31:43 --> Session Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:31:43 --> Session Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Session Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:31:43 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:31:43 --> Config Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:31:43 --> URI Class Initialized
DEBUG - 2016-09-24 19:31:43 --> Router Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Output Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Security Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Input Class Initialized
DEBUG - 2016-09-24 19:31:44 --> XSS Filtering completed
DEBUG - 2016-09-24 19:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:31:44 --> Language Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Session routines successfully run
DEBUG - 2016-09-24 19:31:44 --> Session routines successfully run
DEBUG - 2016-09-24 19:31:44 --> Loader Class Initialized
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "next_link"
DEBUG - 2016-09-24 19:31:44 --> Helper loaded: url_helper
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "prev_link"
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:31:44 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:31:44 --> Table Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Table Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:31:44 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Session routines successfully run
DEBUG - 2016-09-24 19:31:44 --> Model Class Initialized
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "first_link"
DEBUG - 2016-09-24 19:31:44 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:31:44 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:31:44 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "last_link"
DEBUG - 2016-09-24 19:31:44 --> Model Class Initialized
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "next_link"
DEBUG - 2016-09-24 19:31:44 --> Model Class Initialized
ERROR - 2016-09-24 19:31:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:31:44 --> Controller Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Controller Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Table Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Session Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:31:44 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:31:44 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:31:44 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:31:44 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:31:44 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:31:44 --> Controller Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Session routines successfully run
DEBUG - 2016-09-24 19:31:44 --> Helper loaded: language_helper
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "first_link"
DEBUG - 2016-09-24 19:31:44 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:31:44 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:31:44 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Table Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:31:44 --> Model Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Controller Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:31:44 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:31:44 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:31:47 --> Final output sent to browser
DEBUG - 2016-09-24 19:31:47 --> Total execution time: 3.9482
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:31:47 --> Final output sent to browser
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:31:47 --> Total execution time: 4.2622
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:31:47 --> Final output sent to browser
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:31:47 --> Final output sent to browser
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:31:47 --> Final output sent to browser
DEBUG - 2016-09-24 19:31:47 --> Total execution time: 4.1012
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:31:47 --> Total execution time: 3.9352
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:31:47 --> Total execution time: 4.1312
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:31:47 --> Final output sent to browser
DEBUG - 2016-09-24 19:31:47 --> Final output sent to browser
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:31:47 --> Total execution time: 4.2112
DEBUG - 2016-09-24 19:31:47 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:31:47 --> Final output sent to browser
DEBUG - 2016-09-24 19:31:47 --> Total execution time: 4.3733
DEBUG - 2016-09-24 19:31:47 --> Final output sent to browser
DEBUG - 2016-09-24 19:31:47 --> Total execution time: 4.2442
DEBUG - 2016-09-24 19:31:47 --> Final output sent to browser
DEBUG - 2016-09-24 19:31:47 --> Final output sent to browser
DEBUG - 2016-09-24 19:31:47 --> Total execution time: 4.3172
DEBUG - 2016-09-24 19:31:47 --> Total execution time: 4.3532
DEBUG - 2016-09-24 19:31:47 --> Total execution time: 4.1562
DEBUG - 2016-09-24 19:36:10 --> Config Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:36:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:36:10 --> URI Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Router Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Output Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Security Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Input Class Initialized
DEBUG - 2016-09-24 19:36:10 --> XSS Filtering completed
DEBUG - 2016-09-24 19:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:36:10 --> Language Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Loader Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:36:10 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:36:10 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:36:10 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:36:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:36:10 --> Session Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:36:10 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Session routines successfully run
ERROR - 2016-09-24 19:36:10 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:36:10 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:36:10 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:36:10 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:36:10 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Table Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Model Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Model Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:36:10 --> Model Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Controller Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:36:10 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:36:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:36:12 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:36:12 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:36:12 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:36:12 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:36:12 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:36:12 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:36:12 --> Final output sent to browser
DEBUG - 2016-09-24 19:36:12 --> Total execution time: 2.1471
DEBUG - 2016-09-24 19:37:06 --> Config Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:37:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:37:06 --> URI Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Router Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Output Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Security Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Input Class Initialized
DEBUG - 2016-09-24 19:37:06 --> XSS Filtering completed
DEBUG - 2016-09-24 19:37:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:37:06 --> Language Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Loader Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:37:06 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:37:06 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:37:06 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:37:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:37:06 --> Session Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:37:06 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Session routines successfully run
ERROR - 2016-09-24 19:37:06 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:37:06 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:37:06 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:37:06 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:37:06 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Table Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Model Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Model Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:37:06 --> Model Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Controller Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:37:06 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:37:06 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:37:08 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:37:08 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:37:08 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:37:08 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:37:08 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:37:08 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:37:08 --> Final output sent to browser
DEBUG - 2016-09-24 19:37:08 --> Total execution time: 2.0541
DEBUG - 2016-09-24 19:41:24 --> Config Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:41:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:41:24 --> URI Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Router Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Output Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Security Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Input Class Initialized
DEBUG - 2016-09-24 19:41:24 --> XSS Filtering completed
DEBUG - 2016-09-24 19:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:41:24 --> Language Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Loader Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:41:24 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:41:24 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:41:24 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:41:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:41:24 --> Session Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:41:24 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Session routines successfully run
ERROR - 2016-09-24 19:41:24 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:41:24 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:41:24 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:41:24 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:41:24 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Table Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Model Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Model Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:41:24 --> Model Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Controller Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:41:24 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:41:24 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:41:26 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:41:26 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:41:26 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:41:26 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:41:26 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:41:26 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:41:26 --> Final output sent to browser
DEBUG - 2016-09-24 19:41:26 --> Total execution time: 2.4401
DEBUG - 2016-09-24 19:41:52 --> Config Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:41:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:41:52 --> URI Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Router Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Output Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Security Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Input Class Initialized
DEBUG - 2016-09-24 19:41:52 --> XSS Filtering completed
DEBUG - 2016-09-24 19:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:41:52 --> Language Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Loader Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:41:52 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:41:52 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:41:52 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:41:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:41:52 --> Session Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:41:52 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Session routines successfully run
ERROR - 2016-09-24 19:41:52 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:41:52 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:41:52 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:41:52 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:41:52 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Table Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Model Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Model Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:41:52 --> Model Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Controller Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:41:52 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:41:52 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:41:54 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:41:54 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:41:54 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:41:54 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:41:54 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:41:54 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:41:54 --> Final output sent to browser
DEBUG - 2016-09-24 19:41:54 --> Total execution time: 2.2351
DEBUG - 2016-09-24 19:42:02 --> Config Class Initialized
DEBUG - 2016-09-24 19:42:02 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:42:02 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:42:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:42:02 --> URI Class Initialized
DEBUG - 2016-09-24 19:42:02 --> Router Class Initialized
DEBUG - 2016-09-24 19:42:02 --> Output Class Initialized
DEBUG - 2016-09-24 19:42:02 --> Security Class Initialized
DEBUG - 2016-09-24 19:42:03 --> Input Class Initialized
DEBUG - 2016-09-24 19:42:03 --> XSS Filtering completed
DEBUG - 2016-09-24 19:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:42:03 --> Language Class Initialized
DEBUG - 2016-09-24 19:42:03 --> Loader Class Initialized
DEBUG - 2016-09-24 19:42:03 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:42:03 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:42:03 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:42:03 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:42:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:42:03 --> Session Class Initialized
DEBUG - 2016-09-24 19:42:03 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:42:03 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:42:03 --> Session routines successfully run
ERROR - 2016-09-24 19:42:03 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:42:03 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:42:03 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:42:03 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:42:03 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:42:03 --> Table Class Initialized
DEBUG - 2016-09-24 19:42:03 --> Model Class Initialized
DEBUG - 2016-09-24 19:42:03 --> Model Class Initialized
DEBUG - 2016-09-24 19:42:03 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:42:03 --> Model Class Initialized
DEBUG - 2016-09-24 19:42:03 --> Controller Class Initialized
DEBUG - 2016-09-24 19:42:03 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:42:03 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:42:03 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:42:04 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:42:04 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:42:04 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:42:04 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:42:04 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:42:04 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:42:04 --> Final output sent to browser
DEBUG - 2016-09-24 19:42:04 --> Total execution time: 1.8261
DEBUG - 2016-09-24 19:44:32 --> Config Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:44:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:44:32 --> URI Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Router Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Output Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Security Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Input Class Initialized
DEBUG - 2016-09-24 19:44:32 --> XSS Filtering completed
DEBUG - 2016-09-24 19:44:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:44:32 --> Language Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Loader Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:44:32 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:44:32 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:44:32 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:44:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:44:32 --> Session Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:44:32 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Session routines successfully run
ERROR - 2016-09-24 19:44:32 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:44:32 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:44:32 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:44:32 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:44:32 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Table Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Model Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Model Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:44:32 --> Model Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Controller Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:44:32 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:44:32 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:44:35 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:44:35 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:44:35 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:44:35 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:44:35 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:44:35 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:44:35 --> Final output sent to browser
DEBUG - 2016-09-24 19:44:35 --> Total execution time: 2.2231
DEBUG - 2016-09-24 19:49:08 --> Config Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Hooks Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Utf8 Class Initialized
DEBUG - 2016-09-24 19:49:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 19:49:08 --> URI Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Router Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Output Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Security Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Input Class Initialized
DEBUG - 2016-09-24 19:49:08 --> XSS Filtering completed
DEBUG - 2016-09-24 19:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 19:49:08 --> Language Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Loader Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Helper loaded: url_helper
DEBUG - 2016-09-24 19:49:08 --> Helper loaded: form_helper
DEBUG - 2016-09-24 19:49:08 --> Helper loaded: func_helper
DEBUG - 2016-09-24 19:49:08 --> Database Driver Class Initialized
ERROR - 2016-09-24 19:49:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 19:49:08 --> Session Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Helper loaded: string_helper
DEBUG - 2016-09-24 19:49:08 --> Encrypt Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Session routines successfully run
ERROR - 2016-09-24 19:49:08 --> Could not find the language line "first_link"
ERROR - 2016-09-24 19:49:08 --> Could not find the language line "last_link"
ERROR - 2016-09-24 19:49:08 --> Could not find the language line "next_link"
ERROR - 2016-09-24 19:49:08 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 19:49:08 --> Pagination Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Table Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Model Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Model Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Helper loaded: file_helper
DEBUG - 2016-09-24 19:49:08 --> Model Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Controller Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Form Validation Class Initialized
DEBUG - 2016-09-24 19:49:08 --> Helper loaded: language_helper
DEBUG - 2016-09-24 19:49:08 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 19:49:10 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 19:49:10 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 19:49:10 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 19:49:10 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 19:49:10 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 19:49:10 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 19:49:10 --> Final output sent to browser
DEBUG - 2016-09-24 19:49:10 --> Total execution time: 2.3041
DEBUG - 2016-09-24 21:15:17 --> Config Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:15:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:15:17 --> URI Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Router Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Output Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Security Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Input Class Initialized
DEBUG - 2016-09-24 21:15:17 --> XSS Filtering completed
DEBUG - 2016-09-24 21:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:15:17 --> Language Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Loader Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:15:17 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:15:17 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:15:17 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:15:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:15:17 --> Session Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:15:17 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:15:17 --> A session cookie was not found.
DEBUG - 2016-09-24 21:15:17 --> Session routines successfully run
ERROR - 2016-09-24 21:15:17 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:15:17 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:15:17 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:15:17 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:15:17 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Table Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:15:17 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Controller Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Config Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:15:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:15:17 --> URI Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Router Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Output Class Initialized
DEBUG - 2016-09-24 21:15:17 --> Security Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Input Class Initialized
DEBUG - 2016-09-24 21:15:18 --> XSS Filtering completed
DEBUG - 2016-09-24 21:15:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:15:18 --> Language Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Loader Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:15:18 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:15:18 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:15:18 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:15:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:15:18 --> Session Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:15:18 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Session routines successfully run
ERROR - 2016-09-24 21:15:18 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:15:18 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:15:18 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:15:18 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:15:18 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Table Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:15:18 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Controller Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:15:18 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:15:18 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:15:18 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 21:15:18 --> File loaded: application/views/login_form.php
DEBUG - 2016-09-24 21:15:18 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 21:15:18 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 21:15:18 --> Final output sent to browser
DEBUG - 2016-09-24 21:15:18 --> Total execution time: 0.0640
DEBUG - 2016-09-24 21:15:18 --> Config Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:15:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:15:18 --> URI Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Router Class Initialized
ERROR - 2016-09-24 21:15:18 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 21:15:18 --> Config Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:15:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:15:18 --> URI Class Initialized
DEBUG - 2016-09-24 21:15:18 --> Router Class Initialized
ERROR - 2016-09-24 21:15:18 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 21:15:25 --> Config Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:15:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:15:25 --> URI Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Router Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Output Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Security Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Input Class Initialized
DEBUG - 2016-09-24 21:15:25 --> XSS Filtering completed
DEBUG - 2016-09-24 21:15:25 --> XSS Filtering completed
DEBUG - 2016-09-24 21:15:25 --> XSS Filtering completed
DEBUG - 2016-09-24 21:15:25 --> XSS Filtering completed
DEBUG - 2016-09-24 21:15:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:15:25 --> Language Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Loader Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:15:25 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:15:25 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:15:25 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:15:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:15:25 --> Session Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:15:25 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Session routines successfully run
ERROR - 2016-09-24 21:15:25 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:15:25 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:15:25 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:15:25 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:15:25 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Table Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:15:25 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Controller Class Initialized
DEBUG - 2016-09-24 21:15:25 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:15:25 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:15:25 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:27 --> Config Class Initialized
DEBUG - 2016-09-24 21:15:27 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:15:27 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:15:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:15:27 --> URI Class Initialized
DEBUG - 2016-09-24 21:15:27 --> Router Class Initialized
DEBUG - 2016-09-24 21:15:27 --> Output Class Initialized
DEBUG - 2016-09-24 21:15:27 --> Security Class Initialized
DEBUG - 2016-09-24 21:15:27 --> Input Class Initialized
DEBUG - 2016-09-24 21:15:27 --> XSS Filtering completed
DEBUG - 2016-09-24 21:15:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:15:27 --> Language Class Initialized
DEBUG - 2016-09-24 21:15:27 --> Loader Class Initialized
DEBUG - 2016-09-24 21:15:27 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:15:27 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:15:27 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:15:27 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:15:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:15:27 --> Session Class Initialized
DEBUG - 2016-09-24 21:15:27 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:15:27 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:15:28 --> Session routines successfully run
ERROR - 2016-09-24 21:15:28 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:15:28 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:15:28 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:15:28 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:15:28 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:15:28 --> Table Class Initialized
DEBUG - 2016-09-24 21:15:28 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:28 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:28 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:15:28 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:28 --> Controller Class Initialized
DEBUG - 2016-09-24 21:15:28 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:15:28 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:15:28 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:15:30 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:15:30 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:15:30 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:15:30 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:15:30 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:15:30 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:15:30 --> Final output sent to browser
DEBUG - 2016-09-24 21:15:30 --> Total execution time: 2.4700
DEBUG - 2016-09-24 21:15:41 --> Config Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:15:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:15:41 --> URI Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Router Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Output Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Security Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Input Class Initialized
DEBUG - 2016-09-24 21:15:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:15:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:15:41 --> Language Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Loader Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:15:41 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:15:41 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:15:41 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:15:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:15:41 --> Session Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:15:41 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Session routines successfully run
ERROR - 2016-09-24 21:15:41 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:15:41 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:15:41 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:15:41 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:15:41 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Table Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:15:41 --> Model Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Controller Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:15:41 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:15:41 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:15:42 --> Final output sent to browser
DEBUG - 2016-09-24 21:15:42 --> Total execution time: 0.2500
DEBUG - 2016-09-24 21:27:32 --> Config Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:27:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:27:32 --> URI Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Router Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Output Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Security Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Input Class Initialized
DEBUG - 2016-09-24 21:27:32 --> XSS Filtering completed
DEBUG - 2016-09-24 21:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:27:32 --> Language Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Loader Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:27:32 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:27:32 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:27:32 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:27:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:27:32 --> Session Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:27:32 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Session routines successfully run
ERROR - 2016-09-24 21:27:32 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:27:32 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:27:32 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:27:32 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:27:32 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Table Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Model Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Model Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:27:32 --> Model Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Controller Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:27:32 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:27:32 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:27:35 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:27:35 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:27:35 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:28:20 --> Config Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:28:20 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:28:20 --> URI Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Router Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Output Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Security Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Input Class Initialized
DEBUG - 2016-09-24 21:28:20 --> XSS Filtering completed
DEBUG - 2016-09-24 21:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:28:20 --> Language Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Loader Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:28:20 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:28:20 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:28:20 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:28:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:28:20 --> Session Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:28:20 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Session routines successfully run
ERROR - 2016-09-24 21:28:20 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:28:20 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:28:20 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:28:20 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:28:20 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Table Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Model Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Model Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:28:20 --> Model Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Controller Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:28:20 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:28:20 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:28:22 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:28:22 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:28:22 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:29:26 --> Config Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:29:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:29:26 --> URI Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Router Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Output Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Security Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Input Class Initialized
DEBUG - 2016-09-24 21:29:26 --> XSS Filtering completed
DEBUG - 2016-09-24 21:29:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:29:26 --> Language Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Loader Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:29:26 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:29:26 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:29:26 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:29:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:29:26 --> Session Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:29:26 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Session routines successfully run
ERROR - 2016-09-24 21:29:26 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:29:26 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:29:26 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:29:26 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:29:26 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Table Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Model Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Model Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:29:26 --> Model Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Controller Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:29:26 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:29:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:29:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:29:28 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:29:28 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:29:28 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:29:28 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:29:28 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:29:28 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:29:28 --> Final output sent to browser
DEBUG - 2016-09-24 21:29:28 --> Total execution time: 2.1200
DEBUG - 2016-09-24 21:29:36 --> Config Class Initialized
DEBUG - 2016-09-24 21:29:36 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:29:36 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:29:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:29:36 --> URI Class Initialized
DEBUG - 2016-09-24 21:29:36 --> Router Class Initialized
DEBUG - 2016-09-24 21:29:36 --> No URI present. Default controller set.
DEBUG - 2016-09-24 21:29:36 --> Output Class Initialized
DEBUG - 2016-09-24 21:29:36 --> Security Class Initialized
DEBUG - 2016-09-24 21:29:36 --> Input Class Initialized
DEBUG - 2016-09-24 21:29:36 --> XSS Filtering completed
DEBUG - 2016-09-24 21:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:29:36 --> Language Class Initialized
DEBUG - 2016-09-24 21:29:36 --> Loader Class Initialized
DEBUG - 2016-09-24 21:29:36 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:29:36 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:29:36 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:29:36 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:29:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:29:36 --> Session Class Initialized
DEBUG - 2016-09-24 21:29:36 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:29:36 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:29:36 --> Session routines successfully run
ERROR - 2016-09-24 21:29:36 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:29:36 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:29:36 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:29:36 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:29:36 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:29:36 --> Table Class Initialized
DEBUG - 2016-09-24 21:29:36 --> Model Class Initialized
DEBUG - 2016-09-24 21:29:36 --> Model Class Initialized
DEBUG - 2016-09-24 21:29:36 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:29:36 --> Model Class Initialized
DEBUG - 2016-09-24 21:29:36 --> Controller Class Initialized
DEBUG - 2016-09-24 21:29:37 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:29:37 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:29:39 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-24 21:29:42 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:29:42 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 21:29:42 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-24 21:29:42 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-24 21:29:42 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-24 21:29:42 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 21:29:42 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 21:29:42 --> Final output sent to browser
DEBUG - 2016-09-24 21:29:42 --> Total execution time: 6.2320
DEBUG - 2016-09-24 21:29:42 --> Config Class Initialized
DEBUG - 2016-09-24 21:29:42 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:29:42 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:29:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:29:42 --> URI Class Initialized
DEBUG - 2016-09-24 21:29:42 --> Router Class Initialized
ERROR - 2016-09-24 21:29:42 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 21:29:42 --> Config Class Initialized
DEBUG - 2016-09-24 21:29:42 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:29:42 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:29:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:29:42 --> URI Class Initialized
DEBUG - 2016-09-24 21:29:42 --> Router Class Initialized
ERROR - 2016-09-24 21:29:42 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 21:30:09 --> Config Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:30:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:30:09 --> URI Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Router Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Output Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Security Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Input Class Initialized
DEBUG - 2016-09-24 21:30:09 --> XSS Filtering completed
DEBUG - 2016-09-24 21:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:30:09 --> Language Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Loader Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:30:09 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:30:09 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:30:09 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:30:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:30:09 --> Session Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:30:09 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Session routines successfully run
ERROR - 2016-09-24 21:30:09 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:30:09 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:30:09 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:30:09 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:30:09 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Table Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Model Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Model Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:30:09 --> Model Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Controller Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:30:09 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:30:09 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:30:11 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:30:11 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:30:11 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:30:11 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:30:11 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:30:11 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:30:11 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:30:11 --> Final output sent to browser
DEBUG - 2016-09-24 21:30:11 --> Total execution time: 2.2240
DEBUG - 2016-09-24 21:30:17 --> Config Class Initialized
DEBUG - 2016-09-24 21:30:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:30:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:30:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:30:17 --> URI Class Initialized
DEBUG - 2016-09-24 21:30:17 --> Router Class Initialized
DEBUG - 2016-09-24 21:30:17 --> No URI present. Default controller set.
DEBUG - 2016-09-24 21:30:17 --> Output Class Initialized
DEBUG - 2016-09-24 21:30:17 --> Security Class Initialized
DEBUG - 2016-09-24 21:30:17 --> Input Class Initialized
DEBUG - 2016-09-24 21:30:17 --> XSS Filtering completed
DEBUG - 2016-09-24 21:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:30:17 --> Language Class Initialized
DEBUG - 2016-09-24 21:30:17 --> Loader Class Initialized
DEBUG - 2016-09-24 21:30:17 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:30:17 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:30:17 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:30:17 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:30:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:30:17 --> Session Class Initialized
DEBUG - 2016-09-24 21:30:17 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:30:17 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:30:17 --> Session routines successfully run
ERROR - 2016-09-24 21:30:17 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:30:17 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:30:17 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:30:17 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:30:17 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:30:17 --> Table Class Initialized
DEBUG - 2016-09-24 21:30:17 --> Model Class Initialized
DEBUG - 2016-09-24 21:30:17 --> Model Class Initialized
DEBUG - 2016-09-24 21:30:17 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:30:17 --> Model Class Initialized
DEBUG - 2016-09-24 21:30:17 --> Controller Class Initialized
DEBUG - 2016-09-24 21:30:19 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:30:19 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:30:21 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-24 21:30:23 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:30:23 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 21:30:23 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-24 21:30:23 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-24 21:30:23 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-24 21:30:23 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 21:30:23 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 21:30:23 --> Final output sent to browser
DEBUG - 2016-09-24 21:30:23 --> Total execution time: 6.6760
DEBUG - 2016-09-24 21:30:24 --> Config Class Initialized
DEBUG - 2016-09-24 21:30:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:30:24 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:30:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:30:24 --> URI Class Initialized
DEBUG - 2016-09-24 21:30:24 --> Router Class Initialized
ERROR - 2016-09-24 21:30:24 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 21:31:26 --> Config Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:31:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:31:26 --> URI Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Router Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Output Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Security Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Input Class Initialized
DEBUG - 2016-09-24 21:31:26 --> XSS Filtering completed
DEBUG - 2016-09-24 21:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:31:26 --> Language Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Loader Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:31:26 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:31:26 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:31:26 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:31:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:31:26 --> Session Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:31:26 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Session routines successfully run
ERROR - 2016-09-24 21:31:26 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:31:26 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:31:26 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:31:26 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:31:26 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Table Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Model Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Model Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:31:26 --> Model Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Controller Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:31:26 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:31:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:31:28 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:31:28 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:31:28 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:31:28 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:31:28 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:31:28 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:31:28 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:31:28 --> Final output sent to browser
DEBUG - 2016-09-24 21:31:28 --> Total execution time: 1.8930
DEBUG - 2016-09-24 21:31:30 --> Config Class Initialized
DEBUG - 2016-09-24 21:31:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:31:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:31:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:31:30 --> URI Class Initialized
DEBUG - 2016-09-24 21:31:30 --> Router Class Initialized
DEBUG - 2016-09-24 21:31:30 --> No URI present. Default controller set.
DEBUG - 2016-09-24 21:31:30 --> Output Class Initialized
DEBUG - 2016-09-24 21:31:30 --> Security Class Initialized
DEBUG - 2016-09-24 21:31:30 --> Input Class Initialized
DEBUG - 2016-09-24 21:31:30 --> XSS Filtering completed
DEBUG - 2016-09-24 21:31:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:31:30 --> Language Class Initialized
DEBUG - 2016-09-24 21:31:30 --> Loader Class Initialized
DEBUG - 2016-09-24 21:31:30 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:31:30 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:31:30 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:31:30 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:31:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:31:30 --> Session Class Initialized
DEBUG - 2016-09-24 21:31:30 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:31:30 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:31:30 --> Session routines successfully run
ERROR - 2016-09-24 21:31:30 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:31:30 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:31:30 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:31:30 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:31:30 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:31:30 --> Table Class Initialized
DEBUG - 2016-09-24 21:31:30 --> Model Class Initialized
DEBUG - 2016-09-24 21:31:30 --> Model Class Initialized
DEBUG - 2016-09-24 21:31:30 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:31:30 --> Model Class Initialized
DEBUG - 2016-09-24 21:31:30 --> Controller Class Initialized
DEBUG - 2016-09-24 21:31:32 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:31:32 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:31:33 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-24 21:31:36 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:31:36 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 21:31:36 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-24 21:31:36 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-24 21:31:36 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-24 21:31:36 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 21:31:36 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 21:31:36 --> Final output sent to browser
DEBUG - 2016-09-24 21:31:36 --> Total execution time: 6.0720
DEBUG - 2016-09-24 21:31:36 --> Config Class Initialized
DEBUG - 2016-09-24 21:31:36 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:31:36 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:31:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:31:36 --> URI Class Initialized
DEBUG - 2016-09-24 21:31:36 --> Router Class Initialized
ERROR - 2016-09-24 21:31:36 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 21:31:36 --> Config Class Initialized
DEBUG - 2016-09-24 21:31:36 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:31:36 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:31:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:31:36 --> URI Class Initialized
DEBUG - 2016-09-24 21:31:36 --> Router Class Initialized
ERROR - 2016-09-24 21:31:36 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 21:31:41 --> Config Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:31:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:31:41 --> URI Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Router Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Output Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Security Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Input Class Initialized
DEBUG - 2016-09-24 21:31:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:31:41 --> Language Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Loader Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:31:41 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:31:41 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:31:41 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:31:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:31:41 --> Session Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:31:41 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Session routines successfully run
ERROR - 2016-09-24 21:31:41 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:31:41 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:31:41 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:31:41 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:31:41 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Table Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Model Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Model Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:31:41 --> Model Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Controller Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:31:41 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:31:41 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:31:43 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:31:43 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:31:43 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:31:43 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:31:43 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:31:43 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:31:43 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:31:43 --> Final output sent to browser
DEBUG - 2016-09-24 21:31:43 --> Total execution time: 2.5760
DEBUG - 2016-09-24 21:33:27 --> Config Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:33:27 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:33:27 --> URI Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Router Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Output Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Security Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Input Class Initialized
DEBUG - 2016-09-24 21:33:27 --> XSS Filtering completed
DEBUG - 2016-09-24 21:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:33:27 --> Language Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Loader Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:33:27 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:33:27 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:33:27 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:33:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:33:27 --> Session Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:33:27 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Session routines successfully run
ERROR - 2016-09-24 21:33:27 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:33:27 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:33:27 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:33:27 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:33:27 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Table Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Model Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Model Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:33:27 --> Model Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Controller Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:33:27 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:33:27 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:33:30 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:33:30 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:33:30 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:33:30 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:33:30 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:33:30 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:33:30 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:33:30 --> Final output sent to browser
DEBUG - 2016-09-24 21:33:30 --> Total execution time: 2.6902
DEBUG - 2016-09-24 21:37:04 --> Config Class Initialized
DEBUG - 2016-09-24 21:37:04 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:37:04 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:37:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:37:04 --> URI Class Initialized
DEBUG - 2016-09-24 21:37:04 --> Router Class Initialized
DEBUG - 2016-09-24 21:37:04 --> Output Class Initialized
DEBUG - 2016-09-24 21:37:04 --> Security Class Initialized
DEBUG - 2016-09-24 21:37:04 --> Input Class Initialized
DEBUG - 2016-09-24 21:37:04 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:37:04 --> Language Class Initialized
DEBUG - 2016-09-24 21:37:04 --> Loader Class Initialized
DEBUG - 2016-09-24 21:37:04 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:37:04 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:37:04 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:37:04 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:37:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:37:04 --> Session Class Initialized
DEBUG - 2016-09-24 21:37:04 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:37:04 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:37:04 --> A session cookie was not found.
DEBUG - 2016-09-24 21:37:04 --> Session routines successfully run
ERROR - 2016-09-24 21:37:04 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:37:04 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:37:04 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:37:04 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:37:04 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:37:04 --> Table Class Initialized
DEBUG - 2016-09-24 21:37:04 --> Model Class Initialized
DEBUG - 2016-09-24 21:37:04 --> Model Class Initialized
DEBUG - 2016-09-24 21:37:04 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:37:04 --> Model Class Initialized
DEBUG - 2016-09-24 21:37:04 --> Controller Class Initialized
DEBUG - 2016-09-24 21:37:06 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:37:06 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:37:06 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:37:06 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 21:37:06 --> File loaded: application/views/signup/main.php
DEBUG - 2016-09-24 21:37:06 --> File loaded: application/views/signup/login.php
DEBUG - 2016-09-24 21:37:06 --> File loaded: application/views/signup/personal.php
ERROR - 2016-09-24 21:37:06 --> Could not find the language line "register"
DEBUG - 2016-09-24 21:37:06 --> File loaded: application/views/alumni_signup.php
DEBUG - 2016-09-24 21:37:06 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 21:37:06 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 21:37:06 --> Final output sent to browser
DEBUG - 2016-09-24 21:37:06 --> Total execution time: 1.7381
DEBUG - 2016-09-24 21:37:06 --> Config Class Initialized
DEBUG - 2016-09-24 21:37:06 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:37:06 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:37:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:37:06 --> URI Class Initialized
DEBUG - 2016-09-24 21:37:06 --> Router Class Initialized
ERROR - 2016-09-24 21:37:06 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 21:37:38 --> Config Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:37:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:37:38 --> URI Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Router Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Output Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Security Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Input Class Initialized
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:37:38 --> Language Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Loader Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:37:38 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:37:38 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:37:38 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:37:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:37:38 --> Session Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:37:38 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Session routines successfully run
ERROR - 2016-09-24 21:37:38 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:37:38 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:37:38 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:37:38 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:37:38 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Table Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Model Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Model Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:37:38 --> Model Class Initialized
DEBUG - 2016-09-24 21:37:38 --> Controller Class Initialized
DEBUG - 2016-09-24 21:37:40 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:37:40 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:37:40 --> Form Validation Class Initialized
ERROR - 2016-09-24 21:37:40 --> Could not find the language line "year"
ERROR - 2016-09-24 21:37:40 --> Could not find the language line "retype"
DEBUG - 2016-09-24 21:37:40 --> Language file loaded: language/arabic/form_validation_lang.php
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> Config Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:37:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:37:41 --> URI Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Router Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Output Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Security Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Input Class Initialized
DEBUG - 2016-09-24 21:37:41 --> XSS Filtering completed
DEBUG - 2016-09-24 21:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:37:41 --> Language Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Loader Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:37:41 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:37:41 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:37:41 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:37:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:37:41 --> Session Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:37:41 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Session routines successfully run
ERROR - 2016-09-24 21:37:41 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:37:41 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:37:41 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:37:41 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:37:41 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Table Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Model Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Model Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:37:41 --> Model Class Initialized
DEBUG - 2016-09-24 21:37:41 --> Controller Class Initialized
DEBUG - 2016-09-24 21:37:43 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:37:43 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-24 21:37:43 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-09-24 21:37:43 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:37:43 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 21:37:43 --> File loaded: application/views/signup/complete.php
DEBUG - 2016-09-24 21:37:43 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 21:37:43 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 21:37:43 --> Final output sent to browser
DEBUG - 2016-09-24 21:37:43 --> Total execution time: 2.0481
DEBUG - 2016-09-24 21:37:43 --> Config Class Initialized
DEBUG - 2016-09-24 21:37:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:37:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:37:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:37:43 --> URI Class Initialized
DEBUG - 2016-09-24 21:37:43 --> Router Class Initialized
ERROR - 2016-09-24 21:37:43 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 21:38:02 --> Config Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:38:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:38:02 --> URI Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Router Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Output Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Security Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Input Class Initialized
DEBUG - 2016-09-24 21:38:02 --> XSS Filtering completed
DEBUG - 2016-09-24 21:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:38:02 --> Language Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Loader Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:38:02 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:38:02 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:38:02 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:38:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:38:02 --> Session Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:38:02 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Session routines successfully run
ERROR - 2016-09-24 21:38:02 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:38:02 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:38:02 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:38:02 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:38:02 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Table Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Model Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Model Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:38:02 --> Model Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Controller Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:38:02 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:38:02 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:38:04 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:38:04 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:38:04 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:38:04 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:38:04 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:38:04 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:38:04 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:38:04 --> Final output sent to browser
DEBUG - 2016-09-24 21:38:04 --> Total execution time: 2.6130
DEBUG - 2016-09-24 21:40:02 --> Config Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:40:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:40:02 --> URI Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Router Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Output Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Security Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Input Class Initialized
DEBUG - 2016-09-24 21:40:02 --> XSS Filtering completed
DEBUG - 2016-09-24 21:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:40:02 --> Language Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Loader Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:40:02 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:40:02 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:40:02 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:40:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:40:02 --> Session Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:40:02 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Session routines successfully run
ERROR - 2016-09-24 21:40:02 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:40:02 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:40:02 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:40:02 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:40:02 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Table Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Model Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Model Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:40:02 --> Model Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Controller Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:40:02 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:40:02 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:40:03 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:40:03 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:40:03 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:40:03 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:40:03 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:40:03 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:40:03 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:40:03 --> Final output sent to browser
DEBUG - 2016-09-24 21:40:03 --> Total execution time: 1.3781
DEBUG - 2016-09-24 21:40:03 --> Config Class Initialized
DEBUG - 2016-09-24 21:40:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:40:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:40:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:40:03 --> URI Class Initialized
DEBUG - 2016-09-24 21:40:03 --> Router Class Initialized
DEBUG - 2016-09-24 21:40:03 --> Config Class Initialized
DEBUG - 2016-09-24 21:40:03 --> Hooks Class Initialized
ERROR - 2016-09-24 21:40:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:40:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:40:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:40:03 --> URI Class Initialized
DEBUG - 2016-09-24 21:40:03 --> Router Class Initialized
ERROR - 2016-09-24 21:40:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:42:14 --> Config Class Initialized
DEBUG - 2016-09-24 21:42:14 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:42:14 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:42:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:42:14 --> URI Class Initialized
DEBUG - 2016-09-24 21:42:14 --> Router Class Initialized
DEBUG - 2016-09-24 21:42:14 --> Output Class Initialized
DEBUG - 2016-09-24 21:42:14 --> Security Class Initialized
DEBUG - 2016-09-24 21:42:14 --> Input Class Initialized
DEBUG - 2016-09-24 21:42:14 --> XSS Filtering completed
DEBUG - 2016-09-24 21:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:42:14 --> Language Class Initialized
DEBUG - 2016-09-24 21:42:14 --> Loader Class Initialized
DEBUG - 2016-09-24 21:42:14 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:42:14 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:42:14 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:42:14 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:42:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:42:14 --> Session Class Initialized
DEBUG - 2016-09-24 21:42:14 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:42:14 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:42:15 --> Session routines successfully run
ERROR - 2016-09-24 21:42:15 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:42:15 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:42:15 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:42:15 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:42:15 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:42:15 --> Table Class Initialized
DEBUG - 2016-09-24 21:42:15 --> Model Class Initialized
DEBUG - 2016-09-24 21:42:15 --> Model Class Initialized
DEBUG - 2016-09-24 21:42:15 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:42:15 --> Model Class Initialized
DEBUG - 2016-09-24 21:42:15 --> Controller Class Initialized
DEBUG - 2016-09-24 21:42:15 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:42:15 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:42:15 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:42:16 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:42:16 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:42:16 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:42:16 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:42:16 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:42:16 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:42:16 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:42:16 --> Final output sent to browser
DEBUG - 2016-09-24 21:42:16 --> Total execution time: 1.4101
DEBUG - 2016-09-24 21:42:16 --> Config Class Initialized
DEBUG - 2016-09-24 21:42:16 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:42:16 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:42:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:42:16 --> Config Class Initialized
DEBUG - 2016-09-24 21:42:16 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:42:16 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:42:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:42:16 --> URI Class Initialized
DEBUG - 2016-09-24 21:42:16 --> Router Class Initialized
ERROR - 2016-09-24 21:42:16 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:42:16 --> URI Class Initialized
DEBUG - 2016-09-24 21:42:16 --> Router Class Initialized
ERROR - 2016-09-24 21:42:16 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:42:48 --> Config Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:42:48 --> URI Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Router Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Output Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Security Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Input Class Initialized
DEBUG - 2016-09-24 21:42:48 --> XSS Filtering completed
DEBUG - 2016-09-24 21:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:42:48 --> Language Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Loader Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:42:48 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:42:48 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:42:48 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:42:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:42:48 --> Session Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:42:48 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Session routines successfully run
ERROR - 2016-09-24 21:42:48 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:42:48 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:42:48 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:42:48 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:42:48 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Table Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Model Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Model Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:42:48 --> Model Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Controller Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:42:48 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:42:48 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:42:49 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:42:49 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:42:49 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:42:49 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:42:49 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:42:49 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:42:49 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:42:49 --> Final output sent to browser
DEBUG - 2016-09-24 21:42:49 --> Total execution time: 1.3571
DEBUG - 2016-09-24 21:42:50 --> Config Class Initialized
DEBUG - 2016-09-24 21:42:50 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:42:50 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:42:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:42:50 --> URI Class Initialized
DEBUG - 2016-09-24 21:42:50 --> Config Class Initialized
DEBUG - 2016-09-24 21:42:50 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:42:50 --> Router Class Initialized
DEBUG - 2016-09-24 21:42:50 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:42:50 --> UTF-8 Support Enabled
ERROR - 2016-09-24 21:42:50 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:42:50 --> URI Class Initialized
DEBUG - 2016-09-24 21:42:50 --> Router Class Initialized
ERROR - 2016-09-24 21:42:50 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:45:58 --> Config Class Initialized
DEBUG - 2016-09-24 21:45:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:45:58 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:45:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:45:58 --> URI Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Router Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Output Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Security Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Input Class Initialized
DEBUG - 2016-09-24 21:45:59 --> XSS Filtering completed
DEBUG - 2016-09-24 21:45:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:45:59 --> Language Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Loader Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:45:59 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:45:59 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:45:59 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:45:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:45:59 --> Session Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:45:59 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Session routines successfully run
ERROR - 2016-09-24 21:45:59 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:45:59 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:45:59 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:45:59 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:45:59 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Table Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Model Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Model Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:45:59 --> Model Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Controller Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:45:59 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:45:59 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:46:00 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:46:00 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:46:00 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:46:00 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:46:00 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:46:00 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:46:00 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:46:00 --> Final output sent to browser
DEBUG - 2016-09-24 21:46:00 --> Total execution time: 1.3250
DEBUG - 2016-09-24 21:46:00 --> Config Class Initialized
DEBUG - 2016-09-24 21:46:00 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:46:00 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:46:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:46:00 --> URI Class Initialized
DEBUG - 2016-09-24 21:46:00 --> Router Class Initialized
DEBUG - 2016-09-24 21:46:00 --> Config Class Initialized
DEBUG - 2016-09-24 21:46:00 --> Hooks Class Initialized
ERROR - 2016-09-24 21:46:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:46:00 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:46:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:46:00 --> URI Class Initialized
DEBUG - 2016-09-24 21:46:00 --> Router Class Initialized
ERROR - 2016-09-24 21:46:00 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:46:23 --> Config Class Initialized
DEBUG - 2016-09-24 21:46:23 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:46:23 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:46:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:46:23 --> URI Class Initialized
DEBUG - 2016-09-24 21:46:23 --> Router Class Initialized
DEBUG - 2016-09-24 21:46:23 --> No URI present. Default controller set.
DEBUG - 2016-09-24 21:46:23 --> Output Class Initialized
DEBUG - 2016-09-24 21:46:23 --> Security Class Initialized
DEBUG - 2016-09-24 21:46:23 --> Input Class Initialized
DEBUG - 2016-09-24 21:46:23 --> XSS Filtering completed
DEBUG - 2016-09-24 21:46:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:46:23 --> Language Class Initialized
DEBUG - 2016-09-24 21:46:23 --> Loader Class Initialized
DEBUG - 2016-09-24 21:46:23 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:46:23 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:46:23 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:46:23 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:46:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:46:23 --> Session Class Initialized
DEBUG - 2016-09-24 21:46:23 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:46:23 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:46:23 --> Session routines successfully run
ERROR - 2016-09-24 21:46:23 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:46:23 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:46:23 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:46:23 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:46:23 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:46:23 --> Table Class Initialized
DEBUG - 2016-09-24 21:46:23 --> Model Class Initialized
DEBUG - 2016-09-24 21:46:23 --> Model Class Initialized
DEBUG - 2016-09-24 21:46:23 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:46:23 --> Model Class Initialized
DEBUG - 2016-09-24 21:46:23 --> Controller Class Initialized
DEBUG - 2016-09-24 21:46:25 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:46:25 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:46:27 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-24 21:46:30 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:46:30 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 21:46:30 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-24 21:46:30 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-24 21:46:30 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-24 21:46:30 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 21:46:30 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 21:46:30 --> Final output sent to browser
DEBUG - 2016-09-24 21:46:30 --> Total execution time: 7.2530
DEBUG - 2016-09-24 21:46:45 --> Config Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:46:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:46:45 --> URI Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Router Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Output Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Security Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Input Class Initialized
DEBUG - 2016-09-24 21:46:45 --> XSS Filtering completed
DEBUG - 2016-09-24 21:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:46:45 --> Language Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Loader Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:46:45 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:46:45 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:46:45 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:46:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:46:45 --> Session Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:46:45 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Session routines successfully run
ERROR - 2016-09-24 21:46:45 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:46:45 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:46:45 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:46:45 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:46:45 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Table Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Model Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Model Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:46:45 --> Model Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Controller Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:46:45 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:46:45 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-24 21:46:45 --> Could not find the language line "settings"
DEBUG - 2016-09-24 21:46:45 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:46:45 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:46:45 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:46:45 --> File loaded: application/views/admin/settings.php
DEBUG - 2016-09-24 21:46:45 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:46:45 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:46:45 --> Final output sent to browser
DEBUG - 2016-09-24 21:46:45 --> Total execution time: 0.1400
DEBUG - 2016-09-24 21:46:53 --> Config Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:46:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:46:53 --> URI Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Router Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Output Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Security Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Input Class Initialized
DEBUG - 2016-09-24 21:46:53 --> XSS Filtering completed
DEBUG - 2016-09-24 21:46:53 --> XSS Filtering completed
DEBUG - 2016-09-24 21:46:53 --> XSS Filtering completed
DEBUG - 2016-09-24 21:46:53 --> XSS Filtering completed
DEBUG - 2016-09-24 21:46:53 --> XSS Filtering completed
DEBUG - 2016-09-24 21:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:46:53 --> Language Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Loader Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:46:53 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:46:53 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:46:53 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:46:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:46:53 --> Session Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:46:53 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Session routines successfully run
ERROR - 2016-09-24 21:46:53 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:46:53 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:46:53 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:46:53 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:46:53 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Table Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Model Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Model Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:46:53 --> Model Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Controller Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:46:53 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:46:53 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-24 21:46:53 --> Could not find the language line "settings_updated"
DEBUG - 2016-09-24 21:46:55 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:46:55 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:46:55 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:46:55 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:46:55 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:46:55 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:46:55 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:46:55 --> Final output sent to browser
DEBUG - 2016-09-24 21:46:55 --> Total execution time: 1.2970
DEBUG - 2016-09-24 21:46:55 --> Config Class Initialized
DEBUG - 2016-09-24 21:46:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:46:55 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:46:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:46:55 --> Config Class Initialized
DEBUG - 2016-09-24 21:46:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:46:55 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:46:55 --> URI Class Initialized
DEBUG - 2016-09-24 21:46:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:46:55 --> Router Class Initialized
DEBUG - 2016-09-24 21:46:55 --> URI Class Initialized
ERROR - 2016-09-24 21:46:55 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:46:55 --> Router Class Initialized
ERROR - 2016-09-24 21:46:55 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:47:02 --> Config Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:47:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:47:02 --> URI Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Router Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Output Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Security Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Input Class Initialized
DEBUG - 2016-09-24 21:47:02 --> XSS Filtering completed
DEBUG - 2016-09-24 21:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:47:02 --> Language Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Loader Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:47:02 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:47:02 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:47:02 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:47:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:47:02 --> Session Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:47:02 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Session routines successfully run
ERROR - 2016-09-24 21:47:02 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:47:02 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:47:02 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:47:02 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:47:02 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Table Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Model Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Model Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:47:02 --> Model Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Controller Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:47:02 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:47:02 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:47:03 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:47:03 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:47:03 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:47:03 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:47:03 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:47:03 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:47:03 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:47:03 --> Final output sent to browser
DEBUG - 2016-09-24 21:47:03 --> Total execution time: 1.2790
DEBUG - 2016-09-24 21:47:03 --> Config Class Initialized
DEBUG - 2016-09-24 21:47:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:47:03 --> Config Class Initialized
DEBUG - 2016-09-24 21:47:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:47:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:47:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:47:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:47:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:47:03 --> URI Class Initialized
DEBUG - 2016-09-24 21:47:03 --> URI Class Initialized
DEBUG - 2016-09-24 21:47:03 --> Router Class Initialized
DEBUG - 2016-09-24 21:47:03 --> Router Class Initialized
ERROR - 2016-09-24 21:47:03 --> 404 Page Not Found --> application
ERROR - 2016-09-24 21:47:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:47:03 --> Config Class Initialized
DEBUG - 2016-09-24 21:47:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:47:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:47:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:47:04 --> Config Class Initialized
DEBUG - 2016-09-24 21:47:04 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:47:04 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:47:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:47:04 --> URI Class Initialized
DEBUG - 2016-09-24 21:47:04 --> URI Class Initialized
DEBUG - 2016-09-24 21:47:04 --> Router Class Initialized
ERROR - 2016-09-24 21:47:04 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:47:04 --> Config Class Initialized
DEBUG - 2016-09-24 21:47:04 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:47:04 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:47:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:47:04 --> Router Class Initialized
DEBUG - 2016-09-24 21:47:04 --> Config Class Initialized
DEBUG - 2016-09-24 21:47:04 --> URI Class Initialized
DEBUG - 2016-09-24 21:47:04 --> Hooks Class Initialized
ERROR - 2016-09-24 21:47:04 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:47:04 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:47:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:47:04 --> Router Class Initialized
DEBUG - 2016-09-24 21:47:04 --> URI Class Initialized
ERROR - 2016-09-24 21:47:04 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:47:04 --> Router Class Initialized
ERROR - 2016-09-24 21:47:04 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:48:10 --> Config Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:48:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:48:10 --> URI Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Router Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Output Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Security Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Input Class Initialized
DEBUG - 2016-09-24 21:48:10 --> XSS Filtering completed
DEBUG - 2016-09-24 21:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:48:10 --> Language Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Loader Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:48:10 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:48:10 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:48:10 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:48:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:48:10 --> Session Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:48:10 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Session routines successfully run
ERROR - 2016-09-24 21:48:10 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:48:10 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:48:10 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:48:10 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:48:10 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Table Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Model Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Model Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:48:10 --> Model Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Controller Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:48:10 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:48:10 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:48:11 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:48:11 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:48:11 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:48:11 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:48:11 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:48:11 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:48:11 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:48:11 --> Final output sent to browser
DEBUG - 2016-09-24 21:48:11 --> Total execution time: 1.3320
DEBUG - 2016-09-24 21:48:11 --> Config Class Initialized
DEBUG - 2016-09-24 21:48:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:48:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:48:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:48:11 --> URI Class Initialized
DEBUG - 2016-09-24 21:48:11 --> Router Class Initialized
ERROR - 2016-09-24 21:48:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:48:11 --> Config Class Initialized
DEBUG - 2016-09-24 21:48:11 --> Config Class Initialized
DEBUG - 2016-09-24 21:48:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:48:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:48:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:48:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:48:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:48:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:48:11 --> URI Class Initialized
DEBUG - 2016-09-24 21:48:11 --> URI Class Initialized
DEBUG - 2016-09-24 21:48:11 --> Router Class Initialized
DEBUG - 2016-09-24 21:48:11 --> Router Class Initialized
ERROR - 2016-09-24 21:48:11 --> 404 Page Not Found --> application
ERROR - 2016-09-24 21:48:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:48:12 --> Config Class Initialized
DEBUG - 2016-09-24 21:48:12 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:48:12 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:48:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:48:12 --> Config Class Initialized
DEBUG - 2016-09-24 21:48:12 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:48:12 --> URI Class Initialized
DEBUG - 2016-09-24 21:48:12 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:48:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:48:12 --> Router Class Initialized
DEBUG - 2016-09-24 21:48:12 --> URI Class Initialized
DEBUG - 2016-09-24 21:48:12 --> Router Class Initialized
ERROR - 2016-09-24 21:48:12 --> 404 Page Not Found --> application
ERROR - 2016-09-24 21:48:12 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:48:12 --> Config Class Initialized
DEBUG - 2016-09-24 21:48:12 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:48:12 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:48:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:48:12 --> URI Class Initialized
DEBUG - 2016-09-24 21:48:12 --> Router Class Initialized
ERROR - 2016-09-24 21:48:12 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:54:06 --> Config Class Initialized
DEBUG - 2016-09-24 21:54:06 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:54:06 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:54:06 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:54:06 --> URI Class Initialized
DEBUG - 2016-09-24 21:54:06 --> Router Class Initialized
DEBUG - 2016-09-24 21:54:06 --> Output Class Initialized
DEBUG - 2016-09-24 21:54:06 --> Security Class Initialized
DEBUG - 2016-09-24 21:54:06 --> Input Class Initialized
DEBUG - 2016-09-24 21:54:06 --> XSS Filtering completed
DEBUG - 2016-09-24 21:54:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:54:06 --> Language Class Initialized
DEBUG - 2016-09-24 21:54:06 --> Loader Class Initialized
DEBUG - 2016-09-24 21:54:06 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:54:06 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:54:06 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:54:06 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:54:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:54:06 --> Session Class Initialized
DEBUG - 2016-09-24 21:54:06 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:54:06 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:54:06 --> Session routines successfully run
ERROR - 2016-09-24 21:54:06 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:54:06 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:54:06 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:54:06 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:54:06 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:54:06 --> Table Class Initialized
DEBUG - 2016-09-24 21:54:06 --> Model Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Config Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:54:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:54:50 --> URI Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Router Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Output Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Security Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Input Class Initialized
DEBUG - 2016-09-24 21:54:50 --> XSS Filtering completed
DEBUG - 2016-09-24 21:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:54:50 --> Language Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Loader Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:54:50 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:54:50 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:54:50 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:54:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:54:50 --> Session Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:54:50 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Session routines successfully run
ERROR - 2016-09-24 21:54:50 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:54:50 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:54:50 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:54:50 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:54:50 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Table Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Model Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Model Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:54:50 --> Model Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Controller Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:54:50 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:54:50 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:54:51 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:54:51 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:54:51 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:54:51 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:54:51 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:54:51 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:54:51 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:54:51 --> Final output sent to browser
DEBUG - 2016-09-24 21:54:51 --> Total execution time: 1.2940
DEBUG - 2016-09-24 21:54:51 --> Config Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:54:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:54:51 --> URI Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Router Class Initialized
ERROR - 2016-09-24 21:54:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:54:51 --> Config Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:54:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:54:51 --> Config Class Initialized
DEBUG - 2016-09-24 21:54:51 --> URI Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Config Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:54:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:54:51 --> Router Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:54:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:54:51 --> URI Class Initialized
DEBUG - 2016-09-24 21:54:51 --> URI Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Router Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Config Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Hooks Class Initialized
ERROR - 2016-09-24 21:54:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:54:51 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:54:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:54:51 --> Router Class Initialized
DEBUG - 2016-09-24 21:54:51 --> URI Class Initialized
ERROR - 2016-09-24 21:54:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:54:51 --> Config Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Router Class Initialized
ERROR - 2016-09-24 21:54:51 --> 404 Page Not Found --> application
ERROR - 2016-09-24 21:54:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:54:51 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:54:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:54:51 --> URI Class Initialized
DEBUG - 2016-09-24 21:54:51 --> Router Class Initialized
ERROR - 2016-09-24 21:54:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:55:50 --> Config Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:55:50 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:55:50 --> URI Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Router Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Output Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Security Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Input Class Initialized
DEBUG - 2016-09-24 21:55:50 --> XSS Filtering completed
DEBUG - 2016-09-24 21:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:55:50 --> Language Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Loader Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:55:50 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:55:50 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:55:50 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:55:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:55:50 --> Session Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:55:50 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Session routines successfully run
ERROR - 2016-09-24 21:55:50 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:55:50 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:55:50 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:55:50 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:55:50 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Table Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Model Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Model Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:55:50 --> Model Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Controller Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:55:50 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:55:50 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:55:51 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:55:51 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:55:51 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:55:51 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:55:51 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:55:51 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:55:51 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:55:51 --> Final output sent to browser
DEBUG - 2016-09-24 21:55:51 --> Total execution time: 1.2840
DEBUG - 2016-09-24 21:55:51 --> Config Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:55:51 --> URI Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Router Class Initialized
ERROR - 2016-09-24 21:55:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:55:51 --> Config Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:55:51 --> Config Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Config Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:55:51 --> URI Class Initialized
DEBUG - 2016-09-24 21:55:51 --> URI Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Router Class Initialized
ERROR - 2016-09-24 21:55:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:55:51 --> Config Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:55:51 --> URI Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Router Class Initialized
ERROR - 2016-09-24 21:55:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:55:51 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:55:51 --> URI Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Router Class Initialized
ERROR - 2016-09-24 21:55:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:55:51 --> Router Class Initialized
ERROR - 2016-09-24 21:55:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:55:51 --> Config Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:55:51 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:55:51 --> URI Class Initialized
DEBUG - 2016-09-24 21:55:51 --> Router Class Initialized
ERROR - 2016-09-24 21:55:51 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:58:23 --> Config Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:58:23 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:58:23 --> URI Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Router Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Output Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Security Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Input Class Initialized
DEBUG - 2016-09-24 21:58:23 --> XSS Filtering completed
DEBUG - 2016-09-24 21:58:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:58:23 --> Language Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Loader Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:58:23 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:58:23 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:58:23 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:58:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:58:23 --> Session Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:58:23 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Session routines successfully run
ERROR - 2016-09-24 21:58:23 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:58:23 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:58:23 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:58:23 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:58:23 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Table Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Model Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Model Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:58:23 --> Model Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Controller Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:58:23 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:58:23 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:58:24 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:58:24 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:58:24 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:58:24 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:58:24 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:58:24 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:58:24 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:58:24 --> Final output sent to browser
DEBUG - 2016-09-24 21:58:24 --> Total execution time: 1.5940
DEBUG - 2016-09-24 21:58:24 --> Config Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:58:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:58:24 --> URI Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Router Class Initialized
ERROR - 2016-09-24 21:58:24 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:58:24 --> Config Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Config Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Config Class Initialized
DEBUG - 2016-09-24 21:58:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:58:24 --> URI Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Router Class Initialized
ERROR - 2016-09-24 21:58:24 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:58:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:58:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:58:24 --> URI Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Router Class Initialized
ERROR - 2016-09-24 21:58:24 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:58:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:58:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:58:24 --> URI Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Router Class Initialized
ERROR - 2016-09-24 21:58:24 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:58:24 --> Config Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:58:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:58:24 --> URI Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Router Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Config Class Initialized
ERROR - 2016-09-24 21:58:24 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:58:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:58:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:58:24 --> URI Class Initialized
DEBUG - 2016-09-24 21:58:24 --> Router Class Initialized
ERROR - 2016-09-24 21:58:24 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:59:38 --> Config Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:59:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:59:38 --> URI Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Router Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Output Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Security Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Input Class Initialized
DEBUG - 2016-09-24 21:59:38 --> XSS Filtering completed
DEBUG - 2016-09-24 21:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 21:59:38 --> Language Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Loader Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Helper loaded: url_helper
DEBUG - 2016-09-24 21:59:38 --> Helper loaded: form_helper
DEBUG - 2016-09-24 21:59:38 --> Helper loaded: func_helper
DEBUG - 2016-09-24 21:59:38 --> Database Driver Class Initialized
ERROR - 2016-09-24 21:59:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 21:59:38 --> Session Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Helper loaded: string_helper
DEBUG - 2016-09-24 21:59:38 --> Encrypt Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Session routines successfully run
ERROR - 2016-09-24 21:59:38 --> Could not find the language line "first_link"
ERROR - 2016-09-24 21:59:38 --> Could not find the language line "last_link"
ERROR - 2016-09-24 21:59:38 --> Could not find the language line "next_link"
ERROR - 2016-09-24 21:59:38 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 21:59:38 --> Pagination Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Table Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Model Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Model Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Helper loaded: file_helper
DEBUG - 2016-09-24 21:59:38 --> Model Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Controller Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Form Validation Class Initialized
DEBUG - 2016-09-24 21:59:38 --> Helper loaded: language_helper
DEBUG - 2016-09-24 21:59:38 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 21:59:40 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 21:59:40 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 21:59:40 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 21:59:40 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 21:59:40 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 21:59:40 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 21:59:40 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 21:59:40 --> Final output sent to browser
DEBUG - 2016-09-24 21:59:40 --> Total execution time: 1.5880
DEBUG - 2016-09-24 21:59:40 --> Config Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Config Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:59:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:59:40 --> URI Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:59:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:59:40 --> Router Class Initialized
DEBUG - 2016-09-24 21:59:40 --> URI Class Initialized
ERROR - 2016-09-24 21:59:40 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:59:40 --> Router Class Initialized
ERROR - 2016-09-24 21:59:40 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:59:40 --> Config Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Config Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Config Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:59:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:59:40 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:59:40 --> URI Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:59:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:59:40 --> Router Class Initialized
DEBUG - 2016-09-24 21:59:40 --> URI Class Initialized
ERROR - 2016-09-24 21:59:40 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:59:40 --> Router Class Initialized
ERROR - 2016-09-24 21:59:40 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 21:59:40 --> Config Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Hooks Class Initialized
DEBUG - 2016-09-24 21:59:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:59:40 --> Utf8 Class Initialized
DEBUG - 2016-09-24 21:59:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 21:59:40 --> URI Class Initialized
DEBUG - 2016-09-24 21:59:40 --> URI Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Router Class Initialized
DEBUG - 2016-09-24 21:59:40 --> Router Class Initialized
ERROR - 2016-09-24 21:59:40 --> 404 Page Not Found --> application
ERROR - 2016-09-24 21:59:40 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:01:08 --> Config Class Initialized
DEBUG - 2016-09-24 22:01:08 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:01:08 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:01:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:01:08 --> URI Class Initialized
DEBUG - 2016-09-24 22:01:08 --> Router Class Initialized
DEBUG - 2016-09-24 22:01:08 --> Output Class Initialized
DEBUG - 2016-09-24 22:01:08 --> Security Class Initialized
DEBUG - 2016-09-24 22:01:08 --> Input Class Initialized
DEBUG - 2016-09-24 22:01:08 --> XSS Filtering completed
DEBUG - 2016-09-24 22:01:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:01:08 --> Language Class Initialized
DEBUG - 2016-09-24 22:01:08 --> Loader Class Initialized
DEBUG - 2016-09-24 22:01:08 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:01:08 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:01:08 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:01:08 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:01:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:01:08 --> Session Class Initialized
DEBUG - 2016-09-24 22:01:08 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:01:08 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:01:08 --> Session routines successfully run
ERROR - 2016-09-24 22:01:08 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:01:08 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:01:08 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:01:08 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:01:08 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:01:08 --> Table Class Initialized
DEBUG - 2016-09-24 22:01:09 --> Model Class Initialized
DEBUG - 2016-09-24 22:01:09 --> Model Class Initialized
DEBUG - 2016-09-24 22:01:09 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:01:09 --> Model Class Initialized
DEBUG - 2016-09-24 22:01:09 --> Controller Class Initialized
DEBUG - 2016-09-24 22:01:09 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:01:09 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:01:09 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:01:10 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:01:10 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:01:10 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:01:10 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:01:10 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:01:10 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:01:10 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:01:10 --> Final output sent to browser
DEBUG - 2016-09-24 22:01:10 --> Total execution time: 1.5340
DEBUG - 2016-09-24 22:01:10 --> Config Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:01:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:01:10 --> URI Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Router Class Initialized
ERROR - 2016-09-24 22:01:10 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:01:10 --> Config Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:01:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:01:10 --> URI Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Router Class Initialized
ERROR - 2016-09-24 22:01:10 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:01:10 --> Config Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:01:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:01:10 --> URI Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Router Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Config Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Hooks Class Initialized
ERROR - 2016-09-24 22:01:10 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:01:10 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:01:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:01:10 --> URI Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Router Class Initialized
ERROR - 2016-09-24 22:01:10 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:01:10 --> Config Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:01:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:01:10 --> URI Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Router Class Initialized
ERROR - 2016-09-24 22:01:10 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:01:10 --> Config Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:01:10 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:01:10 --> URI Class Initialized
DEBUG - 2016-09-24 22:01:10 --> Router Class Initialized
ERROR - 2016-09-24 22:01:10 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:04 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:04 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Router Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Output Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Security Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Input Class Initialized
DEBUG - 2016-09-24 22:02:04 --> XSS Filtering completed
DEBUG - 2016-09-24 22:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:02:04 --> Language Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Loader Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:02:04 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:02:04 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:02:04 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:02:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:02:04 --> Session Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:02:04 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Session routines successfully run
ERROR - 2016-09-24 22:02:04 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:02:04 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:02:04 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:02:04 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:02:04 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Table Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Model Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Model Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:02:04 --> Model Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Controller Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:02:04 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:02:04 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:02:05 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:02:05 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:02:05 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:02:05 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:02:05 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:02:05 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:02:05 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:02:05 --> Final output sent to browser
DEBUG - 2016-09-24 22:02:05 --> Total execution time: 1.2980
DEBUG - 2016-09-24 22:02:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:05 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Router Class Initialized
ERROR - 2016-09-24 22:02:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:05 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Router Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:05 --> URI Class Initialized
ERROR - 2016-09-24 22:02:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:05 --> Router Class Initialized
ERROR - 2016-09-24 22:02:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:05 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Router Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:05 --> UTF-8 Support Enabled
ERROR - 2016-09-24 22:02:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:05 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Router Class Initialized
ERROR - 2016-09-24 22:02:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:05 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Router Class Initialized
ERROR - 2016-09-24 22:02:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:05 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:05 --> Router Class Initialized
ERROR - 2016-09-24 22:02:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:08 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:08 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Router Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Output Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Security Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Input Class Initialized
DEBUG - 2016-09-24 22:02:08 --> XSS Filtering completed
DEBUG - 2016-09-24 22:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:02:08 --> Language Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Loader Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:02:08 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:02:08 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:02:08 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:02:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:02:08 --> Session Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:02:08 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Session routines successfully run
ERROR - 2016-09-24 22:02:08 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:02:08 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:02:08 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:02:08 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:02:08 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Table Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Model Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Model Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:02:08 --> Model Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Controller Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:02:08 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:02:08 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:02:09 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:02:09 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:02:09 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:02:09 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:02:09 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:02:09 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:02:09 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:02:09 --> Final output sent to browser
DEBUG - 2016-09-24 22:02:09 --> Total execution time: 1.1871
DEBUG - 2016-09-24 22:02:09 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:09 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Router Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Hooks Class Initialized
ERROR - 2016-09-24 22:02:09 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:09 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:09 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:09 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:09 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Router Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Router Class Initialized
ERROR - 2016-09-24 22:02:09 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:09 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:09 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Router Class Initialized
ERROR - 2016-09-24 22:02:09 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:02:09 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:09 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:09 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:09 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Router Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Router Class Initialized
ERROR - 2016-09-24 22:02:09 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:02:09 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:09 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:09 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:09 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Router Class Initialized
DEBUG - 2016-09-24 22:02:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:09 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:09 --> Router Class Initialized
DEBUG - 2016-09-24 22:02:09 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Config Class Initialized
ERROR - 2016-09-24 22:02:09 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:09 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Router Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:09 --> UTF-8 Support Enabled
ERROR - 2016-09-24 22:02:09 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:09 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:09 --> URI Class Initialized
ERROR - 2016-09-24 22:02:09 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:09 --> Router Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Config Class Initialized
DEBUG - 2016-09-24 22:02:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:02:09 --> URI Class Initialized
ERROR - 2016-09-24 22:02:09 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:02:09 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:02:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:02:09 --> URI Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Router Class Initialized
DEBUG - 2016-09-24 22:02:09 --> Router Class Initialized
ERROR - 2016-09-24 22:02:09 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:02:09 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:05:48 --> Config Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:05:48 --> URI Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Router Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Output Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Security Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Input Class Initialized
DEBUG - 2016-09-24 22:05:48 --> XSS Filtering completed
DEBUG - 2016-09-24 22:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:05:48 --> Language Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Loader Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:05:48 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:05:48 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:05:48 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:05:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:05:48 --> Session Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:05:48 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Session routines successfully run
ERROR - 2016-09-24 22:05:48 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:05:48 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:05:48 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:05:48 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:05:48 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Table Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Model Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Model Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:05:48 --> Model Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Controller Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:05:48 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:05:48 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:05:48 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:05:48 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:05:48 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:05:48 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:05:48 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:05:48 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:05:48 --> Final output sent to browser
DEBUG - 2016-09-24 22:05:48 --> Total execution time: 0.2600
DEBUG - 2016-09-24 22:05:48 --> Config Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:05:48 --> URI Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Router Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Config Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:05:48 --> URI Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Router Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Config Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Config Class Initialized
ERROR - 2016-09-24 22:05:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:05:48 --> Config Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:05:48 --> URI Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Config Class Initialized
DEBUG - 2016-09-24 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:05:48 --> URI Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Router Class Initialized
ERROR - 2016-09-24 22:05:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:05:48 --> URI Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Router Class Initialized
ERROR - 2016-09-24 22:05:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:05:48 --> Router Class Initialized
ERROR - 2016-09-24 22:05:48 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:05:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:05:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:05:48 --> URI Class Initialized
DEBUG - 2016-09-24 22:05:48 --> Router Class Initialized
ERROR - 2016-09-24 22:05:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Router Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Output Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Security Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Input Class Initialized
DEBUG - 2016-09-24 22:13:03 --> XSS Filtering completed
DEBUG - 2016-09-24 22:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:13:03 --> Language Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Loader Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:13:03 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:13:03 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:13:03 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:13:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:13:03 --> Session Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:13:03 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Session routines successfully run
ERROR - 2016-09-24 22:13:03 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:13:03 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:13:03 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:13:03 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:13:03 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Table Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Model Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Model Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:13:03 --> Model Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Controller Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:13:03 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:13:03 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:13:03 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:13:03 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:13:03 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:13:03 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:13:03 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:13:03 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:13:03 --> Final output sent to browser
DEBUG - 2016-09-24 22:13:03 --> Total execution time: 0.3000
DEBUG - 2016-09-24 22:13:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:03 --> Router Class Initialized
ERROR - 2016-09-24 22:13:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Router Class Initialized
ERROR - 2016-09-24 22:13:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:03 --> Router Class Initialized
ERROR - 2016-09-24 22:13:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Router Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:03 --> UTF-8 Support Enabled
ERROR - 2016-09-24 22:13:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:03 --> Router Class Initialized
DEBUG - 2016-09-24 22:13:03 --> URI Class Initialized
ERROR - 2016-09-24 22:13:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:03 --> Router Class Initialized
ERROR - 2016-09-24 22:13:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Router Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:03 --> URI Class Initialized
ERROR - 2016-09-24 22:13:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:03 --> Router Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:03 --> UTF-8 Support Enabled
ERROR - 2016-09-24 22:13:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Router Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Utf8 Class Initialized
ERROR - 2016-09-24 22:13:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Router Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Hooks Class Initialized
ERROR - 2016-09-24 22:13:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:03 --> Router Class Initialized
ERROR - 2016-09-24 22:13:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:05 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Router Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Output Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Security Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Input Class Initialized
DEBUG - 2016-09-24 22:13:05 --> XSS Filtering completed
DEBUG - 2016-09-24 22:13:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:13:05 --> Language Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Loader Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:13:05 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:13:05 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:13:05 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:13:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:13:05 --> Session Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:13:05 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Session routines successfully run
ERROR - 2016-09-24 22:13:05 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:13:05 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:13:05 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:13:05 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:13:05 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Table Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Model Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Model Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:13:05 --> Model Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Controller Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:13:05 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:13:05 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:13:05 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:13:05 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:13:05 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:13:05 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:13:05 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:13:05 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:13:05 --> Final output sent to browser
DEBUG - 2016-09-24 22:13:05 --> Total execution time: 0.1790
DEBUG - 2016-09-24 22:13:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:05 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Router Class Initialized
ERROR - 2016-09-24 22:13:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:05 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:05 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:05 --> Router Class Initialized
DEBUG - 2016-09-24 22:13:05 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Router Class Initialized
ERROR - 2016-09-24 22:13:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:05 --> Router Class Initialized
ERROR - 2016-09-24 22:13:05 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:13:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:13:05 --> URI Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:13:05 --> Router Class Initialized
DEBUG - 2016-09-24 22:13:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:13:05 --> URI Class Initialized
ERROR - 2016-09-24 22:13:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:13:05 --> Router Class Initialized
ERROR - 2016-09-24 22:13:05 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:15:21 --> Config Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:15:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:15:21 --> URI Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Router Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Output Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Security Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Input Class Initialized
DEBUG - 2016-09-24 22:15:21 --> XSS Filtering completed
DEBUG - 2016-09-24 22:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:15:21 --> Language Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Loader Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:15:21 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:15:21 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:15:21 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:15:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:15:21 --> Session Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:15:21 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Session routines successfully run
ERROR - 2016-09-24 22:15:21 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:15:21 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:15:21 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:15:21 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:15:21 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Table Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Model Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Model Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:15:21 --> Model Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Controller Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:15:21 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:15:21 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:15:21 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:15:21 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:15:21 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:15:21 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:15:21 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:15:21 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:15:21 --> Final output sent to browser
DEBUG - 2016-09-24 22:15:21 --> Total execution time: 0.2600
DEBUG - 2016-09-24 22:15:21 --> Config Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:15:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:15:21 --> URI Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Router Class Initialized
ERROR - 2016-09-24 22:15:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:15:21 --> Config Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Config Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:15:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:15:21 --> URI Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Router Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:15:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:15:21 --> URI Class Initialized
ERROR - 2016-09-24 22:15:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:15:21 --> Config Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Router Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Hooks Class Initialized
ERROR - 2016-09-24 22:15:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:15:21 --> Config Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:15:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:15:21 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Config Class Initialized
DEBUG - 2016-09-24 22:15:21 --> URI Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Router Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:15:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:15:21 --> UTF-8 Support Enabled
ERROR - 2016-09-24 22:15:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:15:21 --> URI Class Initialized
DEBUG - 2016-09-24 22:15:21 --> URI Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Router Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Router Class Initialized
ERROR - 2016-09-24 22:15:21 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:15:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:15:21 --> Config Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:15:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:15:21 --> URI Class Initialized
DEBUG - 2016-09-24 22:15:21 --> Router Class Initialized
ERROR - 2016-09-24 22:15:21 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:17:30 --> Config Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:17:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:17:30 --> URI Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Router Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Output Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Security Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Input Class Initialized
DEBUG - 2016-09-24 22:17:30 --> XSS Filtering completed
DEBUG - 2016-09-24 22:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:17:30 --> Language Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Loader Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:17:30 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:17:30 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:17:30 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:17:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:17:30 --> Session Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:17:30 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Session routines successfully run
ERROR - 2016-09-24 22:17:30 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:17:30 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:17:30 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:17:30 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:17:30 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Table Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Model Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Model Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:17:30 --> Model Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Controller Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:17:30 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:17:30 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:17:30 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:17:30 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:17:30 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:17:30 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:17:30 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:17:30 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:17:30 --> Final output sent to browser
DEBUG - 2016-09-24 22:17:30 --> Total execution time: 0.2300
DEBUG - 2016-09-24 22:17:30 --> Config Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:17:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:17:30 --> URI Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Router Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Config Class Initialized
ERROR - 2016-09-24 22:17:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:17:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Config Class Initialized
DEBUG - 2016-09-24 22:17:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:17:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:17:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:17:30 --> URI Class Initialized
DEBUG - 2016-09-24 22:17:30 --> URI Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Router Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Router Class Initialized
ERROR - 2016-09-24 22:17:30 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:17:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:17:30 --> Config Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:17:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:17:30 --> URI Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Config Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Config Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Router Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Hooks Class Initialized
ERROR - 2016-09-24 22:17:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:17:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:17:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:17:30 --> URI Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Router Class Initialized
ERROR - 2016-09-24 22:17:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:17:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:17:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:17:30 --> URI Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Router Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Config Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:17:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:17:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:17:30 --> URI Class Initialized
ERROR - 2016-09-24 22:17:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:17:30 --> Router Class Initialized
ERROR - 2016-09-24 22:17:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:17:53 --> Config Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:17:53 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:17:53 --> URI Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Router Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Output Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Security Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Input Class Initialized
DEBUG - 2016-09-24 22:17:53 --> XSS Filtering completed
DEBUG - 2016-09-24 22:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:17:53 --> Language Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Loader Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:17:53 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:17:53 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:17:53 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:17:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:17:53 --> Session Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:17:53 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Session routines successfully run
ERROR - 2016-09-24 22:17:53 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:17:53 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:17:53 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:17:53 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:17:53 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Table Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Model Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Model Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:17:53 --> Model Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Controller Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:17:53 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:17:53 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-24 22:17:53 --> Could not find the language line "personal"
DEBUG - 2016-09-24 22:17:53 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:17:53 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:17:53 --> File loaded: application/views/includes/admin/header.php
ERROR - 2016-09-24 22:17:53 --> Could not find the language line "confirm"
DEBUG - 2016-09-24 22:17:53 --> File loaded: application/views/admin/personal.php
DEBUG - 2016-09-24 22:17:53 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:17:53 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:17:53 --> Final output sent to browser
DEBUG - 2016-09-24 22:17:53 --> Total execution time: 0.1000
DEBUG - 2016-09-24 22:18:01 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:01 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Router Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Output Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Security Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Input Class Initialized
DEBUG - 2016-09-24 22:18:01 --> XSS Filtering completed
DEBUG - 2016-09-24 22:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:18:01 --> Language Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Loader Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:18:01 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:18:01 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:18:01 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:18:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:18:01 --> Session Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:18:01 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Session routines successfully run
ERROR - 2016-09-24 22:18:01 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:18:01 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:18:01 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:18:01 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:18:01 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Table Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:18:01 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Controller Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:18:01 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:18:01 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:18:01 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:18:01 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:18:01 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:18:01 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:18:01 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:18:01 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:18:01 --> Final output sent to browser
DEBUG - 2016-09-24 22:18:01 --> Total execution time: 0.1800
DEBUG - 2016-09-24 22:18:01 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:01 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Router Class Initialized
ERROR - 2016-09-24 22:18:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:18:01 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:01 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:01 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:01 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:01 --> Router Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Router Class Initialized
ERROR - 2016-09-24 22:18:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:18:01 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:01 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Router Class Initialized
DEBUG - 2016-09-24 22:18:01 --> UTF-8 Support Enabled
ERROR - 2016-09-24 22:18:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:18:01 --> URI Class Initialized
ERROR - 2016-09-24 22:18:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:18:01 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Router Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:01 --> UTF-8 Support Enabled
ERROR - 2016-09-24 22:18:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:18:01 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:01 --> Router Class Initialized
ERROR - 2016-09-24 22:18:01 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:18:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:05 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Router Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Output Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Security Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Input Class Initialized
DEBUG - 2016-09-24 22:18:05 --> XSS Filtering completed
DEBUG - 2016-09-24 22:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:18:05 --> Language Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Loader Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:18:05 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:18:05 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:18:05 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:18:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:18:05 --> Session Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:18:05 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Session routines successfully run
ERROR - 2016-09-24 22:18:05 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:18:05 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:18:05 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:18:05 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:18:05 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Table Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:18:05 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Controller Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:18:05 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:18:05 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:05 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Router Class Initialized
DEBUG - 2016-09-24 22:18:05 --> No URI present. Default controller set.
DEBUG - 2016-09-24 22:18:05 --> Output Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Security Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Input Class Initialized
DEBUG - 2016-09-24 22:18:05 --> XSS Filtering completed
DEBUG - 2016-09-24 22:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:18:05 --> Language Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Loader Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:18:05 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:18:05 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:18:05 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:18:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:18:05 --> Session Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:18:05 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Session routines successfully run
ERROR - 2016-09-24 22:18:05 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:18:05 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:18:05 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:18:05 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:18:05 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Table Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:18:05 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:05 --> Controller Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:07 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Router Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Output Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Security Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Input Class Initialized
DEBUG - 2016-09-24 22:18:07 --> XSS Filtering completed
DEBUG - 2016-09-24 22:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:18:07 --> Language Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Loader Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:18:07 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:18:07 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:18:07 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:18:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:18:07 --> Session Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:18:07 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Session routines successfully run
ERROR - 2016-09-24 22:18:07 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:18:07 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:18:07 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:18:07 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:18:07 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Table Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:18:07 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Controller Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:18:07 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:18:07 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:07 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Router Class Initialized
DEBUG - 2016-09-24 22:18:07 --> No URI present. Default controller set.
DEBUG - 2016-09-24 22:18:07 --> Output Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Security Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Input Class Initialized
DEBUG - 2016-09-24 22:18:07 --> XSS Filtering completed
DEBUG - 2016-09-24 22:18:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:18:07 --> Language Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Loader Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:18:07 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:18:07 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:18:07 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:18:07 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:18:07 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:18:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:18:07 --> Session Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:18:07 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Session routines successfully run
ERROR - 2016-09-24 22:18:07 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:18:07 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:18:07 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:18:07 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:18:07 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Table Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:18:07 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:07 --> Controller Class Initialized
DEBUG - 2016-09-24 22:18:09 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-24 22:18:09 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:18:09 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:18:11 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-24 22:18:11 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:18:11 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 22:18:11 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-24 22:18:11 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-24 22:18:11 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-24 22:18:11 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 22:18:11 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 22:18:11 --> Final output sent to browser
DEBUG - 2016-09-24 22:18:11 --> Total execution time: 6.1860
DEBUG - 2016-09-24 22:18:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:18:13 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 22:18:13 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-24 22:18:13 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-24 22:18:13 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-24 22:18:13 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 22:18:13 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 22:18:13 --> Final output sent to browser
DEBUG - 2016-09-24 22:18:13 --> Total execution time: 6.5790
DEBUG - 2016-09-24 22:18:13 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:13 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:13 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:13 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:13 --> Router Class Initialized
ERROR - 2016-09-24 22:18:13 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 22:18:30 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:30 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Router Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Output Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Security Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Input Class Initialized
DEBUG - 2016-09-24 22:18:30 --> XSS Filtering completed
DEBUG - 2016-09-24 22:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:18:30 --> Language Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Loader Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:18:30 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:18:30 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:18:30 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:18:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:18:30 --> Session Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:18:30 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Session routines successfully run
ERROR - 2016-09-24 22:18:30 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:18:30 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:18:30 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:18:30 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:18:30 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Table Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:18:30 --> Model Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Controller Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:18:30 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:18:30 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:18:30 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:18:30 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:18:30 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:18:30 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:18:30 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:18:30 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:18:30 --> Final output sent to browser
DEBUG - 2016-09-24 22:18:30 --> Total execution time: 0.2500
DEBUG - 2016-09-24 22:18:30 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:30 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Router Class Initialized
ERROR - 2016-09-24 22:18:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:18:30 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:30 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:30 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Router Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:30 --> UTF-8 Support Enabled
ERROR - 2016-09-24 22:18:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:18:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:30 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Config Class Initialized
DEBUG - 2016-09-24 22:18:30 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Router Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:18:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:30 --> Router Class Initialized
ERROR - 2016-09-24 22:18:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:18:30 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:18:30 --> URI Class Initialized
ERROR - 2016-09-24 22:18:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:18:30 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:18:30 --> Router Class Initialized
DEBUG - 2016-09-24 22:18:30 --> URI Class Initialized
DEBUG - 2016-09-24 22:18:30 --> Router Class Initialized
ERROR - 2016-09-24 22:18:30 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:18:30 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:19:07 --> Config Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:19:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:19:07 --> URI Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Router Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Output Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Security Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Input Class Initialized
DEBUG - 2016-09-24 22:19:07 --> XSS Filtering completed
DEBUG - 2016-09-24 22:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:19:07 --> Language Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Loader Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:19:07 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:19:07 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:19:07 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:19:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:19:07 --> Session Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:19:07 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Session routines successfully run
ERROR - 2016-09-24 22:19:07 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:19:07 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:19:07 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:19:07 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:19:07 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Table Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Model Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Model Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:19:07 --> Model Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Controller Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:19:07 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:19:07 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:19:07 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:19:07 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:19:07 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:19:07 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:19:07 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:19:07 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:19:07 --> Final output sent to browser
DEBUG - 2016-09-24 22:19:07 --> Total execution time: 0.2400
DEBUG - 2016-09-24 22:19:07 --> Config Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:19:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:19:07 --> URI Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Router Class Initialized
ERROR - 2016-09-24 22:19:07 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:19:07 --> Config Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:19:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:19:07 --> URI Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Router Class Initialized
ERROR - 2016-09-24 22:19:07 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:19:07 --> Config Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Config Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Config Class Initialized
DEBUG - 2016-09-24 22:19:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:19:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:19:07 --> URI Class Initialized
DEBUG - 2016-09-24 22:19:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:19:07 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Router Class Initialized
DEBUG - 2016-09-24 22:19:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:19:07 --> URI Class Initialized
DEBUG - 2016-09-24 22:19:07 --> URI Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Router Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Config Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Router Class Initialized
ERROR - 2016-09-24 22:19:07 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:19:07 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:19:07 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:19:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:19:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:19:07 --> URI Class Initialized
DEBUG - 2016-09-24 22:19:07 --> Router Class Initialized
ERROR - 2016-09-24 22:19:07 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:21:57 --> Config Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:21:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:21:57 --> URI Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Router Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Output Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Security Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Input Class Initialized
DEBUG - 2016-09-24 22:21:57 --> XSS Filtering completed
DEBUG - 2016-09-24 22:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:21:57 --> Language Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Loader Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:21:57 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:21:57 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:21:57 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:21:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:21:57 --> Session Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:21:57 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Session routines successfully run
ERROR - 2016-09-24 22:21:57 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:21:57 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:21:57 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:21:57 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:21:57 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Table Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Model Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Model Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:21:57 --> Model Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Controller Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:21:57 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:21:57 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:21:57 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:21:57 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:21:57 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:21:57 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:21:57 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:21:57 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:21:57 --> Final output sent to browser
DEBUG - 2016-09-24 22:21:57 --> Total execution time: 0.3200
DEBUG - 2016-09-24 22:21:57 --> Config Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:21:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:21:57 --> URI Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Router Class Initialized
ERROR - 2016-09-24 22:21:57 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:21:57 --> Config Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:21:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:21:57 --> Config Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:21:57 --> URI Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Router Class Initialized
DEBUG - 2016-09-24 22:21:57 --> UTF-8 Support Enabled
ERROR - 2016-09-24 22:21:57 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:21:57 --> Config Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:21:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:21:57 --> URI Class Initialized
DEBUG - 2016-09-24 22:21:57 --> URI Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Router Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Router Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Config Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Hooks Class Initialized
ERROR - 2016-09-24 22:21:57 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:21:57 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:21:57 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:21:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:21:57 --> URI Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Router Class Initialized
ERROR - 2016-09-24 22:21:57 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:21:57 --> Config Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:21:57 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:21:57 --> URI Class Initialized
DEBUG - 2016-09-24 22:21:57 --> Router Class Initialized
ERROR - 2016-09-24 22:21:57 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:23:12 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:12 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Router Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Output Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Security Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Input Class Initialized
DEBUG - 2016-09-24 22:23:12 --> XSS Filtering completed
DEBUG - 2016-09-24 22:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:23:12 --> Language Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Loader Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:23:12 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:23:12 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:23:12 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:23:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:23:12 --> Session Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:23:12 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Session routines successfully run
ERROR - 2016-09-24 22:23:12 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:23:12 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:23:12 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:23:12 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:23:12 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Table Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Model Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Model Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:23:12 --> Model Class Initialized
DEBUG - 2016-09-24 22:23:12 --> Controller Class Initialized
DEBUG - 2016-09-24 22:23:13 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:23:13 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-24 22:23:13 --> Severity: Notice  --> Undefined variable: page_title C:\xampp\htdocs\www\alumni\application\views\includes\header.php 6
DEBUG - 2016-09-24 22:23:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:23:13 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 22:23:13 --> File loaded: application/views/signup/complete.php
DEBUG - 2016-09-24 22:23:13 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 22:23:13 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 22:23:13 --> Final output sent to browser
DEBUG - 2016-09-24 22:23:13 --> Total execution time: 1.8211
DEBUG - 2016-09-24 22:23:13 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:13 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:13 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:13 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:13 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:13 --> Router Class Initialized
ERROR - 2016-09-24 22:23:13 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 22:23:14 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:14 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Router Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Output Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Security Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Input Class Initialized
DEBUG - 2016-09-24 22:23:14 --> XSS Filtering completed
DEBUG - 2016-09-24 22:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:23:14 --> Language Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Loader Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:23:14 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:23:14 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:23:14 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:23:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:23:14 --> Session Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:23:14 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Session routines successfully run
ERROR - 2016-09-24 22:23:14 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:23:14 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:23:14 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:23:14 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:23:14 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Table Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Model Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Model Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:23:14 --> Model Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Controller Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:23:14 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:23:14 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:23:17 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:23:17 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:23:17 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:23:17 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:23:17 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:23:17 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:23:17 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:23:17 --> Final output sent to browser
DEBUG - 2016-09-24 22:23:17 --> Total execution time: 3.0400
DEBUG - 2016-09-24 22:23:17 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:17 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Router Class Initialized
ERROR - 2016-09-24 22:23:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:23:17 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:17 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:17 --> Router Class Initialized
DEBUG - 2016-09-24 22:23:17 --> URI Class Initialized
ERROR - 2016-09-24 22:23:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:23:17 --> Router Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Hooks Class Initialized
ERROR - 2016-09-24 22:23:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:23:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:17 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:17 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:17 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Router Class Initialized
DEBUG - 2016-09-24 22:23:17 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:17 --> Router Class Initialized
ERROR - 2016-09-24 22:23:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:23:17 --> Router Class Initialized
ERROR - 2016-09-24 22:23:17 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:23:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:23:32 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:32 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Router Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Output Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Security Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Input Class Initialized
DEBUG - 2016-09-24 22:23:32 --> XSS Filtering completed
DEBUG - 2016-09-24 22:23:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:23:32 --> Language Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Loader Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:23:32 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:23:32 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:23:32 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:23:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:23:32 --> Session Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:23:32 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Session routines successfully run
ERROR - 2016-09-24 22:23:32 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:23:32 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:23:32 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:23:32 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:23:32 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Table Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Model Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Model Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:23:32 --> Model Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Controller Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:23:32 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:23:32 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:23:33 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:33 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:33 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Router Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Output Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Security Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Input Class Initialized
DEBUG - 2016-09-24 22:23:33 --> XSS Filtering completed
DEBUG - 2016-09-24 22:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:23:33 --> Language Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Loader Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:23:33 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:23:33 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:23:33 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:23:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:23:33 --> Session Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:23:33 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Session routines successfully run
ERROR - 2016-09-24 22:23:33 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:23:33 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:23:33 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:23:33 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:23:33 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Table Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Model Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Model Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:23:33 --> Model Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Controller Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:23:33 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:23:33 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:23:35 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:23:35 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:23:35 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:23:35 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:23:35 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:23:35 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:23:35 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:23:35 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:23:35 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:23:35 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:23:35 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:23:35 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:23:35 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:23:35 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:23:35 --> Final output sent to browser
DEBUG - 2016-09-24 22:23:35 --> Total execution time: 2.9810
DEBUG - 2016-09-24 22:23:35 --> Final output sent to browser
DEBUG - 2016-09-24 22:23:35 --> Total execution time: 2.6670
DEBUG - 2016-09-24 22:23:35 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:35 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Router Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Config Class Initialized
ERROR - 2016-09-24 22:23:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:23:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:35 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:35 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Router Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Router Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Config Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Hooks Class Initialized
ERROR - 2016-09-24 22:23:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:23:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:35 --> URI Class Initialized
ERROR - 2016-09-24 22:23:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:23:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Router Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Config Class Initialized
ERROR - 2016-09-24 22:23:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:23:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:23:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:35 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:23:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:23:35 --> URI Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Router Class Initialized
DEBUG - 2016-09-24 22:23:35 --> Router Class Initialized
ERROR - 2016-09-24 22:23:35 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:23:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:31:49 --> Config Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:31:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:31:49 --> URI Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Router Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Output Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Security Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Input Class Initialized
DEBUG - 2016-09-24 22:31:49 --> XSS Filtering completed
DEBUG - 2016-09-24 22:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:31:49 --> Language Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Loader Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:31:49 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:31:49 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:31:49 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:31:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:31:49 --> Session Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:31:49 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Session routines successfully run
ERROR - 2016-09-24 22:31:49 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:31:49 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:31:49 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:31:49 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:31:49 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Table Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Model Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Model Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:31:49 --> Model Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Controller Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:31:49 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:31:49 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:31:52 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:31:52 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:31:52 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:31:52 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:31:52 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:31:52 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:31:52 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:31:52 --> Final output sent to browser
DEBUG - 2016-09-24 22:31:52 --> Total execution time: 2.7930
DEBUG - 2016-09-24 22:31:52 --> Config Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:31:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:31:52 --> URI Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Router Class Initialized
ERROR - 2016-09-24 22:31:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:31:52 --> Config Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Config Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:31:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:31:52 --> URI Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Router Class Initialized
ERROR - 2016-09-24 22:31:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:31:52 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:31:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:31:52 --> URI Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Router Class Initialized
ERROR - 2016-09-24 22:31:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:31:52 --> Config Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Config Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:31:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:31:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:31:52 --> URI Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:31:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:31:52 --> Router Class Initialized
DEBUG - 2016-09-24 22:31:52 --> URI Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Router Class Initialized
ERROR - 2016-09-24 22:31:52 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:31:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:31:52 --> Config Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:31:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:31:52 --> URI Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Router Class Initialized
ERROR - 2016-09-24 22:31:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:31:52 --> Config Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:31:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:31:52 --> Config Class Initialized
DEBUG - 2016-09-24 22:31:52 --> URI Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Router Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:31:52 --> UTF-8 Support Enabled
ERROR - 2016-09-24 22:31:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:31:52 --> URI Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Router Class Initialized
ERROR - 2016-09-24 22:31:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:31:52 --> Config Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Config Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:31:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:31:52 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:31:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:31:52 --> URI Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Config Class Initialized
DEBUG - 2016-09-24 22:31:52 --> URI Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Router Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Router Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Utf8 Class Initialized
ERROR - 2016-09-24 22:31:52 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:31:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:31:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:31:52 --> URI Class Initialized
DEBUG - 2016-09-24 22:31:52 --> Router Class Initialized
ERROR - 2016-09-24 22:31:52 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:42:07 --> Config Class Initialized
DEBUG - 2016-09-24 22:42:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:42:07 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:42:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:42:07 --> URI Class Initialized
DEBUG - 2016-09-24 22:42:07 --> Router Class Initialized
DEBUG - 2016-09-24 22:42:07 --> No URI present. Default controller set.
DEBUG - 2016-09-24 22:42:07 --> Output Class Initialized
DEBUG - 2016-09-24 22:42:07 --> Security Class Initialized
DEBUG - 2016-09-24 22:42:07 --> Input Class Initialized
DEBUG - 2016-09-24 22:42:07 --> XSS Filtering completed
DEBUG - 2016-09-24 22:42:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:42:07 --> Language Class Initialized
DEBUG - 2016-09-24 22:42:07 --> Loader Class Initialized
DEBUG - 2016-09-24 22:42:07 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:42:07 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:42:07 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:42:07 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:42:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:42:07 --> Session Class Initialized
DEBUG - 2016-09-24 22:42:07 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:42:07 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:42:07 --> Session routines successfully run
ERROR - 2016-09-24 22:42:07 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:42:07 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:42:07 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:42:07 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:42:07 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:42:07 --> Table Class Initialized
DEBUG - 2016-09-24 22:42:07 --> Model Class Initialized
DEBUG - 2016-09-24 22:42:07 --> Model Class Initialized
DEBUG - 2016-09-24 22:42:07 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:42:07 --> Model Class Initialized
DEBUG - 2016-09-24 22:42:07 --> Controller Class Initialized
DEBUG - 2016-09-24 22:42:09 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:42:09 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:42:11 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-24 22:42:14 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:42:14 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 22:42:14 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-24 22:42:14 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-24 22:42:14 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-24 22:42:14 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 22:42:14 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 22:42:14 --> Final output sent to browser
DEBUG - 2016-09-24 22:42:14 --> Total execution time: 6.9594
DEBUG - 2016-09-24 22:42:14 --> Config Class Initialized
DEBUG - 2016-09-24 22:42:14 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:42:14 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:42:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:42:14 --> URI Class Initialized
DEBUG - 2016-09-24 22:42:14 --> Router Class Initialized
ERROR - 2016-09-24 22:42:14 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 22:42:14 --> Config Class Initialized
DEBUG - 2016-09-24 22:42:14 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:42:14 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:42:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:42:14 --> URI Class Initialized
DEBUG - 2016-09-24 22:42:14 --> Router Class Initialized
ERROR - 2016-09-24 22:42:14 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 22:45:34 --> Config Class Initialized
DEBUG - 2016-09-24 22:45:34 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:45:34 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:45:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:45:34 --> URI Class Initialized
DEBUG - 2016-09-24 22:45:34 --> Router Class Initialized
DEBUG - 2016-09-24 22:45:34 --> No URI present. Default controller set.
DEBUG - 2016-09-24 22:45:34 --> Output Class Initialized
DEBUG - 2016-09-24 22:45:34 --> Security Class Initialized
DEBUG - 2016-09-24 22:45:34 --> Input Class Initialized
DEBUG - 2016-09-24 22:45:34 --> XSS Filtering completed
DEBUG - 2016-09-24 22:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:45:34 --> Language Class Initialized
DEBUG - 2016-09-24 22:45:34 --> Loader Class Initialized
DEBUG - 2016-09-24 22:45:34 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:45:34 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:45:34 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:45:34 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:45:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:45:34 --> Session Class Initialized
DEBUG - 2016-09-24 22:45:34 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:45:34 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:45:34 --> Session routines successfully run
ERROR - 2016-09-24 22:45:34 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:45:34 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:45:34 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:45:34 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:45:34 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:45:34 --> Table Class Initialized
DEBUG - 2016-09-24 22:45:34 --> Model Class Initialized
DEBUG - 2016-09-24 22:45:34 --> Model Class Initialized
DEBUG - 2016-09-24 22:45:34 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:45:34 --> Model Class Initialized
DEBUG - 2016-09-24 22:45:34 --> Controller Class Initialized
DEBUG - 2016-09-24 22:45:36 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:45:36 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:45:38 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-24 22:45:41 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:45:41 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 22:45:41 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-24 22:45:41 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-24 22:45:41 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-24 22:45:41 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 22:45:41 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 22:45:41 --> Final output sent to browser
DEBUG - 2016-09-24 22:45:41 --> Total execution time: 6.9344
DEBUG - 2016-09-24 22:45:41 --> Config Class Initialized
DEBUG - 2016-09-24 22:45:41 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:45:41 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:45:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:45:41 --> URI Class Initialized
DEBUG - 2016-09-24 22:45:41 --> Router Class Initialized
ERROR - 2016-09-24 22:45:41 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 22:45:41 --> Config Class Initialized
DEBUG - 2016-09-24 22:45:41 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:45:41 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:45:41 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:45:41 --> URI Class Initialized
DEBUG - 2016-09-24 22:45:41 --> Router Class Initialized
DEBUG - 2016-09-24 22:45:41 --> Output Class Initialized
DEBUG - 2016-09-24 22:45:41 --> Security Class Initialized
DEBUG - 2016-09-24 22:45:41 --> Input Class Initialized
DEBUG - 2016-09-24 22:45:41 --> XSS Filtering completed
DEBUG - 2016-09-24 22:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:45:41 --> Language Class Initialized
DEBUG - 2016-09-24 22:45:41 --> Loader Class Initialized
DEBUG - 2016-09-24 22:45:41 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:45:41 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:45:41 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:45:41 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:45:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:45:42 --> Session Class Initialized
DEBUG - 2016-09-24 22:45:42 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:45:42 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:45:42 --> Session routines successfully run
ERROR - 2016-09-24 22:45:42 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:45:42 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:45:42 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:45:42 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:45:42 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:45:42 --> Table Class Initialized
DEBUG - 2016-09-24 22:45:42 --> Model Class Initialized
DEBUG - 2016-09-24 22:45:42 --> Model Class Initialized
DEBUG - 2016-09-24 22:45:42 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:45:42 --> Model Class Initialized
DEBUG - 2016-09-24 22:45:42 --> Controller Class Initialized
DEBUG - 2016-09-24 22:45:42 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:45:42 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:45:42 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:45:44 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:45:44 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:45:44 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:45:44 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:45:44 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:45:44 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:45:44 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:45:44 --> Final output sent to browser
DEBUG - 2016-09-24 22:45:44 --> Total execution time: 2.7302
DEBUG - 2016-09-24 22:45:44 --> Config Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:45:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:45:44 --> URI Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Router Class Initialized
ERROR - 2016-09-24 22:45:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:45:44 --> Config Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:45:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:45:44 --> URI Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Config Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Router Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Utf8 Class Initialized
ERROR - 2016-09-24 22:45:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:45:44 --> Config Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:45:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:45:44 --> URI Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Router Class Initialized
ERROR - 2016-09-24 22:45:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:45:44 --> Config Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:45:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:45:44 --> URI Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Router Class Initialized
ERROR - 2016-09-24 22:45:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:45:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:45:44 --> Config Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:45:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:45:44 --> URI Class Initialized
DEBUG - 2016-09-24 22:45:44 --> URI Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Router Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Router Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Config Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Hooks Class Initialized
ERROR - 2016-09-24 22:45:44 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:45:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:45:44 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:45:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:45:44 --> URI Class Initialized
DEBUG - 2016-09-24 22:45:44 --> Router Class Initialized
ERROR - 2016-09-24 22:45:44 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:45:49 --> Config Class Initialized
DEBUG - 2016-09-24 22:45:49 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:45:49 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:45:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:45:49 --> URI Class Initialized
DEBUG - 2016-09-24 22:45:49 --> Router Class Initialized
DEBUG - 2016-09-24 22:45:49 --> No URI present. Default controller set.
DEBUG - 2016-09-24 22:45:49 --> Output Class Initialized
DEBUG - 2016-09-24 22:45:49 --> Security Class Initialized
DEBUG - 2016-09-24 22:45:49 --> Input Class Initialized
DEBUG - 2016-09-24 22:45:49 --> XSS Filtering completed
DEBUG - 2016-09-24 22:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:45:49 --> Language Class Initialized
DEBUG - 2016-09-24 22:45:49 --> Loader Class Initialized
DEBUG - 2016-09-24 22:45:49 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:45:49 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:45:49 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:45:49 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:45:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:45:49 --> Session Class Initialized
DEBUG - 2016-09-24 22:45:49 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:45:49 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:45:49 --> Session routines successfully run
ERROR - 2016-09-24 22:45:49 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:45:49 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:45:49 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:45:49 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:45:49 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:45:49 --> Table Class Initialized
DEBUG - 2016-09-24 22:45:49 --> Model Class Initialized
DEBUG - 2016-09-24 22:45:49 --> Model Class Initialized
DEBUG - 2016-09-24 22:45:49 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:45:49 --> Model Class Initialized
DEBUG - 2016-09-24 22:45:49 --> Controller Class Initialized
DEBUG - 2016-09-24 22:45:52 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:45:52 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:45:54 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-24 22:45:56 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:45:56 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 22:45:56 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-24 22:45:56 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-24 22:45:56 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-24 22:45:56 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 22:45:56 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 22:45:56 --> Final output sent to browser
DEBUG - 2016-09-24 22:45:56 --> Total execution time: 6.9364
DEBUG - 2016-09-24 22:45:56 --> Config Class Initialized
DEBUG - 2016-09-24 22:45:56 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:45:56 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:45:56 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:45:56 --> URI Class Initialized
DEBUG - 2016-09-24 22:45:56 --> Router Class Initialized
ERROR - 2016-09-24 22:45:56 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 22:46:00 --> Config Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:46:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:46:00 --> URI Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Router Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Output Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Security Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Input Class Initialized
DEBUG - 2016-09-24 22:46:00 --> XSS Filtering completed
DEBUG - 2016-09-24 22:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:46:00 --> Language Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Loader Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:46:00 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:46:00 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:46:00 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:46:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:46:00 --> Session Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:46:00 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Session routines successfully run
ERROR - 2016-09-24 22:46:00 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:46:00 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:46:00 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:46:00 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:46:00 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Table Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Model Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Model Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:46:00 --> Model Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Controller Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:46:00 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:46:00 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:46:03 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:46:03 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:46:03 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:46:03 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:46:03 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:46:03 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:46:03 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:46:03 --> Final output sent to browser
DEBUG - 2016-09-24 22:46:03 --> Total execution time: 2.6782
DEBUG - 2016-09-24 22:46:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:46:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:46:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:46:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Router Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Utf8 Class Initialized
ERROR - 2016-09-24 22:46:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:46:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:46:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Router Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:46:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:46:03 --> UTF-8 Support Enabled
ERROR - 2016-09-24 22:46:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:46:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:46:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Router Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Router Class Initialized
ERROR - 2016-09-24 22:46:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:46:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:46:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:46:03 --> UTF-8 Support Enabled
ERROR - 2016-09-24 22:46:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:46:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:46:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:46:03 --> Router Class Initialized
DEBUG - 2016-09-24 22:46:03 --> URI Class Initialized
ERROR - 2016-09-24 22:46:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:46:03 --> Router Class Initialized
ERROR - 2016-09-24 22:46:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:47:01 --> Config Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:47:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:47:01 --> URI Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Router Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Output Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Security Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Input Class Initialized
DEBUG - 2016-09-24 22:47:01 --> XSS Filtering completed
DEBUG - 2016-09-24 22:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:47:01 --> Language Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Loader Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:47:01 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:47:01 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:47:01 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:47:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:47:01 --> Session Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:47:01 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Session routines successfully run
ERROR - 2016-09-24 22:47:01 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:47:01 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:47:01 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:47:01 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:47:01 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Table Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Model Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Model Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:47:01 --> Model Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Controller Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:47:01 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:47:01 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:47:03 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:47:03 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:47:03 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:47:03 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:47:03 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:47:03 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:47:03 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:47:03 --> Final output sent to browser
DEBUG - 2016-09-24 22:47:03 --> Total execution time: 2.5501
DEBUG - 2016-09-24 22:47:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:47:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:47:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Router Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Hooks Class Initialized
ERROR - 2016-09-24 22:47:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:47:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:47:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:47:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Router Class Initialized
ERROR - 2016-09-24 22:47:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:47:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:47:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:47:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Router Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Config Class Initialized
ERROR - 2016-09-24 22:47:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:47:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:47:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:47:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:47:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:47:03 --> Config Class Initialized
DEBUG - 2016-09-24 22:47:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Router Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Utf8 Class Initialized
ERROR - 2016-09-24 22:47:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:47:03 --> Router Class Initialized
ERROR - 2016-09-24 22:47:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:47:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:47:03 --> URI Class Initialized
DEBUG - 2016-09-24 22:47:03 --> Router Class Initialized
ERROR - 2016-09-24 22:47:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:47:18 --> Config Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:47:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:47:18 --> Config Class Initialized
DEBUG - 2016-09-24 22:47:18 --> URI Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Router Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:47:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:47:18 --> No URI present. Default controller set.
DEBUG - 2016-09-24 22:47:18 --> URI Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Output Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Router Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Security Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Output Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Input Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Security Class Initialized
DEBUG - 2016-09-24 22:47:18 --> XSS Filtering completed
DEBUG - 2016-09-24 22:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:47:18 --> Input Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Language Class Initialized
DEBUG - 2016-09-24 22:47:18 --> XSS Filtering completed
DEBUG - 2016-09-24 22:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:47:18 --> Language Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Loader Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:47:18 --> Loader Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:47:18 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:47:18 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:47:18 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:47:18 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:47:18 --> Database Driver Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:47:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-09-24 22:47:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:47:18 --> Session Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Session Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:47:18 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:47:18 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Session routines successfully run
DEBUG - 2016-09-24 22:47:18 --> Session routines successfully run
ERROR - 2016-09-24 22:47:18 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:47:18 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:47:18 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:47:18 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:47:18 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:47:18 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:47:18 --> Could not find the language line "prev_link"
ERROR - 2016-09-24 22:47:18 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:47:18 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Table Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Table Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Model Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Model Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Model Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Model Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:47:18 --> Model Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:47:18 --> Controller Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Model Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Controller Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:47:18 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:47:18 --> Language file loaded: language/arabic/site_lang.php
ERROR - 2016-09-24 22:47:18 --> 404 Page Not Found --> admin/publish
DEBUG - 2016-09-24 22:47:21 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:47:21 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:47:23 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-24 22:47:25 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:47:25 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 22:47:25 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-24 22:47:25 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-24 22:47:25 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-24 22:47:25 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 22:47:25 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 22:47:25 --> Final output sent to browser
DEBUG - 2016-09-24 22:47:25 --> Total execution time: 7.0704
DEBUG - 2016-09-24 22:47:25 --> Config Class Initialized
DEBUG - 2016-09-24 22:47:25 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:47:25 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:47:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:47:25 --> URI Class Initialized
DEBUG - 2016-09-24 22:47:25 --> Router Class Initialized
ERROR - 2016-09-24 22:47:25 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 22:47:26 --> Config Class Initialized
DEBUG - 2016-09-24 22:47:26 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:47:26 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:47:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:47:26 --> URI Class Initialized
DEBUG - 2016-09-24 22:47:26 --> Router Class Initialized
ERROR - 2016-09-24 22:47:26 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 22:48:11 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:48:11 --> URI Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Router Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Output Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Security Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Input Class Initialized
DEBUG - 2016-09-24 22:48:11 --> XSS Filtering completed
DEBUG - 2016-09-24 22:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:48:11 --> Language Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Loader Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:48:11 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:48:11 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:48:11 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:48:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:48:11 --> Session Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:48:11 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Session routines successfully run
ERROR - 2016-09-24 22:48:11 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:48:11 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:48:11 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:48:11 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:48:11 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Table Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Model Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Model Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:48:11 --> Model Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Controller Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:48:11 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:48:11 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:48:13 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:48:13 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:48:13 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:48:13 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:48:13 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:48:14 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:48:14 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:48:14 --> Final output sent to browser
DEBUG - 2016-09-24 22:48:14 --> Total execution time: 2.2310
DEBUG - 2016-09-24 22:48:14 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:48:14 --> URI Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Router Class Initialized
ERROR - 2016-09-24 22:48:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:48:14 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:48:14 --> URI Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Router Class Initialized
DEBUG - 2016-09-24 22:48:14 --> UTF-8 Support Enabled
ERROR - 2016-09-24 22:48:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:48:14 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:48:14 --> URI Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Router Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:14 --> UTF-8 Support Enabled
ERROR - 2016-09-24 22:48:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:48:14 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:14 --> URI Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Router Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Hooks Class Initialized
ERROR - 2016-09-24 22:48:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:48:14 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:48:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:48:14 --> URI Class Initialized
DEBUG - 2016-09-24 22:48:14 --> Router Class Initialized
DEBUG - 2016-09-24 22:48:14 --> URI Class Initialized
ERROR - 2016-09-24 22:48:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:48:14 --> Router Class Initialized
ERROR - 2016-09-24 22:48:14 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:48:25 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:25 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:48:25 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:48:25 --> URI Class Initialized
DEBUG - 2016-09-24 22:48:25 --> Router Class Initialized
DEBUG - 2016-09-24 22:48:25 --> No URI present. Default controller set.
DEBUG - 2016-09-24 22:48:25 --> Output Class Initialized
DEBUG - 2016-09-24 22:48:25 --> Security Class Initialized
DEBUG - 2016-09-24 22:48:25 --> Input Class Initialized
DEBUG - 2016-09-24 22:48:25 --> XSS Filtering completed
DEBUG - 2016-09-24 22:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:48:25 --> Language Class Initialized
DEBUG - 2016-09-24 22:48:25 --> Loader Class Initialized
DEBUG - 2016-09-24 22:48:25 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:48:25 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:48:25 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:48:25 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:48:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:48:25 --> Session Class Initialized
DEBUG - 2016-09-24 22:48:25 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:48:25 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:48:25 --> Session routines successfully run
ERROR - 2016-09-24 22:48:25 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:48:25 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:48:25 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:48:25 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:48:25 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:48:25 --> Table Class Initialized
DEBUG - 2016-09-24 22:48:25 --> Model Class Initialized
DEBUG - 2016-09-24 22:48:25 --> Model Class Initialized
DEBUG - 2016-09-24 22:48:25 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:48:25 --> Model Class Initialized
DEBUG - 2016-09-24 22:48:25 --> Controller Class Initialized
DEBUG - 2016-09-24 22:48:27 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:48:27 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:48:30 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-24 22:48:32 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:48:32 --> URI Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Router Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Output Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Security Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Input Class Initialized
DEBUG - 2016-09-24 22:48:32 --> XSS Filtering completed
DEBUG - 2016-09-24 22:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:48:32 --> Language Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Loader Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:48:32 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:48:32 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:48:32 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:48:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:48:32 --> Session Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:48:32 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Session routines successfully run
ERROR - 2016-09-24 22:48:32 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:48:32 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:48:32 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:48:32 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:48:32 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Table Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Model Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Model Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:48:32 --> Model Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Controller Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:48:32 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:48:32 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:48:33 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:48:33 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 22:48:33 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-24 22:48:33 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-24 22:48:33 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-24 22:48:33 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 22:48:33 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 22:48:33 --> Final output sent to browser
DEBUG - 2016-09-24 22:48:33 --> Total execution time: 7.8500
DEBUG - 2016-09-24 22:48:35 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:48:35 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 22:48:35 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 22:48:35 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 22:48:35 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 22:48:35 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 22:48:35 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 22:48:35 --> Final output sent to browser
DEBUG - 2016-09-24 22:48:35 --> Total execution time: 2.7830
DEBUG - 2016-09-24 22:48:35 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:48:35 --> URI Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Router Class Initialized
ERROR - 2016-09-24 22:48:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:48:35 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:48:35 --> URI Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Router Class Initialized
ERROR - 2016-09-24 22:48:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:48:35 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Config Class Initialized
DEBUG - 2016-09-24 22:48:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:48:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:35 --> URI Class Initialized
DEBUG - 2016-09-24 22:48:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:48:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:48:35 --> URI Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:48:35 --> URI Class Initialized
DEBUG - 2016-09-24 22:48:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:48:35 --> Router Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Router Class Initialized
DEBUG - 2016-09-24 22:48:35 --> Router Class Initialized
DEBUG - 2016-09-24 22:48:35 --> URI Class Initialized
ERROR - 2016-09-24 22:48:35 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:48:35 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:48:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:48:35 --> Router Class Initialized
ERROR - 2016-09-24 22:48:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:50:36 --> Config Class Initialized
DEBUG - 2016-09-24 22:50:36 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:50:36 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:50:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:50:36 --> URI Class Initialized
DEBUG - 2016-09-24 22:50:36 --> Router Class Initialized
DEBUG - 2016-09-24 22:50:36 --> Output Class Initialized
DEBUG - 2016-09-24 22:50:36 --> Security Class Initialized
DEBUG - 2016-09-24 22:50:36 --> Config Class Initialized
DEBUG - 2016-09-24 22:50:36 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:50:36 --> Input Class Initialized
DEBUG - 2016-09-24 22:50:36 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:50:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:50:36 --> XSS Filtering completed
DEBUG - 2016-09-24 22:50:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:50:36 --> URI Class Initialized
DEBUG - 2016-09-24 22:50:36 --> Language Class Initialized
DEBUG - 2016-09-24 22:50:36 --> Router Class Initialized
DEBUG - 2016-09-24 22:50:36 --> No URI present. Default controller set.
DEBUG - 2016-09-24 22:50:36 --> Loader Class Initialized
DEBUG - 2016-09-24 22:50:36 --> Output Class Initialized
DEBUG - 2016-09-24 22:50:36 --> Security Class Initialized
DEBUG - 2016-09-24 22:50:36 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:50:37 --> Input Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:50:37 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:50:37 --> XSS Filtering completed
DEBUG - 2016-09-24 22:50:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:50:37 --> Language Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Database Driver Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Loader Class Initialized
ERROR - 2016-09-24 22:50:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:50:37 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:50:37 --> Session Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:50:37 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:50:37 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:50:37 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:50:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:50:37 --> Session Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:50:37 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Session routines successfully run
ERROR - 2016-09-24 22:50:37 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:50:37 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:50:37 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:50:37 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:50:37 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Table Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Model Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Model Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:50:37 --> Model Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Session routines successfully run
DEBUG - 2016-09-24 22:50:37 --> Controller Class Initialized
ERROR - 2016-09-24 22:50:37 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:50:37 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:50:37 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:50:37 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:50:37 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Table Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Model Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Model Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:50:37 --> Model Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Controller Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:50:37 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:50:37 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:50:37 --> Final output sent to browser
DEBUG - 2016-09-24 22:50:37 --> Total execution time: 0.1500
DEBUG - 2016-09-24 22:50:39 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:50:39 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:50:40 --> Pagination class already loaded. Second attempt ignored.
DEBUG - 2016-09-24 22:50:43 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 22:50:43 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 22:50:43 --> File loaded: application/views/helpers/alumni_search_view.php
DEBUG - 2016-09-24 22:50:43 --> File loaded: application/views/alumni_view_files/results.php
DEBUG - 2016-09-24 22:50:43 --> File loaded: application/views/alumni_view.php
DEBUG - 2016-09-24 22:50:43 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 22:50:43 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 22:50:43 --> Final output sent to browser
DEBUG - 2016-09-24 22:50:43 --> Total execution time: 6.6440
DEBUG - 2016-09-24 22:50:43 --> Config Class Initialized
DEBUG - 2016-09-24 22:50:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:50:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:50:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:50:43 --> URI Class Initialized
DEBUG - 2016-09-24 22:50:43 --> Router Class Initialized
ERROR - 2016-09-24 22:50:43 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 22:50:48 --> Config Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:50:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:50:48 --> Config Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:50:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:50:48 --> URI Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Router Class Initialized
ERROR - 2016-09-24 22:50:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:50:48 --> Config Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Config Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:50:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:50:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:50:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:50:48 --> URI Class Initialized
DEBUG - 2016-09-24 22:50:48 --> URI Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Router Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Router Class Initialized
ERROR - 2016-09-24 22:50:48 --> 404 Page Not Found --> application
ERROR - 2016-09-24 22:50:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:50:48 --> URI Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Router Class Initialized
ERROR - 2016-09-24 22:50:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:50:48 --> Config Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Config Class Initialized
DEBUG - 2016-09-24 22:50:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:50:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:50:48 --> URI Class Initialized
DEBUG - 2016-09-24 22:50:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:50:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:50:48 --> Router Class Initialized
DEBUG - 2016-09-24 22:50:48 --> URI Class Initialized
ERROR - 2016-09-24 22:50:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:50:48 --> Router Class Initialized
ERROR - 2016-09-24 22:50:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 22:51:01 --> Config Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Hooks Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Utf8 Class Initialized
DEBUG - 2016-09-24 22:51:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 22:51:01 --> URI Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Router Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Output Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Security Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Input Class Initialized
DEBUG - 2016-09-24 22:51:01 --> XSS Filtering completed
DEBUG - 2016-09-24 22:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 22:51:01 --> Language Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Loader Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Helper loaded: url_helper
DEBUG - 2016-09-24 22:51:01 --> Helper loaded: form_helper
DEBUG - 2016-09-24 22:51:01 --> Helper loaded: func_helper
DEBUG - 2016-09-24 22:51:01 --> Database Driver Class Initialized
ERROR - 2016-09-24 22:51:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 22:51:01 --> Session Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Helper loaded: string_helper
DEBUG - 2016-09-24 22:51:01 --> Encrypt Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Session routines successfully run
ERROR - 2016-09-24 22:51:01 --> Could not find the language line "first_link"
ERROR - 2016-09-24 22:51:01 --> Could not find the language line "last_link"
ERROR - 2016-09-24 22:51:01 --> Could not find the language line "next_link"
ERROR - 2016-09-24 22:51:01 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 22:51:01 --> Pagination Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Table Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Model Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Model Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Helper loaded: file_helper
DEBUG - 2016-09-24 22:51:01 --> Model Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Controller Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Form Validation Class Initialized
DEBUG - 2016-09-24 22:51:01 --> Helper loaded: language_helper
DEBUG - 2016-09-24 22:51:01 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 22:51:01 --> Final output sent to browser
DEBUG - 2016-09-24 22:51:01 --> Total execution time: 0.1100
DEBUG - 2016-09-24 23:12:52 --> Config Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:12:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:12:52 --> URI Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Router Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Output Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Security Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Input Class Initialized
DEBUG - 2016-09-24 23:12:52 --> XSS Filtering completed
DEBUG - 2016-09-24 23:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:12:52 --> Language Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Loader Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:12:52 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:12:52 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:12:52 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:12:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:12:52 --> Session Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:12:52 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Session routines successfully run
ERROR - 2016-09-24 23:12:52 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:12:52 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:12:52 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:12:52 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:12:52 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Table Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Model Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Model Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:12:52 --> Model Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Controller Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:12:52 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:12:52 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:12:55 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:12:55 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:12:55 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:12:55 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:12:55 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:12:55 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:12:55 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:12:55 --> Final output sent to browser
DEBUG - 2016-09-24 23:12:55 --> Total execution time: 2.6210
DEBUG - 2016-09-24 23:12:55 --> Config Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:12:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:12:55 --> URI Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Config Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:12:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:12:55 --> URI Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Router Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Router Class Initialized
ERROR - 2016-09-24 23:12:55 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:12:55 --> Config Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Utf8 Class Initialized
ERROR - 2016-09-24 23:12:55 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:12:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:12:55 --> Config Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Config Class Initialized
DEBUG - 2016-09-24 23:12:55 --> URI Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Config Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:12:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:12:55 --> Router Class Initialized
DEBUG - 2016-09-24 23:12:55 --> URI Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Router Class Initialized
DEBUG - 2016-09-24 23:12:55 --> Utf8 Class Initialized
ERROR - 2016-09-24 23:12:55 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:12:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:12:55 --> Utf8 Class Initialized
ERROR - 2016-09-24 23:12:55 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:12:55 --> URI Class Initialized
DEBUG - 2016-09-24 23:12:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:12:55 --> Router Class Initialized
DEBUG - 2016-09-24 23:12:55 --> URI Class Initialized
ERROR - 2016-09-24 23:12:55 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:12:55 --> Router Class Initialized
ERROR - 2016-09-24 23:12:55 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:13:02 --> Config Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:13:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:13:02 --> URI Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Router Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Output Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Security Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Input Class Initialized
DEBUG - 2016-09-24 23:13:02 --> XSS Filtering completed
DEBUG - 2016-09-24 23:13:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:13:02 --> Language Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Loader Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:13:02 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:13:02 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:13:02 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:13:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:13:02 --> Session Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:13:02 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Session routines successfully run
ERROR - 2016-09-24 23:13:02 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:13:02 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:13:02 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:13:02 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:13:02 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Table Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:13:02 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Controller Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:13:02 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:13:02 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:13:02 --> Final output sent to browser
DEBUG - 2016-09-24 23:13:02 --> Total execution time: 0.1200
DEBUG - 2016-09-24 23:13:40 --> Config Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:13:40 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:13:40 --> URI Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Router Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Output Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Security Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Input Class Initialized
DEBUG - 2016-09-24 23:13:40 --> XSS Filtering completed
DEBUG - 2016-09-24 23:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:13:40 --> Language Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Loader Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:13:40 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:13:40 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:13:40 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:13:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:13:40 --> Session Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:13:40 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Session routines successfully run
ERROR - 2016-09-24 23:13:40 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:13:40 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:13:40 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:13:40 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:13:40 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Table Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:13:40 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Controller Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:13:40 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:13:40 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:13:40 --> Final output sent to browser
DEBUG - 2016-09-24 23:13:40 --> Total execution time: 0.0700
DEBUG - 2016-09-24 23:13:42 --> Config Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:13:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:13:42 --> URI Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Router Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Output Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Security Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Input Class Initialized
DEBUG - 2016-09-24 23:13:42 --> XSS Filtering completed
DEBUG - 2016-09-24 23:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:13:42 --> Language Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Loader Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:13:42 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:13:42 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:13:42 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:13:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:13:42 --> Session Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:13:42 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Session routines successfully run
ERROR - 2016-09-24 23:13:42 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:13:42 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:13:42 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:13:42 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:13:42 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Table Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:13:42 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Controller Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:13:42 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:13:42 --> Final output sent to browser
DEBUG - 2016-09-24 23:13:42 --> Total execution time: 0.0800
DEBUG - 2016-09-24 23:13:42 --> Config Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:13:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:13:42 --> URI Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Router Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Output Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Security Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Input Class Initialized
DEBUG - 2016-09-24 23:13:42 --> XSS Filtering completed
DEBUG - 2016-09-24 23:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:13:42 --> Language Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Loader Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:13:42 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:13:42 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:13:42 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:13:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:13:42 --> Session Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:13:42 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Session routines successfully run
ERROR - 2016-09-24 23:13:42 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:13:42 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:13:42 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:13:42 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:13:42 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Table Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:13:42 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Controller Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:13:42 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:13:42 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:13:42 --> Final output sent to browser
DEBUG - 2016-09-24 23:13:42 --> Total execution time: 0.0700
DEBUG - 2016-09-24 23:13:43 --> Config Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:13:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:13:43 --> URI Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Router Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Output Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Security Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Input Class Initialized
DEBUG - 2016-09-24 23:13:43 --> XSS Filtering completed
DEBUG - 2016-09-24 23:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:13:43 --> Language Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Loader Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:13:43 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:13:43 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:13:43 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:13:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:13:43 --> Session Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:13:43 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Session routines successfully run
ERROR - 2016-09-24 23:13:43 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:13:43 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:13:43 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:13:43 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:13:43 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Table Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:13:43 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Controller Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:13:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:13:43 --> Final output sent to browser
DEBUG - 2016-09-24 23:13:43 --> Total execution time: 0.0630
DEBUG - 2016-09-24 23:13:43 --> Config Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:13:43 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:13:43 --> URI Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Router Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Output Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Security Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Input Class Initialized
DEBUG - 2016-09-24 23:13:43 --> XSS Filtering completed
DEBUG - 2016-09-24 23:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:13:43 --> Language Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Loader Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:13:43 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:13:43 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:13:43 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:13:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:13:43 --> Session Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:13:43 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Session routines successfully run
ERROR - 2016-09-24 23:13:43 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:13:43 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:13:43 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:13:43 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:13:43 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Table Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:13:43 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Controller Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:13:43 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:13:43 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:13:43 --> Final output sent to browser
DEBUG - 2016-09-24 23:13:43 --> Total execution time: 0.0800
DEBUG - 2016-09-24 23:13:44 --> Config Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:13:44 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:13:44 --> URI Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Router Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Output Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Security Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Input Class Initialized
DEBUG - 2016-09-24 23:13:44 --> XSS Filtering completed
DEBUG - 2016-09-24 23:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:13:44 --> Language Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Loader Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:13:44 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:13:44 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:13:44 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:13:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:13:44 --> Session Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:13:44 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Session routines successfully run
ERROR - 2016-09-24 23:13:44 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:13:44 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:13:44 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:13:44 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:13:44 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Table Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:13:44 --> Model Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Controller Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:13:44 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:13:44 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:13:44 --> Final output sent to browser
DEBUG - 2016-09-24 23:13:44 --> Total execution time: 0.0700
DEBUG - 2016-09-24 23:15:05 --> Config Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:15:05 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:15:05 --> URI Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Router Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Output Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Security Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Input Class Initialized
DEBUG - 2016-09-24 23:15:05 --> XSS Filtering completed
DEBUG - 2016-09-24 23:15:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:15:05 --> Language Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Loader Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:15:05 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:15:05 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:15:05 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:15:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:15:05 --> Session Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:15:05 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Session routines successfully run
ERROR - 2016-09-24 23:15:05 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:15:05 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:15:05 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:15:05 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:15:05 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Table Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Model Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Model Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:15:05 --> Model Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Controller Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:15:05 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:15:05 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:15:08 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:15:08 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:15:08 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:15:08 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:15:08 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:15:08 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:15:08 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:15:08 --> Final output sent to browser
DEBUG - 2016-09-24 23:15:08 --> Total execution time: 2.5310
DEBUG - 2016-09-24 23:15:08 --> Config Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:15:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:15:08 --> Config Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Config Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:15:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:15:08 --> URI Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Config Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:15:08 --> URI Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Router Class Initialized
DEBUG - 2016-09-24 23:15:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:15:08 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Router Class Initialized
DEBUG - 2016-09-24 23:15:08 --> URI Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:15:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:15:08 --> URI Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Router Class Initialized
ERROR - 2016-09-24 23:15:08 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:15:08 --> Router Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Config Class Initialized
ERROR - 2016-09-24 23:15:08 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:15:08 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:15:08 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:15:08 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Config Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:15:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:15:08 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:15:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:15:08 --> URI Class Initialized
DEBUG - 2016-09-24 23:15:08 --> URI Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Router Class Initialized
DEBUG - 2016-09-24 23:15:08 --> Router Class Initialized
ERROR - 2016-09-24 23:15:08 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:15:08 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:15:15 --> Config Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:15:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:15:15 --> URI Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Router Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Output Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Security Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Input Class Initialized
DEBUG - 2016-09-24 23:15:15 --> XSS Filtering completed
DEBUG - 2016-09-24 23:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:15:15 --> Language Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Loader Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:15:15 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:15:15 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:15:15 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:15:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:15:15 --> Session Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:15:15 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Session routines successfully run
ERROR - 2016-09-24 23:15:15 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:15:15 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:15:15 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:15:15 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:15:15 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Table Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Model Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Model Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:15:15 --> Model Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Controller Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:15:15 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:15:15 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:15:15 --> Final output sent to browser
DEBUG - 2016-09-24 23:15:15 --> Total execution time: 0.1140
DEBUG - 2016-09-24 23:16:46 --> Config Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:16:46 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:16:46 --> URI Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Router Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Output Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Security Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Input Class Initialized
DEBUG - 2016-09-24 23:16:46 --> XSS Filtering completed
DEBUG - 2016-09-24 23:16:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:16:46 --> Language Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Loader Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:16:46 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:16:46 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:16:46 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:16:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:16:46 --> Session Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:16:46 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Session routines successfully run
ERROR - 2016-09-24 23:16:46 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:16:46 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:16:46 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:16:46 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:16:46 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Table Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Model Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Model Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:16:46 --> Model Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Controller Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:16:46 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:16:46 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:16:49 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:16:49 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:16:49 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:16:49 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:16:49 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:16:49 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:16:49 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:16:49 --> Final output sent to browser
DEBUG - 2016-09-24 23:16:49 --> Total execution time: 2.7470
DEBUG - 2016-09-24 23:16:49 --> Config Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:16:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:16:49 --> URI Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Router Class Initialized
ERROR - 2016-09-24 23:16:49 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:16:49 --> Config Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:16:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:16:49 --> URI Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Router Class Initialized
ERROR - 2016-09-24 23:16:49 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:16:49 --> Config Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:16:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:16:49 --> URI Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Router Class Initialized
ERROR - 2016-09-24 23:16:49 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:16:49 --> Config Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Config Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:16:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:16:49 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:16:49 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:16:49 --> URI Class Initialized
DEBUG - 2016-09-24 23:16:49 --> URI Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Router Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Config Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Router Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Hooks Class Initialized
ERROR - 2016-09-24 23:16:49 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:16:49 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:16:49 --> UTF-8 Support Enabled
ERROR - 2016-09-24 23:16:49 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:16:49 --> URI Class Initialized
DEBUG - 2016-09-24 23:16:49 --> Router Class Initialized
ERROR - 2016-09-24 23:16:49 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:16:52 --> Config Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:16:52 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:16:52 --> URI Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Router Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Output Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Security Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Input Class Initialized
DEBUG - 2016-09-24 23:16:52 --> XSS Filtering completed
DEBUG - 2016-09-24 23:16:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:16:52 --> Language Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Loader Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:16:52 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:16:52 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:16:52 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:16:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:16:52 --> Session Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:16:52 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Session routines successfully run
ERROR - 2016-09-24 23:16:52 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:16:52 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:16:52 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:16:52 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:16:52 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Table Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Model Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Model Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:16:52 --> Model Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Controller Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:16:52 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:16:52 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:16:52 --> Final output sent to browser
DEBUG - 2016-09-24 23:16:52 --> Total execution time: 0.1160
DEBUG - 2016-09-24 23:17:32 --> Config Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:17:32 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:17:32 --> URI Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Router Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Output Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Security Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Input Class Initialized
DEBUG - 2016-09-24 23:17:32 --> XSS Filtering completed
DEBUG - 2016-09-24 23:17:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:17:32 --> Language Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Loader Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:17:32 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:17:32 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:17:32 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:17:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:17:32 --> Session Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:17:32 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Session routines successfully run
ERROR - 2016-09-24 23:17:32 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:17:32 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:17:32 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:17:32 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:17:32 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Table Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Model Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Model Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:17:32 --> Model Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Controller Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:17:32 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:17:32 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:17:34 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:17:34 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:17:34 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:17:34 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:17:34 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:17:34 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:17:34 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:17:34 --> Final output sent to browser
DEBUG - 2016-09-24 23:17:34 --> Total execution time: 2.2770
DEBUG - 2016-09-24 23:17:34 --> Config Class Initialized
DEBUG - 2016-09-24 23:17:34 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:17:34 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:17:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:17:34 --> URI Class Initialized
DEBUG - 2016-09-24 23:17:34 --> Router Class Initialized
ERROR - 2016-09-24 23:17:34 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:17:34 --> Config Class Initialized
DEBUG - 2016-09-24 23:17:34 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:17:34 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:17:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:17:34 --> URI Class Initialized
DEBUG - 2016-09-24 23:17:34 --> Router Class Initialized
ERROR - 2016-09-24 23:17:34 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:17:34 --> Config Class Initialized
DEBUG - 2016-09-24 23:17:34 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:17:34 --> Config Class Initialized
DEBUG - 2016-09-24 23:17:34 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:17:34 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:17:34 --> Config Class Initialized
DEBUG - 2016-09-24 23:17:34 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:17:34 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:17:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:17:35 --> URI Class Initialized
DEBUG - 2016-09-24 23:17:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:17:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:17:35 --> Router Class Initialized
DEBUG - 2016-09-24 23:17:35 --> UTF-8 Support Enabled
ERROR - 2016-09-24 23:17:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:17:35 --> URI Class Initialized
DEBUG - 2016-09-24 23:17:35 --> URI Class Initialized
DEBUG - 2016-09-24 23:17:35 --> Router Class Initialized
DEBUG - 2016-09-24 23:17:35 --> Router Class Initialized
ERROR - 2016-09-24 23:17:35 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:17:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:17:35 --> Config Class Initialized
DEBUG - 2016-09-24 23:17:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:17:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:17:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:17:35 --> URI Class Initialized
DEBUG - 2016-09-24 23:17:35 --> Router Class Initialized
ERROR - 2016-09-24 23:17:35 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:17:36 --> Config Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:17:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:17:36 --> URI Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Router Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Output Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Security Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Input Class Initialized
DEBUG - 2016-09-24 23:17:36 --> XSS Filtering completed
DEBUG - 2016-09-24 23:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:17:36 --> Language Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Loader Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:17:36 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:17:36 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:17:36 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:17:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:17:36 --> Session Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:17:36 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Session routines successfully run
ERROR - 2016-09-24 23:17:36 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:17:36 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:17:36 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:17:36 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:17:36 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Table Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Model Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Model Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:17:36 --> Model Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Controller Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:17:36 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:17:36 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:17:36 --> Final output sent to browser
DEBUG - 2016-09-24 23:17:36 --> Total execution time: 0.1100
DEBUG - 2016-09-24 23:17:42 --> Config Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:17:42 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:17:42 --> URI Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Router Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Output Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Security Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Input Class Initialized
DEBUG - 2016-09-24 23:17:42 --> XSS Filtering completed
DEBUG - 2016-09-24 23:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:17:42 --> Language Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Loader Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:17:42 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:17:42 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:17:42 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:17:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:17:42 --> Session Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:17:42 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Session routines successfully run
ERROR - 2016-09-24 23:17:42 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:17:42 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:17:42 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:17:42 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:17:42 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Table Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Model Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Model Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:17:42 --> Model Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Controller Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:17:42 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:17:42 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:17:42 --> Final output sent to browser
DEBUG - 2016-09-24 23:17:42 --> Total execution time: 0.0800
DEBUG - 2016-09-24 23:18:03 --> Config Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:18:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:18:03 --> URI Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Router Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Output Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Security Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Input Class Initialized
DEBUG - 2016-09-24 23:18:03 --> XSS Filtering completed
DEBUG - 2016-09-24 23:18:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:18:03 --> Language Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Loader Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:18:03 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:18:03 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:18:03 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:18:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:18:03 --> Session Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:18:03 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Session routines successfully run
ERROR - 2016-09-24 23:18:03 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:18:03 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:18:03 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:18:03 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:18:03 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Table Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Model Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Model Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:18:03 --> Model Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Controller Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:18:03 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:18:03 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:18:03 --> Final output sent to browser
DEBUG - 2016-09-24 23:18:03 --> Total execution time: 0.0800
DEBUG - 2016-09-24 23:18:26 --> Config Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:18:26 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:18:26 --> URI Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Router Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Output Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Security Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Input Class Initialized
DEBUG - 2016-09-24 23:18:26 --> XSS Filtering completed
DEBUG - 2016-09-24 23:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:18:26 --> Language Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Loader Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:18:26 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:18:26 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:18:26 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:18:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:18:26 --> Session Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:18:26 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Session routines successfully run
ERROR - 2016-09-24 23:18:26 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:18:26 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:18:26 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:18:26 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:18:26 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Table Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Model Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Model Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:18:26 --> Model Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Controller Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:18:26 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:18:26 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:18:26 --> Final output sent to browser
DEBUG - 2016-09-24 23:18:26 --> Total execution time: 0.0600
DEBUG - 2016-09-24 23:25:21 --> Config Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:25:21 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:25:21 --> URI Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Router Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Output Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Security Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Input Class Initialized
DEBUG - 2016-09-24 23:25:21 --> XSS Filtering completed
DEBUG - 2016-09-24 23:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:25:21 --> Language Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Loader Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:25:21 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:25:21 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:25:21 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:25:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:25:21 --> Session Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:25:21 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Session routines successfully run
ERROR - 2016-09-24 23:25:21 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:25:21 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:25:21 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:25:21 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:25:21 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Table Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Model Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Model Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:25:21 --> Model Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Controller Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:25:21 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:25:21 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:25:23 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:25:23 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:25:23 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:26:16 --> Config Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:26:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:26:16 --> URI Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Router Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Output Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Security Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Input Class Initialized
DEBUG - 2016-09-24 23:26:16 --> XSS Filtering completed
DEBUG - 2016-09-24 23:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:26:16 --> Language Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Loader Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:26:16 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:26:16 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:26:16 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:26:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:26:16 --> Session Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:26:16 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Session routines successfully run
ERROR - 2016-09-24 23:26:16 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:26:16 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:26:16 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:26:16 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:26:16 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Table Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Model Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Model Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:26:16 --> Model Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Controller Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:26:16 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:26:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:26:18 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:26:18 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:26:18 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:26:18 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:26:18 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:26:18 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:26:18 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:26:18 --> Final output sent to browser
DEBUG - 2016-09-24 23:26:18 --> Total execution time: 2.4391
DEBUG - 2016-09-24 23:26:18 --> Config Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:26:18 --> URI Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Router Class Initialized
ERROR - 2016-09-24 23:26:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:26:18 --> Config Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Config Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:26:18 --> URI Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:26:18 --> Router Class Initialized
DEBUG - 2016-09-24 23:26:18 --> URI Class Initialized
ERROR - 2016-09-24 23:26:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:26:18 --> Router Class Initialized
ERROR - 2016-09-24 23:26:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:26:18 --> Config Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:26:18 --> URI Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Router Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Config Class Initialized
ERROR - 2016-09-24 23:26:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:26:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:26:18 --> URI Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Router Class Initialized
ERROR - 2016-09-24 23:26:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:26:18 --> Config Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:26:18 --> URI Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Router Class Initialized
ERROR - 2016-09-24 23:26:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:26:18 --> Config Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:26:18 --> URI Class Initialized
DEBUG - 2016-09-24 23:26:18 --> Router Class Initialized
ERROR - 2016-09-24 23:26:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:39:15 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:39:15 --> URI Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Router Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Output Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Security Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Input Class Initialized
DEBUG - 2016-09-24 23:39:15 --> XSS Filtering completed
DEBUG - 2016-09-24 23:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:39:15 --> Language Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Loader Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:39:15 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:39:15 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:39:15 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:39:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:39:15 --> Session Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:39:15 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Session routines successfully run
ERROR - 2016-09-24 23:39:15 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:39:15 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:39:15 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:39:15 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:39:15 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Table Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Model Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Model Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:39:15 --> Model Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Controller Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:39:15 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:39:15 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:39:17 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:39:17 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:39:17 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:39:17 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:39:17 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:39:17 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:39:17 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:39:17 --> Final output sent to browser
DEBUG - 2016-09-24 23:39:17 --> Total execution time: 2.6070
DEBUG - 2016-09-24 23:39:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:39:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Router Class Initialized
ERROR - 2016-09-24 23:39:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:39:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:39:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:39:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:39:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Router Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Router Class Initialized
ERROR - 2016-09-24 23:39:17 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:39:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:39:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:39:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Router Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Hooks Class Initialized
ERROR - 2016-09-24 23:39:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:39:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:39:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Router Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:17 --> UTF-8 Support Enabled
ERROR - 2016-09-24 23:39:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:39:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:39:17 --> Router Class Initialized
ERROR - 2016-09-24 23:39:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:39:22 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:22 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:39:22 --> URI Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Router Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Output Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Security Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Input Class Initialized
DEBUG - 2016-09-24 23:39:22 --> XSS Filtering completed
DEBUG - 2016-09-24 23:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:39:22 --> Language Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Loader Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:39:22 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:39:22 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:39:22 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:39:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:39:22 --> Session Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:39:22 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Session routines successfully run
ERROR - 2016-09-24 23:39:22 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:39:22 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:39:22 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:39:22 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:39:22 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Table Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Model Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Model Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:39:22 --> Model Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Controller Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:39:22 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:39:22 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:39:24 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:39:24 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:39:24 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:39:24 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:39:24 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:39:24 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:39:24 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:39:24 --> Final output sent to browser
DEBUG - 2016-09-24 23:39:24 --> Total execution time: 2.2280
DEBUG - 2016-09-24 23:39:24 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:39:24 --> URI Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Router Class Initialized
ERROR - 2016-09-24 23:39:24 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:39:24 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:39:24 --> URI Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Router Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:39:24 --> URI Class Initialized
ERROR - 2016-09-24 23:39:24 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:39:24 --> Router Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Hooks Class Initialized
ERROR - 2016-09-24 23:39:24 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:39:24 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:39:24 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:24 --> URI Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:39:24 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:39:24 --> Router Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:24 --> UTF-8 Support Enabled
ERROR - 2016-09-24 23:39:24 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:39:24 --> URI Class Initialized
DEBUG - 2016-09-24 23:39:24 --> URI Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Router Class Initialized
DEBUG - 2016-09-24 23:39:24 --> Router Class Initialized
ERROR - 2016-09-24 23:39:24 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:39:24 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:39:25 --> Config Class Initialized
DEBUG - 2016-09-24 23:39:25 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:39:25 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:39:25 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:39:25 --> URI Class Initialized
DEBUG - 2016-09-24 23:39:25 --> Router Class Initialized
ERROR - 2016-09-24 23:39:25 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:40:55 --> Config Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:40:55 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:40:55 --> URI Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Router Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Output Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Security Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Input Class Initialized
DEBUG - 2016-09-24 23:40:55 --> XSS Filtering completed
DEBUG - 2016-09-24 23:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:40:55 --> Language Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Loader Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:40:55 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:40:55 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:40:55 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:40:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:40:55 --> Session Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:40:55 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Session routines successfully run
ERROR - 2016-09-24 23:40:55 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:40:55 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:40:55 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:40:55 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:40:55 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Table Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Model Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Model Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:40:55 --> Model Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Controller Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:40:55 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:40:55 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:40:58 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:40:58 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:40:58 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:40:58 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:40:58 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:40:58 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:40:58 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:40:58 --> Final output sent to browser
DEBUG - 2016-09-24 23:40:58 --> Total execution time: 2.2891
DEBUG - 2016-09-24 23:40:58 --> Config Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:40:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:40:58 --> URI Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Config Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Config Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Router Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Hooks Class Initialized
ERROR - 2016-09-24 23:40:58 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:40:58 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:40:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:40:58 --> URI Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Router Class Initialized
DEBUG - 2016-09-24 23:40:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:40:58 --> Config Class Initialized
ERROR - 2016-09-24 23:40:58 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:40:58 --> URI Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Router Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:40:58 --> UTF-8 Support Enabled
ERROR - 2016-09-24 23:40:58 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:40:58 --> URI Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Router Class Initialized
ERROR - 2016-09-24 23:40:58 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:40:58 --> Config Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Config Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:40:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:40:58 --> URI Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Router Class Initialized
DEBUG - 2016-09-24 23:40:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:40:58 --> URI Class Initialized
ERROR - 2016-09-24 23:40:58 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:40:58 --> Router Class Initialized
ERROR - 2016-09-24 23:40:58 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:40:58 --> Config Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:40:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:40:58 --> URI Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Router Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Config Class Initialized
ERROR - 2016-09-24 23:40:58 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:40:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:40:58 --> URI Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Router Class Initialized
ERROR - 2016-09-24 23:40:58 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:40:58 --> Config Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:40:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:40:58 --> URI Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Router Class Initialized
ERROR - 2016-09-24 23:40:58 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:40:58 --> Config Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:40:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:40:58 --> URI Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Router Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Config Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Config Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:40:58 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:40:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:40:58 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:40:58 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:40:58 --> URI Class Initialized
ERROR - 2016-09-24 23:40:58 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:40:58 --> Router Class Initialized
DEBUG - 2016-09-24 23:40:58 --> URI Class Initialized
ERROR - 2016-09-24 23:40:58 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:40:58 --> Router Class Initialized
ERROR - 2016-09-24 23:40:58 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:41:08 --> Config Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:41:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:41:08 --> URI Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Router Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Output Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Security Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Input Class Initialized
DEBUG - 2016-09-24 23:41:08 --> XSS Filtering completed
DEBUG - 2016-09-24 23:41:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:41:08 --> Language Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Loader Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:41:08 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:41:08 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:41:08 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:41:08 --> Session Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:41:08 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Session routines successfully run
ERROR - 2016-09-24 23:41:08 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:41:08 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:41:08 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:41:08 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:41:08 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Table Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Model Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Model Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:41:08 --> Model Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Controller Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:41:08 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:41:08 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:41:08 --> Final output sent to browser
DEBUG - 2016-09-24 23:41:08 --> Total execution time: 0.1300
DEBUG - 2016-09-24 23:41:48 --> Config Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:41:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:41:48 --> URI Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Router Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Output Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Security Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Input Class Initialized
DEBUG - 2016-09-24 23:41:48 --> XSS Filtering completed
DEBUG - 2016-09-24 23:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:41:48 --> Language Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Loader Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:41:48 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:41:48 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:41:48 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:41:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:41:48 --> Session Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:41:48 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Session routines successfully run
ERROR - 2016-09-24 23:41:48 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:41:48 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:41:48 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:41:48 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:41:48 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Table Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Model Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Model Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:41:48 --> Model Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Controller Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:41:48 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:41:48 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:41:48 --> Final output sent to browser
DEBUG - 2016-09-24 23:41:48 --> Total execution time: 0.0700
DEBUG - 2016-09-24 23:42:12 --> Config Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:42:12 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:42:12 --> URI Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Router Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Output Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Security Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Input Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:42:12 --> Language Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Loader Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:42:12 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:42:12 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:42:12 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:42:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:42:12 --> Session Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:42:12 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:42:12 --> A session cookie was not found.
DEBUG - 2016-09-24 23:42:12 --> Session routines successfully run
ERROR - 2016-09-24 23:42:12 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:42:12 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:42:12 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:42:12 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:42:12 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Table Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Model Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Model Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:42:12 --> Model Class Initialized
DEBUG - 2016-09-24 23:42:12 --> Controller Class Initialized
DEBUG - 2016-09-24 23:42:14 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:42:14 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:42:14 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:42:14 --> File loaded: application/views/includes/header.php
DEBUG - 2016-09-24 23:42:14 --> File loaded: application/views/not_found.php
DEBUG - 2016-09-24 23:42:14 --> File loaded: application/views/includes/footer.php
DEBUG - 2016-09-24 23:42:14 --> File loaded: application/views/includes/template.php
DEBUG - 2016-09-24 23:42:14 --> Final output sent to browser
DEBUG - 2016-09-24 23:42:14 --> Total execution time: 2.1921
DEBUG - 2016-09-24 23:42:14 --> Config Class Initialized
DEBUG - 2016-09-24 23:42:14 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:42:14 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:42:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:42:14 --> URI Class Initialized
DEBUG - 2016-09-24 23:42:14 --> Router Class Initialized
ERROR - 2016-09-24 23:42:14 --> 404 Page Not Found --> js
DEBUG - 2016-09-24 23:49:08 --> Config Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:49:08 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:49:08 --> URI Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Router Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Output Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Security Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Input Class Initialized
DEBUG - 2016-09-24 23:49:08 --> XSS Filtering completed
DEBUG - 2016-09-24 23:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:49:08 --> Language Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Loader Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:49:08 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:49:08 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:49:08 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:49:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:49:08 --> Session Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:49:08 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Session routines successfully run
ERROR - 2016-09-24 23:49:08 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:49:08 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:49:08 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:49:08 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:49:08 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Table Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Model Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Model Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:49:08 --> Model Class Initialized
DEBUG - 2016-09-24 23:49:08 --> Controller Class Initialized
DEBUG - 2016-09-24 23:49:09 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:49:09 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:49:09 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:49:11 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:49:11 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:49:11 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:49:11 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:49:11 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:49:11 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:49:11 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:49:11 --> Final output sent to browser
DEBUG - 2016-09-24 23:49:11 --> Total execution time: 2.4221
DEBUG - 2016-09-24 23:49:11 --> Config Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Config Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:49:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:49:11 --> URI Class Initialized
DEBUG - 2016-09-24 23:49:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:49:11 --> Router Class Initialized
DEBUG - 2016-09-24 23:49:11 --> URI Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Router Class Initialized
ERROR - 2016-09-24 23:49:11 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:49:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:49:11 --> Config Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Config Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Config Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Config Class Initialized
DEBUG - 2016-09-24 23:49:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:49:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:49:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:49:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:49:11 --> URI Class Initialized
DEBUG - 2016-09-24 23:49:11 --> URI Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Router Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Router Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:49:11 --> UTF-8 Support Enabled
ERROR - 2016-09-24 23:49:11 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:49:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:49:11 --> URI Class Initialized
DEBUG - 2016-09-24 23:49:11 --> URI Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Router Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Router Class Initialized
ERROR - 2016-09-24 23:49:11 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:49:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:49:11 --> Config Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Config Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:49:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:49:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:49:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:49:11 --> URI Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Router Class Initialized
ERROR - 2016-09-24 23:49:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:49:11 --> URI Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Router Class Initialized
ERROR - 2016-09-24 23:49:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:49:11 --> Config Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Config Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:49:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:49:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:49:11 --> URI Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Router Class Initialized
DEBUG - 2016-09-24 23:49:11 --> URI Class Initialized
ERROR - 2016-09-24 23:49:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:49:11 --> Router Class Initialized
ERROR - 2016-09-24 23:49:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:49:11 --> Config Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Config Class Initialized
DEBUG - 2016-09-24 23:49:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:49:11 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:49:11 --> URI Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:49:11 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:49:11 --> Router Class Initialized
DEBUG - 2016-09-24 23:49:11 --> URI Class Initialized
DEBUG - 2016-09-24 23:49:11 --> Router Class Initialized
ERROR - 2016-09-24 23:49:11 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:49:11 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:50:09 --> Config Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:50:09 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:50:09 --> URI Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Router Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Output Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Security Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Input Class Initialized
DEBUG - 2016-09-24 23:50:09 --> XSS Filtering completed
DEBUG - 2016-09-24 23:50:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:50:09 --> Language Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Loader Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:50:09 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:50:09 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:50:09 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:50:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:50:09 --> Session Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:50:09 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Session routines successfully run
ERROR - 2016-09-24 23:50:09 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:50:09 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:50:09 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:50:09 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:50:09 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Table Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Model Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Model Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:50:09 --> Model Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Controller Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:50:09 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:50:09 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:50:09 --> Final output sent to browser
DEBUG - 2016-09-24 23:50:09 --> Total execution time: 0.1440
DEBUG - 2016-09-24 23:52:00 --> Config Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:52:00 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:52:00 --> URI Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Router Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Output Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Security Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Input Class Initialized
DEBUG - 2016-09-24 23:52:00 --> XSS Filtering completed
DEBUG - 2016-09-24 23:52:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:52:00 --> Language Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Loader Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:52:00 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:52:00 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:52:00 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:52:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:52:00 --> Session Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:52:00 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Session routines successfully run
ERROR - 2016-09-24 23:52:00 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:52:00 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:52:00 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:52:00 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:52:00 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Table Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Model Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Model Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:52:00 --> Model Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Controller Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:52:00 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:52:00 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:52:02 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:52:02 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:52:02 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:52:02 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:52:02 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:52:02 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:52:02 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:52:02 --> Final output sent to browser
DEBUG - 2016-09-24 23:52:02 --> Total execution time: 2.2851
DEBUG - 2016-09-24 23:52:02 --> Config Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:52:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:52:02 --> URI Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Router Class Initialized
ERROR - 2016-09-24 23:52:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:52:02 --> Config Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Config Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:52:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:52:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:52:02 --> URI Class Initialized
DEBUG - 2016-09-24 23:52:02 --> URI Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Router Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Router Class Initialized
ERROR - 2016-09-24 23:52:02 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:52:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:52:02 --> Config Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:52:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:52:02 --> URI Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Config Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Router Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Utf8 Class Initialized
ERROR - 2016-09-24 23:52:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:52:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:52:02 --> URI Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Router Class Initialized
ERROR - 2016-09-24 23:52:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:52:02 --> Config Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:52:02 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:52:02 --> URI Class Initialized
DEBUG - 2016-09-24 23:52:02 --> Router Class Initialized
ERROR - 2016-09-24 23:52:02 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:52:03 --> Config Class Initialized
DEBUG - 2016-09-24 23:52:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:52:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:52:03 --> Config Class Initialized
DEBUG - 2016-09-24 23:52:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:52:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:52:03 --> URI Class Initialized
DEBUG - 2016-09-24 23:52:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:52:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:52:03 --> Router Class Initialized
DEBUG - 2016-09-24 23:52:03 --> URI Class Initialized
ERROR - 2016-09-24 23:52:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:52:03 --> Router Class Initialized
DEBUG - 2016-09-24 23:52:03 --> Config Class Initialized
DEBUG - 2016-09-24 23:52:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:52:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:52:03 --> UTF-8 Support Enabled
ERROR - 2016-09-24 23:52:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:52:03 --> URI Class Initialized
DEBUG - 2016-09-24 23:52:03 --> Router Class Initialized
ERROR - 2016-09-24 23:52:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:52:03 --> Config Class Initialized
DEBUG - 2016-09-24 23:52:03 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:52:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:52:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:52:03 --> URI Class Initialized
DEBUG - 2016-09-24 23:52:03 --> Router Class Initialized
DEBUG - 2016-09-24 23:52:03 --> Config Class Initialized
DEBUG - 2016-09-24 23:52:03 --> Hooks Class Initialized
ERROR - 2016-09-24 23:52:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:52:03 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:52:03 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:52:03 --> URI Class Initialized
DEBUG - 2016-09-24 23:52:03 --> Router Class Initialized
ERROR - 2016-09-24 23:52:03 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:52:07 --> Config Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:52:07 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:52:07 --> URI Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Router Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Output Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Security Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Input Class Initialized
DEBUG - 2016-09-24 23:52:07 --> XSS Filtering completed
DEBUG - 2016-09-24 23:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:52:07 --> Language Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Loader Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:52:07 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:52:07 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:52:07 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:52:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:52:07 --> Session Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:52:07 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Session routines successfully run
ERROR - 2016-09-24 23:52:07 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:52:07 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:52:07 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:52:07 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:52:07 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Table Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Model Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Model Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:52:07 --> Model Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Controller Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:52:07 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:52:07 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:52:07 --> Final output sent to browser
DEBUG - 2016-09-24 23:52:07 --> Total execution time: 0.0880
DEBUG - 2016-09-24 23:53:35 --> Config Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:53:35 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:53:35 --> URI Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Router Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Output Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Security Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Input Class Initialized
DEBUG - 2016-09-24 23:53:35 --> XSS Filtering completed
DEBUG - 2016-09-24 23:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:53:35 --> Language Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Loader Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:53:35 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:53:35 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:53:35 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:53:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:53:35 --> Session Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:53:35 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Session routines successfully run
ERROR - 2016-09-24 23:53:35 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:53:35 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:53:35 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:53:35 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:53:35 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Table Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Model Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Model Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:53:35 --> Model Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Controller Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:53:35 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:53:35 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:53:38 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:53:38 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:53:38 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:53:38 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:53:38 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:53:38 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:53:38 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:53:38 --> Final output sent to browser
DEBUG - 2016-09-24 23:53:38 --> Total execution time: 2.4031
DEBUG - 2016-09-24 23:53:38 --> Config Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:53:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:53:38 --> URI Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Router Class Initialized
ERROR - 2016-09-24 23:53:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:53:38 --> Config Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:53:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:53:38 --> URI Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Router Class Initialized
ERROR - 2016-09-24 23:53:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:53:38 --> Config Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Config Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:53:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:53:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:53:38 --> URI Class Initialized
DEBUG - 2016-09-24 23:53:38 --> URI Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Config Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Router Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Router Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Utf8 Class Initialized
ERROR - 2016-09-24 23:53:38 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:53:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:53:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:53:38 --> URI Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Router Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Config Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Hooks Class Initialized
ERROR - 2016-09-24 23:53:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:53:38 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:53:38 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:53:38 --> URI Class Initialized
DEBUG - 2016-09-24 23:53:38 --> Router Class Initialized
ERROR - 2016-09-24 23:53:38 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:53:45 --> Config Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:53:45 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:53:45 --> URI Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Router Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Output Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Security Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Input Class Initialized
DEBUG - 2016-09-24 23:53:45 --> XSS Filtering completed
DEBUG - 2016-09-24 23:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:53:45 --> Language Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Loader Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:53:45 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:53:45 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:53:45 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:53:45 --> Session Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:53:45 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Session routines successfully run
ERROR - 2016-09-24 23:53:45 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:53:45 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:53:45 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:53:45 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:53:45 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Table Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Model Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Model Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:53:45 --> Model Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Controller Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:53:45 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:53:45 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:53:48 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:53:48 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:53:48 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:53:48 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:53:48 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:53:48 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:53:48 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:53:48 --> Final output sent to browser
DEBUG - 2016-09-24 23:53:48 --> Total execution time: 2.3871
DEBUG - 2016-09-24 23:53:48 --> Config Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:53:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:53:48 --> URI Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Router Class Initialized
ERROR - 2016-09-24 23:53:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:53:48 --> Config Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Config Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Config Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:53:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:53:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:53:48 --> URI Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:53:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:53:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:53:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:53:48 --> URI Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Router Class Initialized
DEBUG - 2016-09-24 23:53:48 --> URI Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Router Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Config Class Initialized
ERROR - 2016-09-24 23:53:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:53:48 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Config Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Hooks Class Initialized
ERROR - 2016-09-24 23:53:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:53:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:53:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:53:48 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:53:48 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:53:48 --> URI Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Router Class Initialized
DEBUG - 2016-09-24 23:53:48 --> URI Class Initialized
DEBUG - 2016-09-24 23:53:48 --> Router Class Initialized
ERROR - 2016-09-24 23:53:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:53:48 --> Router Class Initialized
ERROR - 2016-09-24 23:53:48 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:53:48 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:54:01 --> Config Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:54:01 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:54:01 --> URI Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Router Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Output Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Security Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Input Class Initialized
DEBUG - 2016-09-24 23:54:01 --> XSS Filtering completed
DEBUG - 2016-09-24 23:54:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:54:01 --> Language Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Loader Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:54:01 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:54:01 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:54:01 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:54:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:54:01 --> Session Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:54:01 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Session routines successfully run
ERROR - 2016-09-24 23:54:01 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:54:01 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:54:01 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:54:01 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:54:01 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Table Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Model Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Model Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:54:01 --> Model Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Controller Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:54:01 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:54:01 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:54:01 --> Final output sent to browser
DEBUG - 2016-09-24 23:54:01 --> Total execution time: 0.1250
DEBUG - 2016-09-24 23:54:36 --> Config Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:54:36 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:54:36 --> URI Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Router Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Output Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Security Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Input Class Initialized
DEBUG - 2016-09-24 23:54:36 --> XSS Filtering completed
DEBUG - 2016-09-24 23:54:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:54:36 --> Language Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Loader Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:54:36 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:54:36 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:54:36 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:54:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:54:36 --> Session Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:54:36 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Session routines successfully run
ERROR - 2016-09-24 23:54:36 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:54:36 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:54:36 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:54:36 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:54:36 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Table Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Model Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Model Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:54:36 --> Model Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Controller Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:54:36 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:54:36 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:54:39 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:54:39 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:54:39 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:54:39 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:54:39 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:54:39 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:54:39 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:54:39 --> Final output sent to browser
DEBUG - 2016-09-24 23:54:39 --> Total execution time: 2.4411
DEBUG - 2016-09-24 23:54:39 --> Config Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Config Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:54:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:54:39 --> Config Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:54:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:54:39 --> URI Class Initialized
DEBUG - 2016-09-24 23:54:39 --> URI Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Router Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Config Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Router Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:54:39 --> UTF-8 Support Enabled
ERROR - 2016-09-24 23:54:39 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:54:39 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:54:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:54:39 --> URI Class Initialized
ERROR - 2016-09-24 23:54:39 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:54:39 --> URI Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Router Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Router Class Initialized
ERROR - 2016-09-24 23:54:39 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:54:39 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:54:39 --> Config Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Config Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:54:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:54:39 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:54:39 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:54:39 --> URI Class Initialized
DEBUG - 2016-09-24 23:54:39 --> URI Class Initialized
DEBUG - 2016-09-24 23:54:39 --> Router Class Initialized
ERROR - 2016-09-24 23:54:39 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:54:39 --> Router Class Initialized
ERROR - 2016-09-24 23:54:39 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:56:14 --> Config Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:56:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:56:14 --> URI Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Router Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Output Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Security Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Input Class Initialized
DEBUG - 2016-09-24 23:56:14 --> XSS Filtering completed
DEBUG - 2016-09-24 23:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:56:14 --> Language Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Loader Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Config Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:56:14 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:56:14 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:56:14 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:56:14 --> URI Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:56:14 --> Router Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Output Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:56:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:56:14 --> Security Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Input Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Session Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:56:14 --> XSS Filtering completed
DEBUG - 2016-09-24 23:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:56:14 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Language Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Loader Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:56:14 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:56:14 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:56:14 --> Session routines successfully run
ERROR - 2016-09-24 23:56:14 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:56:14 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:56:14 --> Could not find the language line "next_link"
DEBUG - 2016-09-24 23:56:14 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:56:14 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:56:14 --> Pagination Class Initialized
ERROR - 2016-09-24 23:56:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:56:14 --> Table Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Model Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Session Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Model Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:56:14 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:56:14 --> Model Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Controller Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Session routines successfully run
ERROR - 2016-09-24 23:56:14 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:56:14 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:56:14 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:56:14 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:56:14 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Table Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Model Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Model Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:56:14 --> Model Class Initialized
DEBUG - 2016-09-24 23:56:14 --> Controller Class Initialized
DEBUG - 2016-09-24 23:56:15 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:56:15 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:56:15 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:56:15 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:56:15 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:56:15 --> Final output sent to browser
DEBUG - 2016-09-24 23:56:15 --> Total execution time: 0.1070
DEBUG - 2016-09-24 23:56:17 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:56:17 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:56:17 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:56:17 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:56:17 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:56:17 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:56:17 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:56:17 --> Final output sent to browser
DEBUG - 2016-09-24 23:56:17 --> Total execution time: 2.3991
DEBUG - 2016-09-24 23:56:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:56:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:56:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Router Class Initialized
ERROR - 2016-09-24 23:56:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:56:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:56:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:56:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Router Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:56:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:56:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:56:17 --> UTF-8 Support Enabled
ERROR - 2016-09-24 23:56:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:56:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:56:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:56:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:56:17 --> Router Class Initialized
DEBUG - 2016-09-24 23:56:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:56:17 --> Router Class Initialized
DEBUG - 2016-09-24 23:56:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:56:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Router Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Router Class Initialized
ERROR - 2016-09-24 23:56:17 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:56:17 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:56:17 --> 404 Page Not Found --> application
ERROR - 2016-09-24 23:56:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:56:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:56:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:56:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Router Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Hooks Class Initialized
ERROR - 2016-09-24 23:56:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:56:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:56:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:56:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Router Class Initialized
ERROR - 2016-09-24 23:56:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:56:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:56:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:56:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Router Class Initialized
ERROR - 2016-09-24 23:56:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:56:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:56:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:56:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:56:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Router Class Initialized
DEBUG - 2016-09-24 23:56:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:56:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:56:17 --> URI Class Initialized
ERROR - 2016-09-24 23:56:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:56:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Router Class Initialized
DEBUG - 2016-09-24 23:56:17 --> UTF-8 Support Enabled
ERROR - 2016-09-24 23:56:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:56:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:56:17 --> Router Class Initialized
ERROR - 2016-09-24 23:56:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:57:16 --> Config Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:57:16 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:57:16 --> URI Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Router Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Output Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Security Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Input Class Initialized
DEBUG - 2016-09-24 23:57:16 --> XSS Filtering completed
DEBUG - 2016-09-24 23:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:57:16 --> Language Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Loader Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:57:16 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:57:16 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:57:16 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:57:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:57:16 --> Session Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:57:16 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Session routines successfully run
ERROR - 2016-09-24 23:57:16 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:57:16 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:57:16 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:57:16 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:57:16 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Table Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Model Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Model Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:57:16 --> Model Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Controller Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:57:16 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:57:16 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:57:16 --> Final output sent to browser
DEBUG - 2016-09-24 23:57:16 --> Total execution time: 0.1160
DEBUG - 2016-09-24 23:59:15 --> Config Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:59:15 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:59:15 --> URI Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Router Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Output Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Security Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Input Class Initialized
DEBUG - 2016-09-24 23:59:15 --> XSS Filtering completed
DEBUG - 2016-09-24 23:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-09-24 23:59:15 --> Language Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Loader Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Helper loaded: url_helper
DEBUG - 2016-09-24 23:59:15 --> Helper loaded: form_helper
DEBUG - 2016-09-24 23:59:15 --> Helper loaded: func_helper
DEBUG - 2016-09-24 23:59:15 --> Database Driver Class Initialized
ERROR - 2016-09-24 23:59:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\www\alumni\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2016-09-24 23:59:15 --> Session Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Helper loaded: string_helper
DEBUG - 2016-09-24 23:59:15 --> Encrypt Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Session routines successfully run
ERROR - 2016-09-24 23:59:15 --> Could not find the language line "first_link"
ERROR - 2016-09-24 23:59:15 --> Could not find the language line "last_link"
ERROR - 2016-09-24 23:59:15 --> Could not find the language line "next_link"
ERROR - 2016-09-24 23:59:15 --> Could not find the language line "prev_link"
DEBUG - 2016-09-24 23:59:15 --> Pagination Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Table Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Model Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Model Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Helper loaded: file_helper
DEBUG - 2016-09-24 23:59:15 --> Model Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Controller Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Form Validation Class Initialized
DEBUG - 2016-09-24 23:59:15 --> Helper loaded: language_helper
DEBUG - 2016-09-24 23:59:15 --> Language file loaded: language/arabic/site_lang.php
DEBUG - 2016-09-24 23:59:17 --> File loaded: application/views/includes/languages.php
DEBUG - 2016-09-24 23:59:17 --> File loaded: application/views/includes/admin/menu.php
DEBUG - 2016-09-24 23:59:17 --> File loaded: application/views/includes/admin/header.php
DEBUG - 2016-09-24 23:59:17 --> File loaded: application/views/admin/admin_toolbar.php
DEBUG - 2016-09-24 23:59:17 --> File loaded: application/views/admin_view.php
DEBUG - 2016-09-24 23:59:17 --> File loaded: application/views/includes/admin/footer.php
DEBUG - 2016-09-24 23:59:17 --> File loaded: application/views/includes/admin/template.php
DEBUG - 2016-09-24 23:59:17 --> Final output sent to browser
DEBUG - 2016-09-24 23:59:17 --> Total execution time: 2.5311
DEBUG - 2016-09-24 23:59:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:59:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:59:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Router Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:59:17 --> UTF-8 Support Enabled
ERROR - 2016-09-24 23:59:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:59:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Router Class Initialized
ERROR - 2016-09-24 23:59:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:59:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:59:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:59:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Router Class Initialized
ERROR - 2016-09-24 23:59:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:59:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:59:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:59:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Router Class Initialized
ERROR - 2016-09-24 23:59:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:59:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:59:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:59:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Router Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:59:17 --> UTF-8 Support Enabled
ERROR - 2016-09-24 23:59:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:59:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Router Class Initialized
ERROR - 2016-09-24 23:59:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:59:17 --> Config Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:59:17 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:59:17 --> URI Class Initialized
DEBUG - 2016-09-24 23:59:17 --> Router Class Initialized
ERROR - 2016-09-24 23:59:17 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:59:18 --> Config Class Initialized
DEBUG - 2016-09-24 23:59:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:59:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:59:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:59:18 --> URI Class Initialized
DEBUG - 2016-09-24 23:59:18 --> Config Class Initialized
DEBUG - 2016-09-24 23:59:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:59:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:59:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:59:18 --> URI Class Initialized
DEBUG - 2016-09-24 23:59:18 --> Router Class Initialized
ERROR - 2016-09-24 23:59:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:59:18 --> Router Class Initialized
ERROR - 2016-09-24 23:59:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:59:18 --> Config Class Initialized
DEBUG - 2016-09-24 23:59:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:59:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:59:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:59:18 --> URI Class Initialized
DEBUG - 2016-09-24 23:59:18 --> Router Class Initialized
DEBUG - 2016-09-24 23:59:18 --> Config Class Initialized
ERROR - 2016-09-24 23:59:18 --> 404 Page Not Found --> application
DEBUG - 2016-09-24 23:59:18 --> Hooks Class Initialized
DEBUG - 2016-09-24 23:59:18 --> Utf8 Class Initialized
DEBUG - 2016-09-24 23:59:18 --> UTF-8 Support Enabled
DEBUG - 2016-09-24 23:59:18 --> URI Class Initialized
DEBUG - 2016-09-24 23:59:18 --> Router Class Initialized
ERROR - 2016-09-24 23:59:18 --> 404 Page Not Found --> application
